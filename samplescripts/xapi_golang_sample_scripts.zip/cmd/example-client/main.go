package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"go-xapi/internal/common"
	"go-xapi/internal/examples/marketdata"
	"go-xapi/internal/examples/order"
	"go-xapi/internal/examples/utility"
)

func main() {
	// Define a command-line flag to specify the APIs to run (comma-separated)
	apiFlag := flag.String("api", "", "Specify the APIs to run, comma-separated (e.g., GetTodaysActivity,SubscribeLevel1Ticks,SubmitSingleOrder)")
	flag.Parse()

	var lib *common.EMSXAPILibrary

	// Initialize logger
	logger, err := common.NewLogger("application-log.log")
	if err != nil {
		log.Fatalf("Failed to initialize logger: %v", err)
	}
	defer func() {
		if lib != nil {
			lib.SuspendHeartbeatThread()
			logger.LogMessage("Going to disconnect")
			lib.Logout(context.Background())
			logger.LogMessage("Going to close Channel")
			lib.CloseChannel()
		}
		fmt.Println("Press any key to exit...")
		fmt.Scanln()
	}()

	logger.LogMessage("Sample xAPI Go Client Application:\n\n")

	// Create EMSXAPILibrary instance
	common.Create(filepath.Join("config", "config.ini"))
	templib := common.Get()

	lib = templib
	if lib == nil {
		logger.LogMessage("Failed to initialize EMSXAPILibrary")
		return
	}

	// Perform login
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	logger.LogMessage("Logging in...")
	err = lib.Login(ctx)
	if err != nil {
		logger.LogMessage(fmt.Sprintf("Login failed: %v", err))
		return
	}

	if lib.GetUserToken() == "" {
		logger.LogMessage("Login Failed....")
		lib = nil
		return
	}

	logger.LogMessage(fmt.Sprintf("User token fetched: %s", lib.GetUserToken()))

	// Support running multiple APIs by splitting the flag
	apiList := []string{}
	if *apiFlag != "" {
		for _, api := range strings.Split(*apiFlag, ",") {
			trimmed := strings.TrimSpace(api)
			if trimmed != "" {
				apiList = append(apiList, trimmed)
			}
		}
	}

	if len(apiList) == 0 {
		logger.LogMessage("No valid API specified. Use the --api flag to specify one or more APIs.")
		printAvailableAPIs()
	} else {
		var wg sync.WaitGroup
		for _, api := range apiList {
			runAPI(api, lib, logger, &wg)
		}
		wg.Wait()
	}
}

func runAPI(api string, lib *common.EMSXAPILibrary, logger *common.Logger, wg *sync.WaitGroup) {
	switch api {

	// ─── Market Data ────────────────────────────────────────────────────────────

	case "GetDailyWeeklyMonthlyBars":
		logger.LogMessage("Running GetDailyWeeklyMonthlyBars API...")
		marketdata.NewExampleGetDailyWeeklyMonthlyBars().Run()

	case "GetIntradayBars":
		logger.LogMessage("Running GetIntradayBars API...")
		marketdata.NewExampleGetIntradayBars().Run()

	case "GetOptionChainForUnderlier":
		logger.LogMessage("Running GetOptionChainForUnderlier API...")
		marketdata.NewExampleGetOptionChainForUnderlier().Run()

	case "GetSymbolReferenceData":
		logger.LogMessage("Running GetSymbolReferenceData API...")
		marketdata.NewExampleGetSymbolReferenceData().Run()

	case "GetTickData":
		logger.LogMessage("Running GetTickData API...")
		marketdata.NewExampleGetTickData().Run()

	case "GetOptionsAndGreekData":
		logger.LogMessage("Running GetOptionsAndGreekData API...")
		marketdata.NewExampleGetOptionsAndGreekData().Run()

	case "GetSecurityData":
		logger.LogMessage("Running GetSecurityData API...")
		marketdata.NewExampleGetSecurityData().Run()

	case "GetOptionSymbolFromDescription":
		logger.LogMessage("Running GetOptionSymbolFromDescription API...")
		marketdata.NewExampleGetOptionSymbolFromDescription().Run()

	case "GetDescriptionFromOptionSymbol":
		logger.LogMessage("Running GetDescriptionFromOptionSymbol API...")
		marketdata.NewExampleGetDescriptionFromOptionSymbol().Run()

	case "SubscribeLevel1Ticks":
		logger.LogMessage("Running SubscribeLevel1Ticks API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			marketdata.NewExampleSubscribeLevel1Ticks().Run()
		}()

	case "UnSubscribeLevel1Data":
		logger.LogMessage("Running UnSubscribeLevel1Data API...")
		marketdata.NewExampleUnSubscribeLevel1Data().Run()

	case "SubscribeLevel2Ticks":
		logger.LogMessage("Running SubscribeLevel2Ticks API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			marketdata.NewExampleSubscribeLevel2Ticks().Run()
		}()

	case "UnSubscribeLevel2Data":
		logger.LogMessage("Running UnSubscribeLevel2Data API...")
		marketdata.NewExampleUnSubscribeLevel2Data().Run()

	case "AddSymbols":
		logger.LogMessage("Running AddSymbols API...")
		marketdata.NewExampleAddSymbols().Run()

	case "RemoveSymbols":
		logger.LogMessage("Running RemoveSymbols API...")
		marketdata.NewExampleRemoveSymbols().Run()

	case "GetSymbolsFromCompanyName":
		logger.LogMessage("Running GetSymbolsFromCompanyName API...")
		marketdata.NewExampleGetSymbolsFromCompanyName().Run()

	case "GetSymbolFromAlternateSymbology":
		logger.LogMessage("Running GetSymbolFromAlternateSymbology API...")
		marketdata.NewExampleGetSymbolFromAlternateSymbology().Run()

	case "GetLevel1MarketData":
		logger.LogMessage("Running GetLevel1MarketData API...")
		marketdata.NewExampleGetLevel1MarketData().Run()

	case "SubscribeTickData":
		logger.LogMessage("Running SubscribeTickData API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			marketdata.NewExampleSubscribeTickData().Run()
		}()

	case "UnSubscribeTickData":
		logger.LogMessage("Running UnSubscribeTickData API...")
		marketdata.NewExampleUnSubscribeTickData().Run()

	// ─── Order ──────────────────────────────────────────────────────────────────

	case "GetUserAccounts":
		logger.LogMessage("Running GetUserAccounts API...")
		order.NewExampleGetUserAccounts().Run()

	case "SubmitSingleOrder":
		logger.LogMessage("Running SubmitSingleOrder API...")
		order.NewExampleSubmitSingleOrder().Run()

	case "CancelSingleOrder":
		logger.LogMessage("Running CancelSingleOrder API...")
		order.NewExampleCancelSingleOrder().Run()

	case "ChangeSingleOrder":
		logger.LogMessage("Running ChangeSingleOrder API...")
		order.NewExampleChangeSingleOrder().Run()

	case "SubmitPairOrder":
		logger.LogMessage("Running SubmitPairOrder API...")
		order.NewExampleSubmitPairOrder().Run()

	case "ChangePairOrder":
		logger.LogMessage("Running ChangePairOrder API...")
		order.NewExampleChangePairOrder().Run()

	case "CancelPairOrder":
		logger.LogMessage("Running CancelPairOrder API...")
		order.NewExampleCancelPairOrder().Run()

	case "SubmitSeedData":
		logger.LogMessage("Running SubmitSeedData API...")
		order.NewExampleSubmitSeedData().Run()

	case "SubmitBasketOrder":
		logger.LogMessage("Running SubmitBasketOrder API...")
		order.NewExampleSubmitBasketOrder().Run()

	case "SubmitAllocationOrder":
		logger.LogMessage("Running SubmitAllocationOrder API...")
		order.NewExampleSubmitAllocationOrder().Run()

	case "SubmitBookTrade":
		logger.LogMessage("Running SubmitBookTrade API...")
		order.NewExampleSubmitBookTrade().Run()

	case "SubmitTradeReport":
		logger.LogMessage("Running SubmitTradeReport API...")
		order.NewExampleSubmitTradeReport().Run()

	case "SubscribeOrderInfo":
		logger.LogMessage("Running SubscribeOrderInfo API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			order.NewExampleSubscribeOrderInfo().Run()
		}()

	case "SubscribeOrderInfoJson":
		logger.LogMessage("Running SubscribeOrderInfoJson API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			order.NewExampleSubscribeOrderInfoJson().Run()
		}()

	case "GetOrderDetailByOrderId":
		logger.LogMessage("Running GetOrderDetailByOrderId API...")
		order.NewExampleGetOrderDetailByOrderId().Run()

	case "GetOrderDetailByOrderTag":
		logger.LogMessage("Running GetOrderDetailByOrderTag API...")
		order.NewExampleGetOrderDetailByOrderTag().Run()

	case "GetOrderDetailByDateRange":
		logger.LogMessage("Running GetOrderDetailByDateRange API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			order.NewExampleGetOrderDetailByDateRange().Run()
		}()

	// ─── Utility ────────────────────────────────────────────────────────────────

	case "GetTodaysActivity":
		logger.LogMessage("Running GetTodaysActivity API...")
		utility.NewExampleGetTodaysActivity().Run()

	case "GetTodaysActivityJson":
		logger.LogMessage("Running GetTodaysActivityJson API...")
		utility.NewExampleGetTodaysActivityJson().Run()

	case "GetTodaysBalances":
		logger.LogMessage("Running GetTodaysBalances API...")
		utility.NewExampleGetTodaysBalances().Run()

	case "GetTodaysNetPositions":
		logger.LogMessage("Running GetTodaysNetPositions API...")
		utility.NewExampleGetTodaysNetPositions().Run()

	case "GetTodaysBrokenDownPositions":
		logger.LogMessage("Running GetTodaysBrokenDownPositions API...")
		utility.NewExampleGetTodaysBrokenDownPositions().Run()

	case "SubscribeNetPositions":
		logger.LogMessage("Running SubscribeNetPositions API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			utility.NewExampleSubscribeNetPositions().Run()
		}()

	case "UnSubscribeNetPositions":
		logger.LogMessage("Running UnSubscribeNetPositions API...")
		utility.NewExampleUnSubscribeNetPositions().Run()

	case "GetUserRoutes":
		logger.LogMessage("Running GetUserRoutes API...")
		utility.NewExampleGetUserRoutes().Run()

	case "GetStrategyList":
		logger.LogMessage("Running GetStrategyList API...")
		utility.NewExampleGetStrategyList().Run()

	case "SubscribeHeartBeat":
		logger.LogMessage("Running SubscribeHeartBeat API...")
		wg.Add(1)
		go func() {
			defer wg.Done()
			utility.NewExampleSubscribeHeartBeat().Run()
		}()

	case "ChangePasswordSRP":
		logger.LogMessage("Running ChangePasswordSRP API...")
		utility.NewExampleChangePasswordSRP().Run()

	default:
		logger.LogMessage(fmt.Sprintf("Unknown API specified: %s", api))
		fmt.Printf("Unknown API: %s\n", api)
		printAvailableAPIs()
	}
}

func printAvailableAPIs() {
	fmt.Print(`
Available APIs (use --api flag with comma-separated names):

Market Data:
  GetDailyWeeklyMonthlyBars       GetIntradayBars
  GetOptionChainForUnderlier      GetSymbolReferenceData
  GetTickData                     GetOptionsAndGreekData
  GetSecurityData                 GetOptionSymbolFromDescription
  GetDescriptionFromOptionSymbol  SubscribeLevel1Ticks
  UnSubscribeLevel1Data           SubscribeLevel2Ticks
  UnSubscribeLevel2Data           AddSymbols
  RemoveSymbols                   GetSymbolsFromCompanyName
  GetSymbolFromAlternateSymbology GetLevel1MarketData
  SubscribeTickData               UnSubscribeTickData

Order:
  GetUserAccounts          SubmitSingleOrder         CancelSingleOrder
  ChangeSingleOrder        SubmitPairOrder           ChangePairOrder
  CancelPairOrder          SubmitSeedData            SubmitBasketOrder
  SubmitAllocationOrder    SubmitBookTrade           SubmitTradeReport
  SubscribeOrderInfo       SubscribeOrderInfoJson    GetOrderDetailByOrderId
  GetOrderDetailByOrderTag GetOrderDetailByDateRange

Utility:
  GetTodaysActivity         GetTodaysActivityJson     GetTodaysBalances
  GetTodaysNetPositions     GetTodaysBrokenDownPositions
  SubscribeNetPositions     UnSubscribeNetPositions   GetUserRoutes
  GetStrategyList           SubscribeHeartBeat        ChangePasswordSRP

Example:
  go run ./cmd/example-client --api GetTodaysActivity,GetUserAccounts
`)
}
