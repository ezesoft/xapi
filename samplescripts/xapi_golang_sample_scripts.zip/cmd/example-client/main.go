package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"go-xapi/internal/common"
	"go-xapi/internal/utils"
)

func main() {
	fmt.Println("[DEBUG] main() started")
	// Define a command-line flag to specify the APIs to run (comma-separated)
	apiFlag := flag.String("api", "", "Specify the APIs to run, comma-separated (e.g., GetTodaysActivity,SubscribeLevel1Ticks,SubmitSingleOrder)")
	flag.Parse()

	var lib *common.EMSXAPILibrary

	// Initialize logger
	logger, err := common.NewLogger("application-log.log")
	if err != nil {
		log.Fatalf("Failed to initialize logger: %v", err)
	}
	defer func() {
		if lib != nil {
			lib.SuspendHeartbeatThread()
			logger.LogMessage("Going to disconnect")
			lib.Logout(context.Background())
			logger.LogMessage("Going to close Channel")
			lib.CloseChannel()
		}
		fmt.Println("Press any key to exit...")
		fmt.Scanln()
	}()

	logger.LogMessage("Sample xAPI Go Client Application:\n\n")

	// Create EMSXAPILibrary instance
	common.Create("config\\config.ini")
	templib := common.Get()

	lib = templib
	if lib == nil {
		fmt.Println("[DEBUG] EMSXAPILibrary is nil after Create/Get")
		logger.LogMessage("Failed to initialize EMSXAPILibrary")
		return
	}

	// Perform login
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	logger.LogMessage("Logging in...")
	err = lib.Login(ctx)
	if err != nil {
		fmt.Println("[DEBUG] Login failed: ", err)
		logger.LogMessage(fmt.Sprintf("Login failed: %v", err))
		return
	}

	if lib.GetUserToken() == "" {
		fmt.Println("[DEBUG] Login returned empty user token")
		logger.LogMessage("Login Failed....")
		lib = nil
		return
	}

	logger.LogMessage(fmt.Sprintf("User token fetched: %s", lib.GetUserToken()))

	// Support running multiple APIs by splitting the flag
	apiList := []string{}
	if *apiFlag != "" {
		fmt.Printf("[DEBUG] apiFlag raw value: '%s'\n", *apiFlag)
		for _, api := range strings.Split(*apiFlag, ",") {
			trimmed := strings.TrimSpace(api)
			if trimmed != "" {
				apiList = append(apiList, trimmed)
			}
		}
		fmt.Printf("[DEBUG] Parsed apiList: %+v\n", apiList)
	}

	if len(apiList) == 0 {
		logger.LogMessage("No valid API specified. Use the --api flag to specify one or more APIs.")
	} else {
		var wg sync.WaitGroup
		for _, api := range apiList {
			switch api {
			case "GetTodaysActivity":
				logger.LogMessage("Running GetTodaysActivity API...")
				todaysActivityExample := utils.NewExampleGetTodaysActivity()
				todaysActivityExample.Run()
			case "SubscribeLevel1Ticks":
				logger.LogMessage("Running SubscribeLevel1Ticks API...")
				wg.Add(1)
				go func() {
					subscribeLevel1TicksExample := utils.NewExampleSubscribeLevel1Ticks()
					subscribeLevel1TicksExample.Run()
					wg.Done()
				}()
			case "SubmitSingleOrder":
				logger.LogMessage("Running SubmitSingleOrder API...")
				submitSingleOrderExample := utils.NewExampleSubmitSingleOrder()
				submitSingleOrderExample.Run()
			case "SubscribeOrderInfo":
				logger.LogMessage("Running SubscribeOrderInfo API...")
				wg.Add(1)
				go func() {
					subscribeOrderInfoExample := utils.NewExampleSubscribeOrderInfo()
					subscribeOrderInfoExample.Run()
					wg.Done()
				}()
			case "GetUserAccounts":
				logger.LogMessage("Running GetUserAccounts API...")
				getUserAccountsExample := utils.NewExampleGetUserAccounts()
				getUserAccountsExample.Run()
			case "SubscribeLevel2Ticks":
				logger.LogMessage("Running SubscribeLevel2Ticks API...")
				wg.Add(1)
				go func() {
					subscribeLevel2TicksExample := utils.NewExampleSubscribeLevel2Ticks()
					subscribeLevel2TicksExample.Run()
					wg.Done()
				}()
			default:
				logger.LogMessage(fmt.Sprintf("Unknown API specified: %s", api))
			}
		}
		// Wait for streaming APIs to finish (if ever)
		wg.Wait()
	}

	// Simulate application running
	time.Sleep(20 * time.Minute)
}
