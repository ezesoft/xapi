# Task List for Code Migration from C# to Go

## Tasks

### 1. Review and Document Functions
- Review all functions in `EMSXAPILibrary.cs`.
- Document their purpose, parameters, and return values.

### 2. Compare Functionality
- Compare the functionality of `EMSXAPILibrary.cs` with `ems_xapi_library.go`.
- Identify overlapping features and differences.

### 3. Identify Missing Features
- List features in `EMSXAPILibrary.cs` that are missing in `ems_xapi_library.go`.
- Highlight critical gaps, especially related to SRP login.

### 4. Port C# Components to Go
- Create a detailed list of C# components to be ported.
- Prioritize components based on functionality and dependencies.

### 5. Implement SRP Login
- Port `_CalculateCompleteSRPLoginVars` to Go.
- Integrate SRP login into the `Login` function in Go.

### 6. Ensure Compatibility
- Ensure compatibility with the existing Go codebase architecture.
- Maintain error handling and logging patterns.

### 7. Authentication and Security
- Preserve authentication and security requirements during migration.
- Use Go libraries for SRP (e.g., `github.com/secure-remote-password/srp`).

### 8. Dependencies and External Packages
- Identify and document dependencies or external packages required for migration.

### 9. Address Compatibility Issues
- Resolve potential compatibility issues, such as threading vs goroutines and data type conversions.

### 10. Testing and Validation
- Test the migrated code for functionality and compatibility.
- Validate error handling and logging mechanisms.

### Next Steps

1. **Implement Helper Functions**
   - Port `Concat`, `GetBytesFromHexEncoded`, and `GetHexEncodedStringFromBytes` to Go.
   - Ensure compatibility with Go's standard library.

2. **Port SRP Login Functionality**
   - Implement `_CalculateCompleteSRPLoginVars` in Go.
   - Integrate SRP login flow into the `Login` function.

3. **Enhance Heartbeat Management**
   - Implement `ExecSubscribeHeartBeat` in Go.
   - Add detailed error handling for heartbeat responses.

4. **Add Missing Utility Functions**
   - Implement `CanConnectToInternet`, `GetStatusEnumAsStringFromResponse`, `GetCurrentTime`, and `CalculateDelayMillis` in Go.

5. **Testing and Validation**
   - Test the migrated code for functionality and compatibility.
   - Validate error handling and logging mechanisms.

6. **Mark Tasks Complete**
   - After completing each task, update this file to mark it as complete.