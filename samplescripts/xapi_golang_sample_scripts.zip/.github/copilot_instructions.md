# Copilot Instructions
This file provides guidelines for using GitHub Copilot effectively in this project.
## 1. **Project Overview**
- Briefly describe the purpose and scope of the project.
- Include links to key files like `project_summary.md` for context.
## 2. **Coding Standards**
- Outline the coding conventions to follow (e.g., naming conventions, indentation, commenting style).
- Specify any frameworks, libraries, or tools being used.
## 3. **File Structure**
- Provide an overview of the project's folder and file organization.
- Mention where new files should be created and how they should be named.
## 4. **Code Generation Guidelines**
- Specify the type of code Copilot should generate (e.g., functions, classes, tests).
- Include examples of acceptable code patterns or templates.
## 5. **Testing Requirements**
- Define the testing framework being used (e.g., Jest, Pytest).
- Mention if unit tests, integration tests, or both are required for new code.
## 6. **Error Handling**
- Describe how errors should be handled (e.g., logging, custom exceptions).
- Provide examples of acceptable error-handling patterns.
## 7. **Documentation**
- Specify how code should be documented (e.g., docstrings, inline comments).
- Mention if additional documentation files are required for new features.
## 8. **Prohibited Content**
- List any types of code or content that should not be generated (e.g., deprecated APIs, insecure patterns).
## 9. **Collaboration Guidelines**
- Explain how Copilot should assist in collaborative workflows (e.g., generating code snippets, reviewing code).
- Mention any specific instructions for pull requests or code reviews.
## 10. **Examples and Templates**
- Provide examples of well-written code from the project.
- Include templates for common tasks (e.g., creating a new API endpoint, writing a test case).
## 11. **Feedback and Iteration**
- Describe how to provide feedback on Copilot's suggestions.
- Mention if iterative improvements are encouraged for generated code.
## 12. **Additional Notes**
- Include any other relevant instructions or tips for using Copilot in this project.

# Copilot Instructions for Go Projects

## General Go Best Practices
- Always use clear, short variable names (`conn`, `msg`, `stream`, `client`, etc.)
- Write small, single-purpose functions.
- Avoid unnecessary abstractions — prefer simple and readable code.
- Prefer composition over inheritance.
- Return early on errors (`if err != nil { return err }`).
- Use goroutines only when necessary; avoid excessive concurrency.
- Use `sync.Mutex` or channels carefully to protect shared resources.
- Use defer to close resources properly (`defer conn.Close()`, `defer cancel()`).

## gRPC Client Code
- Connect to gRPC using context with timeout.
- For streaming APIs, read continuously in a goroutine.
- Detect and handle `io.EOF` and stream errors properly.
- Reconnect automatically if the gRPC stream fails.
- Always log errors meaningfully (`log.Printf("failed to recv update: %v", err)`).
- Keep proto-generated types clean — use helper structs if needed for WebSocket payloads.

## WebSocket Server Code
- Always upgrade HTTP requests to WebSocket carefully (`gorilla/websocket` package).
- Maintain connected clients using `map[*websocket.Conn]bool`, protected by a `sync.Mutex`.
- Handle WebSocket client disconnections cleanly (remove from client map).
- Always write WebSocket messages asynchronously if scaling is needed.
- Marshal gRPC data into JSON before sending it over WebSocket (`json.Marshal(update)`).

## Code Style
- Keep files short and organized: separate gRPC logic, WebSocket logic, and main server setup.
- Group imports into three sections: standard library, third-party, local packages.
- Write clear comments above exported functions (`// Broadcasts an update to all clients`).
- Use consistent error handling (never ignore `err`).
- Keep main() function clean — delegate setup to other packages.

## Efficient Concurrency Patterns
- Use channels to communicate between gRPC stream reader and WebSocket broadcaster.
- Fan-out broadcast messages if handling thousands of WebSocket clients.
- Limit goroutines — don't spawn a goroutine per WebSocket write unless absolutely needed.

## Additional Guidelines
- Always shut down gRPC and WebSocket servers gracefully on SIGINT/SIGTERM.
- Log startup, shutdown, connection, and error events.
- Follow Go idioms: "Don't communicate by sharing memory; share memory by communicating."
- Prefer slices over arrays, maps for lookup tables, and structs for structured data.
- Always validate user input even on WebSocket connections.

## Common Naming Conventions
- Structs: `Update`, `Client`, `Hub`, `Server`
- Interfaces: end with -er (`Streamer`, `Broadcaster`)
- Functions: verbs or actions (`connectGRPC`, `subscribeUpdates`, `broadcastUpdate`)
- Packages: short, lowercase, no underscores (`grpcclient`, `wsserver`, `models`)

