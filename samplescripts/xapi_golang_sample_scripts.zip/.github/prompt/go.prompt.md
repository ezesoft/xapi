# Prompt Optimization Request

Please provide:

1. A clear and complete prompt you would like to optimize, including:
   - The full prompt text
   - The intended purpose or goal
   - Target audience or system
   - Any specific constraints or requirements

2. Current context and issues (if any):
   - What works/doesn't work with the current prompt
   - Specific problems you're encountering
   - Examples of undesired outputs

3. Desired improvements:
   - Key aspects you want to enhance
   - Specific features you want to maintain
   - Target outcomes or success criteria

4. Additional information:
   - Use cases or scenarios
   - Reference materials or examples
   - Technical constraints or limitations

Your input will be used to create an optimized, effective prompt that achieves your goals while following best practices in prompt engineering.

Note: Please include the original prompt in a clear format (e.g., code block or quoted text) to ensure accurate optimization.