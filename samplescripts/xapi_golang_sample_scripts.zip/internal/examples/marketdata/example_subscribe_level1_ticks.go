package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleSubscribeLevel1Ticks handles subscribing to Level 1 tick data.
type ExampleSubscribeLevel1Ticks struct{}

// NewExampleSubscribeLevel1Ticks initializes a new instance.
func NewExampleSubscribeLevel1Ticks() *ExampleSubscribeLevel1Ticks {
	return &ExampleSubscribeLevel1Ticks{}
}

// Run executes the subscription to Level 1 tick data.
func (e *ExampleSubscribeLevel1Ticks) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.Level1MarketDataRequest{
		UserToken: lib.GetUserToken(),
		Advise:    true,
		Request:   true,
		Symbols:   []string{"VOD.LSE", "BARC.LSE", "AAPL"},
	}

	responseStream, err := lib.MarketDataStub.SubscribeLevel1Ticks(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to Level 1 ticks: " + err.Error())
		fmt.Println("Error subscribing to Level 1 ticks:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving Level 1 tick data: " + err.Error())
			fmt.Println("Error receiving Level 1 tick data:", err)
			break
		}
		fmt.Println("Received Level 1 tick data:")
		fmt.Println(response.String())
	}
	lib.Logger.LogMessage("Level 1 tick subscription ended.")
}
