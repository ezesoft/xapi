package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetSecurityData handles fetching security data.
type ExampleGetSecurityData struct{}

// NewExampleGetSecurityData initializes a new instance.
func NewExampleGetSecurityData() *ExampleGetSecurityData {
	return &ExampleGetSecurityData{}
}

// Run executes the GetSecurityData API call.
func (e *ExampleGetSecurityData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.SecurityDataRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "VOD.LSE",
	}

	response, err := lib.MarketDataStub.GetSecurityData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetSecurityData: " + err.Error())
		fmt.Println("Error calling GetSecurityData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Security Data:")
	fmt.Println("Symbol:", request.Symbol)
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Response:", response.String())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched security data successfully.")
}
