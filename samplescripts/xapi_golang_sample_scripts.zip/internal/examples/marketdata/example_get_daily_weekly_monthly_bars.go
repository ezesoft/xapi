package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetDailyWeeklyMonthlyBars handles fetching daily, weekly, or monthly bar data.
type ExampleGetDailyWeeklyMonthlyBars struct{}

// NewExampleGetDailyWeeklyMonthlyBars initializes a new instance.
func NewExampleGetDailyWeeklyMonthlyBars() *ExampleGetDailyWeeklyMonthlyBars {
	return &ExampleGetDailyWeeklyMonthlyBars{}
}

// Run executes the GetDailyWeeklyMonthlyBars API call.
func (e *ExampleGetDailyWeeklyMonthlyBars) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.DailyWeeklyMonthlyBarsRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "VOD.LSE",
		Interim: &market_data.Interval{
			BarIntervalOption: market_data.Interval_DAILY,
		},
	}

	response, err := lib.MarketDataStub.GetDailyWeeklyMonthlyBars(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetDailyWeeklyMonthlyBars: " + err.Error())
		fmt.Println("Error calling GetDailyWeeklyMonthlyBars:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Daily Weekly Monthly Bars:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Display Name:", response.DispName)
	if response.BarFields != nil {
		if len(response.BarFields.AcVol1) > 0 {
			fmt.Println("  Accumulated Volume 1:", response.BarFields.AcVol1[0])
		}
		if len(response.BarFields.High1) > 0 {
			fmt.Println("  High 1:", response.BarFields.High1[0])
		}
		if len(response.BarFields.Low1) > 0 {
			fmt.Println("  Low 1:", response.BarFields.Low1[0])
		}
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched daily/weekly/monthly bars successfully.")
}
