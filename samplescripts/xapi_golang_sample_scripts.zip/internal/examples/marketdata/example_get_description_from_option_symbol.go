package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetDescriptionFromOptionSymbol handles converting an option symbol to a description.
type ExampleGetDescriptionFromOptionSymbol struct{}

// NewExampleGetDescriptionFromOptionSymbol initializes a new instance.
func NewExampleGetDescriptionFromOptionSymbol() *ExampleGetDescriptionFromOptionSymbol {
	return &ExampleGetDescriptionFromOptionSymbol{}
}

// Run executes the GetDescriptionFromOptionSymbol API call.
func (e *ExampleGetDescriptionFromOptionSymbol) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.DescriptionFromOptionSymbolRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "AAPL240315C00150000",
	}

	response, err := lib.MarketDataStub.GetDescriptionFromOptionSymbol(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetDescriptionFromOptionSymbol: " + err.Error())
		fmt.Println("Error calling GetDescriptionFromOptionSymbol:", err)
		return
	}

	optionTypeStr := "PUT"
	if response.OptionType != nil && response.OptionType.CallOrPut == market_data.OptionTypes_CALL {
		optionTypeStr = "CALL"
	}

	fmt.Println("------------------------------")
	fmt.Println("Option Description from Symbol:")
	fmt.Println("Symbol:", request.Symbol)
	fmt.Println("Root:", response.Root)
	fmt.Println("Expiration:", response.Expiration)
	fmt.Println("Type:", optionTypeStr)
	fmt.Printf("Strike Price: $%.2f\n", response.StrikePrice)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched description from option symbol successfully.")
}
