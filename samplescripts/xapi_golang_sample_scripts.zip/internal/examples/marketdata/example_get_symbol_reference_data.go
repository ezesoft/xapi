package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetSymbolReferenceData handles fetching symbol reference data.
type ExampleGetSymbolReferenceData struct{}

// NewExampleGetSymbolReferenceData initializes a new instance.
func NewExampleGetSymbolReferenceData() *ExampleGetSymbolReferenceData {
	return &ExampleGetSymbolReferenceData{}
}

// Run executes the GetSymbolReferenceData API call.
func (e *ExampleGetSymbolReferenceData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.SymbolReferenceDataRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "VOD.LSE",
	}

	response, err := lib.MarketDataStub.GetSymbolReferenceData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetSymbolReferenceData: " + err.Error())
		fmt.Println("Error calling GetSymbolReferenceData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Symbol Reference Data:")
	fmt.Println("Symbol:", request.Symbol)
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Response:", response.String())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched symbol reference data successfully.")
}
