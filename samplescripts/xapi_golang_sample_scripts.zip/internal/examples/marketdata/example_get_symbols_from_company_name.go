package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetSymbolsFromCompanyName handles fetching symbols from a company name.
type ExampleGetSymbolsFromCompanyName struct{}

// NewExampleGetSymbolsFromCompanyName initializes a new instance.
func NewExampleGetSymbolsFromCompanyName() *ExampleGetSymbolsFromCompanyName {
	return &ExampleGetSymbolsFromCompanyName{}
}

// Run executes the GetSymbolsFromCompanyName API call.
func (e *ExampleGetSymbolsFromCompanyName) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.SymbolsFromCompanyNameRequest{
		UserToken:   lib.GetUserToken(),
		CompanyName: "Microsoft Corporation",
	}

	response, err := lib.MarketDataStub.GetSymbolsFromCompanyName(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetSymbolsFromCompanyName: " + err.Error())
		fmt.Println("Error calling GetSymbolsFromCompanyName:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Symbols from Company Name:")
	fmt.Println("Company:", request.CompanyName)
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Symbols:", len(response.SymbolDatalist))
	for i, symbolData := range response.SymbolDatalist {
		fmt.Printf("Symbol %d: %s\n", i+1, symbolData.String())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched symbols from company name successfully.")
}
