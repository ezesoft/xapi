package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetSymbolFromAlternateSymbology handles converting an alternate symbology to a symbol.
type ExampleGetSymbolFromAlternateSymbology struct{}

// NewExampleGetSymbolFromAlternateSymbology initializes a new instance.
func NewExampleGetSymbolFromAlternateSymbology() *ExampleGetSymbolFromAlternateSymbology {
	return &ExampleGetSymbolFromAlternateSymbology{}
}

// Run executes the GetSymbolFromAlternateSymbology API call.
func (e *ExampleGetSymbolFromAlternateSymbology) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.SymbolFromAlternateSymbologyRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "037833100",
		SymbolInfo: &market_data.AlternateSymbology{
			SymbolOption: market_data.AlternateSymbology_CUSIP,
		},
	}

	response, err := lib.MarketDataStub.GetSymbolFromAlternateSymbology(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetSymbolFromAlternateSymbology: " + err.Error())
		fmt.Println("Error calling GetSymbolFromAlternateSymbology:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Symbol from Alternate Symbology:")
	fmt.Println("Input Symbol:", request.Symbol)
	fmt.Println("Symbol Type: CUSIP")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Result:", response.String())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched symbol from alternate symbology successfully.")
}
