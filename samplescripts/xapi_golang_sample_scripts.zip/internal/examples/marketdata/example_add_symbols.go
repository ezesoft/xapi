package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleAddSymbols handles adding symbols to a subscription.
type ExampleAddSymbols struct{}

// NewExampleAddSymbols initializes a new instance.
func NewExampleAddSymbols() *ExampleAddSymbols {
	return &ExampleAddSymbols{}
}

// Run executes the AddSymbols API call.
func (e *ExampleAddSymbols) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	symbolsList := []string{"MSFT", "GOOGL", "TSLA"}

	request := &market_data.AddSymbolsRequest{
		UserToken: lib.GetUserToken(),
		Symbols:   symbolsList,
	}

	response, err := lib.MarketDataStub.AddSymbols(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling AddSymbols: " + err.Error())
		fmt.Println("Error calling AddSymbols:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Added Symbols to Subscriptions:")
	fmt.Println("Symbols:", symbolsList)
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Optional Fields:", response.OptionalFields)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Added symbols successfully.")
}
