package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleUnSubscribeLevel2Data handles unsubscribing from Level 2 data.
type ExampleUnSubscribeLevel2Data struct{}

// NewExampleUnSubscribeLevel2Data initializes a new instance.
func NewExampleUnSubscribeLevel2Data() *ExampleUnSubscribeLevel2Data {
	return &ExampleUnSubscribeLevel2Data{}
}

// Run executes the UnSubscribeLevel2Data API call.
func (e *ExampleUnSubscribeLevel2Data) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.UnSubscribeLevel2DataRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.MarketDataStub.UnSubscribeLevel2Data(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling UnSubscribeLevel2Data: " + err.Error())
		fmt.Println("Error calling UnSubscribeLevel2Data:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Unsubscribed from Level 2 Data:")
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Optional Fields:", response.OptionalFields)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Unsubscribed from Level 2 data successfully.")
}
