package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleUnSubscribeTickData handles unsubscribing from tick data.
type ExampleUnSubscribeTickData struct{}

// NewExampleUnSubscribeTickData initializes a new instance.
func NewExampleUnSubscribeTickData() *ExampleUnSubscribeTickData {
	return &ExampleUnSubscribeTickData{}
}

// Run executes the UnSubscribeTickData API call.
func (e *ExampleUnSubscribeTickData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.UnSubscribeTickDataRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.MarketDataStub.UnSubscribeTickData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling UnSubscribeTickData: " + err.Error())
		fmt.Println("Error calling UnSubscribeTickData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Unsubscribed from Tick Data:")
	fmt.Println("Acknowledgement:", response.Acknowledgement.String())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Unsubscribed from tick data successfully.")
}
