package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleRemoveSymbols handles removing symbols from a subscription.
type ExampleRemoveSymbols struct{}

// NewExampleRemoveSymbols initializes a new instance.
func NewExampleRemoveSymbols() *ExampleRemoveSymbols {
	return &ExampleRemoveSymbols{}
}

// Run executes the RemoveSymbols API call.
func (e *ExampleRemoveSymbols) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	symbolsList := []string{"MSFT", "GOOGL", "TSLA"}

	request := &market_data.RemoveSymbolsRequest{
		UserToken: lib.GetUserToken(),
		Symbols:   symbolsList,
	}

	response, err := lib.MarketDataStub.RemoveSymbols(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling RemoveSymbols: " + err.Error())
		fmt.Println("Error calling RemoveSymbols:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Removed Symbols from Subscriptions:")
	fmt.Println("Symbols:", symbolsList)
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Optional Fields:", response.OptionalFields)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Removed symbols successfully.")
}
