package marketdata

import (
	"context"
	"fmt"
	"math/rand"
	"time"

	"google.golang.org/protobuf/types/known/durationpb"
	"google.golang.org/protobuf/types/known/timestamppb"
	"google.golang.org/protobuf/types/known/wrapperspb"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetTickData handles fetching tick data.
type ExampleGetTickData struct{}

// NewExampleGetTickData initializes a new instance.
func NewExampleGetTickData() *ExampleGetTickData {
	return &ExampleGetTickData{}
}

// Run executes the GetTickData API call.
func (e *ExampleGetTickData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	now := time.Now().UTC()

	request := &market_data.TickDataRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "VOD.LSE",
		Date:      timestamppb.New(now),
		StartTime: durationpb.New(12*time.Hour + 10*time.Minute + 50*time.Second),
		StopTime:  durationpb.New(20*time.Hour + 30*time.Minute + 40*time.Second),
		RequestId: wrapperspb.Int32(rand.Int31()),
	}
	request.TickTypes = append(request.TickTypes, &market_data.TickTypes{TickOption: market_data.TickTypes_TRADE})
	request.TickTypes = append(request.TickTypes, &market_data.TickTypes{TickOption: market_data.TickTypes_BID})
	request.TickTypes = append(request.TickTypes, &market_data.TickTypes{TickOption: market_data.TickTypes_ASK})

	response, err := lib.MarketDataStub.GetTickData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTickData: " + err.Error())
		fmt.Println("Error calling GetTickData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Tick Data:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Records:", len(response.TickInfo))
	for i, tickRecord := range response.TickInfo {
		fmt.Printf("Record %d:\n", i+1)
		fmt.Println("  Count:", tickRecord.Count)
		fmt.Println("  Trade Prices:", tickRecord.TrdPrc1)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched tick data successfully.")
}
