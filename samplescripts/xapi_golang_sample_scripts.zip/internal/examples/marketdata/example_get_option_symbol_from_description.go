package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetOptionSymbolFromDescription handles converting an option description to a symbol.
type ExampleGetOptionSymbolFromDescription struct{}

// NewExampleGetOptionSymbolFromDescription initializes a new instance.
func NewExampleGetOptionSymbolFromDescription() *ExampleGetOptionSymbolFromDescription {
	return &ExampleGetOptionSymbolFromDescription{}
}

// Run executes the GetOptionSymbolFromDescription API call.
func (e *ExampleGetOptionSymbolFromDescription) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.OptionSymbolFromDescriptionRequest{
		UserToken:  lib.GetUserToken(),
		Root:       "AAPL",
		Expiration: "20240315",
		OptionType: &market_data.OptionTypes{
			CallOrPut: market_data.OptionTypes_CALL,
		},
		StrikePrice: 150.0,
	}

	response, err := lib.MarketDataStub.GetOptionSymbolFromDescription(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOptionSymbolFromDescription: " + err.Error())
		fmt.Println("Error calling GetOptionSymbolFromDescription:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Option Symbol from Description:")
	fmt.Println("Root:", request.Root)
	fmt.Println("Expiration:", request.Expiration)
	fmt.Println("Type: CALL")
	fmt.Printf("Strike: $%.2f\n", request.StrikePrice)
	fmt.Println("Symbol:", response.Symbol)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched option symbol from description successfully.")
}
