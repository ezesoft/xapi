package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetOptionChainForUnderlier handles fetching option chain data for an underlier.
type ExampleGetOptionChainForUnderlier struct{}

// NewExampleGetOptionChainForUnderlier initializes a new instance.
func NewExampleGetOptionChainForUnderlier() *ExampleGetOptionChainForUnderlier {
	return &ExampleGetOptionChainForUnderlier{}
}

// Run executes the GetOptionChainForUnderlier API call.
func (e *ExampleGetOptionChainForUnderlier) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.OptionChainRequest{
		UserToken:  lib.GetUserToken(),
		SymbolRoot: "M",
	}

	response, err := lib.MarketDataStub.GetOptionChainForUnderlier(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOptionChainForUnderlier: " + err.Error())
		fmt.Println("Error calling GetOptionChainForUnderlier:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Option Chain for Underlier:")
	fmt.Println("Symbol Root:", request.SymbolRoot)
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Derivatives:", len(response.Derivative))
	for i, derivative := range response.Derivative {
		fmt.Printf("Derivative %d: %s\n", i+1, derivative.String())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched option chain for underlier successfully.")
}
