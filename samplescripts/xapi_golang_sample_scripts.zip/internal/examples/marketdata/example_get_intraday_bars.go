package marketdata

import (
	"context"
	"fmt"
	"time"

	"google.golang.org/protobuf/types/known/durationpb"
	"google.golang.org/protobuf/types/known/timestamppb"
	"google.golang.org/protobuf/types/known/wrapperspb"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetIntradayBars handles fetching intraday bar data.
type ExampleGetIntradayBars struct{}

// NewExampleGetIntradayBars initializes a new instance.
func NewExampleGetIntradayBars() *ExampleGetIntradayBars {
	return &ExampleGetIntradayBars{}
}

// Run executes the GetIntradayBars API call.
func (e *ExampleGetIntradayBars) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	now := time.Now().UTC()

	request := &market_data.IntradayBarsRequest{
		UserToken:        lib.GetUserToken(),
		Symbol:           "VOD.LSE",
		BarInterval:      1,
		DaysBack:         1,
		StartAtMidnight:  false,
		ShowPrePostMarket: false,
		Date:             timestamppb.New(now),
		StartTime:        durationpb.New(12*time.Hour + 10*time.Minute + 50*time.Second),
		StopTime:         durationpb.New(20*time.Hour + 30*time.Minute + 40*time.Second),
		RequestId:        wrapperspb.Int32(12345),
	}

	response, err := lib.MarketDataStub.GetIntradayBars(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetIntradayBars: " + err.Error())
		fmt.Println("Error calling GetIntradayBars:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Intraday Bars Data:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Bars:", response.Bars)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched intraday bars successfully.")
}
