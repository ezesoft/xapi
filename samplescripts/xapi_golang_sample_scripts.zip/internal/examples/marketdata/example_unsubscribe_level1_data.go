package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleUnSubscribeLevel1Data handles unsubscribing from Level 1 data.
type ExampleUnSubscribeLevel1Data struct{}

// NewExampleUnSubscribeLevel1Data initializes a new instance.
func NewExampleUnSubscribeLevel1Data() *ExampleUnSubscribeLevel1Data {
	return &ExampleUnSubscribeLevel1Data{}
}

// Run executes the UnSubscribeLevel1Data API call.
func (e *ExampleUnSubscribeLevel1Data) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.UnSubscribeLevel1DataRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.MarketDataStub.UnSubscribeLevel1Data(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling UnSubscribeLevel1Data: " + err.Error())
		fmt.Println("Error calling UnSubscribeLevel1Data:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Unsubscribed from Level 1 Data:")
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Optional Fields:", response.OptionalFields)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Unsubscribed from Level 1 data successfully.")
}
