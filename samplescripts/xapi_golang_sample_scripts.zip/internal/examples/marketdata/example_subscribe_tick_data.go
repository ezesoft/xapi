package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleSubscribeTickData handles subscribing to tick data stream.
type ExampleSubscribeTickData struct{}

// NewExampleSubscribeTickData initializes a new instance.
func NewExampleSubscribeTickData() *ExampleSubscribeTickData {
	return &ExampleSubscribeTickData{}
}

// Run executes the SubscribeTickData API call.
func (e *ExampleSubscribeTickData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.SubscribeTickDataRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "AAPL",
		Request:   true,
	}

	responseStream, err := lib.MarketDataStub.SubscribeTickData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to tick data: " + err.Error())
		fmt.Println("Error subscribing to tick data:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving tick data subscription: " + err.Error())
			fmt.Println("Error receiving tick data subscription:", err)
			break
		}
		fmt.Println("------------------------------")
		fmt.Println("Tick Data Subscription:")
		fmt.Println(response.String())
		fmt.Println("------------------------------")
	}
	lib.Logger.LogMessage("Tick data subscription ended.")
}
