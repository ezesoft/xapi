package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetOptionsAndGreekData handles fetching options and greek data.
type ExampleGetOptionsAndGreekData struct{}

// NewExampleGetOptionsAndGreekData initializes a new instance.
func NewExampleGetOptionsAndGreekData() *ExampleGetOptionsAndGreekData {
	return &ExampleGetOptionsAndGreekData{}
}

// Run executes the GetOptionsAndGreekData API call.
func (e *ExampleGetOptionsAndGreekData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.OptionsAndGreekDataRequest{
		UserToken: lib.GetUserToken(),
		Symbols:   []string{"M", `+AAPL\15B9\223`, `+IBM\09D9\150`},
	}

	response, err := lib.MarketDataStub.GetOptionsAndGreekData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOptionsAndGreekData: " + err.Error())
		fmt.Println("Error calling GetOptionsAndGreekData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Options and Greek Data:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Options:", len(response.OptionsList))
	for i, option := range response.OptionsList {
		fmt.Printf("Option %d: %s\n", i+1, option.String())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched options and greek data successfully.")
}
