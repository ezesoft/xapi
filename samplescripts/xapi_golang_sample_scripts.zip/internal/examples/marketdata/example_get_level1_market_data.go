package marketdata

import (
	"context"
	"fmt"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleGetLevel1MarketData handles fetching Level 1 market data snapshot.
type ExampleGetLevel1MarketData struct{}

// NewExampleGetLevel1MarketData initializes a new instance.
func NewExampleGetLevel1MarketData() *ExampleGetLevel1MarketData {
	return &ExampleGetLevel1MarketData{}
}

// Run executes the GetLevel1MarketData API call.
func (e *ExampleGetLevel1MarketData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.Level1MarketDataRecordRequest{
		UserToken: lib.GetUserToken(),
		Symbols:   []string{"VOD.LSE", "BARC.LSE", "GSK.LSE"},
	}

	response, err := lib.MarketDataStub.GetLevel1MarketData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetLevel1MarketData: " + err.Error())
		fmt.Println("Error calling GetLevel1MarketData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Level 1 Market Data:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Records:", len(response.DataRecord))
	for i, record := range response.DataRecord {
		fmt.Printf("Symbol %d: %s\n", i+1, record.DispName)
		fmt.Println("  Last Price:", record.Trdprc1)
		fmt.Println("  Bid:", record.Bid)
		fmt.Println("  Ask:", record.Ask)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched Level 1 market data successfully.")
}
