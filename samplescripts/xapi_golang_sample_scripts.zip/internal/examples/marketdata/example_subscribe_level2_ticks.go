package marketdata

import (
	"context"
	"fmt"

	"google.golang.org/protobuf/types/known/wrapperspb"

	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
)

// ExampleSubscribeLevel2Ticks handles subscribing to Level 2 tick data.
type ExampleSubscribeLevel2Ticks struct{}

// NewExampleSubscribeLevel2Ticks initializes a new instance.
func NewExampleSubscribeLevel2Ticks() *ExampleSubscribeLevel2Ticks {
	return &ExampleSubscribeLevel2Ticks{}
}

// Run executes the subscription to Level 2 tick data.
func (e *ExampleSubscribeLevel2Ticks) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &market_data.Level2MarketDataRequest{
		UserToken: lib.GetUserToken(),
		Request:   true,
		Advise:    true,
		RequestId: wrapperspb.Int32(12345),
		Symbols:   []string{"VOD.LSE", "MSFT", "GOOGL"},
	}

	responseStream, err := lib.MarketDataStub.SubscribeLevel2Ticks(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to Level 2 ticks: " + err.Error())
		fmt.Println("Error subscribing to Level 2 ticks:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving Level 2 tick data: " + err.Error())
			fmt.Println("Error receiving Level 2 tick data:", err)
			break
		}
		fmt.Println("------------------------------")
		fmt.Println("Subscribe Level 2 Ticks:")
		fmt.Println(response.String())
		fmt.Println("------------------------------")
	}
	lib.Logger.LogMessage("Level 2 tick subscription ended.")
}
