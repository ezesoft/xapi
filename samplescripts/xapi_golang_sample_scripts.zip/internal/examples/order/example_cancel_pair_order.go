package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleCancelPairOrder handles cancelling a pair order.
type ExampleCancelPairOrder struct{}

// NewExampleCancelPairOrder initializes a new instance.
func NewExampleCancelPairOrder() *ExampleCancelPairOrder {
	return &ExampleCancelPairOrder{}
}

// Run executes the CancelPairOrder API call.
func (e *ExampleCancelPairOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.CancelPairOrderRequest{
		UserToken: lib.GetUserToken(),
		OrderId:   "12345678",
	}

	response, err := lib.OrderServiceStub.CancelPairOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling CancelPairOrder: " + err.Error())
		fmt.Println("Error calling CancelPairOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Cancel Pair Order Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Order Cancellation Response received")
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Cancel pair order request completed.")
}
