package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitTradeReport handles submitting a trade report.
type ExampleSubmitTradeReport struct{}

// NewExampleSubmitTradeReport initializes a new instance.
func NewExampleSubmitTradeReport() *ExampleSubmitTradeReport {
	return &ExampleSubmitTradeReport{}
}

// Run executes the SubmitTradeReport API call.
func (e *ExampleSubmitTradeReport) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubmitTradeReportRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "AAPL",
		Side:      "BUY",
		Quantity:  100,
		Account:   "ACCOUNT123",
		Route:     "ROUTE1",
		OrderType: &pb_order.TradeType{
			OrderTypes: pb_order.TradeType_UserSubmitTradeReport,
		},
		ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
	}

	response, err := lib.OrderServiceStub.SubmitTradeReport(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitTradeReport: " + err.Error())
		fmt.Println("Error calling SubmitTradeReport:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Submit Trade Report Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	if msg, ok := response.OptionalFields["ErrorMessage"]; ok {
		fmt.Println("Error Message:", msg)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submit trade report request completed.")
}
