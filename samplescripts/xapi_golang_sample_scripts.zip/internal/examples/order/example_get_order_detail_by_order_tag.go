package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleGetOrderDetailByOrderTag handles fetching order details by order tag.
type ExampleGetOrderDetailByOrderTag struct{}

// NewExampleGetOrderDetailByOrderTag initializes a new instance.
func NewExampleGetOrderDetailByOrderTag() *ExampleGetOrderDetailByOrderTag {
	return &ExampleGetOrderDetailByOrderTag{}
}

// Run executes the GetOrderDetailByOrderTag API call.
func (e *ExampleGetOrderDetailByOrderTag) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.OrderDetailByOrderTagRequest{
		UserToken:      lib.GetUserToken(),
		OrderEventType: "ALL",
		OrderTags:      []string{"ORDER_TAG_1", "ORDER_TAG_2"},
	}

	response, err := lib.OrderServiceStub.GetOrderDetailByOrderTag(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOrderDetailByOrderTag: " + err.Error())
		fmt.Println("Error calling GetOrderDetailByOrderTag:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Get Order Detail By Order Tag:")
	fmt.Println("Number of Order Details:", len(response.OrderDetails))
	for i, detail := range response.OrderDetails {
		fmt.Printf("Order Detail %d:\n", i+1)
		fmt.Println("  Order ID:", detail.OrderId)
		fmt.Println("  Refers To ID:", detail.RefersToId)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched order detail by order tag successfully.")
}
