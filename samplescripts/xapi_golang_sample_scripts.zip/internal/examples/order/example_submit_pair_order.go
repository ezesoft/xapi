package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitPairOrder handles submitting a pair order.
type ExampleSubmitPairOrder struct{}

// NewExampleSubmitPairOrder initializes a new instance.
func NewExampleSubmitPairOrder() *ExampleSubmitPairOrder {
	return &ExampleSubmitPairOrder{}
}

// Run executes the SubmitPairOrder API call.
func (e *ExampleSubmitPairOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubmitPairOrderRequest{
		UserToken:           lib.GetUserToken(),
		Leg1_Symbol:         "LEG1_SYMBOL",
		Leg1_Side:           "BUY",
		Leg1_Quantity:       1111,
		Leg2_Symbol:         "LEG2_SYMBOL",
		Leg2_Side:           "SELL",
		Leg2_Quantity:       1000,
		Route:               "ROUTE",
		Account:             "BANK;BRANCH;CUSTOMER;DEPOSIT",
		Staged:              false,
		ClaimRequire:        false,
		OrderTag:            "ORDER_TAG",
		TicketId:            "TICKET_ID",
		Leg1_ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
		Leg2_ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
	}

	response, err := lib.OrderServiceStub.SubmitPairOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitPairOrder: " + err.Error())
		fmt.Println("Error calling SubmitPairOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Submit Pair Order Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	if response.ServerResponse == "Failed" {
		fmt.Println("Error Message:", response.OptionalFields["ErrorMessage"])
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submit pair order request completed.")
}
