package order

import (
	"context"
	"fmt"

	"google.golang.org/protobuf/types/known/wrapperspb"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleChangeSingleOrder handles changing a single order.
type ExampleChangeSingleOrder struct{}

// NewExampleChangeSingleOrder initializes a new instance.
func NewExampleChangeSingleOrder() *ExampleChangeSingleOrder {
	return &ExampleChangeSingleOrder{}
}

// Run executes the ChangeSingleOrder API call.
func (e *ExampleChangeSingleOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.ChangeSingleOrderRequest{
		UserToken:      lib.GetUserToken(),
		OrderId:        "ORDER_ID_PLACEHOLDER",
		Quantity:       5000,
		Price:          wrapperspb.Double(121.5),
		OrderTag:       "CHANGE_ORDER_TAG",
		ExtendedFields: map[string]string{"DEST_ROUTE": "DEMOEUR", "ACCT_TYPE": "119"},
	}

	response, err := lib.OrderServiceStub.ChangeSingleOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling ChangeSingleOrder: " + err.Error())
		fmt.Println("Error calling ChangeSingleOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Change Single Order Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	if response.ServerResponse == "Failed" {
		fmt.Println("Error Message:", response.OptionalFields["ErrorMessage"])
	} else {
		fmt.Println("Order changed successfully")
		fmt.Println("New Quantity:", request.Quantity)
		fmt.Printf("New Price: %.2f\n", request.Price.GetValue())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Change single order request completed.")
}
