package order

import (
	"context"
	"fmt"
	"time"

	"google.golang.org/protobuf/types/known/timestamppb"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleGetOrderDetailByDateRange handles fetching order details by date range (streaming).
type ExampleGetOrderDetailByDateRange struct{}

// NewExampleGetOrderDetailByDateRange initializes a new instance.
func NewExampleGetOrderDetailByDateRange() *ExampleGetOrderDetailByDateRange {
	return &ExampleGetOrderDetailByDateRange{}
}

// Run executes the GetOrderDetailByDateRange API call.
func (e *ExampleGetOrderDetailByDateRange) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	startDate := time.Date(2025, 2, 10, 0, 0, 0, 0, time.UTC)
	endDate := time.Date(2026, 2, 10, 23, 59, 59, 0, time.UTC)

	request := &pb_order.OrderDetailByDateRangeRequest{
		UserToken:        lib.GetUserToken(),
		TimeoutInSeconds: 100,
		StartDate:        timestamppb.New(startDate),
		EndDate:          timestamppb.New(endDate),
	}

	responseStream, err := lib.OrderServiceStub.GetOrderDetailByDateRange(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOrderDetailByDateRange: " + err.Error())
		fmt.Println("Error calling GetOrderDetailByDateRange:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving order detail by date range: " + err.Error())
			fmt.Println("Error receiving order detail by date range:", err)
			break
		}
		fmt.Println("Order Details by Date Range")
		fmt.Println(response.Acknowledgement.GetServerResponse())
		if response.Acknowledgement.GetServerResponse() == "Failed" {
			fmt.Println("Error Message:", response.Acknowledgement.GetMessage())
		} else {
			fmt.Println("Response received successfully")
		}
		fmt.Println("-----------------------------")
	}
	lib.Logger.LogMessage("GetOrderDetailByDateRange stream ended.")
}
