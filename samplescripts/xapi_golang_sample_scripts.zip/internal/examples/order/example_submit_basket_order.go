package order

import (
	"context"
	"fmt"
	"math/rand"

	"google.golang.org/protobuf/types/known/wrapperspb"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitBasketOrder handles submitting a basket order.
type ExampleSubmitBasketOrder struct{}

// NewExampleSubmitBasketOrder initializes a new instance.
func NewExampleSubmitBasketOrder() *ExampleSubmitBasketOrder {
	return &ExampleSubmitBasketOrder{}
}

// Run executes the SubmitBasketOrder API call.
func (e *ExampleSubmitBasketOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	orderTag1 := fmt.Sprintf("XAP-%d", rand.Int31())
	orderTag2 := fmt.Sprintf("XAP-%d", rand.Int31())

	order1 := &pb_order.OrderRow{
		DispName:   "SYMBOL1",
		Buyorsell:  "BUY",
		PriceType:  "LIMIT",
		Price:      "100.50",
		VolumeType: "AsEntered",
		Volume:     wrapperspb.Int32(100),
		Exchange:   "EXCHANGE1",
		Styp:       wrapperspb.Int32(1),
		Bank:       "BANK",
		Branch:     "BRANCH",
		Customer:   "CUSTOMER",
		Deposit:    "DEPOSIT",
		GoodUntil:  "DAY",
		Type:       "UserSubmitOrder",
		Route:      "ROUTE1",
	}
	order1.ExtendedFields["ORDER_TAG"] = orderTag1
	order1.ExtendedFields["ACCT_TYPE"] = "119"

	order2 := &pb_order.OrderRow{
		DispName:   "SYMBOL2",
		Buyorsell:  "SELL",
		PriceType:  "LIMIT",
		Price:      "50.25",
		VolumeType: "AsEntered",
		Volume:     wrapperspb.Int32(200),
		Exchange:   "EXCHANGE2",
		Styp:       wrapperspb.Int32(1),
		Bank:       "BANK",
		Branch:     "BRANCH",
		Customer:   "CUSTOMER",
		Deposit:    "DEPOSIT",
		GoodUntil:  "DAY",
		Type:       "UserSubmitOrder",
		Route:      "ROUTE2",
	}
	order2.ExtendedFields["ORDER_TAG"] = orderTag2
	order2.ExtendedFields["ACCT_TYPE"] = "119"

	request := &pb_order.BasketOrderRequest{
		UserToken: lib.GetUserToken(),
		Orders:    []*pb_order.OrderRow{order1, order2},
	}

	response, err := lib.OrderServiceStub.SubmitBasketOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitBasketOrder: " + err.Error())
		fmt.Println("Error calling SubmitBasketOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Basket Order Submitted:")
	fmt.Println("Number of Orders:", len(request.Orders))
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Order Tag 1:", orderTag1)
	fmt.Println("Order Tag 2:", orderTag2)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submitted basket order successfully.")
}
