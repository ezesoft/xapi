package order

import (
	"context"
	"fmt"

	"google.golang.org/protobuf/types/known/wrapperspb"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitAllocationOrder handles submitting an allocation order.
type ExampleSubmitAllocationOrder struct{}

// NewExampleSubmitAllocationOrder initializes a new instance.
func NewExampleSubmitAllocationOrder() *ExampleSubmitAllocationOrder {
	return &ExampleSubmitAllocationOrder{}
}

// Run executes the SubmitAllocationOrder API call.
func (e *ExampleSubmitAllocationOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubmitAllocationOrderRequest{
		UserToken:      lib.GetUserToken(),
		OrderId:        "12345678",
		Symbol:         "AAPL",
		Exchange:       "NASDAQ",
		SourceAccount:  "BANK;BRANCH;CUSTOMER;DEPOSIT",
		TargetAccount:  "TARGET_ACCOUNT",
		TargetQuantity: 100,
		TargetPrice:    wrapperspb.Double(150.50),
		TypeOfAllocation: &pb_order.AllocationType{
			AllocationOrAllocationEx: pb_order.AllocationType_UserSubmitAllocation,
		},
		OrderTypes: &pb_order.OrderType{
			TypeOfOrder: pb_order.OrderType_UserSubmitOrder,
		},
	}

	response, err := lib.OrderServiceStub.SubmitAllocationOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitAllocationOrder: " + err.Error())
		fmt.Println("Error calling SubmitAllocationOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Submit Allocation Order Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	if msg, ok := response.OptionalFields["ErrorMessage"]; ok {
		fmt.Println("Error Message:", msg)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submit allocation order request completed.")
}
