package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleChangePairOrder handles changing a pair order.
type ExampleChangePairOrder struct{}

// NewExampleChangePairOrder initializes a new instance.
func NewExampleChangePairOrder() *ExampleChangePairOrder {
	return &ExampleChangePairOrder{}
}

// Run executes the ChangePairOrder API call.
func (e *ExampleChangePairOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.ChangePairOrderRequest{
		UserToken:           lib.GetUserToken(),
		PairOrderId:         "12345678",
		Leg1_ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
		Leg2_ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
	}

	response, err := lib.OrderServiceStub.ChangePairOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling ChangePairOrder: " + err.Error())
		fmt.Println("Error calling ChangePairOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Change Pair Order Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	fmt.Println("Response received successfully")
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Change pair order request completed.")
}
