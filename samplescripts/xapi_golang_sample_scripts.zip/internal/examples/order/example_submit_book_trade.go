package order

import (
	"context"
	"fmt"

	"google.golang.org/protobuf/types/known/wrapperspb"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitBookTrade handles submitting a book trade.
type ExampleSubmitBookTrade struct{}

// NewExampleSubmitBookTrade initializes a new instance.
func NewExampleSubmitBookTrade() *ExampleSubmitBookTrade {
	return &ExampleSubmitBookTrade{}
}

// Run executes the SubmitBookTrade API call.
func (e *ExampleSubmitBookTrade) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	allocDetail := &pb_order.AllocationDetails{
		TargetAccount:  "BANK;BRANCH;CUSTOMER;DEPOSIT",
		TargetQuantity: 50,
		TargetPrice:    wrapperspb.Double(100.0),
		NetPrice:       wrapperspb.Double(99.5),
	}

	request := &pb_order.SubmitBookTradeRequest{
		UserToken:     lib.GetUserToken(),
		OrderId:       "ORDER123",
		SourceAccount: "SOURCE_ACCOUNT",
		OrderTag:      "BOOK_TRADE_TAG",
		AllocDetails:  []*pb_order.AllocationDetails{allocDetail},
	}

	response, err := lib.OrderServiceStub.SubmitBookTrade(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitBookTrade: " + err.Error())
		fmt.Println("Error calling SubmitBookTrade:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Submit Book Trade Response:")
	fmt.Println("Server Response:", response.ServerResponse)
	for k, v := range response.OptionalFields {
		fmt.Printf("  %s: %s\n", k, v)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submit book trade request completed.")
}
