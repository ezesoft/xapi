package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitSingleOrder handles submitting a single order.
type ExampleSubmitSingleOrder struct{}

// NewExampleSubmitSingleOrder initializes a new instance.
func NewExampleSubmitSingleOrder() *ExampleSubmitSingleOrder {
	return &ExampleSubmitSingleOrder{}
}

// Run executes the SubmitSingleOrder API call.
func (e *ExampleSubmitSingleOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubmitSingleOrderRequest{
		UserToken:      lib.GetUserToken(),
		Symbol:         "SYMBOL",
		Side:           "BUY/SELL",
		Quantity:       100,
		Route:          "ROUTE",
		Staged:         false,
		ClaimRequire:   false,
		Account:        "BANK;BRANCH;CUSTOMER;DEPOSIT",
		ExtendedFields: map[string]string{"ACCT_TYPE": "119"},
	}

	response, err := lib.OrderServiceStub.SubmitSingleOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error submitting single order: " + err.Error())
		fmt.Println("Error submitting single order:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println(response.String())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submitted single order successfully.")
}
