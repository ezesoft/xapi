package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubmitSeedData handles submitting seed data.
type ExampleSubmitSeedData struct{}

// NewExampleSubmitSeedData initializes a new instance.
func NewExampleSubmitSeedData() *ExampleSubmitSeedData {
	return &ExampleSubmitSeedData{}
}

// Run executes the SubmitSeedData API call.
func (e *ExampleSubmitSeedData) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubmitSeedDataRequest{
		UserToken: lib.GetUserToken(),
		Symbol:    "Symbol",
		Account:   "BANK;BRANCH;CUSTOMER;DEPOSIT",
	}

	response, err := lib.OrderServiceStub.SubmitSeedData(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling SubmitSeedData: " + err.Error())
		fmt.Println("Error calling SubmitSeedData:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Submit Seed Data:")
	fmt.Println("Account: BANK;BRANCH;CUSTOMER;DEPOSIT")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Submitted seed data successfully.")
}
