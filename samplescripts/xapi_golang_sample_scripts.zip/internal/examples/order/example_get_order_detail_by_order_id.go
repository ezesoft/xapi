package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleGetOrderDetailByOrderId handles fetching order details by order ID.
type ExampleGetOrderDetailByOrderId struct{}

// NewExampleGetOrderDetailByOrderId initializes a new instance.
func NewExampleGetOrderDetailByOrderId() *ExampleGetOrderDetailByOrderId {
	return &ExampleGetOrderDetailByOrderId{}
}

// Run executes the GetOrderDetailByOrderId API call.
func (e *ExampleGetOrderDetailByOrderId) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.OrderDetailByOrderIdRequest{
		UserToken: lib.GetUserToken(),
		OrderId:   "12345678",
	}

	response, err := lib.OrderServiceStub.GetOrderDetailByOrderId(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetOrderDetailByOrderId: " + err.Error())
		fmt.Println("Error calling GetOrderDetailByOrderId:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Order Details by Order ID:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Response received successfully")
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched order detail by order ID successfully.")
}
