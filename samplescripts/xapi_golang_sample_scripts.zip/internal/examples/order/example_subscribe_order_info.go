package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubscribeOrderInfo handles subscribing to order info stream.
type ExampleSubscribeOrderInfo struct{}

// NewExampleSubscribeOrderInfo initializes a new instance.
func NewExampleSubscribeOrderInfo() *ExampleSubscribeOrderInfo {
	return &ExampleSubscribeOrderInfo{}
}

// Run executes the SubscribeOrderInfo API call.
func (e *ExampleSubscribeOrderInfo) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubscribeOrderInfoRequest{
		UserToken: lib.GetUserToken(),
	}

	responseStream, err := lib.OrderServiceStub.SubscribeOrderInfo(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to order info: " + err.Error())
		fmt.Println("Error subscribing to order info:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving order info: " + err.Error())
			fmt.Println("Error receiving order info:", err)
			break
		}
		logMessage := fmt.Sprintf("SOI: UserToken %s Symbol %s Volume %d OrderID %s OrderTag %s Type %s CurrentStatus %s Reason %s",
			lib.UserTokenHash, response.Symbol, response.Volume, response.OrderId,
			response.OrderTag, response.Type, response.CurrentStatus, response.Reason)
		lib.Logger.LogMessage(logMessage)
		fmt.Println(logMessage)
	}
	lib.Logger.LogMessage("SubscribeOrderInfo ended.")
}
