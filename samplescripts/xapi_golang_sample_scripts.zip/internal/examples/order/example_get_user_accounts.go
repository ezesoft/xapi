package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleGetUserAccounts handles fetching user accounts.
type ExampleGetUserAccounts struct{}

// NewExampleGetUserAccounts initializes a new instance.
func NewExampleGetUserAccounts() *ExampleGetUserAccounts {
	return &ExampleGetUserAccounts{}
}

// Run executes the GetUserAccounts API call.
func (e *ExampleGetUserAccounts) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.UserAccountsRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.OrderServiceStub.GetUserAccounts(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetUserAccounts: " + err.Error())
		fmt.Println("Error calling GetUserAccounts:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("User Accounts:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	for k, v := range response.Accounts {
		fmt.Printf("  %s: %s\n", k, v)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched user accounts successfully.")
}
