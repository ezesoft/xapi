package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleSubscribeOrderInfoJson handles subscribing to order info JSON stream.
type ExampleSubscribeOrderInfoJson struct{}

// NewExampleSubscribeOrderInfoJson initializes a new instance.
func NewExampleSubscribeOrderInfoJson() *ExampleSubscribeOrderInfoJson {
	return &ExampleSubscribeOrderInfoJson{}
}

// Run executes the SubscribeOrderInfoJson API call.
func (e *ExampleSubscribeOrderInfoJson) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.SubscribeOrderInfoJsonRequest{
		UserToken: lib.GetUserToken(),
	}

	responseStream, err := lib.OrderServiceStub.SubscribeOrderInfoJson(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to order info JSON: " + err.Error())
		fmt.Println("Error subscribing to order info JSON:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving order info JSON: " + err.Error())
			fmt.Println("Error receiving order info JSON:", err)
			break
		}
		fmt.Println("------------------------------")
		fmt.Println("Order Info JSON:")
		fmt.Println(response.String())
		fmt.Println("------------------------------")
	}
	lib.Logger.LogMessage("SubscribeOrderInfoJson ended.")
}
