package order

import (
	"context"
	"fmt"

	pb_order "go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleCancelSingleOrder handles cancelling a single order.
type ExampleCancelSingleOrder struct{}

// NewExampleCancelSingleOrder initializes a new instance.
func NewExampleCancelSingleOrder() *ExampleCancelSingleOrder {
	return &ExampleCancelSingleOrder{}
}

// Run executes the CancelSingleOrder API call.
func (e *ExampleCancelSingleOrder) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &pb_order.CancelSingleOrderRequest{
		UserToken: lib.GetUserToken(),
		OrderId:   "ORDER_ID_PLACEHOLDER",
	}

	response, err := lib.OrderServiceStub.CancelSingleOrder(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling CancelSingleOrder: " + err.Error())
		fmt.Println("Error calling CancelSingleOrder:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Server Response:", response.ServerResponse)
	if response.ServerResponse == "Failed" {
		fmt.Println("Error Message:", response.OptionalFields["ErrorMessage"])
	} else {
		fmt.Println("Order cancelled successfully")
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Cancel single order request completed.")
}
