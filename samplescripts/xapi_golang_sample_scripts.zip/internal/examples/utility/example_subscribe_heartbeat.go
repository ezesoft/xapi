package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleSubscribeHeartBeat handles subscribing to heartbeat stream.
type ExampleSubscribeHeartBeat struct{}

// NewExampleSubscribeHeartBeat initializes a new instance.
func NewExampleSubscribeHeartBeat() *ExampleSubscribeHeartBeat {
	return &ExampleSubscribeHeartBeat{}
}

// Run executes the SubscribeHeartBeat API call.
func (e *ExampleSubscribeHeartBeat) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.SubscribeHeartBeatRequest{
		UserToken: lib.GetUserToken(),
	}

	responseStream, err := lib.UtilitySvcStub.SubscribeHeartBeat(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to heartbeat: " + err.Error())
		fmt.Println("Error subscribing to heartbeat:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving heartbeat: " + err.Error())
			fmt.Println("Error receiving heartbeat:", err)
			break
		}
		fmt.Println("Heartbeat received:", response.String())
	}
	lib.Logger.LogMessage("Heartbeat subscription ended.")
}
