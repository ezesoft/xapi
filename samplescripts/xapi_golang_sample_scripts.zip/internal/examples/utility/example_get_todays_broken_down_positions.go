package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysBrokenDownPositions handles fetching today's broken down positions.
type ExampleGetTodaysBrokenDownPositions struct{}

// NewExampleGetTodaysBrokenDownPositions initializes a new instance.
func NewExampleGetTodaysBrokenDownPositions() *ExampleGetTodaysBrokenDownPositions {
	return &ExampleGetTodaysBrokenDownPositions{}
}

// Run executes the GetTodaysBrokenDownPositions API call.
func (e *ExampleGetTodaysBrokenDownPositions) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysBrokenDownPositionsRequest{
		UserToken:        lib.GetUserToken(),
		TimeoutInSeconds: 30,
	}

	response, err := lib.UtilitySvcStub.GetTodaysBrokenDownPositions(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysBrokenDownPositions: " + err.Error())
		fmt.Println("Error calling GetTodaysBrokenDownPositions:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Today's Broken Down Positions:")
	for i, positionRecord := range response.PositionRecords {
		fmt.Println("-------------------------------------------------------")
		fmt.Printf(" POSITION RECORD - %d\n", i+1)
		fmt.Println(positionRecord.String())
	}
	fmt.Println("Total Records:", len(response.PositionRecords))
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched today's broken down positions successfully.")
}
