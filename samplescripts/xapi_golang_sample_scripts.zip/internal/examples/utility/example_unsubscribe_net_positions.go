package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleUnSubscribeNetPositions handles unsubscribing from net positions.
type ExampleUnSubscribeNetPositions struct{}

// NewExampleUnSubscribeNetPositions initializes a new instance.
func NewExampleUnSubscribeNetPositions() *ExampleUnSubscribeNetPositions {
	return &ExampleUnSubscribeNetPositions{}
}

// Run executes the UnSubscribeTodaysNetPositions API call.
func (e *ExampleUnSubscribeNetPositions) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.UnSubscribeNetPositionsRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.UtilitySvcStub.UnSubscribeTodaysNetPositions(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling UnSubscribeTodaysNetPositions: " + err.Error())
		fmt.Println("Error calling UnSubscribeTodaysNetPositions:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("UnSubscribe Net Positions:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	if msg := response.Acknowledgement.GetMessage(); msg != "" {
		fmt.Println("Message:", msg)
	}
	fmt.Println("Unsubscribed from net positions stream successfully")
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Unsubscribed from net positions successfully.")
}
