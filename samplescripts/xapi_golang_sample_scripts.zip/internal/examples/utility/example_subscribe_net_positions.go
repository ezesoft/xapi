package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleSubscribeNetPositions handles subscribing to net positions stream.
type ExampleSubscribeNetPositions struct{}

// NewExampleSubscribeNetPositions initializes a new instance.
func NewExampleSubscribeNetPositions() *ExampleSubscribeNetPositions {
	return &ExampleSubscribeNetPositions{}
}

// Run executes the SubscribeTodaysNetPositions API call.
func (e *ExampleSubscribeNetPositions) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.SubscribeNetPositionsRequest{
		UserToken:        lib.GetUserToken(),
		TimeoutInSeconds: 30,
	}

	responseStream, err := lib.UtilitySvcStub.SubscribeTodaysNetPositions(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error subscribing to net positions: " + err.Error())
		fmt.Println("Error subscribing to net positions:", err)
		return
	}

	for {
		response, err := responseStream.Recv()
		if err != nil {
			lib.Logger.LogMessage("Error receiving net positions: " + err.Error())
			fmt.Println("Error receiving net positions:", err)
			break
		}
		fmt.Println("------------------------------")
		fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
		fmt.Println(response.AggregatePositions.String())
		fmt.Println("------------------------------")
	}
	lib.Logger.LogMessage("Net positions subscription ended.")
}
