package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysBalances handles fetching today's balances.
type ExampleGetTodaysBalances struct{}

// NewExampleGetTodaysBalances initializes a new instance.
func NewExampleGetTodaysBalances() *ExampleGetTodaysBalances {
	return &ExampleGetTodaysBalances{}
}

// Run executes the GetTodaysBalances API call.
func (e *ExampleGetTodaysBalances) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysBalancesRequest{
		UserToken:        lib.GetUserToken(),
		TimeoutInSeconds: 30,
	}

	response, err := lib.UtilitySvcStub.GetTodaysBalances(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysBalances: " + err.Error())
		fmt.Println("Error calling GetTodaysBalances:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Today's Balances:")
	for i, depositRecord := range response.DepositList {
		fmt.Printf("--------------- Deposit Num: %d START ---------------\n", i)
		fmt.Println(depositRecord.String())
		fmt.Printf("--------------- Deposit Num: %d END ---------------\n", i)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched today's balances successfully.")
}
