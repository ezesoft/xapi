package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetStrategyList handles fetching the strategy list.
type ExampleGetStrategyList struct{}

// NewExampleGetStrategyList initializes a new instance.
func NewExampleGetStrategyList() *ExampleGetStrategyList {
	return &ExampleGetStrategyList{}
}

// Run executes the GetStrategyList API call.
func (e *ExampleGetStrategyList) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.StrategyListRequest{
		UserToken: lib.GetUserToken(),
		FirmName:  "EXAMPLE_FIRM",
	}

	response, err := lib.UtilitySvcStub.GetStrategyList(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetStrategyList: " + err.Error())
		fmt.Println("Error calling GetStrategyList:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Strategy List:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Strategies:", len(response.StrategyList))
	for i, strategy := range response.StrategyList {
		fmt.Printf("Strategy %d: %s\n", i+1, strategy.String())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched strategy list successfully.")
}
