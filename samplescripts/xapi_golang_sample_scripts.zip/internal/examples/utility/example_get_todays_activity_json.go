package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysActivityJson handles fetching today's activity as JSON.
type ExampleGetTodaysActivityJson struct{}

// NewExampleGetTodaysActivityJson initializes a new instance.
func NewExampleGetTodaysActivityJson() *ExampleGetTodaysActivityJson {
	return &ExampleGetTodaysActivityJson{}
}

// Run executes the GetTodaysActivityJson API call.
func (e *ExampleGetTodaysActivityJson) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysActivityJsonRequest{
		UserToken:                    lib.GetUserToken(),
		TimeoutInSeconds:             30,
		IncludeUserSubmitOrder:       true,
		IncludeUserSubmitStagedOrder: true,
		IncludeUserSubmitCompoundOrder: true,
		IncludeForeignExecution:      true,
		IncludeUserSubmitChange:      true,
		IncludeUserSubmitCancel:      true,
		IncludeExchangeAcceptOrder:   true,
		IncludeExchangeTradeOrder:    true,
		IncludeUserSubmitTradeReport: true,
		IncludeUserSubmitAllocation:  true,
		IncludeUserSubmitAllocationEx: true,
		IncludeClerkReject:           true,
		IncludeOnlyCompleted:         true,
	}

	response, err := lib.UtilitySvcStub.GetTodaysActivityJson(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysActivityJson: " + err.Error())
		fmt.Println("Error calling GetTodaysActivityJson:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Today's Activity JSON:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Activity JSON:", response.TodaysActivityJson)
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched today's activity JSON successfully.")
}
