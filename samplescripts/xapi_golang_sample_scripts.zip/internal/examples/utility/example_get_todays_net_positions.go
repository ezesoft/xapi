package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysNetPositions handles fetching today's net positions.
type ExampleGetTodaysNetPositions struct{}

// NewExampleGetTodaysNetPositions initializes a new instance.
func NewExampleGetTodaysNetPositions() *ExampleGetTodaysNetPositions {
	return &ExampleGetTodaysNetPositions{}
}

// Run executes the GetTodaysNetPositions API call.
func (e *ExampleGetTodaysNetPositions) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysNetPositionsRequest{
		UserToken:        lib.GetUserToken(),
		TimeoutInSeconds: 30,
	}

	response, err := lib.UtilitySvcStub.GetTodaysNetPositions(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysNetPositions: " + err.Error())
		fmt.Println("Error calling GetTodaysNetPositions:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("Number of Aggregate Positions:", len(response.AggregatePositionsList))
	for i, pos := range response.AggregatePositionsList {
		fmt.Printf("Position %d: %s\n", i+1, pos.String())
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched today's net positions successfully.")
}
