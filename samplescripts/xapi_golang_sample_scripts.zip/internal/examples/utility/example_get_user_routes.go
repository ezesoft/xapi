package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetUserRoutes handles fetching user routes.
type ExampleGetUserRoutes struct{}

// NewExampleGetUserRoutes initializes a new instance.
func NewExampleGetUserRoutes() *ExampleGetUserRoutes {
	return &ExampleGetUserRoutes{}
}

// Run executes the GetUserRoutes API call.
func (e *ExampleGetUserRoutes) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.GetUserRoutesRequest{
		UserToken:   lib.GetUserToken(),
		AccountList: "BANK;BRANCH;CUSTOMER;DEPOSIT",
	}

	response, err := lib.UtilitySvcStub.GetUserRoutes(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetUserRoutes: " + err.Error())
		fmt.Println("Error calling GetUserRoutes:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Get User Routes:")
	fmt.Println("Server Response:", response.Acknowledgement.GetServerResponse())
	fmt.Println("User Routes:")
	for k, v := range response.UserRoutes {
		fmt.Printf("  %s: %s\n", k, v)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("Fetched user routes successfully.")
}
