package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleChangePasswordSRP handles changing a password using SRP.
type ExampleChangePasswordSRP struct{}

// NewExampleChangePasswordSRP initializes a new instance.
func NewExampleChangePasswordSRP() *ExampleChangePasswordSRP {
	return &ExampleChangePasswordSRP{}
}

// Run executes the ChangePasswordSRP API call.
// NOTE: This is a sensitive operation. Replace placeholder values with actual credentials.
func (e *ExampleChangePasswordSRP) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.ChangePasswordSRPRequest{
		UserName:    lib.Config.User,
		Domain:      lib.Config.Domain,
		OldPassword: "OLD_PASSWORD_PLACEHOLDER",
		NewPassword: "NEW_PASSWORD_PLACEHOLDER",
	}

	response, err := lib.UtilitySvcStub.ChangePasswordSRP(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling ChangePasswordSRP: " + err.Error())
		fmt.Println("Error calling ChangePasswordSRP:", err)
		return
	}

	fmt.Println("------------------------------")
	fmt.Println("Change Password SRP Response:")
	fmt.Println("Status:", response.Status)
	if response.Message != "" {
		fmt.Println("Message:", response.Message)
	}
	fmt.Println("------------------------------")
	lib.Logger.LogMessage("ChangePasswordSRP request completed.")
}
