package utility

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysActivity handles fetching today's activity.
type ExampleGetTodaysActivity struct{}

// NewExampleGetTodaysActivity initializes a new instance.
func NewExampleGetTodaysActivity() *ExampleGetTodaysActivity {
	return &ExampleGetTodaysActivity{}
}

// Run executes the GetTodaysActivity API call.
func (e *ExampleGetTodaysActivity) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysActivityRequest{
		UserToken: lib.GetUserToken(),
	}

	// To Filter based on Order Type - uncomment as needed:
	// request.IncludeUserSubmitOrder = false
	// request.IncludeUserSubmitStagedOrder = false
	// request.IncludeUserSubmitCompoundOrder = false
	// request.IncludeForeignExecution = false
	// request.IncludeUserSubmitChange = false
	// request.IncludeUserSubmitCancel = false
	// request.IncludeExchangeAcceptOrder = false
	// request.IncludeExchangeTradeOrder = false
	// request.IncludeUserSubmitTradeReport = false
	// request.IncludeUserSubmitAllocation = false
	// request.IncludeUserSubmitAllocationEx = false
	// request.IncludeClerkReject = false

	// To Filter based on CurrentStatus as Completed - set to true:
	// request.IncludeOnlyCompleted = false

	// To Filter based on UserSubmitStagedOrder and its child - set to true:
	// request.UserSubmitStagedOrderFullInfo = false

	response, err := lib.UtilitySvcStub.GetTodaysActivity(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysActivity: " + err.Error())
		fmt.Println("Error calling GetTodaysActivity:", err)
		return
	}

	fmt.Println(response.Acknowledgement.GetServerResponse())
	for i, orderRecord := range response.OrderRecordList {
		fmt.Printf("--------------- Order Num: %d START ---------------\n", i)
		fmt.Println(orderRecord.String())
		fmt.Printf("--------------- Order Num: %d END ---------------\n", i)
	}
	lib.Logger.LogMessage("Fetched today's activity successfully.")
}
