package common

import "fmt"

// RequestFailedError represents an error when a request fails.
type RequestFailedError struct {
	Message string
}

// Error implements the error interface for RequestFailedError.
func (e *RequestFailedError) Error() string {
	return e.Message
}

// NewRequestFailedError creates a new RequestFailedError with a default message.
func NewRequestFailedError() *RequestFailedError {
	return &RequestFailedError{
		Message: "Request failed",
	}
}

// NewRequestFailedErrorWithMessage creates a new RequestFailedError with a custom message.
func NewRequestFailedErrorWithMessage(message string) *RequestFailedError {
	return &RequestFailedError{
		Message: message,
	}
}

// NewRequestFailedErrorWithCause creates a new RequestFailedError with a custom message and cause.
func NewRequestFailedErrorWithCause(message string, cause error) *RequestFailedError {
	return &RequestFailedError{
		Message: fmt.Sprintf("%s: %v", message, cause),
	}
}
