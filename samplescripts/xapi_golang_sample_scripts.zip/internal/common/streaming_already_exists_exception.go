package common

import (
	"fmt"
	"os"
)

// StreamingAlreadyExistsError represents an error when a streaming session already exists.
type StreamingAlreadyExistsError struct {
	Message string
	logFile *os.File
}

// Error implements the error interface for StreamingAlreadyExistsError.
func (e *StreamingAlreadyExistsError) Error() string {
	return e.Message
}

// NewStreamingAlreadyExistsError creates a new StreamingAlreadyExistsError with a default message.
func NewStreamingAlreadyExistsError(logFilePath string) (*StreamingAlreadyExistsError, error) {
	file, err := os.OpenFile(logFilePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return nil, fmt.Errorf("failed to open log file: %w", err)
	}
	return &StreamingAlreadyExistsError{
		Message: "Streaming already exists",
		logFile: file,
	}, nil
}

// NewStreamingAlreadyExistsErrorWithMessage creates a new StreamingAlreadyExistsError with a custom message.
func NewStreamingAlreadyExistsErrorWithMessage(message, logFilePath string, logger *Logger) (*StreamingAlreadyExistsError, error) {
	logMessage := fmt.Sprintf("Error: %s\n", message)
	logger.LogMessage(logMessage)
	return &StreamingAlreadyExistsError{
		Message: message,
	}, nil
}

// NewStreamingAlreadyExistsErrorWithCause creates a new StreamingAlreadyExistsError with a custom message and cause.
func NewStreamingAlreadyExistsErrorWithCause(message string, cause error, logger *Logger) (*StreamingAlreadyExistsError, error) {
	logMessage := fmt.Sprintf("Error: %s: %v\n", message, cause)
	logger.LogMessage(logMessage)
	return &StreamingAlreadyExistsError{
		Message: fmt.Sprintf("%s: %v", message, cause),
	}, nil
}

// Close closes the log file.
func (e *StreamingAlreadyExistsError) Close() error {
	if e.logFile != nil {
		return e.logFile.Close()
	}
	return nil
}
