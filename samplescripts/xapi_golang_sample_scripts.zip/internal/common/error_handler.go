package common

import (
	"context"
	"fmt"
	"os"
)

// ErrorHandler handles errors in the application.
type ErrorHandler struct {
	logFile *os.File
}

// NewErrorHandler initializes a new ErrorHandler with a log file.
func NewErrorHandler(logFilePath string) (*ErrorHandler, error) {
	file, err := os.OpenFile(logFilePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return nil, fmt.Errorf("failed to open log file: %w", err)
	}
	return &ErrorHandler{logFile: file}, nil
}

// OnError handles an error by logging it and performing cleanup actions.
func (e *ErrorHandler) OnError(ctx context.Context, err error, lib *EMSXAPILibrary, logger *Logger) {
	if err != nil {
		logMessage := fmt.Sprintf("===error in library===\n%v\n", err)
		logger.LogMessage(logMessage)
		if lib != nil {
			lib.StopHeartbeat()
			lib.Logout(ctx)
			lib.CloseChannel()
		}
	}
}

// Close closes the log file.
func (e *ErrorHandler) Close() error {
	if e.logFile != nil {
		return e.logFile.Close()
	}
	return nil
}
