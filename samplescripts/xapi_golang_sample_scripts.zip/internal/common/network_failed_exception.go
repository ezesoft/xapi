package common

import "fmt"

// NetworkFailedError represents an error when there is a network failure.
type NetworkFailedError struct {
	Message string
}

// Error implements the error interface for NetworkFailedError.
func (e *NetworkFailedError) Error() string {
	return e.Message
}

// NewNetworkFailedError creates a new NetworkFailedError with a default message.
func NewNetworkFailedError() *NetworkFailedError {
	return &NetworkFailedError{
		Message: "Failure in network",
	}
}

// NewNetworkFailedErrorWithMessage creates a new NetworkFailedError with a custom message.
func NewNetworkFailedErrorWithMessage(message string) *NetworkFailedError {
	return &NetworkFailedError{
		Message: message,
	}
}

// NewNetworkFailedErrorWithCause creates a new NetworkFailedError with a custom message and cause.
func NewNetworkFailedErrorWithCause(message string, cause error) *NetworkFailedError {
	return &NetworkFailedError{
		Message: fmt.Sprintf("%s: %v", message, cause),
	}
}
