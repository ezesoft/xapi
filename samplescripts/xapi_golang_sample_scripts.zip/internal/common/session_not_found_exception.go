package common

import (
	"fmt"
)

// SessionNotFoundError represents an error when a session is not found.
type SessionNotFoundError struct {
	Message string
}

// Error implements the error interface for SessionNotFoundError.
func (e *SessionNotFoundError) Error() string {
	return e.Message
}

// NewSessionNotFoundError creates a new SessionNotFoundError with a default message.
func NewSessionNotFoundError() *SessionNotFoundError {
	return &SessionNotFoundError{
		Message: "Session not found.",
	}
}

// NewSessionNotFoundErrorWithMessage creates a new SessionNotFoundError with a custom message and logs the error message.
func NewSessionNotFoundErrorWithMessage(message string, logger *Logger) *SessionNotFoundError {
	logMessage := fmt.Sprintf("Error: %s\n", message)
	logger.LogMessage(logMessage)
	return &SessionNotFoundError{
		Message: message,
	}
}
