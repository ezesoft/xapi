package common

import "fmt"

// LoginFailedError represents an error when login fails.
type LoginFailedError struct {
	Message string
}

// Error implements the error interface for LoginFailedError.
func (e *LoginFailedError) Error() string {
	return e.Message
}

// NewLoginFailedError creates a new LoginFailedError with a default message.
func NewLoginFailedError() *LoginFailedError {
	return &LoginFailedError{
		Message: "Login failed",
	}
}

// NewLoginFailedErrorWithMessage creates a new LoginFailedError with a custom message.
func NewLoginFailedErrorWithMessage(message string) *LoginFailedError {
	return &LoginFailedError{
		Message: message,
	}
}

// NewLoginFailedErrorWithCause creates a new LoginFailedError with a custom message and cause.
func NewLoginFailedErrorWithCause(message string, cause error) *LoginFailedError {
	return &LoginFailedError{
		Message: fmt.Sprintf("%s: %v", message, cause),
	}
}
