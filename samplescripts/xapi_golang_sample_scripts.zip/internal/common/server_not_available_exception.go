package common

import (
	"fmt"
)

// ServerNotAvailableError represents an error when the server is not responding.
type ServerNotAvailableError struct {
	Message string
}

// Error implements the error interface for ServerNotAvailableError.
func (e *ServerNotAvailableError) Error() string {
	return e.Message
}

// NewServerNotAvailableError creates a new ServerNotAvailableError with a default message.
func NewServerNotAvailableError() *ServerNotAvailableError {
	return &ServerNotAvailableError{
		Message: "Server not responding",
	}
}

// NewServerNotAvailableErrorWithMessage creates a new ServerNotAvailableError with a custom message.
func NewServerNotAvailableErrorWithMessage(message string) *ServerNotAvailableError {
	return &ServerNotAvailableError{
		Message: message,
	}
}

// NewServerNotAvailableErrorWithCause creates a new ServerNotAvailableError with a custom message and cause.
func NewServerNotAvailableErrorWithCause(message string, cause error) *ServerNotAvailableError {
	return &ServerNotAvailableError{
		Message: fmt.Sprintf("%s: %v", message, cause),
	}
}
