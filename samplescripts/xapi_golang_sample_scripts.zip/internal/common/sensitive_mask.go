package common

import (
	"crypto/sha256"
	"encoding/base64"
)

// SensitiveMask provides utility functions for masking sensitive data.
type SensitiveMask struct{}

// Sha256 returns a SHA-256 hash of the input string, suitable for logging.
// If the input is empty or null, it returns the provided default value.
func (s *SensitiveMask) Sha256(sensitive string, valueIfEmpty string) string {
	if len(sensitive) == 0 {
		return valueIfEmpty
	}

	utfBytes := []byte(sensitive)
	hash := sha256.Sum256(utfBytes)
	return base64.StdEncoding.EncodeToString(hash[:])
}
