package common

import (
	"log"
	"os"
)

// Logger is a custom logger for the application.
type Logger struct {
	logFile *os.File
}

// NewLogger initializes a new Logger with a log file.
func NewLogger(logFilePath string) (*Logger, error) {
	file, err := os.OpenFile(logFilePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return nil, err
	}
	log.SetOutput(file)
	return &Logger{logFile: file}, nil
}

// LogMessage logs a message to the log file and console.
func (l *Logger) LogMessage(message string) {
	log.Println(message)
}

// Close closes the log file.
func (l *Logger) Close() error {
	if l.logFile != nil {
		return l.logFile.Close()
	}
	return nil
}
