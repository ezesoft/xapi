package common

import (
	"fmt"
	"strconv"
	"strings"

	"gopkg.in/ini.v1"
)

// Config holds the configuration values.
type Config struct {
	User             string
	Password         string
	Server           string
	Domain           string
	Port             int
	Locale           string
	KeepAliveTime    int
	KeepAliveTimeout int
	SSL              bool
	SrpLogin         bool
	MaxRetryCount    int
	RetryDelayMS     int
	Route            string
	Account          []string
	CertFilePath     string // Path to CA certificate file
	MaxMessageSize   int    // Maximum gRPC message size in bytes
}

// LoadConfig reads the configuration from the given file path.
func LoadConfig(filePath string) (*Config, error) {
	cfg, err := ini.Load(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to load config file: %w", err)
	}

	section := cfg.Section("Auth Config Section")

	port, _ := strconv.Atoi(section.Key("port").String())
	keepAliveTime, _ := strconv.Atoi(section.Key("keepAliveTime").String())
	keepAliveTimeout, _ := strconv.Atoi(section.Key("keepAliveTimeout").String())
	ssl, _ := strconv.ParseBool(section.Key("ssl").String())
	srpLogin, _ := strconv.ParseBool(section.Key("srp_login").String())
	maxRetryCount, _ := strconv.Atoi(section.Key("maxRetryCount").String())
	retryDelayMS, _ := strconv.Atoi(section.Key("retryDelayMS").String())
	account := strings.Split(section.Key("account").String(), ";")
	certFilePath := section.Key("cert_file_path").String()
	maxMsgSizeStr := section.Key("max_message_size").String()
	maxMsgSize := 100 * 1024 * 1024 // Default 100MB
	if maxMsgSizeStr != "" {
		if v, err := strconv.Atoi(maxMsgSizeStr); err == nil && v > 0 {
			maxMsgSize = v
		}
	}

	return &Config{
		User:             section.Key("user").String(),
		Password:         section.Key("password").String(),
		Server:           section.Key("server").String(),
		Domain:           section.Key("domain").String(),
		Port:             port,
		Locale:           section.Key("locale").String(),
		KeepAliveTime:    keepAliveTime,
		KeepAliveTimeout: keepAliveTimeout,
		SSL:              ssl,
		SrpLogin:         srpLogin,
		MaxRetryCount:    maxRetryCount,
		RetryDelayMS:     retryDelayMS,
		Route:            section.Key("route").String(),
		Account:          account,
		CertFilePath:     certFilePath,
		MaxMessageSize:   maxMsgSize,
	}, nil
}
