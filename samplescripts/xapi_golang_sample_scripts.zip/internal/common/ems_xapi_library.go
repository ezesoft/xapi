package common

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"sync"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/keepalive"

	"go-xapi/generated/market_data"
	"go-xapi/generated/order"
	"go-xapi/generated/utilities"
)

// EMSXAPILibrary represents the main API library.
type EMSXAPILibrary struct {
	Config           *Config
	Channel          *grpc.ClientConn
	UtilitySvcStub   utilities.UtilityServicesClient
	MarketDataStub   market_data.MarketDataServiceClient
	OrderServiceStub order.SubmitOrderServiceClient
	UserToken        string
	UserTokenHash    string
	HeartbeatExit    chan bool
	HeartbeatWG      sync.WaitGroup
	LoggedInStatus   bool
	LogInLock        sync.Mutex
	LogOutLock       sync.Mutex
	IsLoggedInLock   sync.Mutex
	Logger           *Logger
	ErrHandler       *ErrorHandler
	SensitiveMask    *SensitiveMask
}

// Singleton instance and synchronization
var (
	instance     *EMSXAPILibrary
	instanceOnce sync.Once
)

// Create initializes the singleton instance of EMSXAPILibrary.
func Create(configFileName string) {
	instanceOnce.Do(func() {
		logger, err := NewLogger("application-log.log")
		if err != nil {
			fmt.Printf("Failed to initialize logger: %v\n", err)
			return
		}
		config, err := LoadConfig(configFileName)
		if err != nil {
			logger.LogMessage(fmt.Sprintf("Failed to load config: %v", err))
			return
		}

		errHandler := &ErrorHandler{}
		instance, err = NewEMSXAPILibrary(config, logger, errHandler)
		if err != nil {
			logger.LogMessage(fmt.Sprintf("Failed to create EMSXAPILibrary: %v", err))
			return
		}
	})
}

// Get returns the singleton instance of EMSXAPILibrary.
func Get() *EMSXAPILibrary {
	return instance
}

// NewEMSXAPILibrary initializes a new EMSXAPILibrary instance.
func NewEMSXAPILibrary(config *Config, logger *Logger, errHandler *ErrorHandler) (*EMSXAPILibrary, error) {
	lib := &EMSXAPILibrary{
		Config:        config,
		Logger:        logger,
		ErrHandler:    errHandler,
		HeartbeatExit: make(chan bool),
	}

	if err := lib.OpenChannel(); err != nil {
		return nil, fmt.Errorf("failed to open channel: %w", err)
	}
	lib.Logger.LogMessage("Channel opened successfully")
	lib.Logger.LogMessage("EMSXAPILibrary initialized successfully")
	lib.InitStubs()
	return lib, nil
}

// OpenChannel establishes a gRPC connection.
func (lib *EMSXAPILibrary) OpenChannel() error {
	address := fmt.Sprintf("%s:%d", lib.Config.Server, lib.Config.Port)

	// Set gRPC dial options
	dialOptions := []grpc.DialOption{
		grpc.WithDefaultCallOptions(
			grpc.MaxCallRecvMsgSize(lib.Config.MaxMessageSize),
		),
		grpc.WithKeepaliveParams(keepalive.ClientParameters{
			Time:                time.Duration(lib.Config.KeepAliveTime) * time.Millisecond,
			Timeout:             time.Duration(lib.Config.KeepAliveTimeout) * time.Millisecond,
			PermitWithoutStream: true,
		}),
	}

	if lib.Config.SSL && lib.Config.CertFilePath != "" {
		certFile := lib.Config.CertFilePath
		if _, err := os.Stat(certFile); os.IsNotExist(err) {
			return fmt.Errorf("certificate file %s does not exist", certFile)
		}

		certData, err := os.ReadFile(certFile)
		if err != nil {
			return fmt.Errorf("failed to read cert file: %v", err)
		}

		certPool := x509.NewCertPool()
		if !certPool.AppendCertsFromPEM(certData) {
			return fmt.Errorf("failed to append certificates")
		}

		// TLS Config with hostname verification override
		tlsConfig := &tls.Config{
			InsecureSkipVerify: true, // Skip default hostname verification
			ServerName:         lib.Config.Server,
			VerifyPeerCertificate: func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
				certs := make([]*x509.Certificate, len(rawCerts))
				for i, asn1Data := range rawCerts {
					cert, err := x509.ParseCertificate(asn1Data)
					if err != nil {
						return fmt.Errorf("failed to parse certificate: %w", err)
					}
					certs[i] = cert
				}

				opts := x509.VerifyOptions{
					Roots: certPool,
				}

				// Verify chain (but skip SAN hostname matching)
				if _, err := certs[0].Verify(opts); err != nil {
					return fmt.Errorf("failed to verify certificate chain: %w", err)
				}

				return nil // ✅ Certificate chain is trusted
			},
		}

		creds := credentials.NewTLS(tlsConfig)
		dialOptions = append(dialOptions, grpc.WithTransportCredentials(creds))
	} else {
		dialOptions = append(dialOptions, grpc.WithTransportCredentials(insecure.NewCredentials()))
	}

	conn, err := grpc.Dial(address, dialOptions...)
	if err != nil {
		return fmt.Errorf("failed to connect to gRPC server: %v", err)
	}

	lib.Channel = conn
	return nil
}

// CloseChannel closes the gRPC connection.
func (lib *EMSXAPILibrary) CloseChannel() error {
	if lib.Channel != nil {
		if err := lib.Channel.Close(); err != nil {
			return err
		}
		lib.Channel = nil
	}
	return nil
}

// InitStubs initializes gRPC service stubs.
func (lib *EMSXAPILibrary) InitStubs() {
	lib.UtilitySvcStub = utilities.NewUtilityServicesClient(lib.Channel)
	lib.MarketDataStub = market_data.NewMarketDataServiceClient(lib.Channel)
	lib.OrderServiceStub = order.NewSubmitOrderServiceClient(lib.Channel)
	lib.Logger.LogMessage("Stubs initialized successfully")
}

// IsLoggedIn returns the login status.
func (lib *EMSXAPILibrary) IsLoggedIn() bool {
	lib.IsLoggedInLock.Lock()
	defer lib.IsLoggedInLock.Unlock()
	return lib.LoggedInStatus
}

// Login performs the login operation.
func (lib *EMSXAPILibrary) Login(ctx context.Context) error {
	lib.LogInLock.Lock()
	defer lib.LogInLock.Unlock()
	lib.Logger.LogMessage("Login function called")

	if lib.IsLoggedIn() {
		lib.Logger.LogMessage("Already logged in")
		return nil
	}

	// Non-SRP login flow
	connectReq := &utilities.ConnectRequest{
		UserName: lib.Config.User,
		Domain:   lib.Config.Domain,
		Password: lib.Config.Password,
		Locale:   lib.Config.Locale,
	}
	connectResp, err := lib.UtilitySvcStub.Connect(ctx, connectReq)
	if err != nil || connectResp.Response != "success" {
		return fmt.Errorf("failed to login: %v", err)
	}
	lib.SetUserToken(connectResp.UserToken)

	lib.Logger.LogMessage("Login successful")
	lib.LoggedInStatus = true
	return nil
}

// Logout performs the logout operation.
func (lib *EMSXAPILibrary) Logout(ctx context.Context) error {
	lib.LogOutLock.Lock()
	defer lib.LogOutLock.Unlock()

	if !lib.IsLoggedIn() {
		return nil
	}

	req := &utilities.DisconnectRequest{
		UserToken: lib.UserToken,
	}

	resp, err := lib.UtilitySvcStub.Disconnect(ctx, req)
	if err != nil {
		return fmt.Errorf("logout failed: %w", err)
	}

	if resp.ServerResponse != "success" {
		return fmt.Errorf("logout failed: %s", resp.ServerResponse)
	}

	lib.LoggedInStatus = false
	lib.Logger.LogMessage("Logout successful")
	return nil
}

// StartListeningHeartbeat starts the heartbeat monitoring.
func (lib *EMSXAPILibrary) StartListeningHeartbeat(ctx context.Context, reqTimeout int) {
	lib.HeartbeatWG.Add(1)
	go func() {
		defer lib.HeartbeatWG.Done()
		for {
			select {
			case <-lib.HeartbeatExit:
				return
			case <-time.After(time.Duration(reqTimeout) * time.Second):
				lib.Logger.LogMessage("Heartbeat check")
				// Add heartbeat logic here
			}
		}
	}()
}

// StopHeartbeat stops the heartbeat monitoring.
func (lib *EMSXAPILibrary) StopHeartbeat() {
	close(lib.HeartbeatExit)
	lib.HeartbeatWG.Wait()
}

// SuspendHeartbeatThread stops the heartbeat thread gracefully.
func (lib *EMSXAPILibrary) SuspendHeartbeatThread() {
	if lib.HeartbeatExit != nil {
		close(lib.HeartbeatExit)
		lib.HeartbeatWG.Wait()
		lib.Logger.LogMessage("Heartbeat thread suspended")
	}
}

// CanConnectToServer checks if the server is reachable.
func (lib *EMSXAPILibrary) CanConnectToServer() bool {
	conn, err := net.DialTimeout("tcp", net.JoinHostPort(lib.Config.Server, fmt.Sprintf("%d", lib.Config.Port)), 3*time.Second)
	if err != nil {
		return false
	}
	_ = conn.Close()
	return true
}

// SetUserToken sets the user token and its hash.
func (lib *EMSXAPILibrary) SetUserToken(token string) {
	lib.UserToken = token
	lib.UserTokenHash = lib.SensitiveMask.Sha256(token, "some_salt_or_key")
}

// GetUserToken returns the user token.
func (lib *EMSXAPILibrary) GetUserToken() string {
	return lib.UserToken
}

// GetUserTokenHash returns the hashed user token.
func (lib *EMSXAPILibrary) GetUserTokenHash() string {
	return lib.UserTokenHash
}

// Helper functions for byte manipulation and concatenation

// Concat concatenates multiple byte slices into one.
func Concat(initial []byte, args ...[]byte) []byte {
	result := append([]byte{}, initial...)
	for _, arg := range args {
		result = append(result, arg...)
	}
	return result
}

// GetBytesFromHexEncoded converts a hex-encoded string to a byte slice.
func GetBytesFromHexEncoded(strSource string) ([]byte, error) {
	if len(strSource)%2 != 0 {
		return nil, fmt.Errorf("invalid hex string length")
	}
	return hex.DecodeString(strSource)
}

// GetHexEncodedStringFromBytes converts a byte slice to a hex-encoded string.
func GetHexEncodedStringFromBytes(array []byte) string {
	return hex.EncodeToString(array)
}
