package utils

import (
	"context"
	"fmt"
	"go-xapi/generated/market_data"
	"go-xapi/internal/common"
	"time"
)

type ExampleSubscribeLevel2Ticks struct{}

func NewExampleSubscribeLevel2Ticks() *ExampleSubscribeLevel2Ticks {
	return &ExampleSubscribeLevel2Ticks{}
}

func (e *ExampleSubscribeLevel2Ticks) Run() {
	fmt.Println("[SubscribeLevel2Ticks] Starting Level 2 subscription example...")
	lib := common.Get()
	if lib == nil {
		fmt.Println("[SubscribeLevel2Ticks] EMSXAPILibrary instance is nil")
		return
	}

	req := &market_data.Level2MarketDataRequest{
		UserToken: lib.GetUserToken(),
		Symbols:   []string{"AAPL", "MSFT"},
		Request:   true,
		Advise:    true,
	}

	fmt.Printf("[SubscribeLevel2Ticks] Subscribing with request: %+v\n", req)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	stream, err := lib.MarketDataStub.SubscribeLevel2Ticks(ctx, req)
	if err != nil {
		fmt.Println("[SubscribeLevel2Ticks] SubscribeLevel2Ticks error:", err)
		lib.Logger.LogMessage("Error subscribing to Level 2 ticks: " + err.Error())
		return
	}
	fmt.Println("[SubscribeLevel2Ticks] Subscribed to Level2Ticks. Streaming data:")
	for i := 0; i < 10; i++ {
		fmt.Printf("[SubscribeLevel2Ticks] Waiting for Level2Tick %d...\n", i+1)
		msg, err := stream.Recv()
		if err != nil {
			fmt.Println("[SubscribeLevel2Ticks] Stream receive error:", err)
			lib.Logger.LogMessage("Stream receive error in Level 2 ticks: " + err.Error())
			break
		}
		fmt.Printf("[SubscribeLevel2Ticks] Level2Tick %d: %+v\n", i+1, msg)
	}
	lib.Logger.LogMessage("Level 2 tick subscription ended or completed.")
}
