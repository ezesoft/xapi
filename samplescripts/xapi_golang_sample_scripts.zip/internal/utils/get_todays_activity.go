package utils

import (
	"context"
	"fmt"

	"go-xapi/generated/utilities"
	"go-xapi/internal/common"
)

// ExampleGetTodaysActivity represents the logic for fetching today's activity.
type ExampleGetTodaysActivity struct{}

// NewExampleGetTodaysActivity initializes a new instance.
func NewExampleGetTodaysActivity() *ExampleGetTodaysActivity {
	return &ExampleGetTodaysActivity{}
}

// Run executes the GetTodaysActivity API call.
func (e *ExampleGetTodaysActivity) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &utilities.TodaysActivityRequest{
		UserToken: lib.GetUserToken(),
	}

	// Example filters (uncomment and set as needed)
	// request.IncludeUserSubmitOrder = false
	// request.IncludeOnlyCompleted = false

	response, err := lib.UtilitySvcStub.GetTodaysActivity(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error calling GetTodaysActivity: " + err.Error())
		fmt.Println("Error calling GetTodaysActivity:", err)
		return
	}

	fmt.Println("Acknowledgement:", response.Acknowledgement.ServerResponse)
	for i, orderRecord := range response.OrderRecordList {
		fmt.Printf("--------------- Order Num: %d START ---------------\n", i)
		fmt.Println(orderRecord.String())
		fmt.Printf("--------------- Order Num: %d END ---------------\n", i)
	}
	lib.Logger.LogMessage("Fetched today's activity successfully.")
}
