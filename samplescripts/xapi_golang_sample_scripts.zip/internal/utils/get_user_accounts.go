package utils

import (
	"context"
	"fmt"

	"go-xapi/generated/order"
	"go-xapi/internal/common"
)

// ExampleGetUserAccounts handles fetching user accounts.
type ExampleGetUserAccounts struct{}

// NewExampleGetUserAccounts initializes a new instance.
func NewExampleGetUserAccounts() *ExampleGetUserAccounts {
	return &ExampleGetUserAccounts{}
}

// Run executes the GetUserAccounts API call.
func (e *ExampleGetUserAccounts) Run() {
	lib := common.Get()
	if lib == nil {
		fmt.Println("EMSXAPILibrary instance is not initialized.")
		return
	}

	request := &order.UserAccountsRequest{
		UserToken: lib.GetUserToken(),
	}

	response, err := lib.OrderServiceStub.GetUserAccounts(context.Background(), request)
	if err != nil {
		lib.Logger.LogMessage("Error fetching user accounts: " + err.Error())
		fmt.Println("Error fetching user accounts:", err)
		return
	}

	fmt.Println("User Accounts:")
	for account, details := range response.Accounts {
		fmt.Printf("Account: %s, Details: %s\n", account, details)
	}
	lib.Logger.LogMessage("Fetched user accounts successfully.")
}
