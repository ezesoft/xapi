# Go-XAPI

## Getting Started

Welcome to the Go-XAPI project! This section will help you quickly set up and run the project on your system.

- **System Requirements:**
  - Go 1.20 or higher
  - Protobuf Compiler (protoc) 3.20.0 or higher
  - Windows, macOS, or Linux
- **Configuration:**
  - Edit `config/config.ini` with your server and authentication details
  - (Optional) Place your root CA certificate at `config/roots_qa.pem` for SSL
- **Dependencies:**
  - All dependencies are managed via Go modules

👉 **See the full setup guide here:** [setup.md](setup.md)

---

## Project Structure

- `proto/`: Protocol buffer definitions for the gRPC services
  - `market_data.proto` - Market data service definitions
  - `order.proto` - Order management service definitions  
  - `utilities.proto` - Utility service definitions
- `generated/`: Stores generated Go code from Protobuf.
- `internal/`: Core library and utilities.
  - `common/`: Handles API communication, logging, and error handling.
  - `utils/`: Helper functions.
- `cmd/`: Example applications demonstrating usage.
  - `example-client/`: Example client application.

## Purpose of `internal/` and `cmd/`

- `internal/`: This directory contains the core library and utility code that is not intended to be exposed publicly. It includes components like API communication, logging, error handling, and helper functions. The `internal/` directory ensures that these components are only accessible within the project and cannot be imported by external projects.

- `cmd/`: This directory contains example applications that demonstrate how to use the library. These applications serve as practical examples for developers to understand the usage of the core library. Each subdirectory under `cmd/` represents a standalone application.

## Protobuf Code Generation

### Command Used
To generate Go code from the `.proto` files, the following command was used:
```bash
protoc --proto_path=proto --go_out=generated --go-grpc_out=generated proto/*.proto
```

### Updates Made to `.proto` Files
1. **`market_data.proto`**:
   - Updated `go_package` to:
     ```proto
     option go_package = "/market_data";
     ```

2. **`utilities.proto`**:
   - Updated `go_package` to:
     ```proto
     option go_package = "/utilities";
     ```

3. **`order.proto`**:
   - Updated `go_package` to:
     ```proto
     option go_package = "/order";
     ```

### Reason for Updates
The `go_package` option in the `.proto` files was updated to ensure that the generated Go code is placed in the correct directories under the `generated/` folder. This avoids creating unnecessary nested directories and aligns the package structure with the project organization.

### Explanation
The `go_package` option specifies the Go package path for the generated code. By setting it to `generated/<subdirectory>`, the generated files are organized into logical subdirectories (`market_data`, `utilities`, `order`) under the `generated/` folder. This structure improves maintainability and ensures consistency across the project.

### Updated Protobuf Code Generation Command

To ensure the correct import paths in the generated `.pb.go` files, use the following command:
```bash
protoc --proto_path=. --go_out=. --go-grpc_out=generated --go_opt=Mproto/utilities.proto=go-xapi/generated/utilities proto/*.proto
```

### Reason for Update
The `--go_opt` flag is used to explicitly specify the Go package path for `utilities.proto`. This ensures that the generated files correctly import the `utilities` package using the module name `go-xapi`, rather than a relative file system path. This resolves import issues in the generated files and aligns with Go's module-based import system.

### Explanation of Protobuf Code Generation Command

The following command is used to generate Go code from `.proto` files:
```bash
protoc --proto_path=proto --go_out=generated --go-grpc_out=generated proto/*.proto
```

#### Explanation of Each Part:
1. **`protoc`**:
   - This is the Protobuf compiler used to process `.proto` files and generate code in the desired language (Go in this case).

2. **`--proto_path=proto`**:
   - Specifies the directory where the `.proto` files are located. In this case, the `proto/` directory is used as the source path.

3. **`--go_out=generated`**:
   - Specifies the output directory for the generated Go code for Protobuf messages. The generated files will be placed in the `generated/` directory.

4. **`--go-grpc_out=generated`**:
   - Specifies the output directory for the generated Go code for gRPC services. The gRPC client and server code will also be placed in the `generated/` directory.

5. **`proto/*.proto`**:
   - Specifies the input `.proto` files to be processed. The `*.proto` pattern means all `.proto` files in the `proto/` directory will be processed.

This command ensures that both Protobuf message types and gRPC service code are generated and organized in the `generated/` directory.

## Configuration File

### `config.ini`
The `config.ini` file is used to store configuration values for the application. It is located in the `config/` directory at the root of the project.

#### Example Structure:
```ini
[Auth Config Section]
password = XXXX
server = XXXX
user = XXXX
domain = XXXX
locale = XXXX
port = XXXX
ssl = false
srp_login = false
keepAliveTime = 300000
keepAliveTimeout = 30000
maxRetryCount = 10
retryDelayMS = 2000
route = ROUTE
account = BANK;BRANCH;CUSTOMER;DEPOSIT
```

#### Explanation of Fields:
- **`password`**: The password for authentication.
- **`server`**: The server address.
- **`user`**: The username for authentication.
- **`domain`**: The domain for authentication.
- **`locale`**: The locale setting.
- **`port`**: The port number for the server connection.
- **`ssl`**: Boolean indicating whether SSL is enabled.
- **`srp_login`**: Boolean indicating whether SRP login is enabled.
- **`keepAliveTime`**: Keep-alive time in milliseconds.
- **`keepAliveTimeout`**: Keep-alive timeout in milliseconds.
- **`maxRetryCount`**: Maximum number of retries for failed operations.
- **`retryDelayMS`**: Delay between retries in milliseconds.
- **`route`**: Route information.
- **`account`**: Account details in the format `BANK;BRANCH;CUSTOMER;DEPOSIT`.

### Usage
The `config.ini` file is read by the helper utility in the `internal/helper` package. Ensure the file is properly configured before running the application.

### Configuration Helper

The `internal/helper/config.go` file provides functionality to read and parse the `config.ini` file. This helper utility simplifies the process of loading configuration values into a structured format for use in the application.

#### Key Features:
- Reads the `config.ini` file located in the `config/` directory.
- Parses configuration values into a `Config` struct.
- Handles data types like integers, booleans, and lists.

## Secure gRPC Channel with SSL/TLS

The Go-XAPI client supports secure gRPC communication using SSL/TLS. To enable this, set the following in your `config/config.ini`:

```ini
ssl = true
```

The client will use the root CA certificate located at `config/roots_qa.pem` to validate the server's certificate. The Go implementation loads and validates this CA certificate at runtime, and establishes a secure channel using TLS 1.2 or higher. If the file is missing or invalid, the client will fail to connect and log an error.

**Key points:**
- The CA certificate file must be present at `config/roots_qa.pem`.
- The `ssl` flag in `config.ini` must be set to `true` to enable secure connections.
- The client enforces certificate validation and minimum TLS version for security.
- If `ssl` is set to `false`, the client will connect without encryption (not recommended for production).

**Example error handling:**
- If the CA file is missing or cannot be loaded, a clear error is returned and logged.
- If the server's certificate is not trusted by the CA, the connection will be rejected.

**Best practices:**
- Always use a valid CA certificate in production.
- Keep `roots_qa.pem` secure and up to date.
- Do not use insecure connections in production environments.

For more details, see the `OpenChannel` implementation in `internal/common/ems_xapi_library.go`.

## Running and Building the Project

### Run the Project
To run the project directly without building an executable, use the following command:
```bash
go run cmd/example-client/main.go
```

### Build the Project
To build the project into an executable, use the following command:
```bash
go build -o example-client.exe cmd/example-client/main.go
```

This will generate an executable file named `example-client.exe` in the root directory of the project.

## Running Multiple APIs with the --api Flag

The Go-XAPI client now supports running multiple APIs in a single execution by passing a comma-separated list to the `--api` flag. This allows you to execute several API examples in sequence without restarting the application.

### How to Use

Pass a comma-separated list of API names to the `--api` flag. For example:

```bash
# Run GetTodaysActivity and SubmitSingleOrder APIs in one execution
 go run cmd/example-client/main.go --api=GetTodaysActivity,SubmitSingleOrder

# Run all available APIs
 go run cmd/example-client/main.go --api=GetTodaysActivity,SubscribeLevel1Ticks,SubmitSingleOrder,SubscribeOrderInfo,GetUserAccounts

# Run a subset (order does not matter)
 go run cmd/example-client/main.go --api=SubscribeLevel1Ticks,GetUserAccounts
```

The application will execute each specified API example in the order provided.

### Notes
- If an unknown API name is provided, it will be logged as an unknown API and skipped.
- If no valid API is specified, a message will be logged and no API will be run.
- The list of supported API names is:
  - `GetTodaysActivity`
  - `SubscribeLevel1Ticks`
  - `SubmitSingleOrder`
  - `SubscribeOrderInfo`
  - `GetUserAccounts`

See the `main.go` file in `cmd/example-client/` for the latest supported API names and logic.

## Important Notes on Go Imports and Dependencies

### 1. Go Imports Must Be Relative to the Module Name
In Go, all imports must be relative to the module name, not the file system structure. For example, if your module name is `go-xapi`, the correct import path for a package in the `generated/utilities` directory would be:
```go
import "go-xapi/generated/utilities"
```

#### Reason:
Go modules enforce this rule to ensure that all imports are consistent and can be resolved correctly across different environments and systems. Using the module name as the base ensures that the code is portable and works seamlessly with Go's dependency management system.

### 2. Installing the `grpc` Package
The `grpc` package is not included by default in Go. You need to add it to your project using the following command:
```bash
go get google.golang.org/grpc
```

#### Reason:
The `grpc` package provides the necessary tools and libraries to work with gRPC in Go. Installing it ensures that your project has access to the required functionality for creating gRPC clients and servers.

### Context with Timeout in Go

In Go, a context with a timeout is used to manage deadlines and cancellations for operations, such as API calls. Below is an example and explanation:

#### Example:
```go
ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
defer cancel()
```

#### Explanation:
1. **`context.WithTimeout`**:
   - Creates a new context (`ctx`) that will automatically cancel after the specified timeout duration (5 seconds in this case).

2. **`context.Background()`**:
   - This is the base context, typically used as the root context in an application. It is never canceled and does not carry any values or deadlines.

3. **`5 * time.Second`**:
   - Specifies the timeout duration for the context. If the operation does not complete within 5 seconds, the context will be canceled, and the operation will return an error.

4. **`defer cancel()`**:
   - Ensures that resources associated with the context are released when the function exits, even if the operation completes successfully before the timeout.

#### Why Use a Timeout?
- To prevent the program from waiting indefinitely if an operation hangs or takes too long to respond.
- Ensures that the application remains responsive and can handle errors gracefully.

#### Example Scenario:
If an API call takes longer than 5 seconds to respond, the context will be canceled, and the API call will return an error like `context deadline exceeded`.

### Available Commands in `main.go`

The `main.go` file in the `cmd/example-client/` directory provides several commands that can be executed using the `--api` flag. Below is a list of available commands and their descriptions:

#### Commands:

1. **GetTodaysActivity**
   - Description: Fetches today's activity data.
   - Command:
     ```bash
     go run cmd/example-client/main.go --api=GetTodaysActivity
     ```

2. **SubscribeLevel1Ticks**
   - Description: Subscribes to Level 1 market data ticks.
   - Command:
     ```bash
     go run cmd/example-client/main.go --api=SubscribeLevel1Ticks
     ```

3. **SubmitSingleOrder**
   - Description: Submits a single order.
   - Command:
     ```bash
     go run cmd/example-client/main.go --api=SubmitSingleOrder
     ```

4. **SubscribeOrderInfo**
   - Description: Subscribes to order information updates.
   - Command:
     ```bash
     go run cmd/example-client/main.go --api=SubscribeOrderInfo
     ```

5. **GetUserAccounts**
   - Description: Fetches user account details.
   - Command:
     ```bash
     go run cmd/example-client/main.go --api=GetUserAccounts
     ```

#### Usage:
To execute any of the above commands, use the `--api` flag followed by the command name. For example, to fetch user accounts, run:
```bash
go run cmd/example-client/main.go --api=GetUserAccounts
```

