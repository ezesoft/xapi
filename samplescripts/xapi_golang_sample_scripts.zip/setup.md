# Go-XAPI Project Setup Guide

## Table of Contents
1. [System Prerequisites](#system-prerequisites)
2. [Installation Instructions](#installation-instructions)
3. [Configuration & Environment Variables](#configuration--environment-variables)
4. [Database Setup](#database-setup)
5. [Install Dependencies](#install-dependencies)
6. [Build & Compilation](#build--compilation)
7. [Running the Application](#running-the-application)
8. [Running Tests](#running-tests)
9. [Troubleshooting Tips](#troubleshooting-tips)

---

## System Prerequisites

- **Operating System:**
  - Windows 10/11, macOS 12+, or Linux (Ubuntu 20.04+, CentOS 8+)
- **Go (Golang):**
  - Version: **1.20** or higher (tested with 1.20, 1.21)
- **Protobuf Compiler (protoc):**
  - Version: **3.20.0** or higher
- **Git:**
  - Version: **2.30** or higher
- **(Optional) Make:**
  - For Linux/macOS users for easier scripting

## Installation Instructions

### 1. Install Go
- Download and install Go from: https://go.dev/dl/
- Verify installation:
  ```cmd
  go version
  ```

### 2. Install Protobuf Compiler
- Download from: https://github.com/protocolbuffers/protobuf/releases
- Extract and add `protoc` to your PATH.
- Verify installation:
  ```cmd
  protoc --version
  ```

### 3. Clone the Repository
```cmd
git clone <your-repo-url>
cd Go-XAPI
```

### 4. Install Go Dependencies
```cmd
go mod tidy
```

### 5. Generate gRPC/Protobuf Code (if needed)
If you modify `.proto` files, regenerate Go code:
```cmd
protoc --proto_path=proto --go_out=generated --go-grpc_out=generated proto/*.proto
```

---

## Configuration & Environment Variables

- **Configuration File:**
  - Edit `config/config.ini` with your server, user, and authentication details.
- **SSL Certificates:**
  - Place your root CA certificate as `config/roots_qa.pem` if using SSL.
- **No special environment variables** are required by default.

#### Example `config.ini`:
```ini
[Auth Config Section]
password = YOUR_PASSWORD
server = YOUR_SERVER
user = YOUR_USER
... (see README.md for full example)
```

---

## Database Setup

- **No database setup is required** for this project.

---

## Install Dependencies

All dependencies are managed via Go modules. To install:
```cmd
go mod tidy
```

---

## Build & Compilation

To build the example client:
```cmd
go build -o example-client.exe cmd/example-client/main.go
```
- The output will be `example-client.exe` (Windows) or `example-client` (Linux/macOS).

---

## Running the Application

To run directly without building:
```cmd
go run cmd/example-client/main.go --api=GetTodaysActivity
```

To run multiple APIs:
```cmd
go run cmd/example-client/main.go --api=GetTodaysActivity,SubmitSingleOrder
```

---

## Running Tests

> **Note:** No automated tests are included by default. If you add tests, run them with:
```cmd
go test ./...
```

---

## Troubleshooting Tips

- **Go not found:** Ensure Go is installed and in your PATH.
- **protoc not found:** Ensure Protobuf compiler is installed and in your PATH.
- **Dependency errors:** Run `go mod tidy` to resolve.
- **SSL errors:** Ensure `config/roots_qa.pem` exists and is valid if `ssl = true` in `config.ini`.
- **gRPC connection issues:** Check your server address, port, and network connectivity.
- **Permission denied:** Run terminal as administrator (Windows) or use `sudo` (Linux/macOS) if needed.
- **Proto import errors:** Ensure you run the `protoc` command from the project root and paths are correct.

---

For more details, see the [README.md](README.md).
