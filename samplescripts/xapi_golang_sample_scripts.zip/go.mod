module go-xapi

go 1.24.2

require (
	google.golang.org/grpc v1.79.3
	google.golang.org/protobuf v1.36.10
	gopkg.in/ini.v1 v1.67.0
)

require (
	github.com/stretchr/testify v1.10.0 // indirect
	//github.com/wault-pw/srp6ago v0.0.0-20220316105709-be5968598c33 // indirect
	golang.org/x/net v0.48.0 // indirect
	golang.org/x/sys v0.39.0 // indirect
	golang.org/x/text v0.32.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20251202230838-ff82c1b0f217 // indirect
)
