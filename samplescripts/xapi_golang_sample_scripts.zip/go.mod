module go-xapi

go 1.24.2

require (
	google.golang.org/grpc v1.72.0
	google.golang.org/protobuf v1.36.6
	gopkg.in/ini.v1 v1.67.0
)

require (
	github.com/stretchr/testify v1.10.0 // indirect
	//github.com/wault-pw/srp6ago v0.0.0-20220316105709-be5968598c33 // indirect
	golang.org/x/net v0.38.0 // indirect
	golang.org/x/sys v0.31.0 // indirect
	golang.org/x/text v0.23.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20250218202821-56aae31c358a // indirect
)
