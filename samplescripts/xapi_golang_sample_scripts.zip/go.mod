module go-xapi

go 1.25.0

require (
	google.golang.org/grpc v1.83.1
	google.golang.org/protobuf v1.36.11
	gopkg.in/ini.v1 v1.67.0
)

require (
	github.com/stretchr/testify v1.10.0 // indirect
	//github.com/wault-pw/srp6ago v0.0.0-20220316105709-be5968598c33 // indirect
	golang.org/x/net v0.57.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.40.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260526163538-3dc84a4a5aaa // indirect
)
