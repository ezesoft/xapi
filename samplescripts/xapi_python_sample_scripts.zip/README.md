# Python XAPI Client

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![gRPC](https://img.shields.io/badge/gRPC-Latest-green.svg)](https://grpc.io/)
[![License](https://img.shields.io/badge/License-Proprietary-red.svg)](#license)

The Python XAPI client provides a comprehensive interface for interacting with the Eze EMS XAPI server, supporting both market data streaming and trading operations through gRPC.

## Features

- **Service-organized scripts**: Example/utility scripts grouped by gRPC service under `services/`
- **Interactive streaming client**: Menu-driven bidirectional streaming client in `services/streaming_api_client/`
- **Order + market data coverage**: Submit/modify/cancel orders, quotes, bars, ticks, options, symbol reference data
- **Authentication**: Token-based authentication with optional SRP login
- **Canonical protobuf modules**: Generated protobuf/gRPC bindings live in `generated/` (single source)
- **Legacy Tkinter GUI**: GUI app lives in `apps/gui/` (with root wrappers for backward compatibility)

## Repository Layout

- `generated/` — canonical protobuf + gRPC Python modules (`*_pb2.py`, `*_pb2_grpc.py`)
- `runtime/` — core client library + config + shared exceptions (e.g., `runtime/emsxapilibrary.py`)
- `services/` — runnable scripts grouped by service:
    - `services/order/`
    - `services/market_data/`
    - `services/utility/`
    - `services/streaming_api_client/`
- `apps/gui/` — Tkinter GUI app (`apps/gui/xapi_client.py`) and GUI-coupled examples (`apps/gui/examples/`)

## Installation

1. Ensure Python 3.8+ is installed
2. Install required dependencies:
```bash
pip install grpcio protobuf requests srp
```

Optional (only if regenerating protobufs locally):
```bash
pip install grpcio-tools
```

3. Configure the client:
    - Edit `runtime/config.cfg` (included in this repo)
    - By default, the runtime config loader will look for a relative `config.cfg` in the current working directory and (if not found) fall back to `runtime/config.cfg`.
    - Ensure SSL certificates are properly configured if `ssl = true`.

## Quick Start

```python
from generated import order_pb2
from runtime.emsxapilibrary import EMSXAPILibrary

# Initialize and authenticate (defaults to ./config.cfg)
EMSXAPILibrary.create('runtime/config.cfg')
api = EMSXAPILibrary.get()
api.login()

# Example: Get user accounts
request = order_pb2.UserAccountsRequest(UserToken=api.userToken)
response = api.get_order_service_stub().GetUserAccounts(request)
print(response.Acknowledgement.ServerResponse)
print(response.Accounts)

api.logout()
```

## Core Components

### `runtime/emsxapilibrary.py`
Core library used by many scripts:
- Opens a gRPC channel using `runtime/config.cfg` (or a provided config path)
- Performs login (standard or SRP)
- Exposes service stubs via `get_*_service_stub()`

### Streaming Market Data Client
Interactive command-line client for bidirectional market data streaming:

- Location: `services/streaming_api_client/`
- Entry points:
    - `run_streaming_client.py` (dependency checker + launcher)
    - `streaming_client_app.py` (main interactive app)

### Bidirectional Streaming
Real-time market data streaming with dynamic subscriptions:
- Level 1, Level 2, and Tick data
- Symbol addition and level-aware removal
- Subscription level changes (LEVEL1/LEVEL2 transitions preserve TICK)
- Continuous data flow management

## Running Scripts

### Interactive Streaming Client (Recommended)
```bash
# From repo root
python services/streaming_api_client/run_streaming_client.py

# Or as a module
python -m services.streaming_api_client.run_streaming_client

# Or run directly
python services/streaming_api_client/streaming_client_app.py

# Interactive menu options:
# 1. Add symbols to stream (with level selection)
# 2. Remove symbols from stream (with level selection)
# 3. Change subscription level
# 4. Check status (shows active subscriptions)
# 5. Exit

# All market data responses are logged to:
# logs/streaming_client_YYYY-MM-DD_HH-MM-SS.log
```

**Sample Workflow:**
```python
# After login, the client presents an interactive menu:
=== Streaming Market Data Client ===
Available commands:
1. Add symbols to stream
2. Remove symbols from stream (by level)
3. Change subscription level
4. Check status
5. Exit

# Example: Add AAPL for Level1 data
Enter your choice (1-5): 1
Enter symbols to add (comma-separated): AAPL
Select level (1-3): 1  # LEVEL1

# Market data responses are logged to file
# Console shows only warnings/errors for clean UX
```

### Market Data + Order Examples

All service examples are under `services/`:

```bash
# Order examples
python -m services.order.submitsingleorder
python -m services.order.submitbasketorder
python -m services.order.submitpairorder

# Market data examples
python -m services.market_data.GetLevel1LiveQuote
python -m services.market_data.requestandwatchlevel1data

# Utility examples
python -m services.utility.getuserstrategies
python -m services.utility.subscribeheartbeat
```

## Validation

### Change Subscription Validation
Comprehensive validation for CHANGE_SUBSCRIPTION is located at:

- `services/market_data/validate_change_subscription.py`

Run it from repo root:
```bash
python -m services.market_data.validate_change_subscription
```

## GUI (Legacy Tkinter)

The legacy Tkinter GUI was moved under `apps/gui/` along with its GUI-coupled example modules.

Run the GUI from repo root:
```bash
python -m apps.gui.xapi_client
```

Note: `apps/gui/examples/` are GUI helper modules and are not the same as the service scripts under `services/`.

## Supported Operations

### Market Data
- **Interactive Streaming Client**: Command-line client with menu-driven interface for StreamMarketData API
- **Stream Market Data**: Bidirectional streaming with dynamic subscriptions
- **Get Historical Bars**: Daily, weekly, monthly, and intraday bars
- **Get Level 1/2 Data**: Real-time quotes and market depth
- **Get Tick Data**: Individual trade ticks
- **Get Options Chain**: Complete options data for underliers

### Trading Operations
- **Submit Orders**: Single, basket, pair, and spread orders
- **Modify Orders**: Change price, quantity, or other parameters
- **Cancel Orders**: Individual and batch order cancellation
- **Order Status**: Real-time order tracking and execution reporting

### Account Management
- **Get User Accounts**: Available trading accounts
- **Get Positions**: Current positions and balances
- **Get Activity**: Today's trading activity and history

## Configuration

### config.cfg
```ini
[Auth Config Section]
user = your-username
password = your-password
domain = your-domain
server = your-server
port = 9000
locale = en-US

# TLS
ssl = true
cert_file_path = path/to/roots.pem

# Auth
srp_login = true

# gRPC options
keep_alive_time = 3600000
keep_alive_timeout = 30000
max_retry_count = 3
retry_delay_ms = 1000
```

## Error Handling

The client includes comprehensive error handling:

- `LoginFailedException`: Authentication failures
- `NetworkFailedException`: Connection issues
- `ServerNotAvailableException`: Server unreachable
- `SessionNotFoundException`: Invalid sessions
- `StreamingAlreadyExistsException`: Duplicate streams

## Best Practices

1. **Connection Management**: Always properly close connections
2. **Error Handling**: Implement try/catch blocks for all API calls
3. **Authentication**: Cache tokens and handle expiration
4. **Streaming**: Monitor stream health and implement reconnection logic
5. **Rate Limiting**: Respect API rate limits to avoid throttling

## Dependencies

- grpcio
- protobuf
- requests
- srp

Optional (only for local protobuf regeneration):
- grpcio-tools

## Troubleshooting

### Common Issues
- **Authentication failures**: Verify credentials and server URL
- **Connection timeouts**: Check network connectivity and firewall settings
- **SSL certificate errors**: Ensure certificate path is correct and valid
- **Protobuf import errors**: Ensure you are importing from `generated/` (do not mix multiple pb2 locations)

### Debug Mode
Enable detailed logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Development

### Running Tests
```bash
# Run streaming client unit test (if applicable)
python -m services.streaming_api_client.test_streaming_client

# Run validation
python -m services.market_data.validate_change_subscription

# Run an order example
python -m services.order.getuseraccounts
```

### Contributing
- Follow PEP 8 style guidelines
- Add comprehensive error handling
- Include docstrings for all public methods
- Test all changes thoroughly

## Related Documentation

- [Main Project README](../../readme.md)
- [Server Documentation](../../Server/README_ServerCode.md)
- [C# Client Documentation](../CSharp/CSharp_XAPI_Client/Readme_CsharpClient.md)
- [C# Streaming Client](../CSharp/StreamingClientApp/README.md) - C# implementation with identical architecture
- [C# StreamingClient.cs](../CSharp/StreamingClientApp/Core/StreamingClient.cs) - Core streaming implementation
- [Server Unit Tests](../../Server/XAPIServer.UnitTests/README.md) - Bidirectional streaming test coverage
- [Administrative Tools](../../AdminClientScripts/README_Admin_Client.md)
- [Bidirectional Streaming API Documentation](../../docs/Bidirectional-Market-Data-Streaming-API-Documentation.md)
python -m services.streaming_api_client.test_streaming_client
