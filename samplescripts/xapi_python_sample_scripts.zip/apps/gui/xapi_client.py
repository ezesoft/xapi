from pathlib import Path

# Allow running both:
# - as a module:   python -m apps.gui.xapi_client
# - as a script:   python apps/gui/xapi_client.py
try:
    from . import xapi_client_support as imp
except ImportError:  # pragma: no cover
    import sys

    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    from apps.gui import xapi_client_support as imp


def start_gui():
    '''Calling GUI'''
    imp.vp_start_gui()


def establishserverconnection(self):
    ''' Function to establish connection for gRPC server '''
    try:
        host = 'EMSUATXAPI.taltrade.com'
        server_port = 9000
        imp.grpc.max_message_length = (1024 * 1024 * 1024)
        options = [('grpc.max_receive_message_length', imp.grpc.max_message_length)]
        useSSL = False
        if useSSL:
            with open(r'roots.pem', 'rb') as f:  # pathforpemfile
                fin = f.read()
                creds = imp.grpc.ssl_channel_credentials(root_certificates=fin)
            channel = imp.grpc.secure_channel('{}:{}'.format(host, server_port), creds, options)
        else:
            channel = imp.grpc.insecure_channel('{}:{}'.format(host, server_port), options=options)

        self.stub = imp.ob_grpc.SubmitOrderServiceStub(channel)
        self.utility_stub = imp.uPb2_grpc.UtilityServicesStub(channel)
        self.market_stub = imp.mktPb2_grpc.MarketDataServiceStub(channel)
        return True
    except Exception as e:
        imp.tk.messagebox.showinfo("Message", e)
        return False


def btnok_connect(self):
    '''Function to connect(glx2 token)'''
    imp.sSrp.srpconnect(self)

def btnok_changePasswordSRP(self):
   imp.sChangePasswordSRP.changePasswordSRP(self)


def fid_func(self):
    '''Function shows fidlist file required for ExtendedFields/OptionalFields'''
    readme = "fidlist.txt"
    if imp.sys.platform == 'win32':				#windows	
    	imp.os.startfile(readme)   
    elif imp.sys.platform == 'linux':			 #linux
    	imp.os.system('gedit "{0}"'.format(readme))


def btnsubmit(self):
    '''Function to invoke submitsingleorder/submitpair APIs'''
    if self.bselection == 'Submit Single Order':
        imp.sOrder.submitsingleorder(self)  # callingsubmitsingleorderapi
    elif self.bselection == 'Submit Pair Order':
        imp.sPairOrder.submitpairorder(self)  # callingsubmitpairorderapi
    elif self.bselection == 'Submit Seed Data':
        imp.sSeed.submitseeddata(self)  # callingsubmitseeddataapi
    elif self.bselection == 'Submit Basket Order':
        imp.sBasketOrder.submitbasketorder(self)  # callingbasketorderapi
    elif self.bselection == 'Get User Accounts':
        imp.sXpermsAccounts.getuseraccounts(self)  # callinggetuseraccountsapi
    elif self.bselection == 'Subscribe Order Info':
        imp.sSubscribe.init_respStream(self)  # callingorderstreamingthread
    elif self.bselection == 'Submit Trade Report':
        imp.sTradeReport.submittradereport(self)
    elif self.bselection == 'Subscribe to HeartBeats':
        imp.sHeartBeat.init_HeartBeatStream(self)            
    else:
        if self.bselection:
            self.requestapi_grid()  # respective gui for requested api
            self.requestapiresponse()  # callingapi


def submitallocationorder(self):
    '''Function to invoke Submit Allocation Order API'''
    imp.sAllocorder.submitallocationorder(self)


def changesingleorder(self):
    '''Function to invoke Change Single Order API'''
    imp.sChange.changesingleorder(self)  # Callingchange


def changepairorder(self):
    '''Function to invoke Change Pair Order API'''
    imp.sPairChange.changepairorder(self)  # Callingpairchange


def cancelorder(self):
    '''Function to invoke cancelsingleorder/cancelpairorder API'''
    if self.Ordertypecol == '':
        pass
    elif self.Orderlinkedid == '' and self.symcol != '!Pair':
        imp.sCancel.cancelsingleorder(self)
    else:
        imp.sPairCancel.cancelpairorder(self)


def marketdata(self):
    '''Function to invoke Market data APIs'''
    if self.mktSelection == 'Subscribe Level1 Ticks':
        imp.sLQTableExample.requestandwatchlevel1(self)  # callingrequestandwatchlevel1api
    elif self.mktSelection == 'UnSubscribe Level1 Data':
        imp.sUnsubLevel1.unsubscribelevel1data(self)  # callingunsubscribelevel1dataapi
    elif self.mktSelection == 'Subscribe Level2 Ticks':
        imp.sMktMakers.requestandwatchlevel2(self)  # callingrequestandwatchlevel2api
    elif self.mktSelection == 'UnSubscribe Level2 Data':
        imp.sUnsubLevel2.unsubscribelevel2data(self)  # callingunsubscribelevel2dataapi
    elif self.mktSelection == 'Add Symbols':
        imp.sAddsymbols.addsymbols(self)  # callingaddsymbolspi
    elif self.mktSelection == 'Remove Symbols':
        imp.sRemovesymbols.removesymbols(self)  # callingremovesymbolsapi


def viewsourcecode(self):
    '''Function to view selected api source code in notepad'''
    examples_dir = Path(__file__).resolve().parent / 'examples'
    if self.bselection:
        if self.bselection == 'Submit Single Order':
            filename = examples_dir / 'submitsingleorder.py'
            if imp.sys.platform == 'win32':	          #windows
	            imp.os.system(f'notepad "{filename}"')  #Openinnotepad
            elif imp.sys.platform == 'linux':		  #linux
	            imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Subscribe Order Info':
            filename = examples_dir / 'subscribeorderinfo.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Submit Pair Order':
            filename = examples_dir / 'submitpairorder.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Submit Seed Data':
            filename = examples_dir / 'submitseeddata.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Submit Basket Order':
            filename = examples_dir / 'submitbasketorder.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"') 
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Get User Accounts':
            filename = examples_dir / 'getuseraccounts.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Get Symbols From Company Name':
            filename = examples_dir / 'getsymbolsfromcompanyname.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Get Symbol From SEDOL, ISIN, CUSIP, etc':
            filename = examples_dir / 'getsymbolfromalternatesymbology.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.bselection == 'Submit Trade Report':
            filename = examples_dir / 'submittradereport.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        else:  # TodayApis
            filename = examples_dir / 'miscellaneous_apis.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
    if self.mktSelection:
        if self.mktSelection == 'Subscribe Level1 Ticks':
            filename = examples_dir / 'requestandwatchlevel1.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.mktSelection == 'UnSubscribe Level1 Data':
            filename = examples_dir / 'unsubscribe_level1data.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.mktSelection == 'Subscribe Level2 Ticks':
            filename = examples_dir / 'requestandwatchlevel2.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
        elif self.mktSelection == 'UnSubscribe Level2 Data':
            filename = examples_dir / 'unsubscribe_level2data.py'
            if imp.sys.platform == 'win32':	
	            imp.os.system(f'notepad "{filename}"')  
            elif imp.sys.platform == 'linux':			  	
            	imp.os.system('gedit "{0}"'.format(filename))
    
def disconnect(self):
    '''Function to invoke Disconnect API'''
    imp.sDisconnect.disconnect(self)
    self.credentials.clear()


if __name__ == '__main__':
    start_gui()
