"""Tkinter GUI application for XAPIClient."""
