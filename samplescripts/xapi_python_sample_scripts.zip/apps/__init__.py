"""Application entrypoints (GUI, etc.)."""
