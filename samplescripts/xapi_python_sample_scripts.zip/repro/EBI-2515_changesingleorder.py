import time
import asyncio
import os
import grpc
import grpc.aio
from datetime import datetime, timezone
from threading import Event, Thread
from uuid import uuid4
from concurrent import futures
from generated import order_pb2 as ord
from generated import order_pb2_grpc as ord_grpc
from runtime.emsxapilibrary import EMSXAPILibrary


def _utc_now_str():
    return datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]


class ChangeSingleOrder:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

        # Configure these fields before running.
        # For the EBI-3515 repro, set this to the OrderId printed by submitsingleorder.py
        # (or via the EBI3515_ORDER_ID env var).
        self.order_id = os.getenv("EBI3515_ORDER_ID", "3605dd6c-91d-0fg6")  # OrderId of the order to change (required)
        self.order_tag = 'XAP-{0}'.format(str(uuid4()))  # New OrderTag for the change request

        # Optional fields to change (set to None to skip)
        self.new_quantity = 5000  # New quantity/volume
        self.new_price = 121.5  # New limit price
        self.new_stop_price = None  # New stop price (if applicable)

        # Extended fields to change (set as needed)
        self.extended_fields = {
            # 'DEST_ROUTE': 'DEMOEUR',
            # 'ACCT_TYPE': '119',
        }

        # ---- EBI-3515 reproduction knobs (env-toggle) -----------------------------
        # Number of rapid ChangeSingleOrder requests to fire. Each change produces an
        # order-update event the server streams back to the slow subscriber, flooding
        # the HTTP/2 stream and (on an unfixed server) exhausting the small window.
        self.burst_count = int(os.getenv("EBI3515_BURST_COUNT", "250"))
        # Delay between fired changes in ms. 0 = fire as fast as possible (worst case).
        self.burst_delay_ms = int(os.getenv("EBI3515_BURST_DELAY_MS", "0"))
        # ---------------------------------------------------------------------------

        self.ready = Event()

    def change_order(self):
        if not self.order_id or self.order_id == ' ':
            print("Error: order_id is required")
            return
        
        change_order = ord.ChangeSingleOrderRequest()
        change_order.OrderId = self.order_id
        change_order.UserToken = self.xapiLib.userToken
        change_order.OrderTag = self.order_tag
        
        # Set optional fields if provided
        if self.new_quantity is not None:
            change_order.Quantity = self.new_quantity
        
        if self.new_price is not None:
            change_order.Price.value = self.new_price
        
        if self.new_stop_price is not None:
            change_order.StopPrice.value = self.new_stop_price
        
        # Set extended fields
        for key, value in self.extended_fields.items():
            change_order.ExtendedFields[key] = value
        
        print(f"Submitting change for OrderId: {self.order_id}")
        response = self.xapiLib.get_order_service_stub().ChangeSingleOrder(change_order)
        
        if response.ServerResponse == 'success':
            print("Successfully submitted change order")
        else:
            print(f"Failed to change order: {response.OptionalFields.get('ErrorMessage', 'Unknown error')}")
        
        return response

    def stress_test_change_orders(self, num_requests=100):
        """
        Send multiple ChangeSingleOrder requests asynchronously without waiting for responses.
        Quantity is incremented by 1 for each request starting from self.new_quantity.

        This is the EBI-3515 burst driver: fired against the order that a SLOW subscriber
        (submitsingleorder.py) is watching, it produces a flood of order updates that
        exhausts the small HTTP/2 window on an unfixed server -> streaming stall + burst.
        """
        if not self.order_id or self.order_id == ' ':
            print("Error: order_id is required")
            return
        
        print(f"[{_utc_now_str()}] Starting stress test: {num_requests} async "
              f"ChangeSingleOrder requests (burst_delay_ms={self.burst_delay_ms})")
        start_time = time.time()
        
        pending_futures = []
        base_quantity = self.new_quantity if self.new_quantity is not None else 1000
        
        for i in range(num_requests):
            change_order = ord.ChangeSingleOrderRequest()
            change_order.OrderId = self.order_id
            change_order.UserToken = self.xapiLib.userToken
            change_order.OrderTag = f'XAP-STRESS-{i}-{uuid4()}'
            
            # Increment quantity by 1 for each request
            change_order.Quantity = base_quantity + i
            
            if self.new_price is not None:
                change_order.Price.value = self.new_price
            
            if self.new_stop_price is not None:
                change_order.StopPrice.value = self.new_stop_price
            
            for key, value in self.extended_fields.items():
                change_order.ExtendedFields[key] = value
            
            # Log request to console
            print(f"[{_utc_now_str()}] [{i+1}/{num_requests}] Request: OrderId={change_order.OrderId}, "
                  f"OrderTag={change_order.OrderTag}, Quantity={change_order.Quantity}, "
                  f"Price={change_order.Price.value if self.new_price else 'N/A'}")
            
            # Send asynchronously using gRPC future - does not wait for response
            future = self.xapiLib.get_order_service_stub().ChangeSingleOrder.future(change_order)
            pending_futures.append(future)

            if self.burst_delay_ms > 0:
                time.sleep(self.burst_delay_ms / 1000.0)
        
        elapsed = time.time() - start_time
        print(f"\n[{_utc_now_str()}] All {num_requests} requests sent in {elapsed:.3f} seconds "
              f"({num_requests/elapsed:.1f} requests/sec)")
        print(f"Pending futures: {len(pending_futures)}")
        
        return pending_futures

    async def stress_test_change_orders_async(self, num_requests=100):
        """
        Send multiple ChangeSingleOrder requests using grpc.aio async/await.
        Quantity is incremented by 1 for each request starting from self.new_quantity.
        """
        if not self.order_id or self.order_id == ' ':
            print("Error: order_id is required")
            return
        
        print(f"Starting async stress test: {num_requests} ChangeSingleOrder requests using grpc.aio")
        
        # Create async channel with SSL support
        server = f"{self.xapiLib.config.server}:{self.xapiLib.config.port}"
        config = self.xapiLib.config
        
        if config.ssl and config.certFilePath:
            cert_file = config.certFilePath
            if not os.path.exists(cert_file):
                runtime_dir = os.path.dirname(os.path.abspath(__file__))
                cert_file = os.path.join(runtime_dir, '..', '..', 'runtime', config.certFilePath)
            with open(cert_file, 'rb') as f:
                cert_data = f.read()
            credentials = grpc.ssl_channel_credentials(root_certificates=cert_data)
            channel = grpc.aio.secure_channel(server, credentials)
        else:
            channel = grpc.aio.insecure_channel(server)
        
        async with channel:
            stub = ord_grpc.SubmitOrderServiceStub(channel)
            
            base_quantity = self.new_quantity if self.new_quantity is not None else 1000
            
            async def send_change_order(index):
                change_order = ord.ChangeSingleOrderRequest()
                change_order.OrderId = self.order_id
                change_order.UserToken =   self.xapiLib.userToken
                change_order.OrderTag = f'XAP-ASYNC-{index}-{uuid4()}'
                change_order.Quantity = base_quantity + index
                
                if self.new_price is not None:
                    change_order.Price.value = self.new_price
                
                if self.new_stop_price is not None:
                    change_order.StopPrice.value = self.new_stop_price
                
                for key, value in self.extended_fields.items():
                    change_order.ExtendedFields[key] = value
                
                # Log request to console
                print(f"[{index+1}/{num_requests}] Request: OrderId={change_order.OrderId}, OrderTag={change_order.OrderTag}, Quantity={change_order.Quantity}")
                
                response = await stub.ChangeSingleOrder(change_order)
                print(f"[{index+1}/{num_requests}] Response: {response.ServerResponse}")
                return response
            
            # Create all tasks
            start_time = time.time()
            tasks = [send_change_order(i) for i in range(num_requests)]
            
            # Execute all concurrently
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            elapsed = time.time() - start_time
            print(f"\nAll {num_requests} requests completed in {elapsed:.3f} seconds ({num_requests/elapsed:.1f} requests/sec)")
            
            return results


if __name__ == "__main__":
    change_order = ChangeSingleOrder()
    change_order.xapiLib.login()

    if not change_order.order_id or change_order.order_id == ' ':
        print("=" * 78)
        print("EBI-3515 REPRO: order_id is not set.")
        print("  1. Run submitsingleorder.py first (it prints the seed OrderId).")
        print("  2. Set it here via self.order_id or the EBI3515_ORDER_ID env var, e.g.:")
        print("       set EBI3515_ORDER_ID=<orderid>   (PowerShell: $env:EBI3515_ORDER_ID='<orderid>')")
        print("  3. Re-run this script to fire the change burst.")
        print("=" * 78)
        change_order.xapiLib.logout()
    else:
        # EBI-3515 reproduction: fire a rapid BURST of ChangeSingleOrder requests against
        # the order that submitsingleorder.py is slowly subscribing to. On an unfixed
        # server the burst exhausts the small HTTP/2 window and the subscriber sees a
        # long stall followed by a burst flush; with the fix arrivals stay smooth.
        change_order.stress_test_change_orders(num_requests=change_order.burst_count)

        # Alternative drivers (uncomment to use instead of the burst above):
        # change_order.change_order()  # single change
        # asyncio.run(change_order.stress_test_change_orders_async(num_requests=change_order.burst_count))

        time.sleep(3)  # Time in seconds to wait for order updates
        change_order.xapiLib.logout()
