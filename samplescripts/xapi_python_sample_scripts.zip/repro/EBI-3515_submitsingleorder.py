import os
import time
import logging
from datetime import datetime, timezone
from threading import Event, Thread
from uuid import uuid4
from generated import order_pb2 as ord
from generated import order_pb2_grpc as ord_grpc
from runtime.emsxapilibrary import EMSXAPILibrary


# Minimal file logging for analysis. Writes every message to a log file next to
# this script (override path/level via env vars if needed).
_LOG_FILE = os.getenv("EBI3515_LOG_NEW",
                      os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "subscribe_order_info.log"))
logging.basicConfig(
    filename=_LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("subscribe_order_info")


def _log(msg):
    # Emit to both console (existing behaviour) and the analysis log file.
    print(msg)
    log.info(msg)


def _utc_now_str():
    # UTC to match the eze-subscription-raw.log timezone used in the EBI-3515 analysis.
    return datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]


class CreateSingleOrder:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        self.symbol = 'AAPL'
        self.quantity = 1  # Quantity/volume
        self.side = 'BUY'
        self._staged = True
        self._claim_required = False
        self._expiration = 3  # DAY = 0, GTC = 1, GTX = 2, CLO = 3, OPG = 4, IOC = 5, GTD = 6, OTHER = 7
        self.prc = 120.520
        self.prc_type = 1  # Market = 0, Limit = 1, StopMarket = 2, StopLimit = 3, Other = 4
        self._route = 'DEMO'
        self.order_account = 'TAL;TEST;NGARG;TRADE'
        self.get_order_details = True  # True/False, Returns Order Details when set to True
        self.port = 9000

        # OrderId discovered from the first order update (used by the change-order client).
        self.submitted_order_id = None

        # ---- EBI-3515 reproduction knobs (env-toggle, no code edit needed) --------
        # Per-message artificial delay on the READER side. This is the crux of the repro:
        # a slow reader stops sending HTTP/2 WINDOW_UPDATEs, so the server's small default
        # window fills, WriteAsync blocks, and the serialized read->write loop stalls.
        self.reader_delay_ms = int(os.getenv("EBI3515_READER_DELAY_MS", "500"))
        # Default 0 => listen forever. Set EBI3515_LISTEN_SECONDS to a positive
        # number to stop automatically after that many seconds.
        self.listen_seconds = int(os.getenv("EBI3515_LISTEN_SECONDS", "0"))
        self.gap_alert_ms = int(os.getenv("EBI3515_GAP_ALERT_MS", "500"))
        # ---------------------------------------------------------------------------

        self.ready = Event()

    def start_listening(self):
        # start thread to listen to updates from the server about our orders
        self.thread = Thread(target=self.subscribe_order_info, daemon=True)
        self.thread.start()

        # wait for the subscription thread to signal ready
        self.ready.wait()

    # this is the thread func for the order listener
    def subscribe_order_info(self):

        subscribe_request = ord.SubscribeOrderInfoRequest()
        subscribe_request.UserToken =  self.xapiLib.userToken
        # subscribe_request.ExcludeHistory = True
        _log(f"[SUBSCRIBE] UserToken: {subscribe_request.UserToken}")
        _log(f"[SUBSCRIBE] SLOW-READER repro: reader_delay_ms={self.reader_delay_ms}, "
             f"listen_seconds={self.listen_seconds}, gap_alert_ms={self.gap_alert_ms}")
        if self.reader_delay_ms == 0:
            _log("[SUBSCRIBE] reader_delay_ms=0 -> FAST reader (control run: should NOT reproduce the stall).")

        subscribe_response = self.xapiLib.get_order_service_stub().SubscribeOrderInfo(subscribe_request)
        self.ready.set()

        msg_count = 0
        window_count = 0
        window_start = time.time()
        # loop_end = wall-clock time we finished the PREVIOUS iteration (after our sleep).
        # The time from loop_end to the next `now` is the pure blocking-read time spent
        # inside next() -- i.e. how long the server made us wait for the next message.
        # If that time is ~0, the message was already buffered locally => backlog/burst.
        loop_end = None
        # listen_seconds <= 0 means "listen forever" (never stop on a timer).
        run_forever = self.listen_seconds <= 0
        deadline = None if run_forever else time.time() + self.listen_seconds

        try:
            for order_info in subscribe_response:
                now = time.time()
                arrival_str = _utc_now_str()

                # ---- (A) Pure blocking-read time (excludes our artificial sleep) ----
                # Low read_ms after a period of high message rate => messages were
                # sitting in the socket/HTTP2 buffer waiting for us => burst drain.
                read_ms = None
                if loop_end is not None:
                    read_ms = (now - loop_end) * 1000.0

                # ---- (B) Server-vs-client lag using the server submitTime stamp ----
                # This is independent of our sleep: if we fall behind, the server's
                # submitTime falls further and further behind our receive time. A
                # steadily growing lag_ms is the real burst/backlog fingerprint.
                lag_ms = None
                if order_info.HasField("submitTime"):
                    server_ts = order_info.submitTime.ToDatetime(tzinfo=timezone.utc)
                    lag_ms = (datetime.now(timezone.utc) - server_ts).total_seconds() * 1000.0

                # ---- Stall/burst detection (mirrors the EBI-3515 log analysis) ----
                # NOTE: we must NOT measure the gap as (now - last_arrival), because
                # that interval includes our own artificial reader_delay_ms sleep at
                # the end of each loop -- it would fire on every message and tell us
                # nothing about the server. The real "gap" is the time we were blocked
                # inside next() waiting for the server, which is exactly read_ms
                # (measured from loop_end, i.e. AFTER our sleep). A large read_ms means
                # the server genuinely had nothing to give us for that long -> stall.
                if read_ms is not None and read_ms >= self.gap_alert_ms:
                    _log(f"  >>> GAP {read_ms/1000.0:.1f}s ended {arrival_str}  "
                         f"<-- possible WriteAsync stall (EBI-3515 signature)")

                # ---- BURST alert: message was already buffered (read_ms ~ 0) yet the
                # server produced it a while ago (lag_ms high) => we are draining a
                # backlog we could not keep up with.
                buffered = read_ms is not None and read_ms < 20.0
                behind = lag_ms is not None and lag_ms >= self.gap_alert_ms
                if buffered and behind:
                    _log(f"  >>> BURST {arrival_str}: read_ms={read_ms:.0f} "
                         f"(buffered) lag_ms={lag_ms:.0f} <-- draining backlog")

                # messages-per-second window accounting to spot burst flushes
                if now - window_start >= 1.0:
                    if window_count > 0:
                        _log(f"  ... {arrival_str}: {window_count} msgs in last ~1s")
                    window_count = 0
                    window_start = now
                window_count += 1
                msg_count += 1

                # # Capture the OrderId for use by the change-order stress client.
                # if self.submitted_order_id is None and order_info.OrderId:
                #     self.submitted_order_id = order_info.OrderId
                #     _log(f"[SUBSCRIBE] Captured OrderId for change-order stress test: {order_info.OrderId}")

                read_str = f" read_ms={read_ms:.0f}" if read_ms is not None else ""
                lag_str = f" lag_ms={lag_ms:.0f}" if lag_ms is not None else ""
                _log(f"[{arrival_str}] #{msg_count} OrderId:{order_info.OrderId}{read_str}{lag_str}")

                # ---- SLOW READER: the reproduction trigger --------------------------
                # Sleeping here means we do NOT pull from the socket promptly, so the
                # client TCP recv buffer fills and WINDOW_UPDATEs are delayed. This is
                # exactly what a lagging Eze client does during a US-open burst.
                if self.reader_delay_ms > 0:
                    time.sleep(self.reader_delay_ms / 1000.0)

                # Mark the end of this iteration AFTER the sleep so the next iteration's
                # read_ms reflects only time blocked inside next(), not our sleep.
                loop_end = time.time()

                # if deadline is not None and time.time() >= deadline:
                #     _log(f"[SUBSCRIBE] listen_seconds={self.listen_seconds} elapsed; "
                #          f"total received={msg_count}. Stopping reader.")
                #     break

        except Exception as e:
            _log(f"[SUBSCRIBE] stream ended/error: {e}")

    def send_single_order(self):

        # create order
        self.my_order_id = 'XAP-{0}'.format(str(uuid4()))  # OrderTag
        single_order = ord.SubmitSingleOrderRequest()
        single_order.Symbol = self.symbol
        single_order.Side = self.side
        single_order.Quantity = self.quantity
        single_order.Route = self._route  # Route
        single_order.Staged = self._staged  # True if staged
        single_order.ClaimRequire = self._claim_required
        single_order.UserToken = self.xapiLib.userToken
        single_order.Account = self.order_account
        single_order.ReturnResult = self.get_order_details
        print("UserToken:", single_order.UserToken)
        single_order.TimeInForce.Expiration = self._expiration
        if self._expiration == 6:  # in case a GTD(Good Till Date) order is placed, the ExpirationDate field must be given
            single_order.ExpirationDate.FromDatetime(datetime(year=2021, month=7, day=9))
        single_order.Price.value = self.prc
        single_order.StopPrice.value = self.prc + 3.500
        single_order.PriceType.PriceType = self.prc_type
        single_order.OrderTag = self.my_order_id
        single_order.ExtendedFields['ACCT_TYPE'] = '119'
        ######OMS FILEDS if required
        # single_order.ExtendedFields['EZE_OMS_MANAGER'] = ''
        # single_order.ExtendedFields['EZE_OMS_TRADER']  = ''
        # single_order.ExtendedFields['USER_STRATEGY']   = ''
        # single_order.ExtendedFields['REASON_CODE']     = ''
        # single_order.ExtendedFields['CUSTODIAN']       = ''
        ##################
        singleorder_submit_response = self.xapiLib.get_order_service_stub().SubmitSingleOrder(single_order)
        print("[SUBMIT] Server Response:" + str(singleorder_submit_response.ServerResponse))
        print("[SUBMIT] OrderTag:" + self.my_order_id)
        if single_order.ReturnResult:
            print("[SUBMIT] Order Details:" + str(singleorder_submit_response.OrderDetails))
            try:
                self.submitted_order_id = singleorder_submit_response.OrderDetails.OrderId
                print("[SUBMIT] OrderId:" + str(self.submitted_order_id))
            except Exception:
                pass
            print("[SUBMIT] PriceType: " + str(
                singleorder_submit_response.OrderDetails.PriceType.PriceType))  # Market = 0, Limit = 1, StopMarket = 2, StopLimit = 3, Other = 4


if __name__ == '__main__':
    submit_order = CreateSingleOrder()
    submit_order.xapiLib.login()

    # Start the SLOW subscription reader first so we capture the full lifecycle of the
    # seed order and any subsequent ChangeSingleOrder bursts.
    submit_order.start_listening()

    # Submit the seed order (the order we will hammer with ChangeSingleOrder).
    submit_order.send_single_order()  # API call

    print("\n" + "=" * 78)
    print("EBI-3515 REPRO STEPS:")
    print("  This process is now a SLOW subscription reader.")
    print("  In ANOTHER shell, run the change-order burst against the seed order:")
    print("    - copy the OrderId printed above into changesingleorder.py (self.order_id)")
    print("    - run: python changesingleorder.py   (stress mode is enabled there)")
    print("  Then watch the [HH:MM:SS] arrival lines and >>> GAP alerts here.")
    print("  WITHOUT the server fix (small HTTP/2 window): expect long GAPs + burst flushes.")
    print("  WITH the server fix (1MB/2MB window): expect smoother, near-real-time arrivals.")
    print("=" * 78 + "\n")

    # Keep listening for order updates indefinitely. The subscription runs on a
    # daemon thread; block the main thread here until the user interrupts (Ctrl+C).
    print("[MAIN] Listening for order updates indefinitely. Press Ctrl+C to stop.")
    try:
        while submit_order.thread.is_alive():
            submit_order.thread.join(timeout=1.0)
    except KeyboardInterrupt:
        print("\n[MAIN] Ctrl+C received; stopping.")
    submit_order.xapiLib.logout()
