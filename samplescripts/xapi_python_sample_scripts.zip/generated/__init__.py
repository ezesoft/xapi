"""Canonical home for protobuf-generated modules.

This package initializer registers each sibling ``*_pb2`` module twice:
once under its package-qualified name, such as ``generated.utilities_pb2``,
and once under its bare top-level name, such as ``utilities_pb2``.

That makes grpc-generated modules resilient to either import style:

- ``from . import utilities_pb2 as utilities__pb2``
- ``import utilities_pb2 as utilities__pb2``

The second form appears in some grpc Python outputs and normally fails when
the generated files live inside a package. By inserting aliases into
``sys.modules`` during package import, both styles resolve to the same module
object.

The repo root may also keep thin compatibility shims (for example
``order_pb2.py``) so older imports continue to work.
"""

import importlib
import pkgutil
import sys


def _register_pb2_aliases() -> None:
	"""Expose sibling ``*_pb2`` modules as top-level aliases.

	Python checks ``sys.modules`` before loading a module. Registering
	``generated.utilities_pb2`` as ``utilities_pb2`` allows grpc-generated bare
	imports to succeed without changing the generated files themselves.
	"""
	for module_info in pkgutil.iter_modules(__path__):
		module_name = module_info.name
		if not module_name.endswith("_pb2"):
			continue

		qualified_name = f"{__name__}.{module_name}"
		module = importlib.import_module(qualified_name)
		sys.modules.setdefault(module_name, module)


_register_pb2_aliases()
