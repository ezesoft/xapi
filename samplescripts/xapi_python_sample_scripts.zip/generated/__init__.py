"""Canonical home for protobuf-generated modules.

This package initializer registers each sibling ``*_pb2`` module twice:
once under its package-qualified name, such as ``generated.utilities_pb2``,
and once under its bare top-level name, such as ``utilities_pb2``.

That makes grpc-generated modules resilient to either import style:

- ``from . import utilities_pb2 as utilities__pb2``
- ``import utilities_pb2 as utilities__pb2``

The second form appears in some grpc Python outputs and normally fails when
the generated files live inside a package. By inserting aliases into
``sys.modules`` during package import, both styles resolve to the same module
object.

The repo root may also keep thin compatibility shims (for example
``order_pb2.py``) so older imports continue to work.
"""

import importlib
import pkgutil
import sys


def _register_pb2_aliases() -> None:
	"""Expose sibling ``*_pb2`` modules as top-level aliases.

	Python checks ``sys.modules`` before loading a module. Registering
	``generated.utilities_pb2`` as ``utilities_pb2`` allows grpc-generated bare
	imports to succeed without changing the generated files themselves.

	Load order matters. Modern grpc-tools output uses BARE imports for sibling
	pb2 dependencies (``import utilities_pb2`` rather than ``from . import``),
	so a dependent module like ``market_data_pb2`` triggers a top-level lookup
	for ``utilities_pb2`` the moment it's parsed. If we let ``pkgutil.iter_modules``
	drive the order alphabetically, ``market_data_pb2`` loads first and blows up
	before ``utilities_pb2`` has a chance to register.

	The workaround is to prime ``sys.modules`` with the leaf modules first.
	``utilities_pb2`` has no sibling pb2 dependencies; every other pb2 in this
	package (order/market_data) depends on it. Load leaves first, then everything
	else — that turns the bare imports inside dependent modules into ``sys.modules``
	hits and keeps the rest of the algorithm order-agnostic.
	"""
	# Modules that must be primed before any dependent module is parsed.
	# Keep this list dependency-free (no cross-pb2 imports).
	_LEAF_MODULES = ("utilities_pb2",)

	loaded: set[str] = set()

	def _load(module_name: str) -> None:
		if module_name in loaded:
			return
		qualified_name = f"{__name__}.{module_name}"
		module = importlib.import_module(qualified_name)
		# setdefault so we don't clobber an already-registered top-level module.
		sys.modules.setdefault(module_name, module)
		loaded.add(module_name)

	# Pass 1: load known leaves so their bare-name alias exists in sys.modules
	# before any dependent pb2 module runs its ``import utilities_pb2`` line.
	for name in _LEAF_MODULES:
		_load(name)

	# Pass 2: load everything else. Order within this pass is irrelevant now that
	# leaves are primed.
	for module_info in pkgutil.iter_modules(__path__):
		module_name = module_info.name
		if not module_name.endswith("_pb2"):
			continue
		_load(module_name)


_register_pb2_aliases()
