from emsxapilibrary import EMSXAPILibrary
import market_data_pb2 as mkt


class GetSymbolFromAlternateSymbology:  # set username, password, domain, locale, port number and server address details
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def get_symbol_from_alternate_symbology(self):
        self.xapiLib.login()

        request = mkt.SymbolFromAlternateSymbologyRequest()  # create symbolfromalternatesymbologyrequest
        request.Symbol = '037833100'  # any valid symbol such as Isin, Sedol, RIC, Cusip or BBG id
        request.SymbolInfo.SymbolOption = 3  # alternate symbology enum. Isin = 0, Sedol = 1 , RIC = 2, Cusip = 3 or BBG = 4
        request.UserToken = self.xapiLib.userToken
        response = self.xapiLib.get_market_data_service_stub().GetSymbolFromAlternateSymbology(
            request)  # API call to fetch symbol info from alternate symbology
        print(response.Acknowledgement.ServerResponse)  # accessing response object
        print(response.SymbolInfolist[0])

        self.xapiLib.logout()


if __name__ == "__main__":
    symbol_from_alternate_symbology_example = GetSymbolFromAlternateSymbology()  # password
    symbol_from_alternate_symbology_example.get_symbol_from_alternate_symbology()
