from emsxapilibrary import EMSXAPILibrary
import market_data_pb2


class GetLevel1MarketData:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def get_level1_market_data(self):
        self.xapiLib.login()
        print('User token: '+self.xapiLib.userToken)
        request = market_data_pb2.Level1MarketDataRequest()  # create Level1 market data request object
        request.UserToken = self.xapiLib.userToken
        request.Symbols.extend(["VOD.LSE", "BARC.LSE", "GSK.LSE"])  # List of ticker symbols
        response = self.xapiLib.get_market_data_service_stub().GetLevel1MarketData(request)  # API call to fetch Level1 market data
        print('Server Response: '+response.Acknowledgement.ServerResponse + ' | Message: '+response.Acknowledgement.Message)
        
        for data in response.DataRecord:
            if data.Bid.DecimalValue != 0.0 and data.Ask.DecimalValue != 0.0:
                print('DispName:{0} SymbolDesc:{1} Bid:{2} Ask:{3}'.format(data.DispName, data.SymbolDesc,
                                                                           data.Bid.DecimalValue,
                                                                           data.Ask.DecimalValue))
        self.xapiLib.logout()
        self.xapiLib.close_channel()


if __name__ == "__main__":
    get_level1_market_data_example = GetLevel1MarketData()
    get_level1_market_data_example.get_level1_market_data()
    
