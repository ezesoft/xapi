from emsxapilibrary import EMSXAPILibrary
import market_data_pb2 as mkt
from datetime import datetime
from datetime import timedelta


class CTickData:
    def __init__(self): # set username, password, domain, locale, port number and server address details
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()


    def getTickData(self):
        self.xapiLib.login()
        
        data = {
             "Symbol"   : 'symbol',
             "TickTypes": [{"TickOption": 1}, {"TickOption": 2}, {"TickOption": 3}]  #TRADE = 0;BID = 1;ASK = 2;REGIONAL_BID = 3;REGIONAL_ASK = 4;DELETED = 11;INSERTED = 12;IRREGULAR_DELETE = 44;FORM_T_TRADE = 32;
             }
        
        request = mkt.TickDataRequest(**data) # create getTickData request object
        request.UserToken = self.xapiLib.userToken
        request.Date.FromDatetime(datetime.now()) #The end date for the query, i.e. the most recent date for which Ticks should be retrieved.  If null, defaults to the current date.
        request.StartTime.FromTimedelta(timedelta(hours=12, minutes=10, seconds=50)) 	#Records earlier in the day than this start time will be excluded.  If null, there is no restriction.
        request.StopTime.FromTimedelta(timedelta(hours=20, minutes=30, seconds=40))  	#Records later in the day than this stop time will be excluded.  If null, there is no restriction.	
        request.RequestId.value = 12345	#A user-supplied request ID that can be used to disambiguate response data.  This is ignored by the server but will be echoed back
        response = self.xapiLib.get_market_data_service_stub().GetTickData(request) # API call to fetch tickdata	
        print(response.Acknowledgement.ServerResponse) # accessing response object

        self.xapiLib.logout()

if __name__ == "__main__":
    tick_data_example = CTickData()  # password
    tick_data_example.getTickData()


