"""Streaming API client example package."""
