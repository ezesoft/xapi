#!/usr/bin/env python3
"""
Streaming API Client - Python Implementation
==========================================

Command-line application for bidirectional streaming market data operations.
Supports adding/removing symbols, checking status, and changing subscriptions.

This script mirrors the functionality of the C# StreamingClientApp with:
- Modular architecture (RequestHandler, StatusManager, SymbolManager)
- Comprehensive logging for all subscription operations
- Bidirectional streaming with proper error handling
- Interactive command-line interface

Author: SS&C Eze Software
Date: December 1, 2025
"""

import asyncio
import concurrent.futures
import logging
import os
import queue
import sys
import threading
import time
from datetime import datetime
from typing import Dict, List, Set, Optional, Tuple

# EMSX API imports
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2
from generated import market_data_pb2_grpc


class StreamingLogger:
    """Enhanced file logger for streaming market data operations."""

    def __init__(self, log_directory: str = "logs"):
        """Initialize the streaming logger with timestamped log file."""
        self.log_directory = log_directory
        self._setup_logging()

    def _setup_logging(self):
        """Configure comprehensive logging for the streaming client."""
        # Create logs directory if it doesn't exist
        os.makedirs(self.log_directory, exist_ok=True)

        # Create log file with timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        log_filename = f"streaming_client_{timestamp}.log"
        self.log_file_path = os.path.join(self.log_directory, log_filename)

        # Configure logger
        self.logger = logging.getLogger("StreamingClient")
        self.logger.setLevel(logging.DEBUG)

        # Prevent duplicate handlers
        if self.logger.handlers:
            return

        # File handler for detailed logging
        file_handler = logging.FileHandler(self.log_file_path)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)

        # Console handler for important messages
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(console_formatter)

        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)

        # Log initialization
        self.logger.info("=== Streaming API Client Log Started ===")
        self.logger.info(f"Log file: {self.log_file_path}")
        self.logger.info(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    def log_subscription(self, operation: str, symbols: List[str], market_data_level: str = ""):
        """Log subscription operations (add, remove, change)."""
        symbol_list = ", ".join(symbols) if symbols else "NONE"
        level_info = f" | Level: {market_data_level}" if market_data_level else ""
        self.logger.info(f"SUBSCRIPTION | {operation} | Symbols: [{symbol_list}]{level_info}")

    def log_subscription_request(self, request_type: str, symbols: List[str],
                               market_data_level: str, user_token: str):
        """Log detailed subscription request information."""
        symbol_list = ", ".join(symbols) if symbols else "NONE"
        level_info = f" | Level: {market_data_level}" if market_data_level else ""
        token_info = f" | Token: {user_token[:8]}..." if user_token else " | Token: None"
        self.logger.info(f"REQUEST | {request_type} | Symbols: [{symbol_list}]{level_info}{token_info}")

    def log_streaming_response(self, response):
        """Log complete streaming response for debugging and action tracking."""
        try:
            response_str = str(response)
            # Convert to single line by replacing newlines
            response_str = response_str.replace('\n', ' ').replace('  ', ' ').strip()
            # Truncate very long responses for readability
            if len(response_str) > 1000:
                response_str = response_str[:1000] + "..."
            self.logger.info(f"STREAMING_RESPONSE | {response_str}")
        except Exception as e:
            self.logger.error(f"Error logging streaming response: {e}")

    def log_market_data(self, symbol: str, data_type: str, data: str):
        """Log market data in structured format."""
        self.logger.info(f"MARKET_DATA | {symbol} | {data_type} | {data}")

    def log_status(self, status: str):
        """Log status updates."""
        self.logger.info(f"STATUS | {status}")

    def log_error(self, error: str):
        """Log errors."""
        self.logger.error(f"ERROR | {error}")

    def log_success(self, message: str):
        """Log success messages."""
        self.logger.info(f"SUCCESS | {message}")

    def log_message(self, message: str):
        """Log a general message."""
        self.logger.info(f"MESSAGE | {message}")

    @property
    def log_path(self) -> str:
        """Get the current log file path."""
        return self.log_file_path


class StreamingClient:
    """Core streaming client handling bidirectional communication."""

    def __init__(self, xapi_lib):
        self.xapi_lib = xapi_lib
        self.logger = StreamingLogger()
        self.active_subscriptions = {
            'LEVEL1': set(),
            'LEVEL2': set(),
            'TICK': set(),
            # INTRADAY_BARS piggybacks on the same multiplexed stream. Symbols added
            # at this level receive INTRADAY_BAR_DATA responses (CLOSED bars on boundary;
            # PARTIAL every trade tick when EmitPartialBars=True). It intentionally does
            # NOT participate in the L1<->L2 CHANGE_SUBSCRIPTION swap in update_subscriptions.
            'INTRADAY_BARS': set()
        }
        # Bar-kind names mirror market_data.proto BarUpdateKind:
        #   0 UNSPECIFIED, 1 HISTORICAL, 2 PARTIAL, 3 CLOSED
        self._BAR_KIND_NAMES = {0: "UNSPECIFIED", 1: "HISTORICAL", 2: "PARTIAL", 3: "CLOSED"}
        self.is_streaming = False
        self.streaming_call = None
        self.response_thread = None
        self.request_queue = queue.Queue()
        self.ready_event = threading.Event()
        self.stop_event = threading.Event()
        self.console_lock = threading.Lock()

    def add_subscriptions(self, symbols: List[str], market_data_level: str):
        """Add symbols to active subscriptions tracking.
        A symbol can appear in multiple levels simultaneously (e.g. LEVEL1 + LEVEL2).
        We do NOT remove it from other levels here.
        """
        if market_data_level in self.active_subscriptions:
            self.active_subscriptions[market_data_level].update(symbols)

    def remove_subscriptions(self, symbols: List[str], market_data_level: str = ""):
        """Remove symbols from active subscriptions tracking.

        If market_data_level is provided, remove only from that level.
        If market_data_level is empty, remove from all levels (legacy fallback).
        """
        if market_data_level and market_data_level in self.active_subscriptions:
            self.active_subscriptions[market_data_level].difference_update(symbols)
            return

        for level_symbols in self.active_subscriptions.values():
            level_symbols.difference_update(symbols)

    def update_subscriptions(self, symbols: List[str], market_data_level: str):
        """Update subscription level for symbols (CHANGE_SUBSCRIPTION semantics).
        Removes the symbol from the other L-level (L1 <-> L2) but preserves TICK.
        """
        l_levels = {'LEVEL1', 'LEVEL2'}
        # Only remove from the opposite L-level, not from TICK
        for level in l_levels:
            if level != market_data_level and level in self.active_subscriptions:
                self.active_subscriptions[level].difference_update(symbols)
        # Add to the requested level
        if market_data_level in self.active_subscriptions:
            self.active_subscriptions[market_data_level].update(symbols)

    async def send_request_async(self, request):
        """Send a request through the streaming call."""
        if self.is_streaming:
            self.request_queue.put(request)

    async def start_streaming_async(self):
        """Start the bidirectional streaming connection."""
        try:
            self.logger.log_status("Starting bidirectional streaming connection...")

            # Set streaming flag
            self.is_streaming = True

            # Get the market data service stub
            stub = self.xapi_lib._mkt_data_svc_stub

            # Create synchronous request generator
            def request_generator():
                # Send initial request
                yield market_data_pb2.MarketDataStreamRequest(
                    UserToken=self.xapi_lib.userToken,
                    RequestType="INIT",
                    Request=True
                )
                # Process additional requests from queue
                while self.is_streaming:
                    try:
                        request = self.request_queue.get(timeout=0.1)
                        yield request
                    except queue.Empty:
                        continue

            # Start bidirectional streaming
            self.streaming_call = stub.StreamMarketData(request_generator())

            # Start response processing thread
            self.response_thread = threading.Thread(target=self._process_responses_sync)
            self.response_thread.daemon = True
            self.response_thread.start()

            # Wait for ready signal
            if self.ready_event.wait(timeout=10.0):
                self.logger.log_success("Bidirectional streaming connection established")
            else:
                raise TimeoutError("Timeout waiting for streaming connection to be ready")

        except Exception as e:
            self.logger.log_error(f"Failed to start streaming: {e}")
            raise

    async def stop_streaming_async(self):
        """Stop the streaming connection."""
        try:
            self.logger.log_status("Stopping streaming connection...")

            self.is_streaming = False

            # Wait for response thread to finish
            if self.response_thread and self.response_thread.is_alive():
                self.response_thread.join(timeout=5.0)

            self.logger.log_success("Streaming connection stopped")

        except Exception as e:
            self.logger.log_error(f"Error stopping streaming: {e}")

    def _process_responses_sync(self):
        """Process streaming responses synchronously."""
        try:
            for response in self.streaming_call:
                self._handle_response_sync(response)
        except Exception as e:
            self.logger.log_error(f"Error in synchronous response processing: {e}")

    def _handle_response_sync(self, response):
        """Handle individual streaming responses synchronously."""
        try:
            # Log the complete streaming response for debugging and action tracking
            self.logger.log_streaming_response(response)

            # Check for acknowledgments
            if hasattr(response, 'Acknowledgement') and response.Acknowledgement:
                ack = response.Acknowledgement
                if ack.ServerResponse == "success":
                    self.logger.log_success(f"Server acknowledgment: {ack.Message}")
                    if not self.ready_event.is_set():
                        self.ready_event.set()
                else:
                    self.logger.log_error(f"Server error: {ack.Message}")

            # Process different response types
            response_type = getattr(response, 'ResponseType', '')

            if response_type == "LEVEL1_DATA":
                self._process_level1_data_sync(response)
            elif response_type == "LEVEL2_DATA":
                self._process_level2_data_sync(response)
            elif response_type == "TICK_DATA":
                self._process_tick_data_sync(response)
            elif response_type == "INTRADAY_BAR_DATA":
                self._process_intraday_bar_data_sync(response)
            elif response_type == "STATUS_UPDATE":
                self.logger.log_status(f"Status update: {getattr(response, 'StatusMessage', 'Unknown')}")
            else:
                self.logger.log_message(f"Unknown response type: {response_type}")

        except Exception as e:
            self.logger.log_error(f"Error handling response: {e}")

    def _process_level1_data_sync(self, response):
        """Process Level1 market data synchronously."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')

            # Extract price data
            bid = getattr(response, 'Bid', None)
            ask = getattr(response, 'Ask', None)
            last = getattr(response, 'Trdprc1', None)

            bid_val = bid.DecimalValue if bid and hasattr(bid, 'DecimalValue') and not getattr(bid, 'Isnull', True) else 0.0
            ask_val = ask.DecimalValue if ask and hasattr(ask, 'DecimalValue') and not getattr(ask, 'Isnull', True) else 0.0
            last_val = last.DecimalValue if last and hasattr(last, 'DecimalValue') and not getattr(last, 'Isnull', True) else 0.0

            data = f"Bid: {bid_val:.2f} | Ask: {ask_val:.2f} | Last: {last_val:.2f}"
            self.logger.log_market_data(symbol, "LEVEL1", data)

        except Exception as e:
            self.logger.log_error(f"Error processing Level1 data: {e}")

    def _process_level2_data_sync(self, response):
        """Process Level2 market data synchronously."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')
            data = f"Level2 data for {symbol}"
            self.logger.log_market_data(symbol, "LEVEL2", data)
        except Exception as e:
            self.logger.log_error(f"Error processing Level2 data: {e}")

    def _process_tick_data_sync(self, response):
        """Process tick data synchronously."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')
            data = f"Tick data for {symbol}"
            self.logger.log_market_data(symbol, "TICK", data)
        except Exception as e:
            self.logger.log_error(f"Error processing tick data: {e}")

    def _process_intraday_bar_data_sync(self, response):
        """Process INTRADAY_BAR_DATA responses on the multiplexed stream.

        One response = one bar. Payload lives on ``response.Bar`` (IntradayBarUpdate);
        the owning symbol is on both ``response.DispName`` and ``response.Bar.Symbol``
        (they mirror each other for demux flexibility). ``response.BarInterval`` echoes
        the config interval in minutes so multi-interval subscriptions can route bars
        per interval without inspecting each bar's Kind.
        """
        try:
            bar = getattr(response, 'Bar', None)
            if bar is None:
                self.logger.log_error(
                    f"INTRADAY_BAR_DATA response missing Bar payload for symbol '{getattr(response, 'DispName', 'N/A')}'")
                return

            symbol = getattr(response, 'DispName', '') or getattr(bar, 'Symbol', '') or 'UNKNOWN'
            kind_name = self._BAR_KIND_NAMES.get(bar.Kind, f"UNKNOWN({bar.Kind})")
            interval = getattr(response, 'BarInterval', 0)

            ohlcv = self._extract_bar_ohlcv(bar)
            open_time_iso = self._extract_bar_timestamp(bar)
            data = self._format_bar_data(kind_name, interval, ohlcv, bar, open_time_iso)
            self.logger.log_market_data(symbol, "INTRADAY_BARS", data)
        except Exception as e:
            self.logger.log_error(f"Error processing intraday bar data: {e}")

    def _extract_bar_ohlcv(self, bar):
        """Extract OHLCV prices from bar with Isnull guards. Extracted to reduce cognitive complexity."""
        def _px(p):
            if p is None:
                return None
            if hasattr(p, 'Isnull') and getattr(p, 'Isnull', False):
                return None
            return getattr(p, 'DecimalValue', None)

        return {
            'open': _px(bar.OpenPrc),
            'high': _px(bar.High1),
            'low': _px(bar.Low1),
            'close': _px(bar.Settle)
        }

    def _extract_bar_timestamp(self, bar) -> str:
        """Extract bar OpenTime as ISO string. Extracted to reduce cognitive complexity."""
        if bar.OpenTime and bar.OpenTime.seconds:
            return bar.OpenTime.ToDatetime().isoformat()
        return ""

    def _format_bar_data(self, kind_name: str, interval: int, ohlcv: dict, bar, open_time_iso: str) -> str:
        """Format bar data for logging. Extracted to reduce cognitive complexity."""
        def _fmt(v):
            return f"{v:.4f}" if isinstance(v, float) else (str(v) if v is not None else "N/A")

        return (f"[{kind_name}] {interval}m "
                f"open={_fmt(ohlcv['open'])} high={_fmt(ohlcv['high'])} low={_fmt(ohlcv['low'])} close={_fmt(ohlcv['close'])} "
                f"vol={bar.AcVol1} ticks={bar.TickCount} ts={open_time_iso or 'N/A'}")

    async def _process_level1_data(self, response):
        """Process Level1 market data."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')

            # Extract price data
            bid = getattr(response, 'Bid', None)
            ask = getattr(response, 'Ask', None)
            last = getattr(response, 'Trdprc1', None)

            bid_val = bid.DecimalValue if bid and hasattr(bid, 'DecimalValue') and not getattr(bid, 'Isnull', True) else 0.0
            ask_val = ask.DecimalValue if ask and hasattr(ask, 'DecimalValue') and not getattr(ask, 'Isnull', True) else 0.0
            last_val = last.DecimalValue if last and hasattr(last, 'DecimalValue') and not getattr(last, 'Isnull', True) else 0.0

            data = f"Bid: {bid_val:.2f} | Ask: {ask_val:.2f} | Last: {last_val:.2f}"
            self.logger.log_market_data(symbol, "LEVEL1", data)

        except Exception as e:
            self.logger.log_error(f"Error processing Level1 data: {e}")

    async def _process_level2_data(self, response):
        """Process Level2 market data."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')
            data = f"Level2 data for {symbol}"
            self.logger.log_market_data(symbol, "LEVEL2", data)
        except Exception as e:
            self.logger.log_error(f"Error processing Level2 data: {e}")

    async def _process_tick_data(self, response):
        """Process tick data."""
        try:
            symbol = getattr(response, 'DispName', '') or getattr(response, 'SymbolDesc', '')
            data = f"Tick data for {symbol}"
            self.logger.log_market_data(symbol, "TICK", data)
        except Exception as e:
            self.logger.log_error(f"Error processing tick data: {e}")

    def log_message(self, message: str):
        """Log a general message."""
        self.logger.logger.info(message)


class RequestHandler:
    """Handles sending subscription requests to the streaming service."""

    def __init__(self, streaming_client: StreamingClient):
        self.streaming_client = streaming_client
        try:
            self.xapi_lib = EMSXAPILibrary.get()
        except Exception as e:
            print(f"Warning: Failed to get EMSXAPILibrary in RequestHandler: {e}")
            self.xapi_lib = None

    async def add_symbols_async(self, symbols: List[str], market_data_level: str,
                                bar_config: Optional[dict] = None):
        """Send a subscription request for adding symbols.

        ``bar_config`` is only meaningful when ``market_data_level`` is INTRADAY_BARS.
        It carries the per-symbol bar interval list, the EmitPartialBars flag, and
        an optional DaysBack backfill window — all validated up-front by the caller.
        """
        self.streaming_client.logger.log_subscription("ADD_SYMBOL", symbols, market_data_level)
        await self._send_subscription_request("ADD_SYMBOL", symbols, market_data_level, bar_config=bar_config)
        self.streaming_client.add_subscriptions(symbols, market_data_level)

    async def remove_symbols_async(self, symbols: List[str], market_data_level: str):
        """Send a level-specific subscription request for removing symbols."""
        self.streaming_client.logger.log_subscription("REMOVE_SYMBOL", symbols, market_data_level)
        await self._send_subscription_request("REMOVE_SYMBOL", symbols, market_data_level)
        self.streaming_client.remove_subscriptions(symbols, market_data_level)

    async def change_subscription_async(self, symbols: List[str], market_data_level: str):
        """Send a subscription request for changing subscription levels.

        CHANGE_SUBSCRIPTION doesn't support INTRADAY_BARS server-side; the UI
        already filters that option out, so we don't need to guard here.
        """
        self.streaming_client.logger.log_subscription("CHANGE_SUBSCRIPTION", symbols, market_data_level)
        await self._send_subscription_request("CHANGE_SUBSCRIPTION", symbols, market_data_level)
        self.streaming_client.update_subscriptions(symbols, market_data_level)

    async def _send_subscription_request(self, request_type: str, symbols: List[str], market_data_level: str,
                                         bar_config: Optional[dict] = None):
        """Send a subscription request to the server."""
        if not self.xapi_lib:
            print("Error: EMSXAPILibrary is not initialized")
            return

        request = market_data_pb2.MarketDataStreamRequest()
        request.UserToken = self.xapi_lib.userToken if self.xapi_lib else ""
        request.RequestType = request_type
        request.Request = True
        request.Advise = True

        if symbols:
            request.Symbols.extend(symbols)

        if market_data_level:
            request.MarketDataLevel = market_data_level

        # Populate INTRADAY_BARS-specific fields when the caller supplied them.
        self._populate_bar_config(request, bar_config, market_data_level)

        # Log the detailed request
        self.streaming_client.logger.log_subscription_request(
            request_type, symbols, market_data_level, request.UserToken
        )

        await self.streaming_client.send_request_async(request)

        # Log the action performed — include bar-config summary when relevant.
        self._log_subscription_action(request_type, market_data_level, symbols, bar_config)

    def _populate_bar_config(self, request, bar_config: Optional[dict], market_data_level: str) -> None:
        """Populate INTRADAY_BARS-specific fields. Extracted to reduce cognitive complexity."""
        if not (bar_config and market_data_level == "INTRADAY_BARS"):
            return

        intervals = bar_config.get("bar_intervals") or []
        if intervals:
            request.BarIntervals.extend(intervals)
        request.EmitPartialBars = bool(bar_config.get("emit_partial_bars", False))
        days_back = int(bar_config.get("days_back", 0) or 0)
        if days_back > 0:
            # DaysBack is Int32Value (wrapper) — only set when > 0 so the field is
            # visibly absent on the wire in the live-only case (matches the server's
            # "unset means live-only" semantics).
            request.DaysBack.value = days_back

    def _log_subscription_action(self, request_type: str, market_data_level: str, symbols: List[str],
                                 bar_config: Optional[dict]) -> None:
        """Log the subscription action performed. Extracted to reduce cognitive complexity."""
        symbol_list = ", ".join(symbols) if symbols else "NONE"
        extra = ""
        if bar_config and market_data_level == "INTRADAY_BARS":
            extra = (f" | Intervals: {bar_config.get('bar_intervals') or 'default(5m)'}"
                     f" | Partials: {bool(bar_config.get('emit_partial_bars', False))}"
                     f" | DaysBack: {int(bar_config.get('days_back', 0) or 0)}")
        self.streaming_client.logger.log_status(
            f"Action performed: {request_type} | Level: {market_data_level} | Symbols: [{symbol_list}]{extra}")


class SymbolManager:
    """Handles user input for symbol management operations."""

    def __init__(self, request_handler: RequestHandler):
        self.request_handler = request_handler
        if not hasattr(request_handler, 'streaming_client'):
            raise AttributeError("RequestHandler missing streaming_client attribute - initialization failed")
        self.streaming_client = request_handler.streaming_client

    async def handle_add_symbols_async(self):
        """Handle adding symbols to the stream.

        For INTRADAY_BARS the user is also prompted for per-symbol bar intervals,
        the EmitPartialBars flag, and an optional DaysBack historical-backfill
        window. Those extra fields are threaded through the RequestHandler and end
        up on the underlying MarketDataStreamRequest.
        """
        # INTRADAY_BARS is a valid ADD target, so the level menu here shows all 4 levels.
        symbols_input = (await asyncio.to_thread(input, "Enter symbols to add (comma-separated): ")).strip()
        if not symbols_input:
            self.streaming_client.logger.log_status("No symbols entered for operation")
            return
        symbols = [s.strip().upper() for s in symbols_input.split(',') if s.strip()]

        level = await self._get_level_input(include_intraday_bars=True)
        if not level:
            return

        bar_config = None
        if level == "INTRADAY_BARS":
            bar_config = await self._get_bar_config_input(len(symbols))
            if bar_config is None:
                # User bailed out of the bar-config prompt.
                return

        await self.request_handler.add_symbols_async(symbols, level, bar_config=bar_config)
        self.streaming_client.logger.log_success(f"Added symbols: {', '.join(symbols)} for {level} data")

    async def handle_remove_symbols_async(self):
        """Handle removing symbols from a specific subscription level.

        INTRADAY_BARS is valid for REMOVE too — the server tears down the
        per-symbol aggregator when the level is dropped.
        """
        symbols = await self._get_symbols_input("remove")
        if not symbols:
            return

        level = await self._get_level_input(include_intraday_bars=True)
        if not level:
            return

        await self.request_handler.remove_symbols_async(symbols, level)
        self.streaming_client.logger.log_success(f"Removed symbols: {', '.join(symbols)} from {level} streaming")

    async def handle_change_subscription_async(self):
        """Handle changing subscription levels for symbols.

        CHANGE_SUBSCRIPTION only supports L1 <-> L2 (and TICK) — the server does
        not support in-place interval changes for INTRADAY_BARS, so it is not
        offered here. To change intervals or reconfigure bars: REMOVE then ADD.
        """
        symbols = await self._get_symbols_input("change")
        if not symbols:
            return

        level = await self._get_level_input(include_intraday_bars=False)
        if not level:
            return

        await self.request_handler.change_subscription_async(symbols, level)
        self.streaming_client.logger.log_success(f"Changed subscription for symbols: {', '.join(symbols)} to {level}")

    async def _get_symbols_input(self, action: str) -> List[str]:
        """Get symbols input from user."""
        symbols_input = (await asyncio.to_thread(input, f"Enter symbols to {action} (comma-separated): ")).strip()
        if not symbols_input:
            self.streaming_client.logger.log_status("No symbols entered for operation")
            return []

        return [s.strip().upper() for s in symbols_input.split(',') if s.strip()]

    async def _get_level_input(self, include_intraday_bars: bool = False) -> str:
        """Get market data level input from user.

        When ``include_intraday_bars`` is True (ADD_SYMBOL / REMOVE_SYMBOL) the
        menu offers all 4 levels. When False (CHANGE_SUBSCRIPTION) it hides the
        INTRADAY_BARS option because the server rejects that transition.
        """
        print("\nAvailable market data levels:")
        print("1. LEVEL1 - Basic price data (bid, ask, last)")
        print("2. LEVEL2 - Market depth data")
        print("3. TICK - Individual trade ticks")
        if include_intraday_bars:
            print("4. INTRADAY_BARS - OHLCV bar aggregation (multi-interval, optional historical backfill)")

        max_choice = 4 if include_intraday_bars else 3
        prompt = f"Select level (1-{max_choice}): "

        while True:
            choice = (await asyncio.to_thread(input, prompt)).strip()
            if choice == "1":
                return "LEVEL1"
            elif choice == "2":
                return "LEVEL2"
            elif choice == "3":
                return "TICK"
            elif choice == "4" and include_intraday_bars:
                return "INTRADAY_BARS"
            else:
                self.streaming_client.logger.log_error("Invalid level choice selected")

    # Supported bar intervals mirror Constants.BarIntervals.Supported on the server —
    # keep this whitelist in sync or the server will reject the request with FAILED.
    _SUPPORTED_BAR_INTERVALS = {1, 5, 15, 30, 60, 240, 1440}

    async def _get_bar_config_input(self, symbol_count: int) -> Optional[dict]:
        """Prompt for the INTRADAY_BARS-specific fields.

        Returns a dict with keys {bar_intervals, emit_partial_bars, days_back} or
        None if the user aborts. Validates interval alignment (one interval, or
        one per symbol) and whitelist membership up-front so the client fails
        fast instead of round-tripping to the server for a rejection.
        """
        print("\nINTRADAY_BARS configuration:")
        print(f"  Supported intervals (minutes): {sorted(self._SUPPORTED_BAR_INTERVALS)}")
        print(f"  Alignment: 1 value = same interval for all {symbol_count} symbol(s), or exactly {symbol_count} values (one per symbol)")

        intervals_raw = (await asyncio.to_thread(input, f"  Bar interval(s) [default 5]: ")).strip()
        bar_intervals = await self._validate_bar_intervals(intervals_raw, symbol_count)
        if bar_intervals is None:
            return None

        partials_raw = (await asyncio.to_thread(input, "  Emit PARTIAL bars on every trade tick? [y/N]: ")).strip().lower()
        emit_partial_bars = partials_raw in ("y", "yes", "true", "1")

        days_back_raw = (await asyncio.to_thread(input, "  Historical backfill (DaysBack) [default 0 = live-only]: ")).strip()
        days_back = await self._validate_days_back(days_back_raw)
        if days_back is None:
            return None

        return {
            "bar_intervals": bar_intervals,
            "emit_partial_bars": emit_partial_bars,
            "days_back": days_back,
        }

    async def _validate_bar_intervals(self, intervals_raw: str, symbol_count: int) -> Optional[List[int]]:
        """Validate and parse bar intervals input. Extracted to reduce cognitive complexity."""
        if not intervals_raw:
            return []  # server will apply the default (5m)

        try:
            bar_intervals = [int(x.strip()) for x in intervals_raw.split(',') if x.strip()]
        except ValueError:
            self.streaming_client.logger.log_error("Bar intervals must be comma-separated integers")
            return None

        if len(bar_intervals) not in (1, symbol_count):
            self.streaming_client.logger.log_error(
                f"BarIntervals length ({len(bar_intervals)}) must be 1 or match Symbols length ({symbol_count})")
            return None

        for iv in bar_intervals:
            if iv not in self._SUPPORTED_BAR_INTERVALS:
                self.streaming_client.logger.log_error(
                    f"Unsupported bar interval {iv}. Supported: {sorted(self._SUPPORTED_BAR_INTERVALS)}")
                return None

        return bar_intervals

    async def _validate_days_back(self, days_back_raw: str) -> Optional[int]:
        """Validate and parse DaysBack input. Extracted to reduce cognitive complexity."""
        if not days_back_raw:
            return 0

        try:
            days_back = int(days_back_raw)
        except ValueError:
            self.streaming_client.logger.log_error("DaysBack must be a non-negative integer")
            return None

        if days_back < 0:
            self.streaming_client.logger.log_error("DaysBack must be a non-negative integer")
            return None

        return days_back


class StatusManager:
    """Handles status display and monitoring operations."""

    def __init__(self, request_handler: RequestHandler, streaming_client: StreamingClient):
        self.request_handler = request_handler
        self.streaming_client = streaming_client

    async def handle_check_status_async(self):
        """Handle status check request."""
        connection_status = "Connected" if self.streaming_client.ready_event.is_set() else "Disconnected"

        # Build a per-level view that correctly reflects multi-level subscriptions.
        # active_subscriptions is{ level -> set(symbols) } where a symbol CAN appear
        # in more than one level at the same time.
        all_subscribed: dict[str, set] = self.streaming_client.active_subscriptions

        # Total unique symbols across all levels
        unique_symbols: set = set().union(*all_subscribed.values())

        # Per-symbol level list for display
        symbol_levels: dict[str, list] = {}
        for level, syms in all_subscribed.items():
            for sym in syms:
                symbol_levels.setdefault(sym, []).append(level)

        # Log line
        status_info = []
        for level, symbols in all_subscribed.items():
            if symbols:
                status_info.append(f"{level}: {', '.join(sorted(symbols))}")
        status_info.append(f"Total unique symbols: {len(unique_symbols)}")
        status_info.append(f"Connection: {connection_status}")
        self.streaming_client.logger.log_status(f"Status check | {' | '.join(status_info)}")

        # Display to user
        print("\n=== Current Streaming Status ===")
        print(f"Connection Status: {connection_status}")
        print()
        print("Active Subscriptions (by level):")
        for level in ('LEVEL1', 'LEVEL2', 'TICK', 'INTRADAY_BARS'):
            syms = sorted(all_subscribed.get(level, set()))
            if syms:
                print(f"  {level}: {', '.join(syms)}")
            else:
                print(f"  {level}: None")
        print()
        print(f"Total unique symbols: {len(unique_symbols)}")
        if symbol_levels:
            print()
            print("Per-symbol level detail:")
            for sym in sorted(symbol_levels):
                levels_str = ' + '.join(sorted(symbol_levels[sym]))
                print(f"  {sym}: [{levels_str}]")
        print(f"Log File: {self.streaming_client.logger.log_path}")
        print("================================")

    async def view_logs_async(self, num_lines: int = 20):
        """View the last N lines of the log file dynamically."""
        import subprocess
        import platform
        
        log_path = self.streaming_client.logger.log_path
        
        print(f"\n=== Viewing Log File (last {num_lines} lines) ===")
        print(f"Log file: {log_path}")
        print("Press Enter to refresh, 'q' to quit, or enter number of lines to show")
        print("="*50)
        
        while True:
            try:
                # Read and display last N lines
                with open(log_path, 'r') as f:
                    lines = f.readlines()
                    last_lines = lines[-num_lines:] if len(lines) >= num_lines else lines
                    print(f"\n--- Last {len(last_lines)} log entries ---")
                    for line in last_lines:
                        print(line.rstrip())
                    print(f"--- End of log (total: {len(lines)} lines) ---")
                
                # Wait for user input
                user_input = (await asyncio.to_thread(input, "\n[Enter=refresh, q=quit, number=lines]: ")).strip().lower()
                
                if user_input == 'q':
                    break
                elif user_input.isdigit():
                    num_lines = int(user_input)
                # else: refresh with current num_lines
                    
            except FileNotFoundError:
                print(f"Log file not found: {log_path}")
                break
            except Exception as e:
                print(f"Error reading log: {e}")
                break

    async def open_log_in_terminal_async(self):
        """Open a new terminal window to tail the log file."""
        import subprocess
        import platform
        
        log_path = self.streaming_client.logger.log_path
        
        try:
            if platform.system() == 'Windows':
                # Use PowerShell to tail the file
                cmd = f'start powershell -NoExit -Command "Get-Content -Path \"{log_path}\" -Wait -Tail 50"'
                subprocess.Popen(cmd, shell=True)
                print(f"Opened new terminal to tail: {log_path}")
            else:
                # Unix/Mac
                subprocess.Popen(['gnome-terminal', '--', 'tail', '-f', log_path])
                print(f"Opened new terminal to tail: {log_path}")
        except Exception as e:
            print(f"Could not open terminal: {e}")
            print(f"You can manually run: Get-Content -Path \"{log_path}\" -Wait -Tail 50")


async def show_command_menu_async(symbol_manager: SymbolManager, status_manager: StatusManager):
    """Display and handle the interactive command menu."""
    while True:
        print("\n=== Streaming Market Data Client ===")
        print("Available commands:")
        print("1. Add symbols to stream")
        print("2. Remove symbols from stream")
        print("3. Change subscription level")
        print("4. Check status")
        print("5. View logs (inline)")
        print("6. Open log in new terminal")
        print("7. Exit")
        print("==================================")

        choice = (await asyncio.to_thread(input, "Enter your choice (1-7): ")).strip()

        try:
            if choice == "1":
                await symbol_manager.handle_add_symbols_async()
            elif choice == "2":
                await symbol_manager.handle_remove_symbols_async()
            elif choice == "3":
                await symbol_manager.handle_change_subscription_async()
            elif choice == "4":
                await status_manager.handle_check_status_async()
            elif choice == "5":
                await status_manager.view_logs_async()
            elif choice == "6":
                await status_manager.open_log_in_terminal_async()
            elif choice == "7":
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please select 1-7.")
        except Exception as e:
            print(f"Error processing command: {e}")


async def main():
    """Main application entry point."""
    print("=== Bidirectional Streaming Market Data Client (Python) ===")
    print("Command-line interface for market data operations")
    print()

    streaming_client = None

    try:
        # Initialize EMSXAPILibrary
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "runtime", "config.cfg")
        EMSXAPILibrary.create(config_path)
        xapi_lib = EMSXAPILibrary.get()

        # Perform login
        xapi_lib.login()
        if not xapi_lib.userToken:
            print("Login failed. Please check your configuration.")
            return

        print("Successfully logged in and connected to EMS XAPI server.")

        # Create components
        streaming_client = StreamingClient(xapi_lib)
        request_handler = RequestHandler(streaming_client)
        symbol_manager = SymbolManager(request_handler)
        status_manager = StatusManager(request_handler, streaming_client)

        print(f"Streaming data will be logged to: {streaming_client.logger.log_path}")
        print()

        # Start the streaming connection
        await streaming_client.start_streaming_async()

        # Show the command menu
        await show_command_menu_async(symbol_manager, status_manager)

        # Stop streaming and cleanup
        await streaming_client.stop_streaming_async()

        print("\n=== Streaming client completed successfully ===")

    except Exception as e:
        print(f"Error in streaming client: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Ensure proper cleanup
        if streaming_client:
            await streaming_client.stop_streaming_async()


if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main())