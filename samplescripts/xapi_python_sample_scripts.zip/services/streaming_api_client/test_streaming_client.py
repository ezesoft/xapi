#!/usr/bin/env python3
"""
Simple test script for the Streaming API Client
Tests basic functionality without requiring server connection
"""

import sys
import os
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from streaming_client_app import StreamingLogger, SymbolManager, StatusManager, StreamingClient

def test_logging():
    """Test the logging functionality."""
    print("Testing StreamingLogger...")

    logger = StreamingLogger("test_logs")

    # Test subscription logging
    logger.log_subscription("ADD_SYMBOL", ["AAPL", "GOOG"], "LEVEL1")
    logger.log_subscription_request("ADD_SYMBOL", ["AAPL", "GOOG"], "LEVEL1", "test_token_123")

    # Test market data logging
    logger.log_market_data("AAPL", "LEVEL1", "Bid: 150.25 | Ask: 150.30 | Last: 150.27")

    # Test status logging
    logger.log_status("Connection established")
    logger.log_success("Test completed successfully")

    print(f"✓ Logs written to: {logger.log_path}")

def test_symbol_manager():
    """Test symbol manager input handling."""
    print("\nTesting SymbolManager input handling...")

    # Mock request handler for testing
    class MockStreamingClient:
        def __init__(self):
            self.logger = StreamingLogger("test_logs")

    class MockRequestHandler:
        def __init__(self):
            self.streaming_client = MockStreamingClient()

        async def add_symbols_async(self, symbols, level):
            print(f"Mock: Adding symbols {symbols} for {level}")

    request_handler = MockRequestHandler()
    symbol_manager = SymbolManager(request_handler)

    # Test level input
    print("Testing level input parsing...")
    # Note: We can't easily test interactive input in automated test
    print("✓ SymbolManager class structure validated")

def test_status_manager():
    """Test status manager functionality."""
    print("\nTesting StatusManager...")

    # Mock components for testing
    class MockStreamingClient:
        def __init__(self):
            self.active_subscriptions = {
                'LEVEL1': {'AAPL', 'GOOG'},
                'LEVEL2': set(),
                'TICK': {'MSFT'}
            }
            self.ready_event = type('MockEvent', (), {'is_set': lambda: True})()
            self.logger = StreamingLogger("test_logs")

    class MockRequestHandler:
        pass

    streaming_client = MockStreamingClient()
    request_handler = MockRequestHandler()
    status_manager = StatusManager(request_handler, streaming_client)

    print("✓ StatusManager class structure validated")


def test_level_specific_remove_tracking():
    """Test that remove tracking can target a specific level."""
    print("\nTesting level-specific remove tracking...")

    class MockXapiLib:
        pass

    streaming_client = StreamingClient(MockXapiLib())
    streaming_client.add_subscriptions(["AAPL"], "LEVEL1")
    streaming_client.add_subscriptions(["AAPL"], "LEVEL2")

    streaming_client.remove_subscriptions(["AAPL"], "LEVEL1")

    assert "AAPL" not in streaming_client.active_subscriptions["LEVEL1"]
    assert "AAPL" in streaming_client.active_subscriptions["LEVEL2"]
    print("✓ Level-specific remove tracking validated")


def test_change_subscription_preserves_tick_tracking():
    """Test that changing L1/L2 preserves TICK tracking for same symbol."""
    print("\nTesting change-subscription tracking semantics...")

    class MockXapiLib:
        pass

    streaming_client = StreamingClient(MockXapiLib())
    streaming_client.add_subscriptions(["AAPL"], "LEVEL1")
    streaming_client.add_subscriptions(["AAPL"], "TICK")

    streaming_client.update_subscriptions(["AAPL"], "LEVEL2")

    assert "AAPL" not in streaming_client.active_subscriptions["LEVEL1"]
    assert "AAPL" in streaming_client.active_subscriptions["LEVEL2"]
    assert "AAPL" in streaming_client.active_subscriptions["TICK"]
    print("✓ Change-subscription tracking semantics validated")

def main():
    """Run all tests."""
    print("=== Streaming API Client - Test Suite ===")

    try:
        test_logging()
        test_symbol_manager()
        test_status_manager()
        test_level_specific_remove_tracking()
        test_change_subscription_preserves_tick_tracking()

        print("\n✅ All tests passed! The streaming client components are properly structured.")
        print("\nTo run the full application:")
        print("  python streaming_client_app.py")
        print("\nMake sure config.cfg is properly configured for your EMSX environment.")

    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0

if __name__ == "__main__":
    sys.exit(main())