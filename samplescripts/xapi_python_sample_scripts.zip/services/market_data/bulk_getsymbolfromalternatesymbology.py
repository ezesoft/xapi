from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class BulkSymbolFromAlternateSymbology:  # set username, password, domain, locale, port number and server address details
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def _validate_response(self, response):
        """Validate the API response and return success status."""
        if hasattr(response, 'Acknowledgement'):
            print('Server Response: ' + response.Acknowledgement.ServerResponse +
                  ' | Message: ' + response.Acknowledgement.Message)

            if response.Acknowledgement.ServerResponse != "success":
                print(f'API Error: {response.Acknowledgement.Message}')
                return False
        return True

    def _print_summary(self, response):
        """Print bulk summary statistics."""
        print(f'Total: {response.TotalCount} | Success: {response.SuccessCount} | Failed: {response.FailureCount}')

    def _print_detailed_results(self, results):
        """Print detailed results for bulk symbol lookup."""
        for result in results:
            print(f'\nSymbol: {result.RequestedSymbol}')
            if result.SymbolInfolist:
                for i, symbol_info in enumerate(result.SymbolInfolist):
                    print(f'  Result {i+1}: {symbol_info}')
            else:
                print(f'  {result.Acknowledgement.Message}')

    def get_bulk_symbol_from_alternate_symbology(self):
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = mkt.SymbolFromAlternateSymbologyRequest()  # create symbolfromalternatesymbologyrequest
            # Bulk lookup - use Symbols field (repeated) instead of single Symbol field
            request.Symbols.extend([
                '037833100',  # Apple CUSIP
                '594918104',  # Microsoft CUSIP
                '30303M102'   # Meta CUSIP
            ])
            request.SymbolInfo.SymbolOption = 3  # alternate symbology enum. Isin = 0, Sedol = 1 , RIC = 2, Cusip = 3 or BBG = 4
            request.UserToken = self.xapiLib.userToken

            response = self.xapiLib.get_market_data_service_stub().GetSymbolFromAlternateSymbology(
                request)  # API call to fetch symbol info from alternate symbology (bulk)

            # Validate response
            if not self._validate_response(response):
                return

            # Display bulk summary
            self._print_summary(response)

            # Check if Results exist (bulk response)
            if hasattr(response, 'Results') and response.Results:
                print('\nDetailed Results:')
                self._print_detailed_results(response.Results)
            else:
                print('No results found')

        except Exception as e:
            print(f'Error: {e}')
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    bulk_symbol_example = BulkSymbolFromAlternateSymbology()
    bulk_symbol_example.get_bulk_symbol_from_alternate_symbology()
