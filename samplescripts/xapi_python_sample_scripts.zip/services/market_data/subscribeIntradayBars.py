import argparse
import logging
import os
import sys
import time
from threading import Event, Thread

# Ensure both the package root and the generated/ folder are on sys.path so the
# protoc-generated modules (which use bare `import utilities_pb2`) resolve.
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", ".."))
for _p in (_ROOT, os.path.join(_ROOT, "generated")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from generated import market_data_pb2
from runtime.emsxapilibrary import EMSXAPILibrary


# BarUpdateKind values mirror market_data.proto:
#   0 BAR_KIND_UNSPECIFIED, 1 HISTORICAL, 2 PARTIAL, 3 CLOSED
KIND_NAMES = {0: "UNSPECIFIED", 1: "HISTORICAL", 2: "PARTIAL", 3: "CLOSED"}


class SubscribeIntradayBars:
    def __init__(self, symbol, bar_interval, days_back, emit_partials, max_messages):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        self.ready = Event()
        self.stop = Event()
        self.done = Event()
        self.symbol = symbol
        self.bar_interval = bar_interval
        self.days_back = days_back
        self.emit_partials = emit_partials
        self.max_messages = max_messages
        self.message_count = 0
        self.bar_count = 0
        self._call = None

    def start_listening(self):
        self.thread = Thread(target=self._subscribe_intraday_bars, daemon=True)
        self.thread.start()
        self.ready.wait()

    def _subscribe_intraday_bars(self):
        request = market_data_pb2.SubscribeIntradayBarsRequest(
            BarInterval=self.bar_interval,
            StartAtMidnight=False,
            ShowPrePostMarket=False,
            EmitPartialBars=self.emit_partials,
        )
        # Symbols is a repeated field (REQ-7 multi-symbol support)
        request.Symbols.append(self.symbol)
        request.UserToken = self.xapiLib.userToken
        if self.days_back > 0:
            request.DaysBack.value = self.days_back
        request.RequestId.value = 12345

        logging.info("Request: %s", request)
        self._call = self.xapiLib.get_market_data_service_stub().SubscribeIntradayBars(request)
        self.ready.set()

        try:
            for data in self._call:
                if self.stop.is_set():
                    break
                self.message_count += 1

                if data.Acknowledgement.ServerResponse != "success":
                    print("Server Response: {0}, Error: {1}".format(
                        data.Acknowledgement.ServerResponse,
                        data.Acknowledgement.Message))
                    break

                for bar in data.Bars:
                    self.bar_count += 1
                    kind = KIND_NAMES.get(bar.Kind, str(bar.Kind))
                    open_time = bar.OpenTime.ToDatetime().isoformat() if bar.OpenTime.seconds else ""
                    print(
                        "{kind:<10} {sym} {interval}m  open={o:.4f} high={h:.4f} "
                        "low={l:.4f} close={c:.4f} vol={v} ticks={n} ts={t}".format(
                            kind=kind,
                            sym=data.DispName,
                            interval=data.BarInterval,
                            o=bar.OpenPrc.DecimalValue,
                            h=bar.High1.DecimalValue,
                            l=bar.Low1.DecimalValue,
                            c=bar.Settle.DecimalValue,
                            v=bar.AcVol1,
                            n=bar.TickCount,
                            t=open_time,
                        ))
                    logging.info(bar)

                if self.max_messages and self.message_count >= self.max_messages:
                    print("[reached max_messages={}]".format(self.max_messages))
                    break
        except Exception as e:
            print("[stream ended] {}".format(e))
        finally:
            self.done.set()

    def cancel(self):
        self.stop.set()
        if self._call is not None:
            try:
                self._call.cancel()
            except Exception:
                pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default="VOD.LSE")
    parser.add_argument("--interval", type=int, default=5, help="bar interval in minutes")
    parser.add_argument("--days-back", type=int, default=1, help="historical backfill window in days")
    parser.add_argument("--partials", action="store_true", help="emit partial bar updates")
    parser.add_argument("--max-messages", type=int, default=20, help="exit after N messages")
    parser.add_argument("--timeout", type=int, default=120, help="hard exit after T seconds")
    args = parser.parse_args()

    logging.basicConfig(
        filename="SubscribeIntradayBars.log",
        level=logging.INFO,
        format="%(asctime)s %(message)s",
    )

    example = SubscribeIntradayBars(
        symbol=args.symbol,
        bar_interval=args.interval,
        days_back=args.days_back,
        emit_partials=args.partials,
        max_messages=args.max_messages,
    )
    example.xapiLib.login()
    try:
        example.start_listening()
        example.done.wait(timeout=args.timeout)
        if not example.done.is_set():
            print("[hit timeout={}s, cancelling]".format(args.timeout))
            example.cancel()
            example.done.wait(timeout=5)
        print("[summary] messages={} bars={}".format(example.message_count, example.bar_count))
    finally:
        try:
            example.xapiLib.logout()
        finally:
            example.xapiLib.close_channel()


if __name__ == "__main__":
    main()
