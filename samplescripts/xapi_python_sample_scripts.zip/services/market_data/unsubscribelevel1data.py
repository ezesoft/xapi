"""
UnSubscribeLevel1Data API

This module provides functionality to unsubscribe from Level 1 market data streaming.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class UnSubscribeLevel1Data:
    """
    Unsubscribes from Level 1 market data streaming.

    This class provides methods to stop receiving Level 1 market data updates
    that were previously subscribed to via SubscribeLevel1Ticks.
    """

    def __init__(self):
        """
        Initialize the UnSubscribeLevel1Data instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def unsubscribe_level1_data(self):
        """
        Unsubscribe from all Level 1 market data streams.

        This method sends an unsubscribe request to stop receiving Level 1
        market data updates for all previously subscribed symbols.

        Returns:
            bool: True if unsubscribe was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = mkt.UnSubscribeLevel1DataRequest()
            request.UserToken = self.xapiLib.userToken

            response = self.xapiLib.get_market_data_service_stub().UnSubscribeLevel1Data(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse == "success":
                    print('Successfully unsubscribed from Level 1 data')
                    if hasattr(response, 'ServerResponse') and response.ServerResponse:
                        print(f'Server Response Detail: {response.ServerResponse}')
                    return True
                else:
                    print(f'API Error: {response.Acknowledgement.Message}')
                    if hasattr(response, 'OptionalFields') and 'ErrorMessage' in response.OptionalFields:
                        print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                    return False

            return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    unsubscribe_example = UnSubscribeLevel1Data()
    unsubscribe_example.unsubscribe_level1_data()
