"""
GetDescriptionFromOptionSymbol API

This module provides functionality to retrieve option description details
from an option symbol.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class GetDescriptionFromOptionSymbol:
    """
    Retrieves option description details from an option symbol.

    This class provides methods to convert an option symbol into its
    description components (root symbol, expiration date, call/put type,
    and strike price).
    """

    def __init__(self):
        """
        Initialize the GetDescriptionFromOptionSymbol instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def get_description_from_option_symbol(self, symbol):
        """
        Retrieve the option description for the given option symbol.

        Args:
            symbol (str): The option symbol to decode (e.g., 'AAPL240315C00150000').

        Returns:
            dict: A dictionary containing the option description fields:
                - root (str): The root symbol
                - expiration (str): The expiration date
                - option_type (int): 0 for CALL, 1 for PUT
                - strike_price (float): The strike price
            Returns None if the request fails.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = mkt.DescriptionFromOptionSymbolRequest()
            request.UserToken = self.xapiLib.userToken
            request.Symbol = symbol

            response = self.xapiLib.get_market_data_service_stub().GetDescriptionFromOptionSymbol(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse != "success":
                    print(f'API Error: {response.Acknowledgement.Message}')
                    return None

            result = {
                'root': response.Root if hasattr(response, 'Root') else '',
                'expiration': response.Expiration if hasattr(response, 'Expiration') else '',
                'option_type': response.OptionType.CallOrPut if hasattr(response, 'OptionType') else None,
                'strike_price': response.StrikePrice if hasattr(response, 'StrikePrice') else 0.0
            }

            option_type_str = 'CALL' if result['option_type'] == 0 else 'PUT'
            print(f"Root: {result['root']}")
            print(f"Expiration: {result['expiration']}")
            print(f"Option Type: {option_type_str}")
            print(f"Strike Price: {result['strike_price']}")

            return result

        except Exception as e:
            print(f'Error: {e}')
            return None
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    description_example = GetDescriptionFromOptionSymbol()
    # Example: Get description for an option symbol
    description_example.get_description_from_option_symbol('AAPL240315C00150000')
