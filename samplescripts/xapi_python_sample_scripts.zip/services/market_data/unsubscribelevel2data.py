"""
UnSubscribeLevel2Data API

This module provides functionality to unsubscribe from Level 2 market data streaming.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class UnSubscribeLevel2Data:
    """
    Unsubscribes from Level 2 market data streaming.

    This class provides methods to stop receiving Level 2 market data updates
    that were previously subscribed to via SubscribeLevel2Ticks.
    """

    def __init__(self):
        """
        Initialize the UnSubscribeLevel2Data instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def unsubscribe_level2_data(self):
        """
        Unsubscribe from all Level 2 market data streams.

        This method sends an unsubscribe request to stop receiving Level 2
        market data updates for all previously subscribed symbols.

        Returns:
            bool: True if unsubscribe was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = mkt.UnSubscribeLevel2DataRequest()
            request.UserToken = self.xapiLib.userToken

            response = self.xapiLib.get_market_data_service_stub().UnSubscribeLevel2Data(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse == "success":
                    print('Successfully unsubscribed from Level 2 data')
                    if hasattr(response, 'ServerResponse') and response.ServerResponse:
                        print(f'Server Response Detail: {response.ServerResponse}')
                    return True
                else:
                    print(f'API Error: {response.Acknowledgement.Message}')
                    if hasattr(response, 'OptionalFields') and 'ErrorMessage' in response.OptionalFields:
                        print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                    return False

            return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    unsubscribe_example = UnSubscribeLevel2Data()
    unsubscribe_example.unsubscribe_level2_data()
