"""
EBI-3464  —  StreamMarketData TICK UTC-midnight rollover regression script
==========================================================================

PURPOSE
-------
This script reproduces and then verifies the fix for the client-reported issue
where TICK_DATA responses go silent for CME futures symbols between roughly
04:00 and 09:00 UTC daily while LEVEL1_DATA keeps flowing on the same stream.

ROOT CAUSE (2026.4 and older)
-----------------------------
BuildTickRequestWindowUtc captured DateTime.UtcNow at subscribe time and
built a date-scoped TQL window:

    TqlForTimeAndSales(symbol, date=TODAY, startTime=now-8h, stopTime=23:59:59)

After UTC midnight, all new CME trades are stamped with the NEXT UTC date.
Because the TQL was scoped to TODAY (the subscribe date), those trades are
outside the query — the toolkit stops delivering them.  LEVEL1 uses an undated
rolling LivequoteRecord so it never goes silent, masking the bug.

FIX (2026.5)
-----------
1. The window is now anchored to the current UTC calendar day at subscribe time
   (startTime=00:00:00 when duration >= 24h so all of today is captured).
2. A per-user System.Threading.Timer fires just after each UTC midnight and
   rebuilds the subscription with the new date, keeping the TQL current.
3. DefaultTickDurationHours raised from 8 to 24 as belt-and-braces.

HOW TO USE THIS SCRIPT
-----------------------
Run it at any time of day.  The script:

  Phase 0 — Order submission
    Submit one market order per symbol in SYMBOLS using the configured
    Route and Account.  Runs on the same session as the market data phases
    so no second login is needed.  Skipped if ORDER_ROUTE is empty.

  Phase 1 — Baseline check
    Subscribe /ESU6 (or your CME symbol) at TICK + LEVEL1.
    Measure tick rate over a 60s window.
    Print a PASS/FAIL verdict with tick count and rate.

  Phase 2 — Midnight-rollover simulation
    Synthetically advance the TQL date to yesterday (mimicking what the server
    did on 2026.4).  Re-subscribe with that stale date.  Verify tick rate
    collapses (reproduces the bug on a patched server by injecting the old
    window explicitly via the SubscribeTickData RPC, which still accepts
    explicit Date/StartTime/StopTime fields).
    Print a WARN if ticks keep flowing (server-side fix prevents reproduction
    via the streaming path, which is expected on 2026.5+).

  Phase 3 — Post-rollover verify (2026.5 path)
    Re-subscribe via StreamMarketData ADD_SYMBOL (the patched path).
    Measure tick rate over a 60s window.
    Print PASS if ticks are flowing, FAIL if silent.

EXPECTED RESULTS
----------------
  2026.4 and older  →  Phase 1 PASS (if run during RTH), Phase 2 WARN/SILENT,
                        Phase 3 FAIL (off-hours) or PASS (during RTH only)
  2026.5 and newer  →  Phase 1 PASS, Phase 2 WARN (fix prevents injection),
                        Phase 3 PASS at any hour including 04:00–09:00 UTC

CONFIGURATION
-------------
Edit SYMBOLS, OBSERVATION_SECONDS, and MIN_TICKS_EXPECTED below, or set
environment variables:
    TICK_SYMBOLS         comma-separated symbols  (default: /ESU6,/ESTU6)
    TICK_OBS_SECONDS     observation window        (default: 60)
    TICK_MIN_EXPECTED    minimum ticks for PASS    (default: 5)
    TICK_SERVER_VERSION  label printed in output   (default: unknown)
    XAPI_CONFIG_FILE     path to config.cfg        (default: config.cfg)
    ORDER_ROUTE          order route               (default: CAT-NEELIMA)
    ORDER_ACCOUNT        Bank;Branch;Customer;Deposit (default: S;BMOHAN;BMOHAN;TRADING)
    ORDER_SIDE           BUY or SELL               (default: BUY)
    ORDER_QTY            order quantity            (default: 1)
    ORDER_PRICE_TYPE     0=Market 1=Limit          (default: 0)

REQUIREMENTS
------------
  pip install grpcio protobuf
  config.cfg in Client/XapiClient/runtime/ with valid credentials.
"""

import os
import sys
import time
import queue
import threading
from datetime import datetime, timedelta, timezone

# ---------------------------------------------------------------------------
# Path bootstrap — allow running from repo root or from this directory
# ---------------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
_CLIENT_ROOT = os.path.normpath(os.path.join(_HERE, "..", ".."))
if _CLIENT_ROOT not in sys.path:
    sys.path.insert(0, _CLIENT_ROOT)

from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2, order_pb2
from google.protobuf import timestamp_pb2, duration_pb2

# ---------------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------ ---------
SYMBOLS = [s.strip() for s in os.getenv("TICK_SYMBOLS", "/ESU6,/RTYU6").split(",") if s.strip()]
OBSERVATION_SECONDS = int(os.getenv("TICK_OBS_SECONDS", "60"))
MIN_TICKS_EXPECTED = int(os.getenv("TICK_MIN_EXPECTED", "5"))
SERVER_VERSION_LABEL = os.getenv("TICK_SERVER_VERSION", "unknown")

# Connection override — set to use a non-default config file path.
# Host/port/credentials are read from config.cfg; edit that file or supply
# a different path via XAPI_CONFIG_FILE if running against a non-default server.
XAPI_CONFIG_FILE = os.environ.get("XAPI_CONFIG_FILE", "config.cfg")

# Use only the first symbol for the midnight-rollover phase (single-symbol restriction)
PRIMARY_SYMBOL = SYMBOLS[0]

# Order submission config — used by submit_orders_for_symbols()
ORDER_ROUTE   = os.getenv("ORDER_ROUTE",   "CAT-NEELIMA")
ORDER_ACCOUNT = os.getenv("ORDER_ACCOUNT", "S;BMOHAN;BMOHAN;TRADING")
ORDER_SIDE    = os.getenv("ORDER_SIDE",    "BUY")
ORDER_QTY     = int(os.getenv("ORDER_QTY", "1"))
# PriceType: 0=Market 1=Limit 2=StopMarket 3=StopLimit
ORDER_PRICE_TYPE = int(os.getenv("ORDER_PRICE_TYPE", "0"))  # Market by default


# ---------------------------------------------------------------------------
# Tick counter — thread-safe accumulator used across all phases
# ---------------------------------------------------------------------------
class TickCounter:
    def __init__(self):
        self._lock = threading.Lock()
        self._count = 0
        self._snapshots: list[tuple[float, int]] = []   # (wall_time, cumulative_count)

    def add(self, n: int):
        with self._lock:
            self._count += n
            self._snapshots.append((time.monotonic(), self._count))

    def total(self) -> int:
        with self._lock:
            return self._count

    def reset(self):
        with self._lock:
            self._count = 0
            self._snapshots.clear()

    def rate_per_second(self, window_seconds: float) -> float:
        """Ticks received in the last `window_seconds`, divided by the window."""
        cutoff = time.monotonic() - window_seconds
        with self._lock:
            recent = [c for t, c in self._snapshots if t >= cutoff]
            if len(recent) < 2:
                return self._count / max(window_seconds, 1)
            return (recent[-1] - recent[0]) / window_seconds


# ---------------------------------------------------------------------------
# StreamMarketData bidirectional session (minimal, purpose-built for this test)
# ---------------------------------------------------------------------------
class TickReproSession:
    """
    Thin wrapper around the StreamMarketData RPC that feeds a TickCounter.
    One instance = one streaming session.  Call start(), wait, then stop().
    """

    def __init__(self, lib: EMSXAPILibrary, counter: TickCounter,
                 on_tick=None, on_level1=None):
        self._lib = lib
        self._counter = counter
        self._on_tick = on_tick
        self._on_level1 = on_level1
        self._q: queue.Queue = queue.Queue()
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._level1_count = 0
        self._level1_lock = threading.Lock()

    def start(self):
        self._stop.clear()
        self._ready.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=15):
            raise TimeoutError("Stream did not become ready within 15 s")

    def add_tick(self, symbol: str):
        req = market_data_pb2.MarketDataStreamRequest()
        req.UserToken = self._lib.userToken
        req.RequestType = "ADD_SYMBOL"
        req.Symbols.append(symbol)
        req.MarketDataLevel = "TICK"
        req.Request = True
        req.Advise = True
        self._q.put(req)

    def add_level1(self, symbol: str):
        req = market_data_pb2.MarketDataStreamRequest()
        req.UserToken = self._lib.userToken
        req.RequestType = "ADD_SYMBOL"
        req.Symbols.append(symbol)
        req.MarketDataLevel = "LEVEL1"
        req.Request = True
        req.Advise = True
        self._q.put(req)

    def level1_updates(self) -> int:
        with self._level1_lock:
            return self._level1_count

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self):
        def _requests():
            init = market_data_pb2.MarketDataStreamRequest()
            init.UserToken = self._lib.userToken
            init.RequestType = "INIT"
            yield init
            self._ready.set()
            while not self._stop.is_set():
                try:
                    yield self._q.get(timeout=1.0)
                except queue.Empty:
                    pass

        try:
            stub = self._lib.get_market_data_service_stub()
            for resp in stub.StreamMarketData(_requests()):
                if self._stop.is_set():
                    break
                if resp.ResponseType == "TICK_DATA" and resp.Count > 0:
                    self._counter.add(resp.Count)
                    if self._on_tick:
                        self._on_tick(resp)
                elif resp.ResponseType == "LEVEL1_DATA":
                    with self._level1_lock:
                        self._level1_count += 1
                    if self._on_level1:
                        self._on_level1(resp)
        except Exception as exc:
            if not self._stop.is_set():
                print(f"  [stream error] {exc}")


# ---------------------------------------------------------------------------
# Pretty-print helpers
# ---------------------------------------------------------------------------
SEP = "=" * 72

def _fmt_price(p) -> str:
    """Return DecimalValue as string, or — when null/zero."""
    if p is None or p.Isnull:
        return "—"
    return f"{p.DecimalValue:.4f}"

def _fmt_dur(d) -> str:
    """Convert a protobuf Duration to HH:MM:SS string."""
    if d is None:
        return "?"
    h, rem = divmod(int(d.seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def banner(title: str):
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)

def now_utc_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def verdict(passed: bool, detail: str):
    mark = "PASS ✓" if passed else "FAIL ✗"
    print(f"  [{mark}]  {detail}")
    return passed


def _observe(counter: TickCounter, duration: int, session=None) -> None:
    """Replace bare time.sleep: prints a progress line every 10 s."""
    start = time.monotonic()
    end = start + duration
    report_interval = 10
    next_report = start + report_interval
    while True:
        now = time.monotonic()
        if now >= end:
            break
        sleep_for = min(next_report, end) - now
        if sleep_for > 0:
            time.sleep(sleep_for)
        elapsed = int(time.monotonic() - start)
        ticks = counter.total()
        rate = counter.rate_per_second(report_interval)
        l1_str = f"  L1={session.level1_updates()}" if session else ""
        print(f"  [{now_utc_str()}]  {elapsed:>3}s/{duration}s{l1_str}"
              f"  ticks={ticks}  rate={rate:.1f}/s")
        next_report += report_interval


# ---------------------------------------------------------------------------
# Order submission — one market order per symbol, same session, no extra login
# ---------------------------------------------------------------------------
def submit_orders_for_symbols(lib: EMSXAPILibrary) -> bool:
    banner(f"Phase 0 — Submit single orders for configured symbols  [{now_utc_str()}]")
    print(f"  Symbols  : {SYMBOLS}")
    print(f"  Route    : {ORDER_ROUTE}")
    print(f"  Account  : {ORDER_ACCOUNT}")
    print(f"  Side     : {ORDER_SIDE}  Qty: {ORDER_QTY}  PriceType: {ORDER_PRICE_TYPE}")

    account_parts = ORDER_ACCOUNT.split(";")
    if len(account_parts) != 4:
        print(f"  [ERROR] ORDER_ACCOUNT must be Bank;Branch;Customer;Deposit — got: {ORDER_ACCOUNT}")
        return verdict(False, "Invalid ORDER_ACCOUNT format")

    stub = lib.get_order_service_stub()
    all_ok = True
    for sym in SYMBOLS:
        req = order_pb2.SubmitSingleOrderRequest()
        req.UserToken = lib.userToken
        req.Symbol    = sym
        req.Side      = ORDER_SIDE
        req.Quantity  = ORDER_QTY
        req.Route     = ORDER_ROUTE
        req.Account   = ORDER_ACCOUNT
        req.PriceType.PriceType = ORDER_PRICE_TYPE
        try:
            resp = stub.SubmitSingleOrder(req)
            # SUCCESS=0 per ResponseCodesEnum; treat any other code as failure
            ok = resp.Acknowledgement.ResponseCode == 0
            detail = (f"{sym} → OrderId={resp.OrderDetails.OrderId or 'pending'} "
                      f"Status={resp.OrderDetails.CurrentStatus or resp.ServerResponse}")
            if not verdict(ok, detail):
                all_ok = False
        except Exception as exc:
            print(f"  [ERROR] {sym}: {exc}")
            all_ok = False
    return all_ok


# ---------------------------------------------------------------------------
# Phase 1 — Baseline: subscribe via 2026.5 path, measure ticks
# ---------------------------------------------------------------------------
def phase1_baseline(lib: EMSXAPILibrary) -> bool:
    banner(f"Phase 1 — Baseline TICK subscription via StreamMarketData  [{now_utc_str()}]")
    print(f"  Symbols  : {SYMBOLS}")
    print(f"  Window   : {OBSERVATION_SECONDS}s")
    print(f"  Server   : {SERVER_VERSION_LABEL}")

    counter = TickCounter()

    def _on_tick(resp):
        sym = resp.DispName or "?"
        px = _fmt_price(resp.TrdPrc1List[0]) if resp.TrdPrc1List else "—"
        vol = resp.TrdVol1List[0] if resp.TrdVol1List else 0
        t_str = _fmt_dur(resp.TrdTim1List[0]) if resp.TrdTim1List else "?"
        print(f"  [TICK]  {sym:<14}  px={px}  vol={vol}  t={t_str}  ({resp.Count} tick(s))")

    session = TickReproSession(lib, counter, on_tick=_on_tick)
    session.start()

    # Subscribe LEVEL1 first (proves the stream itself is working regardless of TICK)
    for sym in SYMBOLS:
        session.add_level1(sym)
    time.sleep(2)

    # Subscribe TICK — server supports exactly one symbol per TicksTable; each
    # ADD_SYMBOL TICK replaces the previous subscription.  Only the last symbol
    # in the list will deliver TICK_DATA (EBI-3464 / Finding 2).  Phase 3 uses
    # PRIMARY_SYMBOL only to avoid this ambiguity.
    for sym in SYMBOLS:
        session.add_tick(sym)

    print(f"\n  Observing for {OBSERVATION_SECONDS}s …")
    _observe(counter, OBSERVATION_SECONDS, session)

    total_ticks = counter.total()
    l1_updates = session.level1_updates()
    rate = counter.rate_per_second(OBSERVATION_SECONDS)
    session.stop()

    print(f"\n  LEVEL1 updates : {l1_updates}  (confirms stream is alive)")
    print(f"  TICK_DATA total: {total_ticks}  ({rate:.1f} ticks/s)")

    l1_alive = verdict(l1_updates > 0,
                       f"LEVEL1 flowing ({l1_updates} updates)")
    tick_ok  = verdict(total_ticks >= MIN_TICKS_EXPECTED,
                       f"TICK flowing ({total_ticks} ticks >= threshold {MIN_TICKS_EXPECTED})")

    if l1_alive and not tick_ok:
        print("\n  *** LEVEL1 flows but TICK is silent — this is exactly the EBI-3464 pattern.")
        print("  *** If the server version is 2026.4 or older and the time is 04:00–09:00 UTC,")
        print("  *** this is the confirmed bug.  On 2026.5+ this should not happen.")

    return l1_alive and tick_ok


# ---------------------------------------------------------------------------
# Phase 2 — Rollover simulation via SubscribeTickData with stale date
# ---------------------------------------------------------------------------
def phase2_rollover_simulation(lib: EMSXAPILibrary) -> bool:
    """
    Directly inject the stale-date TQL that 2026.4 would have built for a
    subscription taken yesterday.  We use the standalone SubscribeTickData RPC
    (not StreamMarketData) because that RPC still accepts explicit Date/
    StartTime/StopTime fields, letting us reproduce the exact window the old
    server-side code produced.

    On a 2026.5 server the streaming path is fixed, but an explicit stale date
    sent to SubscribeTickData will still produce silence — confirming the TQL
    date-scoping mechanism works exactly as the bug analysis described.
    """
    banner(f"Phase 2 — Midnight-rollover simulation (stale date injection)  [{now_utc_str()}]")
    print(f"  Symbol  : {PRIMARY_SYMBOL}")
    print("  Method  : SubscribeTickData with yesterday's UTC date")
    print("  Purpose : Reproduce silence caused by date-scoped TQL expiring at midnight")

    # Build the stale window: yesterday's date, start 08:00, stop 23:59:59
    # This is what 2026.4 would have produced for a subscribe taken at 16:00 UTC
    # the previous day (8-hour lookback from subscribe time).
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).date()
    stale_date_ts = timestamp_pb2.Timestamp()
    stale_date_ts.FromDatetime(datetime(yesterday.year, yesterday.month, yesterday.day,
                                        tzinfo=timezone.utc))

    start_dur = duration_pb2.Duration()
    start_dur.FromTimedelta(timedelta(hours=8))        # 08:00 yesterday

    stop_dur = duration_pb2.Duration()
    stop_dur.FromTimedelta(timedelta(hours=23, minutes=59, seconds=59))

    req = market_data_pb2.SubscribeTickDataRequest()
    req.UserToken = lib.userToken
    req.Symbol = PRIMARY_SYMBOL
    req.Date.CopyFrom(stale_date_ts)
    req.StartTime.CopyFrom(start_dur)
    req.StopTime.CopyFrom(stop_dur)
    req.Request = True
    req.TickTypes.append(market_data_pb2.TickTypes(
        TickOption=market_data_pb2.TickTypes.Ticks.Value("TRADE")))

    print(f"\n  Stale window : {yesterday} 08:00 → 23:59:59 UTC")
    print(f"  (Trades today are on {datetime.now(timezone.utc).date()}, "
          f"outside this window — they should be invisible)")

    counter = TickCounter()
    stop_evt = threading.Event()

    def _listener():
        try:
            stub = lib.get_market_data_service_stub()
            # SubscribeTickData is unary_stream — pass the request directly, not
            # wrapped in an iterator (which would fail serialization at runtime).
            for resp in stub.SubscribeTickData(req):
                if stop_evt.is_set():
                    break
                if resp.Count > 0:
                    counter.add(resp.Count)
                    sym = resp.DispName[0] if resp.DispName else PRIMARY_SYMBOL
                    px = _fmt_price(resp.TrdPrc1[0]) if resp.TrdPrc1 else "—"
                    t_str = _fmt_dur(resp.TrdTim1[0]) if resp.TrdTim1 else "?"
                    print(f"  [TICK]  {sym:<14}  px={px}  t={t_str}  ({resp.Count} tick(s))")
        except Exception as exc:
            if not stop_evt.is_set():
                print(f"  [stream error] {exc}")

    t = threading.Thread(target=_listener, daemon=True)
    t.start()

    print(f"\n  Observing for {OBSERVATION_SECONDS}s …")
    _observe(counter, OBSERVATION_SECONDS)
    stop_evt.set()
    t.join(timeout=5)

    total = counter.total()
    print(f"\n  Total ticks received (snapshot + live) : {total}")
    print("  (Snapshot ticks from yesterday are expected; "
          "NEW live ticks today should be 0 with a stale date)")

    # On any version: if live ticks arrive on a yesterday-scoped TQL, something
    # unexpected is happening.  We flag that as a WARN, not a FAIL, because some
    # exchanges replay across the boundary.
    if total == 0:
        print("\n  *** Zero ticks — TQL window expired as expected.  This confirms the")
        print("  *** date-scoping mechanism works.  On 2026.4 this is what the server")
        print("  *** produced silently for live subscriptions after midnight.")
        return verdict(True, "Stale-date TQL produced silence (mechanism confirmed)")
    else:
        print(f"\n  *** {total} ticks arrived on a yesterday-scoped window.")
        print("  *** This may be a snapshot-only replay.  Acceptable if all ticks have")
        print("  *** TrdDateList entries stamped with yesterday's date (not today's).")
        return verdict(True,
                       f"Ticks present ({total}) — snapshot replay, not live advise (expected)")


# ---------------------------------------------------------------------------
# Phase 3 — Post-rollover verify: 2026.5 streaming path
# ---------------------------------------------------------------------------
def phase3_post_rollover_verify(lib: EMSXAPILibrary) -> bool:
    """
    Subscribe via the FIXED StreamMarketData path (2026.5).  On a patched
    server, ticks must flow at any UTC hour including 04:00–09:00.
    On an unpatched server (2026.4), this phase will fail between 04:00–09:00.
    """
    banner(f"Phase 3 — 2026.5 path verify (same ADD_SYMBOL, fresh date)  [{now_utc_str()}]")
    print(f"  Symbol  : {PRIMARY_SYMBOL}")
    print(f"  Window  : {OBSERVATION_SECONDS}s")
    print(f"  Expect  : ticks flow regardless of UTC hour (test of the fix)")

    counter = TickCounter()

    def _on_tick(resp):
        sym = resp.DispName or PRIMARY_SYMBOL
        px = _fmt_price(resp.TrdPrc1List[0]) if resp.TrdPrc1List else "—"
        vol = resp.TrdVol1List[0] if resp.TrdVol1List else 0
        t_str = _fmt_dur(resp.TrdTim1List[0]) if resp.TrdTim1List else "?"
        print(f"  [TICK]  {sym:<14}  px={px}  vol={vol}  t={t_str}  ({resp.Count} tick(s))")

    session = TickReproSession(lib, counter, on_tick=_on_tick)
    session.start()

    session.add_level1(PRIMARY_SYMBOL)
    time.sleep(2)
    session.add_tick(PRIMARY_SYMBOL)

    print(f"\n  Observing for {OBSERVATION_SECONDS}s …")
    _observe(counter, OBSERVATION_SECONDS, session)

    total_ticks = counter.total()
    l1_updates = session.level1_updates()
    rate = counter.rate_per_second(OBSERVATION_SECONDS)
    session.stop()

    utc_hour = datetime.now(timezone.utc).hour
    in_bug_window = 4 <= utc_hour < 9

    print(f"\n  Current UTC hour : {utc_hour:02d}:xx  "
          f"({'inside' if in_bug_window else 'outside'} the historical 04–09 UTC bug window)")
    print(f"  LEVEL1 updates   : {l1_updates}")
    print(f"  TICK_DATA total  : {total_ticks}  ({rate:.1f} ticks/s)")

    if in_bug_window:
        print("\n  *** Running inside the 04:00–09:00 UTC window where 2026.4 was silent.")
        if total_ticks >= MIN_TICKS_EXPECTED:
            print("  *** Ticks are flowing — FIX CONFIRMED for this time window.")
        else:
            print("  *** No ticks — this is the EBI-3464 defect.  Server is 2026.4 or older,")
            print("  *** or the midnight-rebuild timer has not yet fired.")

    l1_ok   = verdict(l1_updates > 0, f"LEVEL1 alive ({l1_updates} updates)")
    tick_ok = verdict(total_ticks >= MIN_TICKS_EXPECTED,
                      f"TICK flowing ({total_ticks} ticks >= threshold {MIN_TICKS_EXPECTED})")
    return l1_ok and tick_ok


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
def print_summary(results: dict[str, bool]):
    banner("SUMMARY")
    print(f"  Server version : {SERVER_VERSION_LABEL}")
    print(f"  Symbols        : {SYMBOLS}")
    print(f"  Run time       : {now_utc_str()}")
    print()
    all_pass = True
    for phase, passed in results.items():
        mark = "PASS ✓" if passed else "FAIL ✗"
        print(f"  [{mark}]  {phase}")
        if not passed:
            all_pass = False
    print()
    if all_pass:
        print("  Overall: ALL PHASES PASSED")
        print("  This confirms the 2026.5 fix is effective at the current UTC hour.")
    else:
        print("  Overall: ONE OR MORE PHASES FAILED")
        print("  If Phase 1 or Phase 3 failed between 04:00–09:00 UTC, this is EBI-3464.")
        print("  Upgrade to 2026.5 or later to resolve.")
    print(SEP)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    banner(f"EBI-3464  StreamMarketData TICK midnight-rollover regression  [{now_utc_str()}]")
    print(f"  Server : {SERVER_VERSION_LABEL}")
    print(f"  Symbols: {SYMBOLS}")
    print(f"  Observation window per phase: {OBSERVATION_SECONDS}s")
    print(f"  Minimum ticks for PASS      : {MIN_TICKS_EXPECTED}")
    print(f"\n  Running at UTC {datetime.now(timezone.utc).strftime('%H:%M')} — "
          f"{'INSIDE the historical bug window (04–09 UTC)' if 4 <= datetime.now(timezone.utc).hour < 9 else 'outside the historical bug window'}")

    EMSXAPILibrary.create(XAPI_CONFIG_FILE)
    lib = EMSXAPILibrary.get()

    print("\n[AUTH] Logging in …")
    lib.login()
    print(f"[AUTH] OK — token {lib.userToken[:8]}…")

    results = {}
    try:
        results["Phase 0 — Submit orders"] = submit_orders_for_symbols(lib)
        results["Phase 1 — Baseline (StreamMarketData TICK)"] = phase1_baseline(lib)
        results["Phase 2 — Stale-date TQL injection (rollover simulation)"] = phase2_rollover_simulation(lib)
        results["Phase 3 — 2026.5 path verify (post-rollover)"] = phase3_post_rollover_verify(lib)
    finally:
        print_summary(results)
        lib.logout()
        lib.close_channel()


if __name__ == "__main__":
    main()
