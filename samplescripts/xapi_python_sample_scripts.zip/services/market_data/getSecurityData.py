from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class GetSecurityData: # set username, password, domain, locale, port number and server address details
    def __init__(self, symbols=None):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        # Support single symbol (backward compatible) or list of symbols
        if symbols is None:
            self.symbols = ['VOD.LSE']
        elif isinstance(symbols, str):
            self.symbols = [symbols]
        else:
            self.symbols = symbols

    def get_security_data(self):
        self.xapiLib.login()

        # Send all requested symbols in a single batched request
        self._fetch_and_print_security_data(self.symbols)

        #self.xapiLib.logout()

    def _fetch_and_print_security_data(self, symbols):
        """Fetch and print security data for one or more symbols in a single request"""
        request = mkt.SecurityDataRequest()
        request.UserToken = self.xapiLib.userToken

        # Prefer the bulk Symbols field; fall back to the single Symbol for a lone ticker
        if len(symbols) == 1:
            request.Symbol = symbols[0]
        else:
            request.Symbols.extend(symbols)

        response = self.xapiLib.get_market_data_service_stub().GetSecurityData(
            request)  # API call to fetch data

        # Print simplified response with basic info and GICS sector only
        print("=" * 80)
        print("SECURITY DATA RESPONSE FOR:", ", ".join(symbols))
        print("=" * 80)
        
        # Print acknowledgement
        if response.HasField('Acknowledgement'):
            ack = response.Acknowledgement
            print("\nAcknowledgement:")
            print(f"  ResponseCode: {ack.ResponseCode} ({util.ServerAcknowledgement.ResponseCodesEnum.Name(ack.ResponseCode)})")
            print(f"  ServerResponse: {ack.ServerResponse}")
            print(f"  Message: {ack.Message}")
        
        # Print security data records
        if response.SecurityInfoList:
            print(f"\nNumber of Security Records: {len(response.SecurityInfoList)}")
            
            for idx, security in enumerate(response.SecurityInfoList, 1):
                print(f"\n{'-' * 80}")
                print(f"Security Record #{idx}")
                print(f"{'-' * 80}")
                
                # Basic Information
                print("\n[Basic Information]")
                print(f"  DispName: {security.DispName}")
                print(f"  CompanyName: {security.CompanyName}")
                print(f"  PrimaryExchange: {security.PrimaryExchange}")
                print(f"  Country: {security.Country}")
                print(f"  Region: {security.Region}")
                
                # GICS Sector
                print("\n[GICS Sector]")
                print(f"  GicsSector: {security.GicsSector}")
        
        print("=" * 80)
        print()
        
        #self.xapiLib.logout()

if __name__ == "__main__":
    # Example 1: Single symbol (backward compatible)
    # get_security_data_example = GetSecurityData()
    # get_security_data_example.get_security_data()
    
    # Example 2: Multiple symbols
    # Note: US symbols use just the ticker (AAPL, MSFT)
    # International symbols use ticker.exchange format (VOD.LSE)
    symbols = ['VOD.LSE','AAPL','MSFT']
    get_security_data_example = GetSecurityData(symbols)
    get_security_data_example.get_security_data()