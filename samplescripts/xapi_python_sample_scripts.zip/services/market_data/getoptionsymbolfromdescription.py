"""
GetOptionSymbolFromDescription API

This module provides functionality to retrieve an option symbol from its description
components (root, expiration, option type, strike price).
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import market_data_pb2 as mkt
class GetOptionSymbolFromDescription:
    """
    Retrieves an option symbol based on its description components.

    This class provides methods to convert option description parameters
    (root symbol, expiration date, call/put type, and strike price)
    into the corresponding option symbol.
    """

    def __init__(self):
        """
        Initialize the GetOptionSymbolFromDescription instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def get_option_symbol_from_description(self, root, expiration, option_type, strike_price):
        """
        Retrieve the option symbol for the given description parameters.

        Args:
            root (str): The root symbol of the option (e.g., 'AAPL', 'SPY').
            expiration (str): The expiration date string (e.g., '20240315' for March 15, 2024).
            option_type (int): The option type - 0 for CALL, 1 for PUT.
            strike_price (float): The strike price of the option.

        Returns:
            str: The option symbol if successful, None otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = mkt.OptionSymbolFromDescriptionRequest()
            request.UserToken = self.xapiLib.userToken
            request.Root = root
            request.Expiration = expiration
            request.OptionType.CallOrPut = option_type  # 0 = CALL, 1 = PUT
            request.StrikePrice = strike_price

            response = self.xapiLib.get_market_data_service_stub().GetOptionSymbolFromDescription(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse != "success":
                    print(f'API Error: {response.Acknowledgement.Message}')
                    return None

            if hasattr(response, 'Symbol') and response.Symbol:
                print(f'Option Symbol: {response.Symbol}')
                return response.Symbol
            else:
                print('No symbol found for the given description')
                return None

        except Exception as e:
            print(f'Error: {e}')
            return None
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    option_symbol_example = GetOptionSymbolFromDescription()
    # Example: Get CALL option symbol for AAPL, expiration 20240315, strike 150.0
    option_symbol_example.get_option_symbol_from_description(
        root='AAPL',
        expiration='20240315',
        option_type=0,  # CALL
        strike_price=150.0
    )
