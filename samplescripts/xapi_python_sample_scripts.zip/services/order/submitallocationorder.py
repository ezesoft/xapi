"""
SubmitAllocationOrder API

This module provides functionality to submit allocation orders for executed trades.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import order_pb2
class SubmitAllocationOrder:
    """
    Submits allocation orders for executed trades.

    This class provides methods to allocate executed order quantities
    to different target accounts.
    """

    def __init__(self):
        """
        Initialize the SubmitAllocationOrder instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def submit_allocation_order(self, order_id, symbol, exchange, source_account,
                                 target_account, target_quantity, target_price=None,
                                 allocation_type=0, order_type=0):
        """
        Submit an allocation order.

        Args:
            order_id (str): The original order ID to allocate from.
            symbol (str): The symbol of the security.
            exchange (str): The exchange where the order was executed.
            source_account (str): The source account (format: 'bank;branch;customer;deposit').
            target_account (str): The target account to allocate to.
            target_quantity (int): The quantity to allocate to the target account.
            target_price (float, optional): The price for the allocation. Defaults to None.
            allocation_type (int, optional): Type of allocation:
                0 = UserSubmitAllocation
                1 = UserSubmitAllocationEx
                Defaults to 0.
            order_type (int, optional): Type of order:
                0 = UserSubmitOrder
                1 = ForeignExecution
                Defaults to 0.

        Returns:
            bool: True if allocation was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = order_pb2.SubmitAllocationOrderRequest()
            request.UserToken = self.xapiLib.userToken
            request.OrderId = order_id
            request.Symbol = symbol
            request.Exchange = exchange
            request.SourceAccount = source_account
            request.TargetAccount = target_account
            request.TargetQuantity = target_quantity

            if target_price is not None:
                request.TargetPrice.value = target_price

            # Set allocation type
            request.TypeOfAllocation.AllocationOrAllocationEx = allocation_type

            # Set order type
            request.OrderTypes.TypeOfOrder = order_type

            response = self.xapiLib.get_order_service_stub().SubmitAllocationOrder(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

            if hasattr(response, 'ServerResponse') and response.ServerResponse == "success":
                print('Successfully submitted allocation order')
                return True
            else:
                print(f'Allocation failed')
                if hasattr(response, 'OptionalFields') and 'ErrorMessage' in response.OptionalFields:
                    print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    allocation_example = SubmitAllocationOrder()
    # Example allocation order
    allocation_example.submit_allocation_order(
        order_id='12345',
        symbol='AAPL',
        exchange='NASDAQ',
        source_account='BANK;BRANCH;CUSTOMER;DEPOSIT',
        target_account='TARGET_ACCOUNT',
        target_quantity=100,
        target_price=150.50,
        allocation_type=0,  # UserSubmitAllocation
        order_type=0  # UserSubmitOrder
    )
