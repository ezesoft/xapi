import time
from generated import order_pb2 as ord
from runtime.emsxapilibrary import EMSXAPILibrary


class CancelSingleOrder:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        
        # Configure these fields before running
        self.order_id = ''  # OrderId of the order to cancel (required)

    def cancel_order(self):
        if not self.order_id:
            print("Error: order_id is required")
            return
        
        cancel_order = ord.CancelSingleOrderRequest()
        cancel_order.OrderId = self.order_id
        cancel_order.UserToken = self.xapiLib.userToken
        
        print(f"Submitting cancel for OrderId: {self.order_id}")
        response = self.xapiLib.get_order_service_stub().CancelSingleOrder(cancel_order)
        
        if response.ServerResponse == 'success':
            print("Successfully submitted cancel order")
        else:
            print(f"Failed to cancel order: {response.OptionalFields.get('ErrorMessage', 'Unknown error')}")
        
        return response


if __name__ == "__main__":
    cancel_order = CancelSingleOrder()
    
    # Configure the order to cancel
    cancel_order.order_id = ''  # Set the OrderId to cancel
    
    cancel_order.xapiLib.login()
    cancel_order.cancel_order()
    time.sleep(3)  # Time in seconds to wait for order updates
    cancel_order.xapiLib.logout()
