import enum
import time
from threading import Event, Lock, Thread
from uuid import uuid4
from generated import order_pb2 as ord
from runtime.emsxapilibrary import EMSXAPILibrary
import sys


# Submits a compound spread order with 2 staged legs via XAPI.
# Set submitthenexecuteorder = False to only stage, True to stage and execute.
class CreateStagedSpreadOrder:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        self.order_account = 'BANK;BRANCH;CUSTOMER;DEPOSIT'  # Replace with your account info

        # Order tags to correlate server updates (staging phase)
        self.my_order_id = 'XAP-{0}'.format(str(uuid4()))    # !SPREAD parent
        self.my_order_id1 = 'XAP-{0}'.format(str(uuid4()))   # leg 1
        self.my_order_id2 = 'XAP-{0}'.format(str(uuid4()))   # leg 2

        # Spread details
        self.underLyingSym = 'LOW'
        self.exchange = 'OPR'
        self._route = 'NONE'                # staging route (no routing)
        self._exec_route = 'BTIG SPREADS'   # execution route (real destination)
        self.spreadquantity = 5
        self.spread_prc = '2.5'             # net limit price for the spread
        self.good_until = 'DAY'

        # Leg 1 - symbol format: +<UNDERLYING>\<expiry-code>\<strike>
        self.leg1symbol = '+LOW\\17G6\\200'
        self._buy_sell1 = 'BUY'
        self.leg1_prc_type = 'Market'
        self.leg1_prc = '0.0'
        self.leg1ratio = 6
        self.putOrCallLeg1 = 'C'

        # Leg 2
        self.leg2symbol = '+LOW\\17G6\\250'
        self._buy_sell2 = 'SELL'
        self.leg2_prc_type = 'Market'
        self.leg2_prc = '0.0'
        self.leg2ratio = 6
        self.putOrCallLeg2 = 'C'

        # Threading / synchronization
        self.ready = Event()
        self.status = State.WaitingForConnect
        self._state_lock = Lock()
        self._stop = Event()
        self._staged_ack = Event()
        self._execution_ack = Event()
        self._stream_ended = False

        # Server-assigned order ids (staging phase)
        self.parent_orderid = ''
        self.leg1_orderid = ''
        self.leg2_orderid = ''

        # When True, auto-execute (route) the staged spread once it goes LIVE
        self.submitthenexecuteorder = False

        # Order tags to correlate server updates (execution phase)
        self.exec_order_id = 'XAP-{0}'.format(str(uuid4()))    # !SPREAD parent
        self.exec_order_id1 = 'XAP-{0}'.format(str(uuid4()))   # leg 1
        self.exec_order_id2 = 'XAP-{0}'.format(str(uuid4()))   # leg 2

        # Server-assigned order ids (execution phase)
        self.exec_parent_orderid = ''
        self.exec_leg1_orderid = ''
        self.exec_leg2_orderid = ''

        self.execution_submitted = False
        self.execution_rejected = False
        self.execution_reject_reason = ''
        self._subscribe_call = None
        self._order_finished_printed = False
        self._seen_updates = set()

    def start_listening(self, timeout=10):
        """Start the order subscription listener thread. Returns False on timeout."""
        self.thread = Thread(target=self.subscribe_order_info)
        self.thread.daemon = True
        self.thread.start()

        if not self.ready.wait(timeout=timeout):
            with self._state_lock:
                self.status = State.ConnectionFailed
            print("ERROR: order subscription not ready within {0}s - "
                  "connection failed".format(timeout))
            return False
        return True

    def shutdown(self, join_timeout=5):
        """Stop listener thread and cancel the gRPC stream before logout."""
        self._stop.set()
        call = self._subscribe_call
        if call is not None:
            try:
                call.cancel()
            except Exception:
                pass
        thread = getattr(self, 'thread', None)
        if thread is not None and thread.is_alive():
            thread.join(timeout=join_timeout)

    def subscribe_order_info(self):
        """Listener thread: subscribes to order updates and processes them."""
        subscribe_request = ord.SubscribeOrderInfoRequest()
        subscribe_request.Level = 0
        subscribe_request.UserToken = self.xapiLib.userToken
        try:
            subscribe_response = self.xapiLib.get_order_service_stub().SubscribeOrderInfo(subscribe_request)
        except Exception as e:
            print("ERROR: failed to open order subscription: {0}".format(e))
            with self._state_lock:
                self._stream_ended = True
            self._staged_ack.set()
            self._execution_ack.set()
            return

        self._subscribe_call = subscribe_response
        self.ready.set()

        try:
            for order_info in subscribe_response:
                if self._stop.is_set():
                    break
                try:
                    self._process_order_update(order_info)
                except Exception as e:
                    print("WARN: skipping order update: {0}".format(e))
        except StopIteration:
            pass
        except Exception as e:
            if not self._stop.is_set():
                print("ERROR: order stream terminated: {0}".format(e))
        finally:
            with self._state_lock:
                self._stream_ended = True
            self._staged_ack.set()
            self._execution_ack.set()

    def _order_tag(self, order_info):
        """Safely extract OrderTag from ExtendedFields."""
        try:
            return order_info.ExtendedFields.get('OrderTag', '')
        except Exception:
            return ''

    def _process_order_update(self, order_info):
        """Process a single order update from the stream."""
        order_tag = self._order_tag(order_info)

        # Only process updates belonging to our orders
        owned_tags = (
            self.my_order_id, self.my_order_id1, self.my_order_id2,
            self.exec_order_id, self.exec_order_id1, self.exec_order_id2)

        if not order_tag or order_tag not in owned_tags:
            return

        # Deduplicate repeated server notifications for the same order+status+type
        update_key = (order_info.OrderId, order_info.CurrentStatus, order_info.Type)
        if update_key in self._seen_updates:
            return
        self._seen_updates.add(update_key)

        print('sym:{0} vol:{1} status:{2} oid:{3} tid:{4} r:{5} ot:{6} otype:{7}'.format(
            order_info.Symbol,
            order_info.Volume, order_info.CurrentStatus, order_info.OrderId,
            order_info.TicketId, order_info.Reason, order_tag,
            order_info.Type))

        current_order = False
        trigger_execute = False

        with self._state_lock:
            # Track staged spread order ids
            if order_info.Type == 'UserSubmitCompoundOrder' and order_tag == self.my_order_id:
                current_order = True
                self.parent_orderid = order_info.OrderId
            elif order_info.Type == 'UserSubmitStagedOrder' and order_tag == self.my_order_id1:
                current_order = True
                self.leg1_orderid = order_info.OrderId
            elif order_info.Type == 'UserSubmitStagedOrder' and order_tag == self.my_order_id2:
                current_order = True
                self.leg2_orderid = order_info.OrderId

            # Track execution (routed) spread order ids
            elif order_info.Type == 'UserSubmitCompoundOrder' and order_tag == self.exec_order_id:
                self.exec_parent_orderid = order_info.OrderId
            elif order_info.Type == 'UserSubmitOrder' and order_tag == self.exec_order_id1:
                self.exec_leg1_orderid = order_info.OrderId
            elif order_info.Type == 'UserSubmitOrder' and order_tag == self.exec_order_id2:
                self.exec_leg2_orderid = order_info.OrderId

            # Detect execution rejection (only explicit ClerkReject)
            if order_tag in (self.exec_order_id, self.exec_order_id1, self.exec_order_id2):
                if order_info.Type == 'ClerkReject':
                    self.execution_rejected = True
                    if order_info.Reason:
                        self.execution_reject_reason = order_info.Reason

            have_all_staged = bool(self.parent_orderid and self.leg1_orderid and self.leg2_orderid)
            have_all_exec = bool(self.exec_parent_orderid and self.exec_leg1_orderid and self.exec_leg2_orderid)

            # Auto-execute once staged spread is LIVE
            if have_all_staged and current_order and self.submitthenexecuteorder \
                    and not self.execution_submitted \
                    and order_info.Type == 'UserSubmitCompoundOrder' \
                    and order_tag == self.my_order_id \
                    and order_info.CurrentStatus == 'LIVE':
                trigger_execute = True
                self.execution_submitted = True

            # Mark order done on terminal status
            if order_info.Type == 'UserSubmitCompoundOrder' \
                    and order_tag in (self.my_order_id, self.exec_order_id) \
                    and order_info.CurrentStatus in ('COMPLETED', 'DELETED'):
                if not self._order_finished_printed:
                    print("ORDER FINISHED")
                    self._order_finished_printed = True
                self.status = State.OrderDone

            staged_ready = have_all_staged
            execution_done = have_all_exec or self.execution_rejected

        # Signal waiters outside the lock
        if staged_ready:
            self._staged_ack.set()
        if execution_done:
            self._execution_ack.set()

        if trigger_execute:
            print("STAGED SPREAD LIVE -- SUBMITTING EXECUTION (ROUTE)")
            self.send_execute_spread_order()

    def _build_parent_row(self, account, route, relationship, order_tag, ticket_id=None):
        """Build the compound !SPREAD parent OrderRow."""
        row = ord.OrderRow()
        row.DispName = '!SPREAD'
        row.Buyorsell = 'BUY'
        row.PriceType = 'LIMIT'
        row.Undersym = self.underLyingSym
        row.Price = self.spread_prc
        row.VolumeType = 'AsEntered'
        row.Volume.value = self.spreadquantity
        row.Exchange = self.exchange
        row.Styp.value = 21                          # Synthetic
        row.Bank = account[0]
        row.Branch = account[1]
        row.Customer = account[2]
        row.Deposit = account[3]
        row.GoodUntil = self.good_until
        row.Type = 'UserSubmitCompoundOrder'
        row.Route = route
        if ticket_id:
            row.TicketId = ticket_id
        row.SpreadNumLegs.value = 2
        row.LinkedOrderRelationship.value = relationship  # 14=Staged, 2=Spread(exec)
        row.LinkedOrderCancellation.value = 2             # AllOrNone
        row.ExtendedFields['EZE_OMS_TRADER'] = 'OMS Trader Id 1'
        row.ExtendedFields['ORDER_TAG'] = order_tag
        return row

    def _build_leg_row(self, account, disp_name, buy_sell, prc_type, price, ratio,
                       leg_type, route, leg_number, put_call, relationship,
                       linked_order_id, order_tag, oms_trader, ticket_id=None):
        """Build a single spread-leg OrderRow."""
        row = ord.OrderRow()
        row.DispName = disp_name
        row.Buyorsell = buy_sell
        row.PriceType = prc_type
        row.Undersym = self.underLyingSym
        row.Price = price
        row.VolumeType = 'AsEntered'
        row.Volume.value = self.spreadquantity * ratio
        row.Exchange = self.exchange
        row.Styp.value = 2                           # Stock Option
        row.Bank = account[0]
        row.Branch = account[1]
        row.Customer = account[2]
        row.Deposit = account[3]
        row.GoodUntil = self.good_until
        row.Type = leg_type
        row.Route = route
        if ticket_id:
            row.TicketId = ticket_id
        row.SpreadNumLegs.value = 2
        row.SpreadLegNumber.value = leg_number
        row.SpreadLegCount.value = 2
        row.Putcallind = put_call
        row.LinkedOrderRelationship.value = relationship  # 14=Staged, 2=Spread(exec)
        row.LinkedOrderId = linked_order_id
        row.ExtendedFields['EZE_OMS_TRADER'] = oms_trader
        row.ExtendedFields['ORDER_TAG'] = order_tag
        return row

    def send_staged_spread_order(self):
        """Submit the staged spread order (parent + 2 legs, relationship=14)."""
        spread_order = ord.BasketOrderRequest()
        account = self.order_account.split(';')

        ord_request = self._build_parent_row(
            account, self._route, 14, self.my_order_id)

        ord_Leg1 = self._build_leg_row(
            account, self.leg1symbol, self._buy_sell1, self.leg1_prc_type,
            self.leg1_prc, self.leg1ratio, 'UserSubmitStagedOrder', self._route,
            1, self.putOrCallLeg1, 14, self.my_order_id, self.my_order_id1,
            'OMS Trader Id 2')
        ord_Leg2 = self._build_leg_row(
            account, self.leg2symbol, self._buy_sell2, self.leg2_prc_type,
            self.leg2_prc, self.leg2ratio, 'UserSubmitStagedOrder', self._route,
            2, self.putOrCallLeg2, 14, self.my_order_id, self.my_order_id2,
            'OMS Trader Id 3')

        spread_order.Orders.extend([ord_request, ord_Leg1, ord_Leg2])
        spread_order.UserToken = self.xapiLib.userToken

        with self._state_lock:
            self.status = State.OrderInPlay
        resp_spreadOrder = self.xapiLib.get_order_service_stub().SubmitBasketOrder(spread_order)

        if resp_spreadOrder.ServerResponse == 'success':
            print("Successfully Submitted Staged Spread Order")
        else:
            print(resp_spreadOrder.OptionalFields["ErrorMessage"])

    def send_execute_spread_order(self):
        """Execute (route) the staged spread by submitting a new basket order
        with relationship=2, referencing the staged orders via TicketId."""
        execute_order = ord.BasketOrderRequest()
        account = self.order_account.split(';')

        ord_request = self._build_parent_row(
            account, self._exec_route, 2, self.exec_order_id,
            ticket_id=self.parent_orderid)

        ord_Leg1 = self._build_leg_row(
            account, self.leg1symbol, self._buy_sell1, self.leg1_prc_type,
            self.leg1_prc, self.leg1ratio, 'UserSubmitOrder', self._exec_route,
            1, self.putOrCallLeg1, 2, self.exec_order_id, self.exec_order_id1,
            'OMS Trader Id 2', ticket_id=self.leg1_orderid)
        ord_Leg2 = self._build_leg_row(
            account, self.leg2symbol, self._buy_sell2, self.leg2_prc_type,
            self.leg2_prc, self.leg2ratio, 'UserSubmitOrder', self._exec_route,
            2, self.putOrCallLeg2, 2, self.exec_order_id, self.exec_order_id2,
            'OMS Trader Id 3', ticket_id=self.leg2_orderid)

        execute_order.Orders.extend([ord_request, ord_Leg1, ord_Leg2])
        execute_order.UserToken = self.xapiLib.userToken

        resp_executeOrder = self.xapiLib.get_order_service_stub().SubmitBasketOrder(execute_order)

        if resp_executeOrder.ServerResponse == 'success':
            print("Successfully Submitted Execution (routed) Spread Order on route '{0}'".format(self._exec_route))
        else:
            print(resp_executeOrder.OptionalFields["ErrorMessage"])

    def wait_for_acknowledgement(self, timeout=30):
        """Wait until server confirms all 3 staged order ids. Returns True/False."""
        self._staged_ack.wait(timeout=timeout)

        with self._state_lock:
            parent = self.parent_orderid
            leg1 = self.leg1_orderid
            leg2 = self.leg2_orderid
            ended = self._stream_ended

        if parent and leg1 and leg2:
            print("CONFIRMED: staged spread acknowledged by server "
                  "(parent={0}, leg1={1}, leg2={2})".format(parent, leg1, leg2))
            return True
        if ended:
            print("ERROR: order stream ended before staged spread was confirmed")
            return False
        print("WARNING: staged spread NOT fully confirmed within {0}s "
              "(parent='{1}', leg1='{2}', leg3='{3}')".format(
                  timeout, parent, leg1, leg2))
        return False

    def wait_for_execution(self, timeout=30):
        """Wait until server confirms all 3 execution order ids. Returns True/False."""
        if not self.submitthenexecuteorder:
            return True

        self._execution_ack.wait(timeout=timeout)

        with self._state_lock:
            rejected = self.execution_rejected
            reason = self.execution_reject_reason
            parent = self.exec_parent_orderid
            leg1 = self.exec_leg1_orderid
            leg2 = self.exec_leg2_orderid
            ended = self._stream_ended

        if rejected:
            print("REJECTED: executed (routed) spread refused by server"
                  "{0}".format(" - " + reason if reason else ""))
            return False
        if parent and leg1 and leg2:
            print("CONFIRMED: executed (routed) spread acknowledged by server "
                  "(parent={0}, leg1={1}, leg2={2})".format(parent, leg1, leg2))
            return True
        if ended:
            print("ERROR: order stream ended before execution was confirmed")
            return False
        print("WARNING: executed spread NOT fully confirmed within {0}s "
              "(parent='{1}', leg1='{2}', leg3='{3}')".format(
                  timeout, parent, leg1, leg2))
        return False


class State(enum.Enum):
    WaitingForConnect = 0
    OrderInPlay = 1
    OrderDone = 2
    ConnectionFailed = 3


if __name__ == "__main__":
    submit_order = CreateStagedSpreadOrder()
    submit_order.xapiLib.login()

    if not submit_order.start_listening():
        print("RESULT: FAILED - could not establish order subscription")
        submit_order.shutdown()
        submit_order.xapiLib.logout()
        sys.exit(1)

    confirmed = False
    executed = False
    try:
        submit_order.send_staged_spread_order()
        confirmed = submit_order.wait_for_acknowledgement(timeout=30)
        if confirmed:
            executed = submit_order.wait_for_execution(timeout=30)
        time.sleep(5)
    finally:
        submit_order.shutdown()
        submit_order.xapiLib.logout()

    # Final summary
    print("=" * 60)
    with submit_order._state_lock:
        parent = submit_order.parent_orderid
        leg1 = submit_order.leg1_orderid
        leg2 = submit_order.leg2_orderid
        exec_parent = submit_order.exec_parent_orderid
        exec_leg1 = submit_order.exec_leg1_orderid
        exec_leg2 = submit_order.exec_leg2_orderid
    if confirmed and (executed or not submit_order.submitthenexecuteorder):
        print("RESULT: SUCCESS - staged spread order placed "
              "(parent={0}, leg1={1}, leg2={2})".format(parent, leg1, leg2))
        if submit_order.submitthenexecuteorder:
            print("        executed (routed) on '{0}' "
                  "(parent={1}, leg1={2}, leg3={3})".format(
                      submit_order._exec_route, exec_parent, exec_leg1, exec_leg2))
        sys.exit(0)
    else:
        print("RESULT: FAILED - staged spread order not confirmed "
              "(staged parent='{0}', leg1='{1}', leg2='{2}'; "
              "exec parent='{3}', leg1='{4}', leg2='{5}')".format(
                  parent, leg1, leg2, exec_parent, exec_leg1, exec_leg2))
        sys.exit(1)
