"""
SubmitSeedData API

This module provides functionality to submit seed data for securities.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import order_pb2
class SubmitSeedData:
    """
    Submits seed data for securities.

    This class provides methods to send seed security messages
    to initialize security data for a given account and symbol.
    """

    def __init__(self):
        """
        Initialize the SubmitSeedData instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def submit_seed_data(self, account, symbol):
        """
        Submit seed data for a security.

        Args:
            account (str): The account for which to seed the security data.
            symbol (str): The symbol of the security to seed.

        Returns:
            bool: True if seed data was submitted successfully, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = order_pb2.SubmitSeedDataRequest()
            request.UserToken = self.xapiLib.userToken
            request.Account = account
            request.Symbol = symbol.upper()

            response = self.xapiLib.get_order_service_stub().SubmitSeedData(request)

            ack = response.Acknowledgement
            success_code = ack.DESCRIPTOR.fields_by_name['ResponseCode'].enum_type.values_by_name['SUCCESS'].number
            if ack.ResponseCode == success_code:
                print(f'Successfully sent seed security message for symbol: {symbol}')
                return True
            else:
                print('Seed data submission failed'
                      + (f' | {ack.ServerResponse}' if ack.ServerResponse else '')
                      + (f': {ack.Message}' if ack.Message else ''))
                if 'ErrorMessage' in response.OptionalFields:
                    print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    seed_data_example = SubmitSeedData()
    # Example seed data submission
    seed_data_example.submit_seed_data(
        account='ACCOUNT123',
        symbol=r'AAPL' #r prefix is used to treat the string as a raw string, which is useful if the symbol contains special characters
    )
