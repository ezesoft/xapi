import time
import asyncio
import os
import grpc
import grpc.aio
from threading import Event, Thread
from uuid import uuid4
from concurrent import futures
from generated import order_pb2 as ord
from generated import order_pb2_grpc as ord_grpc
from runtime.emsxapilibrary import EMSXAPILibrary


class ChangeSingleOrder:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        
        # Configure these fields before running
        self.order_id = ' '  # OrderId of the order to change (required)
        self.order_tag = 'XAP-{0}'.format(str(uuid4()))  # New OrderTag for the change request
        
        # Optional fields to change (set to None to skip)
        self.new_quantity = 5000  # New quantity/volume
        self.new_price = 121.5  # New limit price
        self.new_stop_price = None  # New stop price (if applicable)
        
        # Extended fields to change (set as needed)
        self.extended_fields = {
            # 'DEST_ROUTE': 'DEMOEUR',
            # 'ACCT_TYPE': '119',
        }
        
        self.ready = Event()

    def change_order(self):
        if not self.order_id:
            print("Error: order_id is required")
            return
        
        change_order = ord.ChangeSingleOrderRequest()
        change_order.OrderId = self.order_id
        change_order.UserToken = self.xapiLib.userToken
        change_order.OrderTag = self.order_tag
        
        # Set optional fields if provided
        if self.new_quantity is not None:
            change_order.Quantity = self.new_quantity
        
        if self.new_price is not None:
            change_order.Price.value = self.new_price
        
        if self.new_stop_price is not None:
            change_order.StopPrice.value = self.new_stop_price
        
        # Set extended fields
        for key, value in self.extended_fields.items():
            change_order.ExtendedFields[key] = value
        
        print(f"Submitting change for OrderId: {self.order_id}")
        response = self.xapiLib.get_order_service_stub().ChangeSingleOrder(change_order)
        
        if response.ServerResponse == 'success':
            print("Successfully submitted change order")
        else:
            print(f"Failed to change order: {response.OptionalFields.get('ErrorMessage', 'Unknown error')}")
        
        return response

    def stress_test_change_orders(self, num_requests=100):
        """
        Send multiple ChangeSingleOrder requests asynchronously without waiting for responses.
        Quantity is incremented by 1 for each request starting from self.new_quantity.
        """
        if not self.order_id:
            print("Error: order_id is required")
            return
        
        print(f"Starting stress test: {num_requests} async ChangeSingleOrder requests")
        start_time = time.time()
        
        pending_futures = []
        base_quantity = self.new_quantity if self.new_quantity is not None else 1000
        
        for i in range(num_requests):
            change_order = ord.ChangeSingleOrderRequest()
            change_order.OrderId = self.order_id
            change_order.UserToken = self.xapiLib.userToken
            change_order.OrderTag = f'XAP-STRESS-{i}-{uuid4()}'
            
            # Increment quantity by 1 for each request
            change_order.Quantity = base_quantity + i
            
            if self.new_price is not None:
                change_order.Price.value = self.new_price
            
            if self.new_stop_price is not None:
                change_order.StopPrice.value = self.new_stop_price
            
            for key, value in self.extended_fields.items():
                change_order.ExtendedFields[key] = value
            
            # Log request to console
            print(f"[{i+1}/{num_requests}] Request: OrderId={change_order.OrderId}, OrderTag={change_order.OrderTag}, Quantity={change_order.Quantity}, Price={change_order.Price.value if self.new_price else 'N/A'}")
            
            # Send asynchronously using gRPC future - does not wait for response
            future = self.xapiLib.get_order_service_stub().ChangeSingleOrder.future(change_order)
            pending_futures.append(future)
        
        elapsed = time.time() - start_time
        print(f"\nAll {num_requests} requests sent in {elapsed:.3f} seconds ({num_requests/elapsed:.1f} requests/sec)")
        print(f"Pending futures: {len(pending_futures)}")
        
        return pending_futures

    async def stress_test_change_orders_async(self, num_requests=100):
        """
        Send multiple ChangeSingleOrder requests using grpc.aio async/await.
        Quantity is incremented by 1 for each request starting from self.new_quantity.
        """
        if not self.order_id:
            print("Error: order_id is required")
            return
        
        print(f"Starting async stress test: {num_requests} ChangeSingleOrder requests using grpc.aio")
        
        # Create async channel with SSL support
        server = f"{self.xapiLib.config.server}:{self.xapiLib.config.port}"
        config = self.xapiLib.config
        
        if config.ssl and config.certFilePath:
            cert_file = config.certFilePath
            if not os.path.exists(cert_file):
                runtime_dir = os.path.dirname(os.path.abspath(__file__))
                cert_file = os.path.join(runtime_dir, '..', '..', 'runtime', config.certFilePath)
            with open(cert_file, 'rb') as f:
                cert_data = f.read()
            credentials = grpc.ssl_channel_credentials(root_certificates=cert_data)
            channel = grpc.aio.secure_channel(server, credentials)
        else:
            channel = grpc.aio.insecure_channel(server)
        
        async with channel:
            stub = ord_grpc.SubmitOrderServiceStub(channel)
            
            base_quantity = self.new_quantity if self.new_quantity is not None else 1000
            
            async def send_change_order(index):
                change_order = ord.ChangeSingleOrderRequest()
                change_order.OrderId = self.order_id
                change_order.UserToken = self.xapiLib.userToken
                change_order.OrderTag = f'XAP-ASYNC-{index}-{uuid4()}'
                change_order.Quantity = base_quantity + index
                
                if self.new_price is not None:
                    change_order.Price.value = self.new_price
                
                if self.new_stop_price is not None:
                    change_order.StopPrice.value = self.new_stop_price
                
                for key, value in self.extended_fields.items():
                    change_order.ExtendedFields[key] = value
                
                # Log request to console
                print(f"[{index+1}/{num_requests}] Request: OrderId={change_order.OrderId}, OrderTag={change_order.OrderTag}, Quantity={change_order.Quantity}")
                
                response = await stub.ChangeSingleOrder(change_order)
                print(f"[{index+1}/{num_requests}] Response: {response.ServerResponse}")
                return response
            
            # Create all tasks
            start_time = time.time()
            tasks = [send_change_order(i) for i in range(num_requests)]
            
            # Execute all concurrently
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            elapsed = time.time() - start_time
            print(f"\nAll {num_requests} requests completed in {elapsed:.3f} seconds ({num_requests/elapsed:.1f} requests/sec)")
            
            return results


if __name__ == "__main__":
    change_order = ChangeSingleOrder()
    change_order.xapiLib.login()
    
    # Single change order
    change_order.change_order()
    
    # Stress test using gRPC futures (fire-and-forget style)
    # change_order.stress_test_change_orders(num_requests=100)
    
    # Stress test using grpc.aio async/await (recommended)
    # asyncio.run(change_order.stress_test_change_orders_async(num_requests=100))
    
    time.sleep(3)  # Time in seconds to wait for order updates
    change_order.xapiLib.logout()
