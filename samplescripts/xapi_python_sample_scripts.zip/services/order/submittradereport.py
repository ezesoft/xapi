"""
SubmitTradeReport API

This module provides functionality to submit trade reports.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import order_pb2
class SubmitTradeReport:
    """
    Submits trade reports.

    This class provides methods to submit trade reports for executed
    trades that need to be reported to the system.
    """

    def __init__(self):
        """
        Initialize the SubmitTradeReport instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def submit_trade_report(self, symbol, side, quantity, account, route,
                            order_type=0, extended_fields=None):
        """
        Submit a trade report.

        Args:
            symbol (str): The symbol of the security.
            side (str): The side of the trade ('BUY' or 'SELL').
            quantity (int): The quantity of the trade.
            account (str): The account for the trade.
            route (str): The route for the trade.
            order_type (int, optional): Type of order:
                0 = UserSubmitTradeReport
                1 = ForeignExecution
                Defaults to 0.
            extended_fields (dict, optional): Additional extended fields for the trade.
                Defaults to None.

        Returns:
            bool: True if trade report was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = order_pb2.SubmitTradeReportRequest()
            request.UserToken = self.xapiLib.userToken
            request.Symbol = symbol.upper()
            request.Side = side.upper()
            request.Quantity = quantity
            request.Account = account
            request.Route = route.upper()

            # Set order type
            request.OrderType.OrderTypes = order_type

            # Add extended fields if provided
            if extended_fields:
                for key, value in extended_fields.items():
                    request.ExtendedFields[key] = str(value)

            response = self.xapiLib.get_order_service_stub().SubmitTradeReport(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

            if hasattr(response, 'ServerResponse') and response.ServerResponse == "success":
                print('Successfully submitted trade report')
                return True
            else:
                print(f'Trade report submission failed')
                if hasattr(response, 'OptionalFields') and 'ErrorMessage' in response.OptionalFields:
                    print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    trade_report_example = SubmitTradeReport()
    # Example trade report
    trade_report_example.submit_trade_report(
        symbol='AAPL',
        side='BUY',
        quantity=100,
        account='ACCOUNT123',
        route='ROUTE1',
        order_type=0,  # UserSubmitTradeReport
        extended_fields={'Price': '150.50', 'ExecutionTime': '09:30:00'}
    )
