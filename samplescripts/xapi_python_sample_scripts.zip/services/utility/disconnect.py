"""
Disconnect API

This module provides functionality to disconnect from the server.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import utilities_pb2
class Disconnect:
    """
    Disconnects from the server.

    This class provides methods to terminate an active session
    and disconnect from the server.
    """

    def __init__(self):
        """
        Initialize the Disconnect instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def disconnect(self):
        """
        Disconnect from the server.

        This method sends a disconnect request to terminate the current
        session and release server resources.

        Returns:
            bool: True if disconnect was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            if not self.xapiLib.userToken:
                print('No active session to disconnect')
                return False

            request = utilities_pb2.DisconnectRequest()
            request.UserToken = self.xapiLib.userToken

            response = self.xapiLib.get_utility_service_stub().Disconnect(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

            if hasattr(response, 'ServerResponse') and response.ServerResponse == "success":
                print('Successfully disconnected from server')
                self.xapiLib.userToken = ''
                self.xapiLib.set_is_logged_in(False)
                return True
            else:
                print(f'Disconnect failed')
                if hasattr(response, 'OptionalFields') and 'ErrorMessage' in response.OptionalFields:
                    print(f'Error Message: {response.OptionalFields["ErrorMessage"]}')
                return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.close_channel()
            except Exception as e:
                print(f'Close channel error: {e}')


if __name__ == "__main__":
    disconnect_example = Disconnect()
    # First login to establish a session
    disconnect_example.xapiLib.login()
    # Then disconnect
    disconnect_example.disconnect()
