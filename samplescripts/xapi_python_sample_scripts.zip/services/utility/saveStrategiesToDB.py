from generated import utilities_pb2 as util
from generated import utilities_pb2_grpc as util_grpc
from runtime.emsxapilibrary import EMSXAPILibrary
import random
import string

class SaveStrategyToDB:
    def __init__(self):
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()
        self.xapiLib.login()
        self.firm_name = ""
        self.algo_name = "S_Lazard_Testing" # specify existing algo name
        self.strategy_name ="Test" # specify existing strategy name under the algo
        #genearate random strategy name
        self.new_strategy_name = "Test_" + ''.join(random.choices(string.ascii_letters + string.digits, k=3))
        self.strat_params =""
        self.version=""

    def get_firm_name(self):
        get_firm_name_request = util.GetFirmNameRequest()
        get_firm_name_request.UserToken = self.xapiLib.userToken
        get_firm_name_response = self.xapiLib.get_utility_service_stub().GetFirmName(get_firm_name_request)
        if get_firm_name_response:
            print(get_firm_name_response)
            if len(get_firm_name_response.FirmName) > 0:
                self.firm_name = get_firm_name_response.FirmName
                print(f"Firm Name:: {get_firm_name_response.FirmName} ")
            else:
                print("Firm Name not found")

    def get_strategy_list(self):
        get_strategy_list_request = util.StrategyListRequest()
        get_strategy_list_request.UserToken = self.xapiLib.userToken
        get_strategy_list_request.FirmName = self.firm_name
        get_strategy_list_response = self.xapiLib.get_utility_service_stub().GetStrategyList(get_strategy_list_request)
        print(get_strategy_list_response.Acknowledgement.ServerResponse)
        if len(get_strategy_list_response.StrategyList) > 0:
            i=0
            for strategy in get_strategy_list_response.StrategyList:
                print("--------------- Strategy Num: ", i, " START ---------------")
                print(strategy)
                print("--------------- Strategy Num: ", i, " END ---------------")
                i = i + 1
        else:
            print("No Strategies found")

    def get_strategy_data(self):
        get_strategy_data_request = util.GetStrategyDataRequest()
        get_strategy_data_request.UserToken = self.xapiLib.userToken
        get_strategy_data_request.FirmName = self.firm_name
        get_strategy_data_request.AlgoName = self.algo_name
        get_strategy_data_request.StrategyName = self.strategy_name
        strategy_data = self.xapiLib.get_utility_service_stub().GetStrategyData(get_strategy_data_request)
        print(strategy_data.Acknowledgement.ServerResponse)
        print(strategy_data)
        if strategy_data.Acknowledgement.ServerResponse == "success":
            # if strategy_data.AlgoName == self.algo_name and strategy_data.StrategyName == self.strategy_name:
            self.strat_params = strategy_data.StrategyData.StratParams
            self.version = strategy_data.StrategyData.Version
            print("--------------- Strategy Data  START ---------------")
            print(f"FirmName:: {strategy_data.StrategyData.FirmName} ")
            print(f"UserName:: \n {strategy_data.StrategyData.UserName}")
            print(f"AlgoName:: {strategy_data.StrategyData.AlgoName} ")
            print(f"StrategyName:: {strategy_data.StrategyData.StrategyName} ")
            print(f"StratParams:: \n {strategy_data.StrategyData.StratParams} ")
            print(f"Version:: {strategy_data.StrategyData.Version} ")
            print("--------------- Strategy Data  END ---------------")
        else:
            print(f"Strategy Data not found for Algo: {self.algo_name} and Strategy: {self.strategy_name}")

    def create_strategy(self):
        create_strategy_request = util.CreateStrategyRequest()
        create_strategy_request.UserToken = self.xapiLib.userToken
        create_strategy_request.FirmName = self.firm_name
        create_strategy_request.AlgoName = self.algo_name
        create_strategy_request.StrategyName = self.new_strategy_name
        create_strategy_request.StratParams = self.strat_params
        create_strategy_response = self.xapiLib.get_utility_service_stub().CreateStrategy(create_strategy_request)
        print(create_strategy_response.Acknowledgement.ServerResponse)
        if create_strategy_response.Acknowledgement.ServerResponse == "success":
            print(f"Strategy {self.strategy_name} created successfully under Algo {self.algo_name}")
            #get the strategy data to verify
            self.strategy_name = self.new_strategy_name
            print("Verifying the created strategy data:")
            self.get_strategy_data()
        else:
            print(f"Failed to create Strategy {self.new_strategy_name} under Algo {self.algo_name}")

    def update_strategy(self):
        update_strategy_request = util.UpdateStrategyRequest()
        update_strategy_request.UserToken = self.xapiLib.userToken
        update_strategy_request.FirmName = self.firm_name
        update_strategy_request.AlgoName = self.algo_name
        update_strategy_request.StrategyName = self.strategy_name
        update_strategy_request.StratParams = self.strat_params
        update_strategy_request.Version = self.version
        update_strategy_response = self.xapiLib.get_utility_service_stub().UpdateStrategy(update_strategy_request)
        print(update_strategy_response.Acknowledgement.ServerResponse)
        if update_strategy_response.Acknowledgement.ServerResponse == "success":
            print(f"Strategy {self.strategy_name} updated successfully under Algo {self.algo_name}")
            #get the strategy data to verify
            print("Verifying the updated strategy data:")
            self.get_strategy_data()
        else:
            print(f"Failed to update Strategy {self.strategy_name} under Algo {self.algo_name}")

if __name__ == "__main__":
    save_strategies_db_demo = SaveStrategyToDB()
    print("===================================")
    print("Get Firm Name")
    print("===================================")
    save_strategies_db_demo.get_firm_name()
    print("===================================")
    print("Get Strategy List")
    print("===================================")
    save_strategies_db_demo.get_strategy_list()
    print("===================================")
    print("Get Strategy Data")
    print("===================================")
    save_strategies_db_demo.get_strategy_data()
    print("===================================")
    print("Create Strategy")
    print("===================================")
    save_strategies_db_demo.create_strategy()
    print("===================================")
    print("Update Strategy")
    print("===================================")
    save_strategies_db_demo.update_strategy()
    print("===================================")
    save_strategies_db_demo.xapiLib.logout()
