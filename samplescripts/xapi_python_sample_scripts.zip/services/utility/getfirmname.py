"""
GetFirmName API

This module provides functionality to retrieve the firm name for the current user.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import utilities_pb2
class GetFirmName:
    """
    Retrieves the firm name for the current user.

    This class provides methods to get the firm name associated
    with the authenticated user's account.
    """

    def __init__(self):
        """
        Initialize the GetFirmName instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def get_firm_name(self):
        """
        Retrieve the firm name for the current user.

        Returns:
            str: The firm name if successful, None otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = utilities_pb2.GetFirmNameRequest()
            request.UserToken = self.xapiLib.userToken

            response = self.xapiLib.get_utility_service_stub().GetFirmName(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse != "success":
                    print(f'API Error: {response.Acknowledgement.Message}')
                    return None

            if hasattr(response, 'FirmName') and response.FirmName:
                print(f'Firm Name: {response.FirmName}')
                return response.FirmName
            else:
                print('No firm name found')
                return None

        except Exception as e:
            print(f'Error: {e}')
            return None
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    firm_name_example = GetFirmName()
    firm_name_example.get_firm_name()
