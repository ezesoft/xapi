"""
CreateStrategy API

This module provides functionality to create a new strategy in the system.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import utilities_pb2
class CreateStrategy:
    """
    Creates a new strategy in the system.

    This class provides methods to create a new strategy
    for a specified firm and algorithm.
    """

    def __init__(self):
        """
        Initialize the CreateStrategy instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def create_strategy(self, firm_name, algo_name, strategy_name, strat_params=None):
        """
        Create a new strategy.

        Args:
            firm_name (str): The firm name that will own the strategy.
                Format is typically 'USERNAME@DOMAIN'.
            algo_name (str): The algorithm name to associate with the strategy.
            strategy_name (str): The name of the new strategy.
            strat_params (str, optional): The strategy parameters as a string
                (typically JSON or key-value pairs). Defaults to None.

        Returns:
            bool: True if strategy creation was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = utilities_pb2.CreateStrategyRequest()
            request.UserToken = self.xapiLib.userToken
            request.FirmName = firm_name
            request.AlgoName = algo_name
            request.StrategyName = strategy_name

            if strat_params:
                request.StratParams = strat_params

            response = self.xapiLib.get_utility_service_stub().CreateStrategy(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse == "success":
                    print(f'Successfully created strategy: {strategy_name}')
                    return True
                else:
                    print(f'API Error: {response.Acknowledgement.Message}')
                    return False

            return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    create_strategy_example = CreateStrategy()
    # Example: Create strategy
    create_strategy_example.create_strategy(
        firm_name='ABC@DOMAIN',
        algo_name='VWAP',
        strategy_name='MyNewStrategy',
        strat_params='{"startTime":"09:30","endTime":"16:00","participationRate":0.1}'
    )
