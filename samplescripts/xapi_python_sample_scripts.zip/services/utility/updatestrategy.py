"""
UpdateStrategy API

This module provides functionality to update an existing strategy in the system.
"""
from runtime.emsxapilibrary import EMSXAPILibrary
from generated import utilities_pb2
class UpdateStrategy:
    """
    Updates an existing strategy in the system.

    This class provides methods to update the parameters
    of an existing strategy.
    """

    def __init__(self):
        """
        Initialize the UpdateStrategy instance.

        Sets up the EMSXAPILibrary singleton and obtains a reference to it.
        """
        EMSXAPILibrary.create()
        self.xapiLib = EMSXAPILibrary.get()

    def update_strategy(self, firm_name, algo_name, strategy_name, version, strat_params):
        """
        Update an existing strategy.

        Args:
            firm_name (str): The firm name that owns the strategy.
                Format is typically 'USERNAME@DOMAIN'.
            algo_name (str): The algorithm name associated with the strategy.
            strategy_name (str): The name of the strategy to update.
            version (int): The current version of the strategy (for optimistic locking).
            strat_params (str): The new strategy parameters as a string
                (typically JSON or key-value pairs).

        Returns:
            bool: True if strategy update was successful, False otherwise.

        Raises:
            Exception: If the API call fails or returns an error.
        """
        try:
            self.xapiLib.login()
            print('User token: ' + self.xapiLib.userToken)

            request = utilities_pb2.UpdateStrategyRequest()
            request.UserToken = self.xapiLib.userToken
            request.FirmName = firm_name
            request.AlgoName = algo_name
            request.StrategyName = strategy_name
            request.Version = version
            request.StratParams = strat_params

            response = self.xapiLib.get_utility_service_stub().UpdateStrategy(request)

            if hasattr(response, 'Acknowledgement'):
                print('Server Response: ' + response.Acknowledgement.ServerResponse +
                      ' | Message: ' + response.Acknowledgement.Message)

                if response.Acknowledgement.ServerResponse == "success":
                    print(f'Successfully updated strategy: {strategy_name}')
                    return True
                else:
                    print(f'API Error: {response.Acknowledgement.Message}')
                    return False

            return False

        except Exception as e:
            print(f'Error: {e}')
            return False
        finally:
            try:
                self.xapiLib.logout()
            except Exception as e:
                print(f'Logout error: {e}')


if __name__ == "__main__":
    update_strategy_example = UpdateStrategy()
    # Example: Update strategy
    update_strategy_example.update_strategy(
        firm_name='ABC@DOMAIN',
        algo_name='VWAP',
        strategy_name='MyStrategy',
        version=1,
        strat_params='{"startTime":"09:30","endTime":"15:30","participationRate":0.15}'
    )
