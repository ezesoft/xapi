using System;
using System.IO;

namespace CSharp_XAPI_Client
{
    public class Logger
    {
        private readonly string logFilePath;

        public Logger()
        {
            logFilePath = string.Format("order_log_{0}.txt", DateTime.Today.ToString("dd-MM-yyyy"));
        }

        public void LogMessage(string message)
        {
            try
            {
                string logEntry = $"{DateTime.Now}: {message}";

                // Write to log file
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    writer.WriteLine(logEntry);
                }

                // Write to console
                Console.WriteLine(logEntry);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to log message: " + ex.Message);
            }
        }
    }
}
