﻿using System;


namespace CSharp_XAPI_Client
{
    public class LoginFailedException : Exception
    {
        public LoginFailedException() : base("Login failed")
        {
        }

        public LoginFailedException(string message) : base(message)
        {
        }

        public LoginFailedException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
