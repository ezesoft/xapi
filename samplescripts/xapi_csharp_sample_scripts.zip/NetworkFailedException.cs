﻿using System;


namespace CSharp_XAPI_Client
{
    public class NetworkFailedException : Exception
    {
        public NetworkFailedException() : base("Failure in network")
        {
        }

        public NetworkFailedException(string message) : base(message)
        {
        }

        public NetworkFailedException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
