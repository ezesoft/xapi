# CSharp_XAPI_Client

## Overview

CSharp_XAPI_Client is a sample client application demonstrating how to interact with the SS&C Eze XAPI platform using C# and .NET 8. It provides examples for authentication, market data streaming, order submission, and more, using gRPC and Protocol Buffers.

## Features

- **Authentication**: Login/logout and heartbeat management
- **Market Data**:
  - Level 1, Level 2, and Tick data streaming (unary and bidirectional)
  - Dynamic symbol subscription management
  - Real-time statistics and formatted output
- **Order Management**:
  - Single and regression order submission
  - Order info subscription
- **Reference Data**:
  - Get today's activity
  - Security and symbol reference queries
- **Error Handling & Logging**: Centralized error handler and logger

## Key Example Files

- `App.cs`: Main entry point, demonstrates authentication, heartbeat, and launches all examples
- `ExampleSubscribeLevel1Ticks.cs`: Server-side streaming for Level 1 market data
- `ExampleGetTodaysActivity.cs`: Reference data query example
- `ExampleSubscribeOrdInfo.cs`: Order info subscription example
- `ExampleSubmitSingleOrder.cs`: Single order submission example

## Getting Started

### Prerequisites
- .NET 8 SDK
- Access to SS&C Eze XAPI server
- Valid configuration file (`config.cfg`) with credentials and server details

### Build & Run
1. Restore NuGet packages:
   ```sh
   dotnet restore
   ```
2. Build the solution:
   ```sh
   dotnet build
   ```
3. Run the client:
   ```sh
   dotnet run --project CSharp_XAPI_Client.csproj
   ```

### Configuration
- Place your `config.cfg` file in the project directory.
- Update credentials, server, and other settings as needed.

## Project Structure

| File/Folder                      | Description                                  |
|----------------------------------|----------------------------------------------|
| App.cs                           | Main application logic and example runner    |
| EMSXAPILibrary.cs                | API wrapper and connection management        |
| ExampleSubscribeLevel1Ticks.cs    | Level 1 market data streaming example        |
| ExampleGetTodaysActivity.cs       | Reference data query example                |
| ExampleSubscribeOrdInfo.cs        | Order info subscription example             |
| ExampleSubmitSingleOrder.cs       | Single order submission example             |
| market_data.proto                 | Protobuf definitions for market data         |
| utilities.proto                   | Protobuf definitions for utility services    |
| Readme_CsharpClient.md            | This file                                   |

## Usage Patterns

- **Authentication**: Use `EMSXAPILibrary.Create()` and `Login()` before making API calls.
- **Streaming**: Use gRPC streaming APIs for real-time data. Always complete request streams and handle responses asynchronously.
- **Order Submission**: Use provided examples for single and regression order flows.
- **Error Handling**: Centralized via `ErrorHandler` and `Logger` classes.

## API Documentation

## Troubleshooting

- Ensure your `config.cfg` is correct and accessible
- Check network connectivity to the XAPI server
- Review console output and logs for error details
- For protobuf/gRPC issues, ensure all NuGet packages are restored and up to date

## License

This sample is provided for demonstration and integration purposes. Please refer to your SS&C Eze license agreement for usage terms.

## Support

For questions or support, contact SS&C Eze technical support or your account representative.
