﻿using System;


namespace EzeSoft.XAPI
{
    public class ErrorHandler
    {
        public void OnError(Exception ex, EMSXAPILibrary lib)
        {
            Console.WriteLine("===error in library===");
            Console.WriteLine(ex.ToString());
            if (lib != null)
            {
                // Note: Error handling has been refactored to use managers
                // The EMSXAPILibrary now handles logout and cleanup internally
                try
                {
                    lib.Logout();
                }
                catch (Exception logoutEx)
                {
                    Console.WriteLine($"Error during logout: {logoutEx.Message}");
                }
            }
        }
}
}
