# EMS XAPI Client Library (Managers Overview)

This library organizes client responsibilities into focused managers for clarity and maintainability:

- AuthenticationManager: Handles login/logout (SRP and standard)
- ChannelManager: Creates and manages the gRPC `GrpcChannel`
- ServiceManager: Provides typed gRPC service clients
- HeartbeatManager: Subscribes to server heartbeat to track connection liveness
- Logger: Minimal logger with optional external sink

## Quick Start

```csharp
// Load configuration
var config = new EMSXAPIConfig("config.cfg");
var logger = new Logger();

// Create channel and services
var channelManager = new ChannelManager(config, logger);
var serviceManager = new ServiceManager(channelManager.Channel, logger);
serviceManager.InitializeServices();

// Authenticate (SRP if enabled in config)
var authManager = new AuthenticationManager(config, logger, serviceManager.UtilityClient);
authManager.Login();

// Start heartbeat
var heartbeatManager = new HeartbeatManager(config, logger, serviceManager.UtilityClient, authManager);
heartbeatManager.StartHeartbeat();

// Use services
var marketData = serviceManager.MarketDataClient;
// ... call APIs

// Cleanup
heartbeatManager.StopHeartbeat();
authManager.Logout();
channelManager.CloseChannel();
```

## Configuration Notes

- Environment variables override file values for security.
- SSL can be enabled by setting `ssl=true`; platform defaults handle certificate validation.

## Heartbeat Scheduling

`HeartbeatManager` uses a timer to trigger a single background subscription task and supports clean cancellation.
For advanced scheduling (retries, backoff, calendars), consider integrating Quartz.NET.

## Logging

`Logger` writes to a rotating file under `./logs` and console. If the log directory is not writable, it disables file logging and continues console logging.

To integrate Serilog/NLog later, use the `IEMSLogger` interface or pass an external sink (`Action<string>`) to `Logger`.

## Error Handling

- Authentication: Exceptions are logged and rethrown with context; SRP errors include inner exceptions for debugging.
- Channel: Channel creation exceptions are wrapped in `ChannelClosedException` for clearer diagnostics.

## Legacy APIs

Legacy methods are marked `[Obsolete]` in `EMSXAPILibrary.cs`. Prefer using the manager classes directly.
