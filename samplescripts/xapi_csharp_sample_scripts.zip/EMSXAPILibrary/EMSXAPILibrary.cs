using System;
using Grpc.Net.Client;
using ezesoft.xapi.generated;
using static ezesoft.xapi.generated.SubscribeHeartBeatResponse.Types;

//SRP Stuff
using Org.BouncyCastle.Crypto.Agreement.Srp;//for Srp6Client
using Org.BouncyCastle.Crypto.Digests;//SHA256Digest
using Org.BouncyCastle.Security;//SecureRandom
using System.Security.Cryptography;//Sha256Managed
using Org.BouncyCastle.Math;//BigInteger

// The EzeSoft.XAPI namespace is used to organize the EMS XAPI client library components
// and maintain consistency with the overall project structure and naming conventions.
namespace EzeSoft.XAPI
{
    /// <summary>
    /// Main library class for EMS XAPI client operations.
    /// Orchestrates channel management, authentication, service access, and heartbeat functionality.
    /// </summary>
    public class EMSXAPILibrary : IDisposable
    {
        private static readonly object instanceLock = new object();
        private static EMSXAPILibrary? instance;

        private readonly ChannelManager channelManager;
        private readonly AuthenticationManager authManager;
        private readonly ServiceManager serviceManager;
        private readonly HeartbeatManager heartbeatManager;
        private readonly EMSXAPIConfig config;
        private readonly Logger logger;

        private bool disposed = false;

        /// <summary>
        /// Gets a value indicating whether the user is currently logged in.
        /// </summary>
        public bool IsLoggedIn => authManager.IsLoggedIn;

        /// <summary>
        /// Gets the current user token.
        /// </summary>
        public string? UserToken => authManager.UserToken;

        /// <summary>
        /// Gets the user token hash for security purposes.
        /// </summary>
        public string? UserTokenHash => !string.IsNullOrEmpty(UserToken) ? SensitiveMask.Sha256(UserToken) : null;

        /// <summary>
        /// Gets the utility services client.
        /// </summary>
        public UtilityServices.UtilityServicesClient UtilityClient => serviceManager.UtilityClient;

        /// <summary>
        /// Gets the market data services client.
        /// </summary>
        public MarketDataService.MarketDataServiceClient MarketDataClient => serviceManager.MarketDataClient;

        /// <summary>
        /// Gets the order services client.
        /// </summary>
        public SubmitOrderService.SubmitOrderServiceClient OrderClient => serviceManager.OrderClient;

        /// <summary>
        /// Gets the gRPC channel.
        /// </summary>
        public GrpcChannel Channel => channelManager.Channel;

        /// <summary>
        /// Gets the channel manager for direct access to channel operations.
        /// </summary>
        public ChannelManager ChannelManager => channelManager;

        /// <summary>
        /// Gets the heartbeat manager for direct access to heartbeat operations.
        /// </summary>
        public HeartbeatManager HeartbeatManager => heartbeatManager;

        /// <summary>
        /// Initializes a new instance of the EMSXAPILibrary class.
        /// </summary>
        /// <param name="configFileName">The configuration file name.</param>
        private EMSXAPILibrary(string configFileName)
        {
            config = new EMSXAPIConfig(configFileName);
            logger = new Logger();

            // Initialize managers
            channelManager = new ChannelManager(config, logger);
            serviceManager = new ServiceManager(channelManager.Channel, logger);
            authManager = new AuthenticationManager(config, logger, serviceManager.UtilityClient);
            heartbeatManager = new HeartbeatManager(config, logger, serviceManager.UtilityClient, authManager);

            // Initialize services
            serviceManager.InitializeServices();
        }

        /// <summary>
        /// Creates a new instance of the EMSXAPILibrary.
        /// </summary>
        /// <param name="configFileName">The configuration file name.</param>
        public static void Create(string configFileName)
        {
            lock (instanceLock)
            {
                instance = new EMSXAPILibrary(configFileName);
            }
        }

        /// <summary>
        /// Gets the singleton instance of the EMSXAPILibrary.
        /// </summary>
        /// <returns>The EMSXAPILibrary instance.</returns>
        public static EMSXAPILibrary Get()
        {
            return instance ?? throw new InvalidOperationException("EMSXAPILibrary not initialized. Call Create() first.");
        }

        /// <summary>
        /// Authenticates with the XAPI server using the configured credentials.
        /// </summary>
        public void Login()
        {
            authManager.Login();
            heartbeatManager.StartHeartbeat();
        }

        /// <summary>
        /// Logs out from the XAPI server and stops heartbeat.
        /// </summary>
        public void Logout()
        {
            heartbeatManager.StopHeartbeat();
            authManager.Logout();
        }

        /// <summary>
        /// Disposes of the EMSXAPILibrary and releases all resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes of the EMSXAPILibrary resources.
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    heartbeatManager?.Dispose();
                    serviceManager?.Dispose();
                    channelManager?.Dispose();
                }
                disposed = true;
            }
        }

        // Legacy methods removed to simplify API. Use properties and manager classes directly.
    }
}
