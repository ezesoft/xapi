﻿using System;


namespace EzeSoft.XAPI
{
    /// <summary>
    /// Exception thrown when gRPC channel operations fail due to connectivity or configuration issues.
    /// </summary>
    public class ChannelClosedException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the ChannelClosedException class with a default message.
        /// </summary>
        public ChannelClosedException() : base("Channel might be closed or unresponsive")
        {
        }

        /// <summary>
        /// Initializes a new instance of the ChannelClosedException class with a specified message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public ChannelClosedException(string message) : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the ChannelClosedException class with a specified message and inner exception.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="innerException">The exception that is the cause of the current exception.</param>
        public ChannelClosedException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
