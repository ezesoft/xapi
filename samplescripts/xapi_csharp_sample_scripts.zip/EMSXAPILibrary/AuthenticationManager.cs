using System;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using Grpc.Core;
using Org.BouncyCastle.Crypto.Agreement.Srp;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Security;
using ezesoft.xapi.generated;

namespace EzeSoft.XAPI
{
    /// <summary>
    /// Helper class for cryptographic operations and utilities.
    /// </summary>
    public static class Helper
    {
        private static readonly string[] HexTbl = Enumerable.Range(0, 256).Select(v => v.ToString("X2")).ToArray();

        public static T[] Concat<T>(T[] initial, params T[][] args)
        {
            return _Concat(initial, args).ToArray();
        }

        private static IEnumerable<T> _Concat<T>(T[] initial, T[][] args)
        {
            int i = 0;
            while (i < initial.Length)
            {
                yield return initial[i];
                i++;
            }
            i = 0;
            while (i < args.Length)
            {
                int j = 0;
                while (j < args[i].Length)
                {
                    yield return args[i][j];
                    j++;
                }
                i++;
            }
        }

        public static byte[] GetBytesFromHexEncoded(string strSource)
        {
            if (strSource.Length % 2 != 0)//invalid string
                return new byte[0];
            return _GetBytesFromHexEncoded(strSource).ToArray();
        }
        public static IEnumerable<byte> _GetBytesFromHexEncoded(string strSource)
        {
            int nLen = strSource.Length / 2;
            int i = 0;
            while (i < nLen)
            {
                yield return Byte.Parse(strSource.Substring(i * 2, 2), System.Globalization.NumberStyles.HexNumber);
                i++;
            }
        }

        public static string GetHexEncodedStringFromBytes(byte[] array)
        {
            return string.Concat(array.Select(i => HexTbl[i]));
        }
    }

    /// <summary>
    /// Manages authentication operations for the EMS XAPI library.
    /// Supports both standard authentication and SRP (Secure Remote Password) authentication.
    /// </summary>
    public class AuthenticationManager
        {
            private readonly EMSXAPIConfig config;
            private readonly Logger logger;
            private readonly UtilityServices.UtilityServicesClient utilityClient;
            private string? userToken;
            private bool isLoggedIn;

            /// <summary>
            /// Initializes a new instance of the AuthenticationManager class.
            /// </summary>
            /// <param name="config">The configuration containing authentication settings.</param>
            /// <param name="logger">The logger for recording authentication operations.</param>
            /// <param name="utilityClient">The utility services gRPC client.</param>
            public AuthenticationManager(EMSXAPIConfig config, Logger logger, UtilityServices.UtilityServicesClient utilityClient)
            {
                this.config = config ?? throw new ArgumentNullException(nameof(config));
                this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
                this.utilityClient = utilityClient ?? throw new ArgumentNullException(nameof(utilityClient));
            }

            /// <summary>
            /// Gets a value indicating whether the user is currently logged in.
            /// </summary>
            public bool IsLoggedIn => isLoggedIn;

            /// <summary>
            /// Gets the current user token.
            /// </summary>
            public string? UserToken => userToken;

            /// <summary>
            /// Authenticates with the XAPI server using the configured credentials.
            /// Supports both standard authentication and SRP authentication.
            /// </summary>
            /// <exception cref="LoginFailedException">Thrown when authentication fails.</exception>
            /// <exception cref="NetworkFailedException">Thrown when network issues prevent authentication.</exception>
            /// <exception cref="ServerNotAvailableException">Thrown when the server is not available.</exception>
            public void Login()
            {
                try
                {
                    isLoggedIn = false;

                    if (config.Srp_login)
                    {
                        PerformSrpLogin();
                    }
                    else
                    {
                        PerformStandardLogin();
                    }

                    isLoggedIn = true;
                    logger.LogMessage("Authentication successful");
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Authentication failed: {ex.Message}");
                    throw;
                }
            }

            /// <summary>
            /// Logs out from the XAPI server.
            /// </summary>
            /// <exception cref="NetworkFailedException">Thrown when logout fails due to network issues.</exception>
            public void Logout()
            {
                try
                {
                    if (!isLoggedIn || string.IsNullOrEmpty(userToken))
                    {
                        logger.LogMessage("Not logged in, skipping logout");
                        return;
                    }

                    var disconnectRequest = new DisconnectRequest { UserToken = userToken };
                    var response = utilityClient.Disconnect(disconnectRequest);

                    if (response.ServerResponse != "success")
                    {
                        logger.LogMessage($"Disconnect failed: {response.ServerResponse}");
                        // Don't throw exception for disconnect failures, just log
                    }
                    else
                    {
                        logger.LogMessage("Disconnect successful");
                    }

                    userToken = null;
                    isLoggedIn = false;
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Disconnect error: {ex.Message}");
                    throw new NetworkFailedException($"Failed to disconnect: {ex.Message}", ex);
                }
            }

            /// <summary>
            /// Performs standard authentication with username/password.
            /// </summary>
            private void PerformStandardLogin()
            {
                var connectRequest = new ConnectRequest
                {
                    UserName = config.User,
                    Domain = config.Domain,
                    Password = config.Password,
                    Locale = config.Locale
                };

                var connectResponse = utilityClient.Connect(connectRequest);
                if (connectResponse.Response != "success")
                {
                    logger.LogMessage($"Standard login failed: {connectResponse.Response}");
                    throw new LoginFailedException($"Authentication failed: {connectResponse.Response}");
                }

                userToken = connectResponse.UserToken;
            }

            /// <summary>
            /// Performs SRP (Secure Remote Password) authentication.
            /// </summary>
            private void PerformSrpLogin()
            {
                try
                {
                    // Step 1: Initialize SRP login
                    var srpLoginRequest = new StartLoginSrpRequest
                    {
                        UserName = config.User,
                        Domain = config.Domain
                    };

                    logger.LogMessage("Starting SRP authentication...");
                    var startResponse = utilityClient.StartLoginSrp(srpLoginRequest);

                    if (startResponse.Response != "success")
                    {
                        logger.LogMessage($"SRP login initialization failed: {startResponse.Response}");
                        throw new LoginFailedException($"SRP login initialization failed: {startResponse.Response}");
                    }

                    // Step 2: Calculate SRP parameters and complete login
                    string identity = $"{config.User.ToUpper()}@{config.Domain.ToUpper()}";
                    string ephemeralA, srpKey, proofM;

                    CalculateCompleteSrpLoginVars(
                        config.User,
                        config.Domain,
                        identity,
                        config.Password,
                        startResponse.SrpTransactId,
                        startResponse.SrpSalt,
                        startResponse.Srpb,
                        startResponse.SrpN,
                        startResponse.Srpg,
                        out ephemeralA,
                        out srpKey,
                        out proofM
                    );

                    var completeRequest = new CompleteLoginSrpRequest
                    {
                        Identity = identity,
                        SrpTransactId = startResponse.SrpTransactId,
                        StrEphA = ephemeralA,
                        StrMc = proofM,
                        UserName = config.User,
                        Domain = config.Domain.ToUpper(),
                        Locale = config.Locale.ToUpper()
                    };

                    var completeResponse = utilityClient.CompleteLoginSrp(completeRequest);
                    if (completeResponse.Response != "success")
                    {
                        logger.LogMessage($"SRP login completion failed: {completeResponse.Response}");
                        throw new LoginFailedException($"SRP authentication failed: {completeResponse.Response}");
                    }

                    userToken = completeResponse.UserToken;
                }
                catch (RpcException ex) when (ex.StatusCode == StatusCode.Unavailable)
                {
                    logger.LogMessage($"SRP authentication failed due to server unavailability: {ex.Message}");
                    throw new ServerNotAvailableException("XAPI server is not available for SRP authentication", ex);
                }
                catch (RpcException ex) when (ex.StatusCode == StatusCode.DeadlineExceeded)
                {
                    logger.LogMessage($"SRP authentication timed out: {ex.Message}");
                    throw new NetworkFailedException("SRP authentication request timed out", ex);
                }
                catch (RpcException ex)
                {
                    logger.LogMessage($"SRP authentication failed due to network error: {ex.Message}");
                    throw new NetworkFailedException($"Network error during SRP authentication: {ex.StatusCode}", ex);
                }
                catch (LoginFailedException)
                {
                    // Re-throw login-specific exceptions as-is
                    throw;
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Unexpected error during SRP authentication: {ex.Message}");
                    throw new LoginFailedException($"SRP authentication failed unexpectedly: {ex.Message}", ex);
                }
            }

            /// <summary>
            /// Calculates the complete SRP login variables for authentication.
            /// SRP (Secure Remote Password) is a password-authenticated key exchange protocol
            /// that allows secure authentication without transmitting the password.
            /// This method implements the client-side calculations for the SRP-6a protocol.
            /// </summary>
            /// <param name="userName">The user's login name.</param>
            /// <param name="domain">The authentication domain.</param>
            /// <param name="identity">The full identity string (username@domain).</param>
            /// <param name="password">The user's password.</param>
            /// <param name="srpTransactId">The SRP transaction ID from the server.</param>
            /// <param name="srpSalt">The salt value from the server (hex encoded).</param>
            /// <param name="srpB">The server's public ephemeral value B (hex encoded).</param>
            /// <param name="srpN">The SRP group parameter N (hex encoded).</param>
            /// <param name="srpG">The SRP group parameter g (hex encoded).</param>
            /// <param name="ephemeralA">Output: Client's public ephemeral value A (hex encoded).</param>
            /// <param name="srpKey">Output: The derived session key K (hex encoded).</param>
            /// <param name="proofM">Output: The proof M for authentication (hex encoded).</param>
            private static void CalculateCompleteSrpLoginVars(
                string userName,
                string domain,
                string identity,
                string password,
                string srpTransactId,
                string srpSalt,
                string srpB,
                string srpN,
                string srpG,
                out string ephemeralA,
                out string srpKey,
                out string proofM)
            {
                // Validate input parameters
                if (string.IsNullOrEmpty(srpTransactId) ||
                    string.IsNullOrEmpty(srpSalt) ||
                    string.IsNullOrEmpty(srpB) ||
                    string.IsNullOrEmpty(srpN) ||
                    string.IsNullOrEmpty(srpG))
                {
                    ephemeralA = "";
                    srpKey = "";
                    proofM = "";
                    return;
                }

                // Initialize SRP client with group parameters
                var client = new Srp6Client();
                var random = new SecureRandom();

                using (var hash = SHA256.Create())
                {
                    client.Init(new Org.BouncyCastle.Math.BigInteger(srpN), new Org.BouncyCastle.Math.BigInteger(srpG), new Sha256Digest(), random);

                    // Convert hex-encoded parameters to byte arrays
                    var saltBytes = Helper.GetBytesFromHexEncoded(srpSalt);
                    var identityBytes = Encoding.ASCII.GetBytes(identity);
                    var passwordBytes = Encoding.ASCII.GetBytes(password);

                    // Step 1: Generate client credentials (ephemeral value A)
                    var clientEphemeral = client.GenerateClientCredentials(saltBytes, identityBytes, passwordBytes);
                    ephemeralA = clientEphemeral.ToString();

                    // Step 2: Calculate the shared secret K
                    var clientKey = client.CalculateSecret(new Org.BouncyCastle.Math.BigInteger(srpB));
                    var keyBytes = clientKey.ToByteArrayUnsigned();
                    srpKey = Helper.GetHexEncodedStringFromBytes(hash.ComputeHash(keyBytes));

                    // Step 3: Calculate proof M = H(H(N) ^ H(g), H(I), s, A, B, K_c)
                    // This is the client proof that it knows the password
                    var proofBytes = CalculateSrpProof(hash, srpN, srpG, identityBytes, saltBytes, ephemeralA, srpB, keyBytes);
                    proofM = Helper.GetHexEncodedStringFromBytes(proofBytes);
                }
            }

            /// <summary>
            /// Calculates the SRP proof M = H(H(N) ^ H(g), H(I), s, A, B, K_c)
            /// </summary>
            private static byte[] CalculateSrpProof(
                System.Security.Cryptography.SHA256 hash,
                string srpN,
                string srpG,
                byte[] identityBytes,
                byte[] saltBytes,
                string ephemeralA,
                string srpB,
                byte[] keyBytes)
            {
                // H(N) and H(g)
                var hashN = hash.ComputeHash(new Org.BouncyCastle.Math.BigInteger(srpN).ToByteArrayUnsigned());
                var hashG = hash.ComputeHash(new Org.BouncyCastle.Math.BigInteger(srpG).ToByteArrayUnsigned());

                // H(N) ^ H(g)
                var nXorG = new byte[hashN.Length];
                for (int i = 0; i < hashN.Length; i++)
                {
                    nXorG[i] = (byte)(hashN[i] ^ hashG[i]);
                }

                // H(I)
                var hashI = hash.ComputeHash(identityBytes);

                // Convert A and B to byte arrays
                var A = new Org.BouncyCastle.Math.BigInteger(ephemeralA).ToByteArrayUnsigned();
                var B = new Org.BouncyCastle.Math.BigInteger(srpB).ToByteArrayUnsigned();

                // H(K_c)
                var kc = hash.ComputeHash(keyBytes);

                // Concatenate all components: H(N)^H(g), H(I), s, A, B, H(K_c)
                var toHash = Helper.Concat(nXorG, hashI, saltBytes, A, B, kc);

                // Final hash to get proof M
                return hash.ComputeHash(toHash);
            }
    }
}