﻿using System;
using System.Collections.Generic;
using System.IO;

namespace EzeSoft.XAPI
{
    /// <summary>
/// Configuration class for EMSXAPILibrary settings.
/// Loads configuration from file and environment variables, with environment variables taking precedence for security.
/// </summary>
public class EMSXAPIConfig
    {
        private int keepAliveTime;
        private int keepAliveTimeout;
        private string user;
        private string password;
        private string server;
        private string domain;
        private int port;
        private string locale;
        private bool ssl;
        private bool srp_login;
        private int maxRetryCount;
        private int retryDelayMS;
        private string route;
        private string account;

        /// <summary>
        /// Initializes a new instance of the EMSXAPIConfig class.
        /// </summary>
        /// <param name="cfgFileName">The configuration file name. If null or empty, defaults to "config.cfg".</param>
        /// <exception cref="FileNotFoundException">Thrown when the configuration file is not found.</exception>
        /// <exception cref="UnauthorizedAccessException">Thrown when access to the configuration file is denied.</exception>
        /// <exception cref="FormatException">Thrown when configuration values cannot be parsed.</exception>
        /// <exception cref="InvalidOperationException">Thrown when required configuration values are missing.</exception>
        public EMSXAPIConfig(string cfgFileName)
        {
            if (string.IsNullOrEmpty(cfgFileName))
            {
                cfgFileName = "config.cfg";
            }

            var properties = new Dictionary<string, string>();

            try
            {
                Console.WriteLine($"Loading config file: {cfgFileName}");
                Console.WriteLine($"Current directory: {Directory.GetCurrentDirectory()}");
                Console.WriteLine($"Full config path: {Path.GetFullPath(cfgFileName)}");

                using (var fileStream = new FileStream(cfgFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var reader = new StreamReader(fileStream);
                    string line;
                    while ((line = reader?.ReadLine()) != null)
                    {
                        var trimmedLine = line.Trim();
                        if (string.IsNullOrEmpty(trimmedLine) || trimmedLine.StartsWith("#") || !trimmedLine.Contains('='))
                            continue;

                        var parts = trimmedLine.Split('=');
                        if (parts.Length >= 2)
                        {
                            var key = parts[0].Trim();
                            var value = parts[1].Trim();
                            // Remove inline comments
                            var commentIndex = value.IndexOf('#');
                            if (commentIndex >= 0)
                            {
                                value = value.Substring(0, commentIndex).Trim();
                            }
                            properties[key] = value;
                        }
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                throw new FileNotFoundException($"Configuration file '{cfgFileName}' not found. Please ensure the file exists and contains valid XAPI configuration.", cfgFileName, ex);
            }
            catch (UnauthorizedAccessException ex)
            {
                throw new UnauthorizedAccessException($"Access denied to configuration file '{cfgFileName}'. Please check file permissions.", ex);
            }
            catch (IOException ex)
            {
                throw new IOException($"Error reading configuration file '{cfgFileName}': {ex.Message}", ex);
            }

            // Read and validate config items with proper error handling
            try
            {
                user = GetConfigValue(properties, "user", "XAPI_USER");
                password = GetConfigValue(properties, "password", "XAPI_PASSWORD");
                server = GetConfigValue(properties, "server", "XAPI_SERVER");
                domain = GetConfigValue(properties, "domain", "XAPI_DOMAIN");

                port = ParseIntValue(properties, "port", 9000, "XAPI_PORT");
                locale = GetConfigValue(properties, "locale", "XAPI_LOCALE");

                keepAliveTime = ParseIntValue(properties, "keepAliveTime", 300000, "XAPI_KEEP_ALIVE_TIME");
                keepAliveTimeout = ParseIntValue(properties, "keepAliveTimeout", 30000, "XAPI_KEEP_ALIVE_TIMEOUT");
                ssl = ParseBoolValue(properties, "ssl", false, "XAPI_SSL");
                srp_login = ParseBoolValue(properties, "srp_login", false, "XAPI_SRP_LOGIN");
                maxRetryCount = ParseIntValue(properties, "maxRetryCount", 3, "XAPI_MAX_RETRY_COUNT");
                retryDelayMS = ParseIntValue(properties, "retryDelayMS", 2000, "XAPI_RETRY_DELAY_MS");

                route = GetConfigValue(properties, "route", "XAPI_ROUTE", "ROUTE");
                account = GetConfigValue(properties, "account", "XAPI_ACCOUNT", "BANK;BRANCH;CUSTOMER;DEPOSIT");
                // Certificate file path configuration is no longer used; certificates should be installed at OS level.
            }
            catch (Exception ex) when (ex is not (FileNotFoundException or UnauthorizedAccessException or IOException))
            {
                throw new InvalidOperationException($"Error parsing configuration file '{cfgFileName}': {ex.Message}", ex);
            }

            // Validate required and formatted values
            Validate();
        }

        /// <summary>
        /// Gets a configuration value from either environment variables or properties file.
        /// Environment variables take precedence over file values for security.
        /// </summary>
        /// <param name="properties">The properties dictionary from the config file.</param>
        /// <param name="configKey">The key in the config file.</param>
        /// <param name="envVarName">The environment variable name.</param>
        /// <summary>
        /// Retrieves a configuration value with a hierarchical priority: environment variables (highest priority for security),
        /// configuration file properties, then default value. This approach allows secure overrides via environment variables
        /// while maintaining flexibility through config files.
        /// </summary>
        /// <param name="properties">The dictionary of properties loaded from the configuration file.</param>
        /// <param name="configKey">The key to look for in the configuration file.</param>
        /// <param name="envVarName">The environment variable name to check first (for security and containerization).</param>
        /// <param name="defaultValue">The default value if neither source provides a value.</param>
        /// <returns>The configuration value from the highest priority source available.</returns>
        /// <exception cref="InvalidOperationException">Thrown when a required value is missing from both sources and no default is provided.</exception>
        /// <summary>
        /// Retrieves a configuration value with a hierarchical lookup strategy: environment variable first (for security),
        /// then configuration file, then default value, or throws an exception if none are available.
        /// This approach prioritizes environment variables for sensitive configuration while allowing
        /// file-based configuration for development and default values for optional settings.
        /// </summary>
        /// <param name="properties">The dictionary of configuration properties loaded from file.</param>
        /// <param name="configKey">The key to look for in the configuration file.</param>
        /// <param name="envVarName">The environment variable name to check first.</param>
        /// <param name="defaultValue">Optional default value if neither environment variable nor config file has the value.</param>
        /// <returns>The configuration value from the highest priority source available.</returns>
        /// <exception cref="InvalidOperationException">Thrown when no value is found and no default is provided.</exception>
        /// <summary>
        /// Retrieves a configuration value with fallback hierarchy: environment variable -> config file -> default value -> exception.
        /// This method implements a secure configuration loading strategy where environment variables take precedence
        /// over config file values for security, followed by default values, with exceptions thrown for missing required values.
        /// </summary>
        /// <param name="properties">Dictionary containing config file properties.</param>
        /// <param name="configKey">The key to look for in the config file.</param>
        /// <param name="envVarName">The environment variable name to check first (more secure).</param>
        /// <param name="defaultValue">Optional default value if neither env var nor config file has the value.</param>
        /// <returns>The configuration value from the highest priority source available.</returns>
        private static string GetConfigValue(Dictionary<string, string> properties, string configKey, string envVarName, string defaultValue = null)
        {
            // Check environment variable first (more secure), then config file, then default
            return Environment.GetEnvironmentVariable(envVarName) ??
                   (properties.TryGetValue(configKey, out var fileValue) && !string.IsNullOrWhiteSpace(fileValue) ? fileValue : null) ??
                   defaultValue ??
                   throw new InvalidOperationException($"Required configuration value '{configKey}' is missing. Set it in the config file or environment variable '{envVarName}'.");
        }

        /// <summary>
        /// Gets a required string value from the properties dictionary.
        /// </summary>
        private static string GetRequiredValue(Dictionary<string, string> properties, string key)
        {
            if (!properties.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException($"Required configuration value '{key}' is missing or empty.");
            }
            return value;
        }

        /// <summary>
        /// Parses an integer value from the properties dictionary or environment variable with a default fallback.
        /// </summary>
        private static int ParseIntValue(Dictionary<string, string> properties, string configKey, int defaultValue, string envVarName)
        {
            // Check environment variable first
            var envValue = Environment.GetEnvironmentVariable(envVarName);
            if (!string.IsNullOrWhiteSpace(envValue))
            {
                if (int.TryParse(envValue.Trim(), out var envResult))
                {
                    return envResult;
                }
                throw new FormatException($"Environment variable '{envVarName}' must be a valid integer. Found: '{envValue}'");
            }

            // Fall back to config file
            if (!properties.TryGetValue(configKey, out var value) || string.IsNullOrWhiteSpace(value))
            {
                return defaultValue;
            }

            if (!int.TryParse(value.Trim(), out var result))
            {
                throw new FormatException($"Configuration value '{configKey}' must be a valid integer. Found: '{value}'");
            }

            return result;
        }

        /// <summary>
        /// Parses a boolean value from the properties dictionary or environment variable with a default fallback.
        /// </summary>
        private static bool ParseBoolValue(Dictionary<string, string> properties, string configKey, bool defaultValue, string envVarName)
        {
            // Check environment variable first
            var envValue = Environment.GetEnvironmentVariable(envVarName);
            if (!string.IsNullOrWhiteSpace(envValue))
            {
                if (bool.TryParse(envValue.Trim(), out var envResult))
                {
                    return envResult;
                }
                throw new FormatException($"Environment variable '{envVarName}' must be a valid boolean (true/false). Found: '{envValue}'");
            }

            // Fall back to config file
            if (!properties.TryGetValue(configKey, out var value) || string.IsNullOrWhiteSpace(value))
            {
                return defaultValue;
            }

            if (!bool.TryParse(value.Trim(), out var result))
            {
                throw new FormatException($"Configuration value '{configKey}' must be a valid boolean (true/false). Found: '{value}'");
            }

            return result;
        }

        public string User => user;

        public string Password => password;

        public string Server => server;

        public string Domain => domain;

        public int Port => port;

        public string Locale => locale;

        public int MaxMessageSize => 1024 * 1024 * 1024;

        public int KeepAliveTimeout => keepAliveTimeout;

        public int KeepAliveTime => keepAliveTime;

        public bool IsSslEnabled => ssl;

        public bool Srp_login => srp_login;

        public int MaxRetryCount => maxRetryCount;

        public int RetryDelayMS => retryDelayMS;
        public string Route => route;

        public string Account => account;

        // Certificate file path removed: rely on OS-installed certificates

        /// <summary>
        /// Validates that required configuration values are present and correctly formatted.
        /// Throws descriptive exceptions for invalid configuration to fail fast.
        /// </summary>
        private void Validate()
        {
            // Required fields
            if (string.IsNullOrWhiteSpace(user))
                throw new InvalidOperationException("Configuration 'user' is required and cannot be empty.");
            if (string.IsNullOrWhiteSpace(password))
                throw new InvalidOperationException("Configuration 'password' is required and cannot be empty.");
            if (string.IsNullOrWhiteSpace(server))
                throw new InvalidOperationException("Configuration 'server' is required and cannot be empty.");
            if (string.IsNullOrWhiteSpace(domain))
                throw new InvalidOperationException("Configuration 'domain' is required and cannot be empty.");
            if (string.IsNullOrWhiteSpace(locale))
                throw new InvalidOperationException("Configuration 'locale' is required and cannot be empty.");

            // Numeric ranges
            if (port <= 0 || port > 65535)
                throw new InvalidOperationException($"Configuration 'port' must be within 1-65535. Found: {port}.");
            if (keepAliveTime <= 0)
                throw new InvalidOperationException($"Configuration 'keepAliveTime' must be a positive integer (milliseconds). Found: {keepAliveTime}.");
            if (keepAliveTimeout <= 0)
                throw new InvalidOperationException($"Configuration 'keepAliveTimeout' must be a positive integer (milliseconds). Found: {keepAliveTimeout}.");
            if (maxRetryCount < 0)
                throw new InvalidOperationException($"Configuration 'maxRetryCount' cannot be negative. Found: {maxRetryCount}.");
            if (retryDelayMS < 0)
                throw new InvalidOperationException($"Configuration 'retryDelayMS' cannot be negative. Found: {retryDelayMS}.");

            // SSL certificates are expected to be installed at OS level; no file validation required.
        }
    }
}