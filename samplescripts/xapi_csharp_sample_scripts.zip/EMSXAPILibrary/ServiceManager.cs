using System;
using Grpc.Net.Client;
using ezesoft.xapi.generated;

namespace EzeSoft.XAPI
{
    /// <summary>
    /// Manages gRPC service stubs for the EMS XAPI library.
    /// Provides access to utility, market data, and order services.
    /// </summary>
    public class ServiceManager : IDisposable
    {
        private readonly GrpcChannel channel;
        private readonly Logger logger;

        private UtilityServices.UtilityServicesClient? _utilitySvcStub;
        private MarketDataService.MarketDataServiceClient? _marketDataSvcStub;
        private SubmitOrderService.SubmitOrderServiceClient? _orderServiceStub;

        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the ServiceManager class.
        /// </summary>
        /// <param name="channel">The gRPC channel to use for service communication.</param>
        /// <param name="logger">The logger for recording service operations.</param>
        public ServiceManager(GrpcChannel channel, Logger logger)
        {
            this.channel = channel ?? throw new ArgumentNullException(nameof(channel));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Gets the utility services client, initializing it if necessary.
        /// </summary>
        public UtilityServices.UtilityServicesClient UtilityClient
        {
            get
            {
                if (_utilitySvcStub == null)
                {
                    _utilitySvcStub = new UtilityServices.UtilityServicesClient(channel);
                    logger.LogMessage("Utility services client initialized");
                }
                return _utilitySvcStub;
            }
        }

        /// <summary>
        /// Gets the market data services client, initializing it if necessary.
        /// </summary>
        public MarketDataService.MarketDataServiceClient MarketDataClient
        {
            get
            {
                if (_marketDataSvcStub == null)
                {
                    _marketDataSvcStub = new MarketDataService.MarketDataServiceClient(channel);
                    logger.LogMessage("Market data services client initialized");
                }
                return _marketDataSvcStub;
            }
        }

        /// <summary>
        /// Gets the order services client, initializing it if necessary.
        /// </summary>
        public SubmitOrderService.SubmitOrderServiceClient OrderClient
        {
            get
            {
                if (_orderServiceStub == null)
                {
                    _orderServiceStub = new SubmitOrderService.SubmitOrderServiceClient(channel);
                    logger.LogMessage("Order services client initialized");
                }
                return _orderServiceStub;
            }
        }

        /// <summary>
        /// Initializes all service stubs.
        /// </summary>
        public void InitializeServices()
        {
            // Access properties to trigger initialization
            var utility = UtilityClient;
            var marketData = MarketDataClient;
            var order = OrderClient;

            logger.LogMessage("All service clients initialized");
        }

        /// <summary>
        /// Disposes of the service manager and releases resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes of the service manager resources.
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Dispose service clients to release any resources
                    _utilitySvcStub = null;
                    _marketDataSvcStub = null;
                    _orderServiceStub = null;
                    logger.LogMessage("Service manager disposed");
                }
                disposed = true;
            }
        }
    }
}