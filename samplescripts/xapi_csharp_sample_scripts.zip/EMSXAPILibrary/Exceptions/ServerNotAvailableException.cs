using System;


namespace EzeSoft.XAPI.Exceptions
{
    public class ServerNotAvailableException : Exception
    {
        public ServerNotAvailableException() : base("Server not responding")
        {
        }

        public ServerNotAvailableException(string message) : base(message)
        {
        }

        public ServerNotAvailableException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
