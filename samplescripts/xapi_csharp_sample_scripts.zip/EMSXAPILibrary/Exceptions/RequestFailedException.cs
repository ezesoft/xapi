using System;


namespace EzeSoft.XAPI.Exceptions
{
    public class RequestFailedException : Exception
    {
        public RequestFailedException() : base("Request failed")
        {
        }

        public RequestFailedException(string message) : base(message)
        {
        }

        public RequestFailedException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
