using System;

namespace EzeSoft.XAPI.Exceptions
{
    public class SessionNotFoundException : Exception
    {
        public SessionNotFoundException() : base("Session not found.")
        {
        }

        public SessionNotFoundException(string message) : base(message)
        {
        }
    }
}
