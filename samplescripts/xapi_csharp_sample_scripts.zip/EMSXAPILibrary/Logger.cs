using System;
using System.IO;
using System.Linq;

namespace EzeSoft.XAPI
{
    /// <summary>
    /// Minimal logger interface to enable future adapter-based logging (e.g., Serilog/NLog)
    /// without breaking existing consumers of Logger.
    /// </summary>
    public interface IEMSLogger
    {
        void LogMessage(string message);
    }
    /// <summary>
    /// Custom logger implementation used instead of established libraries like Serilog or NLog to maintain
    /// minimal dependencies and provide specific functionality for timestamped log files with automatic
    /// rotation and cleanup, tailored to the EMS XAPI client's logging requirements. This approach avoids
    /// adding external dependencies while providing the essential logging features needed for order tracking
    /// and debugging in a financial trading environment.
    /// </summary>
    public class Logger : IDisposable, IEMSLogger
    {
            private readonly Action<string>? externalSink;
        private readonly string logDirectory;
        private readonly string baseLogFileName;
        private readonly long maxFileSizeBytes = 10 * 1024 * 1024; // 10MB default
        private readonly int maxLogFiles = 30; // Keep 30 days of logs
            private bool fileLoggingEnabled = true;
        private string currentLogFilePath;
        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the Logger class.
        /// </summary>
        public Logger(Action<string>? externalSink = null)
        {
            this.externalSink = externalSink;
            logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
            baseLogFileName = "order_log";

            // Ensure log directory exists (gracefully degrade if not writable)
            try
            {
                Directory.CreateDirectory(logDirectory);
            }
            catch (Exception ex)
            {
                fileLoggingEnabled = false;
                Console.WriteLine($"Logger: File logging disabled (cannot create '{logDirectory}'): {ex.Message}");
            }

            // Clean up old log files
            if (fileLoggingEnabled)
            {
                CleanupOldLogFiles();
            }

            // Set initial log file
            currentLogFilePath = fileLoggingEnabled ? GetCurrentLogFilePath() : string.Empty;
        }

        /// <summary>
        /// Logs a message to the current log file, rotating files as needed.
        /// </summary>
        /// <param name="message">The message to log.</param>
        public void LogMessage(string message)
        {
            try
            {
                string logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}: {message}";

                // Check if rotation is needed
                if (fileLoggingEnabled && ShouldRotateLog())
                {
                    RotateLogFile();
                }

                // Write to current log file
                if (fileLoggingEnabled && !string.IsNullOrWhiteSpace(currentLogFilePath))
                {
                    try
                    {
                        using (StreamWriter writer = new StreamWriter(currentLogFilePath, true))
                        {
                            writer.WriteLine(logEntry);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Disable file logging on persistent write failures
                        fileLoggingEnabled = false;
                        Console.WriteLine($"Logger: File logging disabled (write failure): {ex.Message}");
                    }
                }

                // Write to console
                Console.WriteLine(logEntry);

                // Forward to external sink if provided (e.g., Serilog adapter)
                externalSink?.Invoke(logEntry);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to log message: " + ex.Message);
            }
        }

        /// <summary>
        /// Determines if the current log file should be rotated based on size.
        /// </summary>
        /// <returns>True if rotation is needed, false otherwise.</returns>
        private bool ShouldRotateLog()
        {
            try
            {
                var fileInfo = new FileInfo(currentLogFilePath);
                return fileInfo.Exists && fileInfo.Length >= maxFileSizeBytes;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Rotates the current log file by creating a new timestamped file.
        /// </summary>
        private void RotateLogFile()
        {
            try
            {
                // Create new log file path with timestamp
                currentLogFilePath = fileLoggingEnabled ? GetCurrentLogFilePath() : string.Empty;

                // Clean up old log files after rotation
                if (fileLoggingEnabled)
                {
                    CleanupOldLogFiles();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to rotate log file: {ex.Message}");
            }
        }

        /// <summary>
        /// Gets the path for the current log file.
        /// </summary>
        /// <returns>The full path to the current log file.</returns>
        private string GetCurrentLogFilePath()
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            string fileName = $"{baseLogFileName}_{timestamp}.txt";
            return Path.Combine(logDirectory, fileName);
        }

        /// <summary>
        /// Cleans up old log files, keeping only the most recent ones based on maxLogFiles.
        /// </summary>
        private void CleanupOldLogFiles()
        {
            try
            {
                var logFiles = Directory.GetFiles(logDirectory, $"{baseLogFileName}_*.txt")
                    .Select(f => new FileInfo(f))
                    .OrderByDescending(f => f.CreationTime)
                    .ToList();

                // Keep only the most recent files
                if (logFiles.Count > maxLogFiles)
                {
                    var filesToDelete = logFiles.Skip(maxLogFiles);
                    foreach (var file in filesToDelete)
                    {
                        try
                        {
                            file.Delete();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Failed to delete old log file {file.Name}: {ex.Message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to cleanup old log files: {ex.Message}");
            }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources
                    // Note: No managed resources to dispose in this class
                }

                // Dispose unmanaged resources
                // Note: No unmanaged resources to dispose in this class

                disposed = true;
            }
        }

        /// <summary>
        /// Finalizes an instance of the Logger class.
        /// </summary>
        ~Logger()
        {
            Dispose(false);
        }
    }
}
