using System;
using System.Threading;
using System.Threading.Tasks;
using ezesoft.xapi.generated;

namespace EzeSoft.XAPI
{
    /// <summary>
    /// Manages heartbeat operations to maintain connection with the XAPI server.
    /// Uses streaming heartbeat subscription for continuous connection monitoring.
    /// </summary>
    public class HeartbeatManager : IDisposable
    {
        private readonly EMSXAPIConfig config;
        private readonly Logger logger;
        private readonly UtilityServices.UtilityServicesClient utilityClient;
        private readonly AuthenticationManager authManager;

        private Timer? heartbeatTimer;
        private Task? heartbeatTask;
        private CancellationTokenSource? cancellationTokenSource;
        private bool isRunning = false;
        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the HeartbeatManager class.
        /// </summary>
        /// <param name="config">The configuration containing heartbeat settings.</param>
        /// <param name="logger">The logger for recording heartbeat operations.</param>
        /// <param name="utilityClient">The utility services gRPC client.</param>
        /// <param name="authManager">The authentication manager for user token access.</param>
        public HeartbeatManager(
            EMSXAPIConfig config,
            Logger logger,
            UtilityServices.UtilityServicesClient utilityClient,
            AuthenticationManager authManager)
        {
            this.config = config ?? throw new ArgumentNullException(nameof(config));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.utilityClient = utilityClient ?? throw new ArgumentNullException(nameof(utilityClient));
            this.authManager = authManager ?? throw new ArgumentNullException(nameof(authManager));
        }

        /// <summary>
        /// Starts the heartbeat timer to send periodic heartbeat messages.
        /// Uses System.Threading.Timer for better resource management and cancellation support.
        /// </summary>
        public void StartHeartbeat()
        {
            if (isRunning)
            {
                logger.LogMessage("Heartbeat already running");
                return;
            }

            isRunning = true;
            cancellationTokenSource = new CancellationTokenSource();

            // Use Timer instead of Thread for better control and resource management
            heartbeatTimer = new Timer(
                callback: _ =>
                {
                    try
                    {
                        SendHeartbeat();
                    }
                    catch (Exception ex)
                    {
                        logger.LogMessage($"Unhandled exception in heartbeat timer: {ex.Message}");
                        // Don't rethrow to prevent timer from crashing the process
                    }
                },
                state: null,
                dueTime: 0, // Start immediately
                period: config.KeepAliveTime); // Repeat every KeepAliveTime milliseconds

            logger.LogMessage("Heartbeat timer started");
        }

        /// <summary>
        /// Stops the heartbeat timer and cancels any ongoing operations.
        /// </summary>
        public void StopHeartbeat()
        {
            if (!isRunning)
            {
                return;
            }

            isRunning = false;

            // Cancel the timer
            heartbeatTimer?.Dispose();
            heartbeatTimer = null;

            // Cancel any ongoing operations
            cancellationTokenSource?.Cancel();
            cancellationTokenSource?.Dispose();
            cancellationTokenSource = null;

            // Allow the running heartbeat task to finish gracefully
            var task = heartbeatTask;
            heartbeatTask = null;
            if (task != null)
            {
                try
                {
                    // Avoid long blocking; wait briefly for cleanup
                    task.Wait(TimeSpan.FromSeconds(3));
                }
                catch
                {
                    // Swallow exceptions during shutdown
                }
            }

            logger.LogMessage("Heartbeat timer stopped");
        }



        /// <summary>
        /// Sends a single heartbeat message to the server using streaming subscription.
        /// </summary>
        private void SendHeartbeat()
        {
            try
            {
                // Check if we should still be running and if user is logged in
                if (!isRunning || !authManager.IsLoggedIn || authManager.UserToken == null || string.IsNullOrWhiteSpace(authManager.UserToken))
                {
                    return;
                }

                // Subscribe to heartbeat stream to maintain connection
                var heartbeatRequest = new ezesoft.xapi.generated.SubscribeHeartBeatRequest
                {
                    UserToken = authManager.UserToken,
                    TimeoutInSeconds = config.KeepAliveTime / 1000 // Convert milliseconds to seconds
                };

                // Start the heartbeat subscription in a background task (single instance)
                if (heartbeatTask != null && !heartbeatTask.IsCompleted)
                {
                    // Existing heartbeat stream still active
                    return;
                }

                heartbeatTask = Task.Run(async () =>
                {
                    try
                    {
                        using var call = utilityClient.SubscribeHeartBeat(heartbeatRequest);
                        while (isRunning && await call.ResponseStream.MoveNext(cancellationTokenSource?.Token ?? CancellationToken.None))
                        {
                            var response = call.ResponseStream.Current;
                            if (response.Status != ezesoft.xapi.generated.SubscribeHeartBeatResponse.Types.HeartBeatStatus.Live)
                            {
                                logger.LogMessage($"Heartbeat status changed: {response.Status}");
                                if (response.Acknowledgement != null && !string.IsNullOrEmpty(response.Acknowledgement.ServerResponse))
                                {
                                    logger.LogMessage($"Heartbeat acknowledgement: {response.Acknowledgement.ServerResponse}");
                                }
                            }
                            else
                            {
                                logger.LogMessage("Heartbeat: Connection is LIVE");
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        // Expected when stopping heartbeat
                        logger.LogMessage("Heartbeat stream cancelled");
                    }
                    catch (Exception ex)
                    {
                        logger.LogMessage($"Heartbeat stream error: {ex.Message}");
                    }
                });

                logger.LogMessage("Heartbeat subscription initiated");
            }
            catch (Exception ex)
            {
                logger.LogMessage($"Failed to initiate heartbeat subscription: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Disposes of the heartbeat manager and releases resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes of the heartbeat manager resources.
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    StopHeartbeat();
                }
                disposed = true;
            }
        }
    }
}