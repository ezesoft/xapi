using System;
using System.IO;
using System.Net.Http;
using Grpc.Core;
using Grpc.Net.Client;

namespace EzeSoft.XAPI
{
    /// <summary>
    /// Manages gRPC channel creation and lifecycle for the EMS XAPI library.
    /// Handles SSL configuration and channel options.
    /// </summary>
    public class ChannelManager : IDisposable
    {
        private readonly EMSXAPIConfig config;
        private readonly Logger logger;
        private GrpcChannel? _channel;
        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the ChannelManager class.
        /// </summary>
        /// <param name="config">The configuration containing connection settings.</param>
        /// <param name="logger">The logger for recording channel operations.</param>
        public ChannelManager(EMSXAPIConfig config, Logger logger)
        {
            this.config = config ?? throw new ArgumentNullException(nameof(config));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Gets the current gRPC channel, creating it if necessary.
        /// </summary>
        public GrpcChannel Channel
        {
            get
            {
                if (_channel == null)
                {
                    _channel = CreateChannel(config.Server, config.Port);
                }
                return _channel;
            }
        }

        /// <summary>
        /// Creates a new gRPC channel with the configured settings.
        /// </summary>
        /// <returns>A configured GrpcChannel instance.</returns>
        /// <exception cref="ChannelClosedException">Thrown when channel creation fails.</exception>
        private GrpcChannel CreateChannel(string hostName, int port)
        {
            GrpcChannelOptions channelOptions;
            string address = config.IsSslEnabled ? "https://" : "http://";

            // Configure an explicit HTTP handler and client to control
            // certificate validation and proxy settings if needed.
            var handler = new System.Net.Http.SocketsHttpHandler
            {
                EnableMultipleHttp2Connections = true,
                PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
                ConnectTimeout = TimeSpan.FromMilliseconds(config.KeepAliveTimeout)
            };

            // Using platform defaults for TLS certificate validation; no file path configuration.

            channelOptions = new GrpcChannelOptions
            {
                MaxReceiveMessageSize = config.MaxMessageSize,
                Credentials = config.IsSslEnabled ? Grpc.Core.ChannelCredentials.SecureSsl : Grpc.Core.ChannelCredentials.Insecure,
                HttpHandler = handler
            };

            logger.LogMessage("Create Channel");
            try
            {
                return GrpcChannel.ForAddress($"{address}{hostName}:{port}", channelOptions);
            }
            catch (System.Net.Http.HttpRequestException ex)
            {
                var msg = $"Network error creating gRPC channel to '{address}{hostName}:{port}': {ex.Message}";
                logger.LogMessage(msg);
                throw new ChannelClosedException(msg, ex);
            }
            catch (System.Net.Sockets.SocketException ex)
            {
                var msg = $"Socket error creating gRPC channel to '{address}{hostName}:{port}': {ex.Message}";
                logger.LogMessage(msg);
                throw new ChannelClosedException(msg, ex);
            }
            catch (Exception ex)
            {
                var msg = $"Failed to create gRPC channel to '{address}{hostName}:{port}': {ex.Message}";
                logger.LogMessage(msg);
                throw new ChannelClosedException(msg, ex);
            }
        }

        /// <summary>
        /// Closes the current channel if it exists.
        /// </summary>
        public void CloseChannel()
        {
            if (_channel != null)
            {
                logger.LogMessage("Closing gRPC channel...");
                _channel.Dispose();
                _channel = null;
                logger.LogMessage("gRPC channel closed");
            }
        }

        /// <summary>
        /// Disposes of the channel manager and releases resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes of the channel manager resources.
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    CloseChannel();
                }
                disposed = true;
            }
        }
    }
}
