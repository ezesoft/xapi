﻿using System;


namespace EzeSoft.XAPI
{
    public class StreamingAlreadyExistsException : Exception
    {
        public StreamingAlreadyExistsException() : base("Streaming already exists")
        {
        }

        public StreamingAlreadyExistsException(string message) : base(message)
        {
        }

        public StreamingAlreadyExistsException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
