﻿using System;


namespace EzeSoft.XAPI
{
    public class LoginFailedException : Exception
    {
        public LoginFailedException() : base("Login failed")
        {
        }

        public LoginFailedException(string message) : base(message)
        {
        }

        public LoginFailedException(string message, Exception innerEx) : base(message, innerEx)
        {
        }
    }
}
