﻿using System;

namespace CSharp_XAPI_Client
{
    public class SessionNotFoundException : Exception
    {
        public SessionNotFoundException() : base("Session not found.")
        {
        }

        public SessionNotFoundException(string message) : base(message)
        {
        }
    }
}
