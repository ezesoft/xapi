﻿using System;


namespace CSharp_XAPI_Client
{
    public class ErrorHandler
    {
        public void OnError(Exception ex, EMSXAPILibrary lib)
        {
            Console.WriteLine("===error in library===");
            Console.WriteLine(ex.ToString());
            if (lib != null)
            {
                lib.SuspendHeartbeatThread();
                lib.Logout();
                lib.CloseChannel();
            }
        }
}
}
