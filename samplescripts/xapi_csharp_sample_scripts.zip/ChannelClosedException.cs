﻿using System;


namespace CSharp_XAPI_Client
{
    public class ChannelClosedException : Exception
    {
        public ChannelClosedException() : base("Channel might be closed or unresponsive")
        {
        }

        public ChannelClosedException(string message) : base(message)
        {
        }
    }
}
