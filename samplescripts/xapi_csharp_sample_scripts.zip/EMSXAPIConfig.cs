﻿using System;

namespace CSharp_XAPI_Client
{
    public class EMSXAPIConfig
    {
        private int keepAliveTime;
        private int keepAliveTimeout;
        private string user;
        private string password;
        private string server;
        private string domain;
        private int port;
        private string locale;
        private bool ssl;
        private bool srp_login;
        private int maxRetryCount;
        private int retryDelayMS;
        private string route;
        private string account;

        public EMSXAPIConfig(string cfgFileName)
        {
            if (string.IsNullOrEmpty(cfgFileName))
            {
                cfgFileName = "config.cfg";
            }

            var properties = new Dictionary<string, string>();
            try
            {
                using (var fileStream = new FileStream(cfgFileName, FileMode.Open))
                {
                    var reader = new StreamReader(fileStream);
                    string line;
                    while ((line = reader?.ReadLine()) != null)
                    {
                        var parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            var key = parts[0].Trim();
                            var value = parts[1].Trim();
                            properties[key] = value;
                        }
                    }
                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }

            // Read config items
            user = properties["user"];
            password = properties["password"];
            server = properties["server"];
            domain = properties["domain"];
            port = int.Parse(properties["port"].Trim());
            locale = properties["locale"];
            keepAliveTime = int.Parse(properties["keepAliveTime"].Trim());
            keepAliveTimeout = int.Parse(properties["keepAliveTimeout"].Trim());
            ssl = bool.Parse(properties["ssl"]);
            srp_login = bool.Parse(properties["srp_login"]);
            maxRetryCount = int.Parse(properties["maxRetryCount"].Trim());
            retryDelayMS = int.Parse(properties["retryDelayMS"].Trim());
            route = properties.GetValueOrDefault("route");
            account = properties.GetValueOrDefault("account");
        }

        public string User => user;

        public string Password => password;

        public string Server => server;

        public string Domain => domain;

        public int Port => port;

        public string Locale => locale;

        public int MaxMessageSize => 1024 * 1024 * 1024;

        public int KeepAliveTimeout => keepAliveTimeout;

        public int KeepAliveTime => keepAliveTime;

        public bool IsSslEnabled => ssl;

        public bool Srp_login => srp_login;

        public int MaxRetryCount => maxRetryCount;

        public int RetryDelayMS => retryDelayMS;
        public string Route => route;

        public string Account => account;
    }
}