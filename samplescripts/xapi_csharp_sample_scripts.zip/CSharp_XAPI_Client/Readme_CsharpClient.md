# CSharp_XAPI_Client Solution

<!-- This documentation is manually maintained rather than auto-generated using tools like Swagger or XML comments
because it provides comprehensive usage examples, architectural explanations, integration guidance, and practical
code samples that go beyond simple API documentation. The manual approach allows for better narrative flow,
contextual explanations, and real-world integration patterns that are more valuable for developers working
with the XAPI platform in financial trading environments. -->

## Overview

The CSharp_XAPI_Client solution is a comprehensive sample demonstrating how to interact with the SS&C Eze XAPI platform using C# and .NET 8. The solution consists of three projects that provide examples for authentication, market data streaming, order submission, and more, using gRPC and Protocol Buffers.

## Solution Structure

The solution contains three projects:

### 1. EMSXAPILibrary
**Shared library providing core XAPI connectivity and authentication**
- `EMSXAPILibrary.cs`: API wrapper and connection management
- `EMSXAPIConfig.cs`: Configuration file reader and settings management
- `Logger.cs`, `ErrorHandler.cs`: Centralized logging and error handling
- `Protos/`: Protocol Buffer definitions (market_data.proto, order.proto, utilities.proto)
- Exception classes: `LoginFailedException`, `NetworkFailedException`, `RequestFailedException`, etc.

### 2. CSharp_XAPI_Client
**Console application with example implementations**
- `App.cs`: Main entry point demonstrating authentication, heartbeat, and example launcher
- `ExampleSubscribeLevel1Ticks.cs`: Server-side streaming for Level 1 market data
- `ExampleGetTodaysActivity.cs`: Reference data query example
- `ExampleSubscribeOrdInfo.cs`: Order info subscription example
- `ExampleSubmitSingleOrder.cs`: Single order submission example
- `ExampleSubmitOrderRegression.cs`: Regression testing for order submission

### 3. StreamingClientApp (New - December 2025)
**Dedicated interactive streaming client with modular architecture**
- `Program.cs`: Interactive command-line application for streaming market data
- `Core/StreamingClient.cs`: Bidirectional streaming client with comprehensive error handling
- `Handlers/RequestHandler.cs`: Manages subscription requests (add, remove, change)
- `Handlers/StatusManager.cs`: Status display and monitoring operations
- `Handlers/SymbolManager.cs`: User input handling for symbol management
- `Utils/StreamingLogger.cs`: Enhanced file and console logging
- `Utils/DataFormatter.cs`: Market data formatting utilities
- **Features**: Real-time Level 1, Level 2, and Tick data with interactive subscription management

## Features

- **Authentication**: Login/logout and heartbeat management with streaming heartbeat subscription
- **Market Data**:
  - Level 1, Level 2, and Tick data streaming (unary and bidirectional)
  - Dynamic symbol subscription management
  - Real-time statistics and formatted output
  - Interactive streaming client with command-line interface
- **Order Management**:
  - Single and regression order submission
  - Order info subscription
- **Reference Data**:
  - Get today's activity
  - Security and symbol reference queries
- **Error Handling & Logging**: Centralized error handler and logger with file-based logging

## Getting Started

### Prerequisites
- .NET 8 SDK
- Access to SS&C Eze XAPI server
- Valid configuration file (`EMSXAPILibrary/config.cfg`) with credentials and server details

### Build & Run

#### Building the Solution
1. Restore NuGet packages:
   ```sh
   dotnet restore CSharp_XAPI_Client.sln
   ```
2. Build the entire solution:
   ```sh
   dotnet build CSharp_XAPI_Client.sln
   ```

#### Running the Example Client
Run the traditional example client with all demonstrations:
```sh
cd CSharp_XAPI_Client
dotnet run
```

#### Running the Interactive Streaming Client
Run the new interactive streaming client for real-time market data:
```sh
cd StreamingClientApp
dotnet run
```

The streaming client provides an interactive menu:
1. Add symbols to stream
2. Remove symbols from stream
3. Change subscription level
4. Check status
5. Exit

Streaming data is logged to timestamped files in the `logs/` directory.

### Configuration
- **Master Configuration**: All projects use the shared `EMSXAPILibrary/config.cfg` file
- **Automatic Copying**: Configuration is automatically copied to each project's build output directory
- Update the following fields in `EMSXAPILibrary/config.cfg`:
  - `user`, `password`, `domain`: Your XAPI credentials
  - `server`, `port`: XAPI server address and port
  - `ssl`: Enable/disable SSL (true/false)
- Configuration files are automatically copied to the build output directory

## Detailed Project Structure

### EMSXAPILibrary Project
```
EMSXAPILibrary/
├── EMSXAPILibrary.cs         # Core API wrapper and connection management
├── EMSXAPIConfig.cs           # Configuration file parser
├── Logger.cs                  # Centralized logging utility
├── ErrorHandler.cs            # Error handling and exception management
├── SensitiveMask.cs           # Credential masking for security
├── HeartbeatManager.cs        # Streaming heartbeat subscription manager
├── ChannelManager.cs          # gRPC channel creation with SSL certificate support
├── AuthenticationManager.cs   # SRP authentication handling
├── ServiceManager.cs          # gRPC service client management
├── Exception Classes:
│   ├── ChannelClosedException.cs
│   ├── LoginFailedException.cs
│   ├── NetworkFailedException.cs
│   ├── RequestFailedException.cs
│   ├── ServerNotAvailableException.cs
│   ├── SessionNotFoundException.cs
│   └── StreamingAlreadyExistsException.cs
└── Protos/
    ├── market_data.proto      # Market data service definitions
    ├── order.proto            # Order service definitions
    └── utilities.proto        # Utility service definitions (includes heartbeat)
```

### CSharp_XAPI_Client Project
```
CSharp_XAPI_Client/
├── App.cs                               # Main application entry point
├── ExampleSubscribeLevel1Ticks.cs       # Server-side streaming example
├── ExampleGetTodaysActivity.cs          # Reference data queries
├── ExampleSubscribeOrdInfo.cs           # Order info subscriptions
├── ExampleSubmitSingleOrder.cs          # Single order submission
├── ExampleSubmitOrderRegression.cs      # Order submission regression tests
├── StreamMarketDataExamples_README.md   # Streaming API documentation
└── config.cfg                           # Configuration (copied from EMSXAPILibrary)
```

### StreamingClientApp Project
```
StreamingClientApp/
├── Program.cs                     # Interactive application entry point
├── Core/
│   └── StreamingClient.cs         # Bidirectional streaming client
├── Handlers/
│   ├── RequestHandler.cs          # Subscription request management
│   ├── StatusManager.cs           # Status display and monitoring
│   └── SymbolManager.cs           # User input and symbol management
├── Utils/
│   ├── StreamingLogger.cs         # File and console logging
│   └── DataFormatter.cs           # Market data formatting
├── README.md                      # Streaming client documentation
└── config.cfg                     # Configuration (copied from EMSXAPILibrary)
```

## Usage Patterns

### Using EMSXAPILibrary (Shared Library)
```csharp
// Initialize and authenticate
EMSXAPILibrary.Create("config.cfg");
var lib = EMSXAPILibrary.Get();
lib.Login();

// Access service stubs
var marketDataStub = lib.getMarketDataServiceStub;
var orderStub = lib.getOrderServiceStub;
var utilityStub = lib.getUtilityServiceStub;
```

### Traditional Example Client (CSharp_XAPI_Client)
- **Authentication**: Use `EMSXAPILibrary.Create()` and `Login()` before making API calls
- **Heartbeat Management**: Automatic streaming heartbeat subscription maintains connection. Use `StartListeningHeartbeat()` to begin and `SuspendHeartbeatThread()` to stop
- **Streaming**: Use gRPC streaming APIs for real-time data. Always complete request streams and handle responses asynchronously
- **Order Submission**: Use provided examples for single and regression order flows
- **Error Handling**: Centralized via `ErrorHandler` and `Logger` classes

### Interactive Streaming Client (StreamingClientApp)
The StreamingClientApp provides a modular, interactive approach to market data streaming:

1. **Start the application**: `dotnet run` from StreamingClientApp directory
2. **Choose operations from the menu**:
   - Add symbols with market data level (LEVEL1, LEVEL2, or TICK)
   - Remove symbols from streaming
   - Change subscription levels for existing symbols
   - Check current status and active subscriptions
3. **Monitor data**: All market data responses are logged to timestamped files in `logs/`
4. **Architecture**:
   - `StreamingClient`: Core bidirectional streaming with error handling
   - `RequestHandler`: Manages add/remove/change subscription requests
   - `SymbolManager`: Handles user input for symbol operations
   - `StatusManager`: Displays connection and subscription status
   - `StreamingLogger`: File-based logging with console warnings only

## API Documentation

- **StreamMarketDataExamples_README.md**: Detailed documentation for streaming APIs, request/response types, and sample output
- **StreamingClientApp/README.md**: Documentation specific to the interactive streaming client architecture and usage

## Troubleshooting

### Common Issues

**Configuration Problems**
- Ensure your `EMSXAPILibrary/config.cfg` is correct and accessible
- Verify credentials (user, password, domain) are valid
- Check server and port settings match your XAPI environment

**Connection Issues**
- Check network connectivity to the XAPI server
- Verify SSL settings match server requirements
- Review firewall rules for gRPC ports

**Build/Package Issues**
- Ensure all NuGet packages are restored: `dotnet restore`
- For protobuf/gRPC issues, clean and rebuild: `dotnet clean && dotnet build`
- Verify .NET 8 SDK is installed: `dotnet --version`

**Streaming Client Issues**
- Check logs in `StreamingClientApp/logs/` directory for detailed error messages
- Ensure EMSXAPILibrary login succeeds before starting streaming
- Verify market data service stub is initialized correctly

**Debugging Tips**
- Enable detailed logging in `EMSXAPILibrary/config.cfg`
- Use console output and log files to track API calls
- Check for null reference exceptions in streaming responses
- Review gRPC status codes for connection errors

## Recent Updates

### December 2025 - SSL Certificate & Heartbeat Implementation
- **SSL Certificate Authentication**: Implemented HttpClient-based SSL certificate handling using X509Certificate2 instead of unsupported GrpcChannel SslCredentials
- **Heartbeat Streaming**: Replaced stub heartbeat implementation with proper streaming subscription to SubscribeHeartBeat service
- **Manager Architecture**: Refactored EMSXAPILibrary into specialized managers (HeartbeatManager, ChannelManager, AuthenticationManager, ServiceManager)
- **Certificate File Deployment**: Updated project configurations to properly copy certificate files (roots_qa.pem) to output directories
- **Legacy API Compatibility**: Maintained backward compatibility with existing StartListeningHeartbeat() and SuspendHeartbeatThread() methods

### December 2025 - StreamingClientApp Addition
- **New Project**: Added dedicated interactive streaming client application
- **Modular Architecture**: Separated concerns into Core, Handlers, and Utils components
- **Enhanced Logging**: File-based logging with timestamped log files
- **Improved Error Handling**: Comprehensive null checks and exception handling
- **XML Documentation**: Complete documentation for all public APIs
- **Interactive Interface**: Command-line menu for dynamic subscription management

## License

This sample is provided for demonstration and integration purposes. Please refer to your SS&C Eze license agreement for usage terms.

## Support

For questions or support, contact SS&C Eze technical support or your account representative.

---

**Last Updated**: December 3, 2025  
**Solution Version**: 3.44.0.2  
**.NET Version**: 8.0
