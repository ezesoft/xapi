using ezesoft.xapi.generated;
using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EzeSoft.XAPI;

namespace CSharp_XAPI_Client
{
    class ExampleSubmitSingleOrder
    {
        public ExampleSubmitSingleOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubmitSingleOrderRequest req = new SubmitSingleOrderRequest
                { 
                    UserToken = EMSXAPILibrary.Get().UserToken,
                    Symbol = "SYMBOL",
                    Side = "BUY/SELL",
                    Quantity = 100,
                    Route = "ROUTE",
                    Staged = false,
                    ClaimRequire = false,
                    Account = "BANK;BRANCH;CUSTOMER;DEPOSIT"
                };

                SubmitSingleOrderResponse response = lib.OrderClient.SubmitSingleOrder(req);

                Console.WriteLine("------------------------------");
                Console.WriteLine(response.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }

    }
}
