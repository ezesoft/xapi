using ezesoft.xapi.generated;
using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EzeSoft.XAPI;

namespace CSharp_XAPI_Client
{
    class ExampleSubscribeOrdInfo
    {
        private readonly Logger logger;
        public ExampleSubscribeOrdInfo() { logger = new Logger(); }

        public async Task Run()
        {

            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();
                SubscribeOrderInfoRequest req = new SubscribeOrderInfoRequest()
                {
                    UserToken = EMSXAPILibrary.Get().UserToken
                };

                var responseIt = EMSXAPILibrary.Get().OrderClient.SubscribeOrderInfo(req);

                await foreach (SubscribeOrderInfoResponse response in responseIt.ResponseStream.ReadAllAsync())
                {
                    string logMessage =$"SOI: UserToken { lib.UserTokenHash } Symbol {response.Symbol} Volume - {response.Volume} -OrderID- {response.OrderId} -OrderTag- {response.OrderTag} - Type - {response.Type} CurrentStatus {response.CurrentStatus} Reasons {response.Reason}\n";
                    logger.LogMessage(logMessage);
                }
            }
            catch (Exception ex)
            {
                logger.LogMessage("Error - " + ex.ToString());
            }
            finally
            {
                logger.LogMessage("ExampleSubscribeOrdInfo Exited");
            }
        }
    }
}
