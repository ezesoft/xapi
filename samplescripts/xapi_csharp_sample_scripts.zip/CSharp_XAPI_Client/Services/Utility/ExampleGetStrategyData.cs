using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetStrategyData
    {
        public ExampleGetStrategyData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                GetStrategyDataRequest request = new GetStrategyDataRequest
                {
                    UserToken = lib.UserToken,
                    FirmName = "EXAMPLE_FIRM",
                    AlgoName = "EXAMPLE_ALGO",
                    StrategyName = "EXAMPLE_STRATEGY"
                };

                GetStrategyDataResponse response = lib.UtilityClient.GetStrategyData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Strategy Data:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Strategy Data: " + response.StrategyData.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
