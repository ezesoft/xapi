using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetFirmName
    {
        public ExampleGetFirmName() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                GetFirmNameRequest request = new GetFirmNameRequest
                {
                    UserToken = lib.UserToken
                };

                GetFirmNameResponse response = lib.UtilityClient.GetFirmName(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Get Firm Name:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Firm Name: " + response.FirmName);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
