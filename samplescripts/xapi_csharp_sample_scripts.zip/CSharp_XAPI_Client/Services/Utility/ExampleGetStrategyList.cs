using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetStrategyList
    {
        public ExampleGetStrategyList() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                StrategyListRequest request = new StrategyListRequest
                {
                    UserToken = lib.UserToken,
                    FirmName = "EXAMPLE_FIRM"
                };

                StrategyListResponse response = lib.UtilityClient.GetStrategyList(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Strategy List:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Strategies: " + response.StrategyList.Count);
                for (int i = 0; i < response.StrategyList.Count; i++)
                {
                    Console.WriteLine($"Strategy {i + 1}: " + response.StrategyList[i].ToString());
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
