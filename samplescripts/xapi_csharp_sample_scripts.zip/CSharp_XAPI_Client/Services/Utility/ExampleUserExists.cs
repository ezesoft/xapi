using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleUserExists
    {
        public ExampleUserExists() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UserExistsRequest request = new UserExistsRequest
                {
                    UserToken = lib.UserToken,
                    FirmName = "EXAMPLE_FIRM"
                };

                UserExistsResponse response = lib.UtilityClient.UserExists(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("User Exists:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("User Exists: " + response.UserExists);
                Console.WriteLine("Firm Name: " + response.FirmName);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
