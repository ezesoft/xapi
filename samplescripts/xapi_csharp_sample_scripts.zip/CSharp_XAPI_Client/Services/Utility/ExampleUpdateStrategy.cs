using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleUpdateStrategy
    {
        public ExampleUpdateStrategy() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UpdateStrategyRequest request = new UpdateStrategyRequest
                {
                    UserToken = lib.UserToken,
                    FirmName = "TestFirm",
                    AlgoName = "TestAlgo",
                    StrategyName = "TestStrategy",
                    Version = 1,
                    StratParams = "param1=updated_value1,param2=updated_value2"
                };

                UpdateStrategyResponse response = lib.UtilityClient.UpdateStrategy(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Update Strategy:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                if (!string.IsNullOrEmpty(response.Acknowledgement.Message))
                {
                    Console.WriteLine("Message: " + response.Acknowledgement.Message);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
