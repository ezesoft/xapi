using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetTodaysBalances
    {
        public ExampleGetTodaysBalances() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                TodaysBalancesRequest request = new TodaysBalancesRequest
                {
                    UserToken = lib.UserToken,
                    TimeoutInSeconds = 30
                };

                TodaysBalancesResponse response = lib.UtilityClient.GetTodaysBalances(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Today's Balances:");

                int i = 0;
                foreach (var depositRecord in response.DepositList)
                {
                    Console.WriteLine($"--------------- Deposit Num: {i} START ---------------");
                    Console.WriteLine(depositRecord.ToString());
                    Console.WriteLine($"--------------- Deposit Num: {i} END ---------------");
                    i++;
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
