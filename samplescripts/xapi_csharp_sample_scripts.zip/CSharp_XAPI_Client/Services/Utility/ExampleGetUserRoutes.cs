using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetUserRoutes
    {
        public ExampleGetUserRoutes() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                GetUserRoutesRequest request = new GetUserRoutesRequest
                {
                    UserToken = lib.UserToken,
                    AccountList = "BANK;BRANCH;CUSTOMER;DEPOSIT"
                };

                GetUserRoutesResponse response = lib.UtilityClient.GetUserRoutes(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Get User Routes:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("User Routes:");
                foreach (var kvp in response.UserRoutes)
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
