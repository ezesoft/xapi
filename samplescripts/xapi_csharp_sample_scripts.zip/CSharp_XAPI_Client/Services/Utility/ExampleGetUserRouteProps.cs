using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetUserRouteProps
    {
        public ExampleGetUserRouteProps() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                GetUserRoutePropsRequest request = new GetUserRoutePropsRequest
                {
                    UserToken = lib.UserToken,
                    FilterRoutesList = "SMART,DMA",
                    FilterRoutePropsList = "MaxOrderSize,MinOrderSize"
                };

                GetUserRoutePropsResponse response = lib.UtilityClient.GetUserRouteProps(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Get User Route Properties:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("User Route Properties:");
                foreach (var kvp in response.UserRouteProps)
                {
                    Console.WriteLine($"  Route: {kvp.Key}");
                    foreach (var prop in kvp.Value.Properties)
                    {
                        Console.WriteLine($"    {prop.Key}: {prop.Value}");
                    }
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
