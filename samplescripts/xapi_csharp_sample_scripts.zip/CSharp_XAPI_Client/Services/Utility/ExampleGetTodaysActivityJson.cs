using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetTodaysActivityJson
    {
        public ExampleGetTodaysActivityJson() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                TodaysActivityJsonRequest request = new TodaysActivityJsonRequest
                {
                    UserToken = lib.UserToken,
                    TimeoutInSeconds = 30,
                    IncludeUserSubmitOrder = true,
                    IncludeUserSubmitStagedOrder = true,
                    IncludeUserSubmitCompoundOrder = true,
                    IncludeForeignExecution = true,
                    IncludeUserSubmitChange = true,
                    IncludeUserSubmitCancel = true,
                    IncludeExchangeAcceptOrder = true,
                    IncludeExchangeTradeOrder = true,
                    IncludeUserSubmitTradeReport = true,
                    IncludeUserSubmitAllocation = true,
                    IncludeUserSubmitAllocationEx = true,
                    IncludeClerkReject = true,
                    IncludeOnlyCompleted = true
                };

                TodaysActivityJsonResponse response = lib.UtilityClient.GetTodaysActivityJson(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Today's Activity JSON:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Activity JSON: " + response.TodaysActivityJson);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
