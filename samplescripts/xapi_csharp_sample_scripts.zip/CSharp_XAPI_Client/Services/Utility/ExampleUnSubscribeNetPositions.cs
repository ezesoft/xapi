using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleUnSubscribeNetPositions
    {
        public ExampleUnSubscribeNetPositions() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UnSubscribeNetPositionsRequest request = new UnSubscribeNetPositionsRequest
                {
                    UserToken = lib.UserToken
                };

                UnSubscribeNetPositionsResponse response = lib.UtilityClient.UnSubscribeTodaysNetPositions(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("UnSubscribe Net Positions:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                if (!string.IsNullOrEmpty(response.Acknowledgement.Message))
                {
                    Console.WriteLine("Message: " + response.Acknowledgement.Message);
                }
                Console.WriteLine("Unsubscribed from net positions stream successfully");
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
