using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetTodaysNetPositions
    {
        public ExampleGetTodaysNetPositions() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                TodaysNetPositionsRequest request = new TodaysNetPositionsRequest
                {
                    UserToken = lib.UserToken,
                    TimeoutInSeconds = 30
                };

                TodaysNetPositionsResponse response = lib.UtilityClient.GetTodaysNetPositions(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Aggregate Positions: " + response.AggregatePositionsList.Count);
                for (int i = 0; i < response.AggregatePositionsList.Count; i++)
                {
                    Console.WriteLine($"Position {i + 1}: " + response.AggregatePositionsList[i].ToString());
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
