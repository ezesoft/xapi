using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleSubscribeNetPositions
    {
        public ExampleSubscribeNetPositions() { }

        public async Task Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubscribeNetPositionsRequest request = new SubscribeNetPositionsRequest
                {
                    UserToken = lib.UserToken,
                    TimeoutInSeconds = 30
                };

                var call = lib.UtilityClient.SubscribeTodaysNetPositions(request);

                while (await call.ResponseStream.MoveNext(CancellationToken.None))
                {
                    var response = call.ResponseStream.Current;
                    Console.WriteLine("------------------------------");
                    Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                    Console.WriteLine(response.AggregatePositions.ToString());
                    Console.WriteLine("------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
