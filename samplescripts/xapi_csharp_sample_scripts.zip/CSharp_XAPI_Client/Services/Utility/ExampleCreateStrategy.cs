using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleCreateStrategy
    {
        public ExampleCreateStrategy() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                CreateStrategyRequest request = new CreateStrategyRequest
                {
                    UserToken = lib.UserToken,
                    FirmName = "TestFirm",
                    AlgoName = "TestAlgo",
                    StrategyName = "TestStrategy",
                    StratParams = "param1=value1,param2=value2"
                };

                CreateStrategyResponse response = lib.UtilityClient.CreateStrategy(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Create Strategy:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                if (!string.IsNullOrEmpty(response.Acknowledgement.Message))
                {
                    Console.WriteLine("Message: " + response.Acknowledgement.Message);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
