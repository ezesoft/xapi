using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Utility
{
    class ExampleGetTodaysBrokenDownPositions
    {
        public ExampleGetTodaysBrokenDownPositions() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                TodaysBrokenDownPositionsRequest request = new TodaysBrokenDownPositionsRequest
                {
                    UserToken = lib.UserToken,
                    TimeoutInSeconds = 30
                };

                TodaysBrokenDownPositionsResponse response = lib.UtilityClient.GetTodaysBrokenDownPositions(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Today's Broken Down Positions:");

                int numOfRecords = 0;
                foreach (var positionRecord in response.PositionRecords)
                {
                    numOfRecords++;
                    Console.WriteLine("-------------------------------------------------------");
                    Console.WriteLine($" POSITION RECORD - {numOfRecords}");
                    Console.WriteLine(positionRecord.ToString());
                }
                Console.WriteLine("Total Records: " + numOfRecords);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
