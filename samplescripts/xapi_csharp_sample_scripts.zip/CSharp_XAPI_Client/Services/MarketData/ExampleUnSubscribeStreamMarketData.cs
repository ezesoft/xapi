using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleUnSubscribeStreamMarketData
    {
        public ExampleUnSubscribeStreamMarketData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UnSubscribeStreamMarketDataRequest request = new UnSubscribeStreamMarketDataRequest
                {
                    UserToken = lib.UserToken
                };

                UnSubscribeStreamMarketDataResponse response = lib.MarketDataClient.UnSubscribeStreamMarketData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Unsubscribed from Stream Market Data:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields: " + string.Join(", ", response.OptionalFields));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
