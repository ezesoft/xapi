using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
using Google.Protobuf.WellKnownTypes;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetDailyWeeklyMonthlyBars
    {
        public ExampleGetDailyWeeklyMonthlyBars() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                DailyWeeklyMonthlyBarsRequest request = new DailyWeeklyMonthlyBarsRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "VOD.LSE",
                    Interim = new Interval
                    {
                        BarIntervalOption = Interval.Types.Options.Daily
                    }
                };

                DailyWeeklyMonthlyBarsResponse response = lib.MarketDataClient.GetDailyWeeklyMonthlyBars(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Daily Weekly Monthly Bars:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Display Name: " + response.DispName);
                Console.WriteLine("Bar Data:");
                if (response.BarFields.AcVol1.Count > 0)
                    Console.WriteLine("  Accumulated Volume 1: " + response.BarFields.AcVol1[0]);
                if (response.BarFields.High1.Count > 0)
                    Console.WriteLine("  High 1: " + response.BarFields.High1[0]);
                if (response.BarFields.Low1.Count > 0)
                    Console.WriteLine("  Low 1: " + response.BarFields.Low1[0]);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
