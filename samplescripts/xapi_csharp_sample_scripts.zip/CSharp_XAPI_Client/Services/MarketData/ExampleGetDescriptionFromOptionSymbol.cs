using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetDescriptionFromOptionSymbol
    {
        public ExampleGetDescriptionFromOptionSymbol() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                DescriptionFromOptionSymbolRequest request = new DescriptionFromOptionSymbolRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "AAPL240315C00150000"
                };

                DescriptionFromOptionSymbolResponse response = lib.MarketDataClient.GetDescriptionFromOptionSymbol(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Option Description from Symbol:");
                Console.WriteLine("Symbol: " + request.Symbol);
                Console.WriteLine("Root: " + response.Root);
                Console.WriteLine("Expiration: " + response.Expiration);
                Console.WriteLine("Type: " + (response.OptionType.CallOrPut == OptionTypes.Types.Options.Call ? "CALL" : "PUT"));
                Console.WriteLine("Strike Price: $" + response.StrikePrice);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
