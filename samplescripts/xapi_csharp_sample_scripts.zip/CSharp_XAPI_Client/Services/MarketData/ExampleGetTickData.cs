using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
using Google.Protobuf.WellKnownTypes;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetTickData
    {
        public ExampleGetTickData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                var now = DateTime.UtcNow;

                TickDataRequest request = new TickDataRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "VOD.LSE",
                    Date = Timestamp.FromDateTime(now),
                    StartTime = Duration.FromTimeSpan(TimeSpan.FromHours(12).Add(TimeSpan.FromMinutes(10)).Add(TimeSpan.FromSeconds(50))),
                    StopTime = Duration.FromTimeSpan(TimeSpan.FromHours(20).Add(TimeSpan.FromMinutes(30)).Add(TimeSpan.FromSeconds(40))),
                    RequestId = Math.Abs(Guid.NewGuid().GetHashCode())
                };
                request.TickTypes.Add(new TickTypes { TickOption = TickTypes.Types.Ticks.Trade });
                request.TickTypes.Add(new TickTypes { TickOption = TickTypes.Types.Ticks.Bid });
                request.TickTypes.Add(new TickTypes { TickOption = TickTypes.Types.Ticks.Ask });

                TickDataResponse response = lib.MarketDataClient.GetTickData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Tick Data:");
                Console.WriteLine("Number of Records: " + response.TickInfo.Count);
                for (int i = 0; i < response.TickInfo.Count; i++)
                {
                    var tickRecord = response.TickInfo[i];
                    Console.WriteLine($"Record {i + 1}:");
                    Console.WriteLine("  Count: " + tickRecord.Count);
                    Console.WriteLine("  Trade Prices: " + string.Join(", ", tickRecord.TrdPrc1));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
