using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetOptionsAndGreekData
    {
        public ExampleGetOptionsAndGreekData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                OptionsAndGreekDataRequest request = new OptionsAndGreekDataRequest
                {
                    UserToken = lib.UserToken
                };
                request.Symbols.Add("M");
                request.Symbols.Add("+AAPL\\15B9\\223");
                request.Symbols.Add("+IBM\\09D9\\150");

                OptionsAndGreekDataResponse response = lib.MarketDataClient.GetOptionsAndGreekData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Options and Greek Data:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Options: " + response.OptionsList.Count);
                for (int i = 0; i < response.OptionsList.Count; i++)
                {
                    Console.WriteLine($"Option {i + 1}: " + response.OptionsList[i].ToString());
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
