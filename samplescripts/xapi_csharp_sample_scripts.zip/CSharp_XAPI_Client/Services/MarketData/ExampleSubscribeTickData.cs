using ezesoft.xapi.generated;
using Grpc.Core;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleSubscribeTickData
    {
        public ExampleSubscribeTickData() { }

        public async Task Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubscribeTickDataRequest request = new SubscribeTickDataRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "AAPL",
                    Request = true
                };

                var responseIt = lib.MarketDataClient.SubscribeTickData(request);

                await foreach (var response in responseIt.ResponseStream.ReadAllAsync())
                {
                    Console.WriteLine("------------------------------");
                    Console.WriteLine("Tick Data Subscription:");
                    Console.WriteLine(response.ToString());
                    Console.WriteLine("------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
