using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetSymbolReferenceData
    {
        public ExampleGetSymbolReferenceData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SymbolReferenceDataRequest request = new SymbolReferenceDataRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "VOD.LSE"
                };

                SymbolReferenceDataResponse response = lib.MarketDataClient.GetSymbolReferenceData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Symbol Reference Data:");
                Console.WriteLine("Symbol: " + request.Symbol);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Response: " + response.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
