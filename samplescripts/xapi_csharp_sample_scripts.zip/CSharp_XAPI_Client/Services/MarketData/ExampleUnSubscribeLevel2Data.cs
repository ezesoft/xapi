using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleUnSubscribeLevel2Data
    {
        public ExampleUnSubscribeLevel2Data() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UnSubscribeLevel2DataRequest request = new UnSubscribeLevel2DataRequest
                {
                    UserToken = lib.UserToken
                };

                UnSubscribeLevel2DataResponse response = lib.MarketDataClient.UnSubscribeLevel2Data(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Unsubscribed from Level 2 Data:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields: " + string.Join(", ", response.OptionalFields));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
