using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetSymbolFromAlternateSymbology
    {
        public ExampleGetSymbolFromAlternateSymbology() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SymbolFromAlternateSymbologyRequest request = new SymbolFromAlternateSymbologyRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "037833100",
                    SymbolInfo = new AlternateSymbology
                    {
                        SymbolOption = AlternateSymbology.Types.Symbology.Cusip
                    }
                };

                SymbolFromAlternateSymbologyResponse response = lib.MarketDataClient.GetSymbolFromAlternateSymbology(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Symbol from Alternate Symbology:");
                Console.WriteLine("Input Symbol: " + request.Symbol);
                Console.WriteLine("Symbol Type: " + request.SymbolInfo.SymbolOption);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Result: " + response.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
