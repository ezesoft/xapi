using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleAddSymbols
    {
        public ExampleAddSymbols() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                var symbolsList = new List<string> { "MSFT", "GOOGL", "TSLA" };

                AddSymbolsRequest request = new AddSymbolsRequest
                {
                    UserToken = lib.UserToken
                };
                request.Symbols.AddRange(symbolsList);

                AddSymbolsResponse response = lib.MarketDataClient.AddSymbols(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Added Symbols to Subscriptions:");
                Console.WriteLine("Symbols: " + string.Join(", ", symbolsList));
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields: " + string.Join(", ", response.OptionalFields));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
