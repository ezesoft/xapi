using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetLevel1MarketData
    {
        public ExampleGetLevel1MarketData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                Level1MarketDataRecordRequest request = new Level1MarketDataRecordRequest
                {
                    UserToken = lib.UserToken
                };
                request.Symbols.Add("VOD.LSE");
                request.Symbols.Add("BARC.LSE");
                request.Symbols.Add("GSK.LSE");

                Level1MarketDataRecordResponse response = lib.MarketDataClient.GetLevel1MarketData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Level1 Market Data:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Records: " + response.DataRecord.Count);
                for (int i = 0; i < response.DataRecord.Count; i++)
                {
                    Console.WriteLine($"Symbol {i + 1}: " + response.DataRecord[i].DispName);
                    Console.WriteLine("  Last Price: " + response.DataRecord[i].Trdprc1);
                    Console.WriteLine("  Bid: " + response.DataRecord[i].Bid);
                    Console.WriteLine("  Ask: " + response.DataRecord[i].Ask);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
