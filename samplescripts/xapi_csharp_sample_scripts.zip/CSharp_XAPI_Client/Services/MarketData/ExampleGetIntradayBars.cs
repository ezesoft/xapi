using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
using Google.Protobuf.WellKnownTypes;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetIntradayBars
    {
        public ExampleGetIntradayBars() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                var now = DateTime.UtcNow;

                IntradayBarsRequest request = new IntradayBarsRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "VOD.LSE",
                    BarInterval = 1,
                    DaysBack = 1,
                    StartAtMidnight = false,
                    ShowPrePostMarket = false,
                    Date = Timestamp.FromDateTime(now),
                    StartTime = Duration.FromTimeSpan(TimeSpan.FromHours(12).Add(TimeSpan.FromMinutes(10)).Add(TimeSpan.FromSeconds(50))),
                    StopTime = Duration.FromTimeSpan(TimeSpan.FromHours(20).Add(TimeSpan.FromMinutes(30)).Add(TimeSpan.FromSeconds(40))),
                    RequestId = 12345
                };

                IntradayBarsResponse response = lib.MarketDataClient.GetIntradayBars(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Intraday Bars Data:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Bars: " + response.Bars.ToString());
                Console.WriteLine("Trade Times: " + string.Join(", ", response.TrdTim1));
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
