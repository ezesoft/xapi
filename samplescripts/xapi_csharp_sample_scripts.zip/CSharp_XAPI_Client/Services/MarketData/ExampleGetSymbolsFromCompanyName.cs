using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetSymbolsFromCompanyName
    {
        public ExampleGetSymbolsFromCompanyName() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SymbolsFromCompanyNameRequest request = new SymbolsFromCompanyNameRequest
                {
                    UserToken = lib.UserToken,
                    CompanyName = "Microsoft Corporation"
                };

                SymbolsFromCompanyNameResponse response = lib.MarketDataClient.GetSymbolsFromCompanyName(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Symbols from Company Name:");
                Console.WriteLine("Company: " + request.CompanyName);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Symbols: " + response.SymbolDatalist.Count);
                for (int i = 0; i < response.SymbolDatalist.Count; i++)
                {
                    Console.WriteLine($"Symbol {i + 1}: " + response.SymbolDatalist[i].ToString());
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
