using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
using Google.Protobuf.WellKnownTypes;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetOptionChainForUnderlier
    {
        public ExampleGetOptionChainForUnderlier() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                OptionChainRequest request = new OptionChainRequest
                {
                    UserToken = lib.UserToken,
                    SymbolRoot = "M"
                };

                OptionChainResponse response = lib.MarketDataClient.GetOptionChainForUnderlier(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Option Chain for Underlier:");
                Console.WriteLine("Symbol Root: " + request.SymbolRoot);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Number of Derivatives: " + response.Derivative.Count);
                for (int i = 0; i < response.Derivative.Count; i++)
                {
                    Console.WriteLine($"Derivative {i + 1}: " + response.Derivative[i].ToString());
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
