using ezesoft.xapi.generated;
using Grpc.Core;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleSubscribeLevel2Ticks
    {
        public ExampleSubscribeLevel2Ticks() { }

        public async Task Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                Level2MarketDataRequest request = new Level2MarketDataRequest
                {
                    UserToken = lib.UserToken,
                    Request = true,
                    Advise = true,
                    RequestId = 12345
                };
                request.Symbols.Add("VOD.LSE");
                request.Symbols.Add("MSFT");
                request.Symbols.Add("GOOGL");

                var responseIt = lib.MarketDataClient.SubscribeLevel2Ticks(request);

                await foreach (var response in responseIt.ResponseStream.ReadAllAsync())
                {
                    Console.WriteLine("------------------------------");
                    Console.WriteLine("Subscribe Level 2 Ticks:");
                    Console.WriteLine(response.ToString());
                    Console.WriteLine("------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
