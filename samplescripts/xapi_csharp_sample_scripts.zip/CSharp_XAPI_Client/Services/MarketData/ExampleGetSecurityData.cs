using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetSecurityData
    {
        public ExampleGetSecurityData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SecurityDataRequest request = new SecurityDataRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "VOD.LSE"
                };

                SecurityDataResponse response = lib.MarketDataClient.GetSecurityData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Security Data:");
                Console.WriteLine("Symbol: " + request.Symbol);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Response: " + response.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
