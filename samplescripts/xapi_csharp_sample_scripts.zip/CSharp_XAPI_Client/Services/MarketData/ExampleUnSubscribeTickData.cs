using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleUnSubscribeTickData
    {
        public ExampleUnSubscribeTickData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UnSubscribeTickDataRequest request = new UnSubscribeTickDataRequest
                {
                    UserToken = lib.UserToken
                };

                UnSubscribeTickDataResponse response = lib.MarketDataClient.UnSubscribeTickData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Unsubscribed from Tick Data:");
                Console.WriteLine("Acknowledgement: " + response.Acknowledgement.ToString());
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
