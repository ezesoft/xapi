using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleUnSubscribeLevel1Data
    {
        public ExampleUnSubscribeLevel1Data() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UnSubscribeLevel1DataRequest request = new UnSubscribeLevel1DataRequest
                {
                    UserToken = lib.UserToken
                };

                UnSubscribeLevel1DataResponse response = lib.MarketDataClient.UnSubscribeLevel1Data(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Unsubscribed from Level 1 Data:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields: " + string.Join(", ", response.OptionalFields));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
