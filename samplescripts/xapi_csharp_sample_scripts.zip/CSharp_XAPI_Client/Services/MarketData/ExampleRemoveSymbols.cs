using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleRemoveSymbols
    {
        public ExampleRemoveSymbols() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                var symbolsList = new List<string> { "MSFT", "GOOGL", "TSLA" };

                RemoveSymbolsRequest request = new RemoveSymbolsRequest
                {
                    UserToken = lib.UserToken
                };
                request.Symbols.AddRange(symbolsList);

                RemoveSymbolsResponse response = lib.MarketDataClient.RemoveSymbols(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Removed Symbols from Subscriptions:");
                Console.WriteLine("Symbols: " + string.Join(", ", symbolsList));
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields: " + string.Join(", ", response.OptionalFields));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
