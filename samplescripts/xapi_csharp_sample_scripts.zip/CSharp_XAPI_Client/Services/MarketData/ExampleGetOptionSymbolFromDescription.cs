using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.MarketData
{
    class ExampleGetOptionSymbolFromDescription
    {
        public ExampleGetOptionSymbolFromDescription() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                OptionSymbolFromDescriptionRequest request = new OptionSymbolFromDescriptionRequest
                {
                    UserToken = lib.UserToken,
                    Root = "AAPL",
                    Expiration = "20240315",
                    OptionType = new OptionTypes { CallOrPut = OptionTypes.Types.Options.Call },
                    StrikePrice = 150.0
                };

                OptionSymbolFromDescriptionResponse response = lib.MarketDataClient.GetOptionSymbolFromDescription(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Option Symbol from Description:");
                Console.WriteLine("Root: " + request.Root);
                Console.WriteLine("Expiration: " + request.Expiration);
                Console.WriteLine("Type: " + (request.OptionType.CallOrPut == OptionTypes.Types.Options.Call ? "CALL" : "PUT"));
                Console.WriteLine("Strike: $" + request.StrikePrice);
                Console.WriteLine("Symbol: " + response.Symbol);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
