using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleGetUserAccounts
    {
        public ExampleGetUserAccounts() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                UserAccountsRequest request = new UserAccountsRequest
                {
                    UserToken = lib.UserToken
                };

                UserAccountsResponse response = lib.OrderClient.GetUserAccounts(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("User Accounts:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                foreach (var kvp in response.Accounts)
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
