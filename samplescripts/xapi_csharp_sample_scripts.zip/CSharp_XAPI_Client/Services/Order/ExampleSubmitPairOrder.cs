using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitPairOrder
    {
        public ExampleSubmitPairOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubmitPairOrderRequest request = new SubmitPairOrderRequest
                {
                    UserToken = lib.UserToken,
                    Leg1Symbol = "LEG1_SYMBOL",
                    Leg1Side = "BUY",
                    Leg1Quantity = 1111,
                    Leg2Symbol = "LEG2_SYMBOL",
                    Leg2Side = "SELL",
                    Leg2Quantity = 1000,
                    Route = "ROUTE",
                    Account = "BANK;BRANCH;CUSTOMER;DEPOSIT",
                    Staged = false,
                    ClaimRequire = false,
                    OrderTag = "ORDER_TAG",
                    TicketId = "TICKET_ID"
                };
                request.Leg1ExtendedFields["ACCT_TYPE"] = "119";
                request.Leg2ExtendedFields["ACCT_TYPE"] = "119";

                SubmitPairOrderResponse response = lib.OrderClient.SubmitPairOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Submit Pair Order Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.ServerResponse == "Failed")
                {
                    Console.WriteLine("Error Message: " + response.OptionalFields.GetValueOrDefault("ErrorMessage"));
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
