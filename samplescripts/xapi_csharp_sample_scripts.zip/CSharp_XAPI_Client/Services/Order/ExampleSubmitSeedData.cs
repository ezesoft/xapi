using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitSeedData
    {
        public ExampleSubmitSeedData() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubmitSeedDataRequest request = new SubmitSeedDataRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "Symbol",
                    Account = "BANK;BRANCH;CUSTOMER;DEPOSIT"
                };

                SubmitSeedDataResponse response = lib.OrderClient.SubmitSeedData(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Submit Seed Data:");
                Console.WriteLine("Account: BANK;BRANCH;CUSTOMER;DEPOSIT");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
