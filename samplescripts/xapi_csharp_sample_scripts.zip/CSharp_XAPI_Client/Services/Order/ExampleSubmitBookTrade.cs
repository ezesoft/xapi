using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitBookTrade
    {
        public ExampleSubmitBookTrade() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                AllocationDetails allocDetail = new AllocationDetails
                {
                    TargetAccount = "BANK;BRANCH;CUSTOMER;DEPOSIT",
                    TargetQuantity = 50,
                    TargetPrice = 100.0,
                    NetPrice = 99.5
                };

                SubmitBookTradeRequest request = new SubmitBookTradeRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "ORDER123",
                    SourceAccount = "SOURCE_ACCOUNT",
                    OrderTag = "BOOK_TRADE_TAG"
                };
                request.AllocDetails.Add(allocDetail);

                SubmitBookTradeResponse response = lib.OrderClient.SubmitBookTrade(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Submit Book Trade Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.Count > 0)
                {
                    Console.WriteLine("Optional Fields:");
                    foreach (var kvp in response.OptionalFields)
                    {
                        Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
                    }
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
