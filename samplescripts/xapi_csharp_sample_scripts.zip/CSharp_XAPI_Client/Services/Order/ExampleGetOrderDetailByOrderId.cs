using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleGetOrderDetailByOrderId
    {
        public ExampleGetOrderDetailByOrderId() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                OrderDetailByOrderIdRequest request = new OrderDetailByOrderIdRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "12345678"
                };

                OrderDetailByOrderIdResponse response = lib.OrderClient.GetOrderDetailByOrderId(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Order Details by Order ID:");
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Response received successfully");
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
