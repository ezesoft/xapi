using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitTradeReport
    {
        public ExampleSubmitTradeReport() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubmitTradeReportRequest request = new SubmitTradeReportRequest
                {
                    UserToken = lib.UserToken,
                    Symbol = "AAPL",
                    Side = "BUY",
                    Quantity = 100,
                    Account = "ACCOUNT123",
                    Route = "ROUTE1",
                    OrderType = new TradeType
                    {
                        OrderTypes = TradeType.Types.TypeofOrder.UserSubmitTradeReport
                    }
                };
                request.ExtendedFields["ACCT_TYPE"] = "119";

                SubmitTradeReportResponse response = lib.OrderClient.SubmitTradeReport(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Submit Trade Report Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.ContainsKey("ErrorMessage"))
                {
                    Console.WriteLine("Error Message: " + response.OptionalFields["ErrorMessage"]);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
