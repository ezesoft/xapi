using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleCancelPairOrder
    {
        public ExampleCancelPairOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                CancelPairOrderRequest request = new CancelPairOrderRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "12345678"
                };

                CancelPairOrderResponse response = lib.OrderClient.CancelPairOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Cancel Pair Order Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                Console.WriteLine("Order Cancellation Response received");
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
