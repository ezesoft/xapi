using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
namespace EzeSoft.XAPI.Services.Order
{
    class ExampleChangeSingleOrder
    {
        public ExampleChangeSingleOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                ChangeSingleOrderRequest request = new ChangeSingleOrderRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "ORDER_ID_PLACEHOLDER",
                    Quantity = 5000,
                    Price = 121.5,
                    OrderTag = "CHANGE_ORDER_TAG"
                };
                request.ExtendedFields["DEST_ROUTE"] = "DEMOEUR";
                request.ExtendedFields["ACCT_TYPE"] = "119";

                ChangeSingleOrderResponse response = lib.OrderClient.ChangeSingleOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Change Single Order Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.ServerResponse == "Failed")
                {
                    Console.WriteLine("Error Message: " + response.OptionalFields.GetValueOrDefault("ErrorMessage"));
                }
                else
                {
                    Console.WriteLine("Order changed successfully");
                    Console.WriteLine("New Quantity: " + request.Quantity);
                    Console.WriteLine("New Price: " + request.Price.Value);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
