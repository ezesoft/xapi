using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleChangePairOrder
    {
        public ExampleChangePairOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                ChangePairOrderRequest request = new ChangePairOrderRequest
                {
                    UserToken = lib.UserToken,
                    PairOrderId = "12345678"
                };
                request.Leg1ExtendedFields["ACCT_TYPE"] = "119";
                request.Leg2ExtendedFields["ACCT_TYPE"] = "119";

                ChangePairOrderResponse response = lib.OrderClient.ChangePairOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Change Pair Order Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                Console.WriteLine("Response received successfully");
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
