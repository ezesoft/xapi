using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitAllocationOrder
    {
        public ExampleSubmitAllocationOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                SubmitAllocationOrderRequest request = new SubmitAllocationOrderRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "12345678",
                    Symbol = "AAPL",
                    Exchange = "NASDAQ",
                    SourceAccount = "BANK;BRANCH;CUSTOMER;DEPOSIT",
                    TargetAccount = "TARGET_ACCOUNT",
                    TargetQuantity = 100,
                    TargetPrice = 150.50,
                    TypeOfAllocation = new AllocationType
                    {
                        AllocationOrAllocationEx = AllocationType.Types.Allocation.UserSubmitAllocation
                    },
                    OrderTypes = new OrderType
                    {
                        TypeOfOrder = OrderType.Types.Type.UserSubmitOrder
                    }
                };

                SubmitAllocationOrderResponse response = lib.OrderClient.SubmitAllocationOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Submit Allocation Order Response:");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.OptionalFields.ContainsKey("ErrorMessage"))
                {
                    Console.WriteLine("Error Message: " + response.OptionalFields["ErrorMessage"]);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
