using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleCancelSingleOrder
    {
        public ExampleCancelSingleOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                CancelSingleOrderRequest request = new CancelSingleOrderRequest
                {
                    UserToken = lib.UserToken,
                    OrderId = "ORDER_ID_PLACEHOLDER"
                };

                CancelSingleOrderResponse response = lib.OrderClient.CancelSingleOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Server Response: " + response.ServerResponse);
                if (response.ServerResponse == "Failed")
                {
                    Console.WriteLine("Error Message: " + response.OptionalFields.GetValueOrDefault("ErrorMessage"));
                }
                else
                {
                    Console.WriteLine("Order cancelled successfully");
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
