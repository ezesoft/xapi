using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;

namespace EzeSoft.XAPI.Services.Order
{
    class ExampleGetOrderDetailByOrderTag
    {
        public ExampleGetOrderDetailByOrderTag() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                OrderDetailByOrderTagRequest request = new OrderDetailByOrderTagRequest
                {
                    UserToken = lib.UserToken,
                    OrderEventType = "ALL"
                };
                request.OrderTags.Add("ORDER_TAG_1");
                request.OrderTags.Add("ORDER_TAG_2");

                OrderDetailByOrderTagResponse response = lib.OrderClient.GetOrderDetailByOrderTag(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Get Order Detail By Order Tag:");
                Console.WriteLine("Number of Order Details: " + response.OrderDetails.Count);
                for (int i = 0; i < response.OrderDetails.Count; i++)
                {
                    Console.WriteLine($"Order Detail {i + 1}:");
                    Console.WriteLine("  Order ID: " + response.OrderDetails[i].OrderId);
                    Console.WriteLine("  Refers To ID: " + response.OrderDetails[i].RefersToId);
                }
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
