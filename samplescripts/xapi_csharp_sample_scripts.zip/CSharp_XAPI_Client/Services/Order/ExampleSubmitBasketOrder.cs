using ezesoft.xapi.generated;
using EzeSoft.XAPI.Runtime;
using EzeSoft.XAPI.Exceptions;
namespace EzeSoft.XAPI.Services.Order
{
    class ExampleSubmitBasketOrder
    {
        public ExampleSubmitBasketOrder() { }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                string account = "BANK;BRANCH;CUSTOMER;DEPOSIT";
                string[] accountParts = account.Split(';');
                string orderTag1 = "XAP-" + Guid.NewGuid().ToString();
                string orderTag2 = "XAP-" + Guid.NewGuid().ToString();

                OrderRow order1 = new OrderRow
                {
                    DispName = "SYMBOL1",
                    Buyorsell = "BUY",
                    PriceType = "LIMIT",
                    Price = "100.50",
                    VolumeType = "AsEntered",
                    Volume = 100,
                    Exchange = "EXCHANGE1",
                    Styp = 1,
                    Bank = accountParts[0],
                    Branch = accountParts[1],
                    Customer = accountParts[2],
                    Deposit = accountParts[3],
                    GoodUntil = "DAY",
                    Type = "UserSubmitOrder",
                    Route = "ROUTE1"
                };
                order1.ExtendedFields["ORDER_TAG"] = orderTag1;
                order1.ExtendedFields["ACCT_TYPE"] = "119";

                OrderRow order2 = new OrderRow
                {
                    DispName = "SYMBOL2",
                    Buyorsell = "SELL",
                    PriceType = "LIMIT",
                    Price = "50.25",
                    VolumeType = "AsEntered",
                    Volume = 200,
                    Exchange = "EXCHANGE2",
                    Styp = 1,
                    Bank = accountParts[0],
                    Branch = accountParts[1],
                    Customer = accountParts[2],
                    Deposit = accountParts[3],
                    GoodUntil = "DAY",
                    Type = "UserSubmitOrder",
                    Route = "ROUTE2"
                };
                order2.ExtendedFields["ORDER_TAG"] = orderTag2;
                order2.ExtendedFields["ACCT_TYPE"] = "119";

                BasketOrderRequest request = new BasketOrderRequest
                {
                    UserToken = lib.UserToken
                };
                request.Orders.Add(order1);
                request.Orders.Add(order2);

                BasketOrderResponse response = lib.OrderClient.SubmitBasketOrder(request);

                Console.WriteLine("------------------------------");
                Console.WriteLine("Basket Order Submitted:");
                Console.WriteLine("Number of Orders: " + request.Orders.Count);
                Console.WriteLine("Server Response: " + response.Acknowledgement.ServerResponse);
                Console.WriteLine("Order Tag 1: " + orderTag1);
                Console.WriteLine("Order Tag 2: " + orderTag2);
                Console.WriteLine("------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
        }
    }
}
