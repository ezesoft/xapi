using ezesoft.xapi.generated;
using Grpc.Core;
using EzeSoft.XAPI;

namespace CSharp_XAPI_Client
{
    class ExampleSubscribeLevel1Ticks
    {       

        public ExampleSubscribeLevel1Ticks() { }

        public async Task Run()
        {
            try
            {

                EMSXAPILibrary lib = EMSXAPILibrary.Get();

                List<string> symbolsList = new List<string>
                {
                    "VOD.LSE",
                    "BARC.LSE",
                    "AAPL"
                };

                Level1MarketDataRequest req = new Level1MarketDataRequest()
                {
                    UserToken = lib.UserToken,
                    Advise = true,
                    Request = true
                };

                req.Symbols.AddRange(symbolsList);

                var responseIt = EMSXAPILibrary.Get().MarketDataClient.SubscribeLevel1Ticks(req);


                await foreach (var response in responseIt.ResponseStream.ReadAllAsync())
                {
                    Console.WriteLine("------------------------------");
                    Console.WriteLine(response.ToString());
                    Console.WriteLine("------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error - " + ex.Message);
            }
    
        }
    }
}
