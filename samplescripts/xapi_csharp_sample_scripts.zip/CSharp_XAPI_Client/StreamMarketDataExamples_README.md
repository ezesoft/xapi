# StreamMarketData and UnSubscribeStreamMarketData API Examples

This document provides comprehensive examples for using the bidirectional streaming market data APIs in the C# XAPI Client.

**Note:** For an interactive command-line application demonstrating these APIs, see: `../StreamingClientApp/README.md`

## Overview

The examples demonstrate how to use the following gRPC streaming APIs:
- `StreamMarketData` - Bidirectional streaming for real-time market data
- `UnSubscribeStreamMarketData` - Unary call to stop all streaming subscriptions

## API Methods

### StreamMarketData
- **Type**: Bidirectional Streaming RPC
- **Request**: `stream MarketDataStreamRequest`
- **Response**: `stream MarketDataStreamResponse`
- **Description**: Allows dynamic subscription management for Level1, Level2, and Tick data

### UnSubscribeStreamMarketData  
- **Type**: Unary RPC
- **Request**: `UnSubscribeStreamMarketDataRequest`
- **Response**: `UnSubscribeStreamMarketDataResponse`
- **Description**: Stops all active streaming subscriptions

## Example Files

### 1. ExampleBidirectionalStreamMarketData.cs
**Comprehensive bidirectional streaming example with advanced features:**

- ? Level1, Level2, and Tick data streaming
- ? Dynamic symbol addition and removal
- ? Subscription level changes
- ? Real-time statistics tracking
- ? Professional formatting and error handling
- ? Complete lifecycle management

**Key Features:**
```csharp
// Subscribe to different data levels
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "AAPL", "MSFT" }, "LEVEL1");
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "JPM", "BAC" }, "LEVEL2");
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "XOM", "CVX" }, "TICK");

// Change subscription levels dynamically
await SendSubscriptionRequest(requestStream, "CHANGE_SUBSCRIPTION", new[] { "AAPL" }, "LEVEL2");

// Remove symbols
await SendSubscriptionRequest(requestStream, "REMOVE_SYMBOL", new[] { "MSFT" }, "");
```

### 2. SimpleStreamMarketDataExample.cs
**Simple, focused examples for quick learning:**

- ? Individual demos for Level1, Level2, and Tick data
- ? Clear separation of concerns
- ? Easy to understand code structure
- ? UnSubscribeStreamMarketData demonstration

**Usage:**
```csharp
// Run all demos
await StreamMarketDataQuickDemo.RunAsync();

// Or run individual example
var example = new SimpleStreamMarketDataExample();
await example.Run();
```

**Example Code Snippet:**
```csharp
// Initialize the streaming client
using var client = new EMSXAPILibrary();
client.Login();

// Create streaming request
var request = new StreamMarketDataRequest
{
    RequestType = "ADD_SYMBOL",
    MarketDataLevel = "LEVEL1",
    Symbols = { "AAPL", "MSFT", "GOOGL" }
};

// Start streaming
using var streamingCall = client.StreamMarketData(request);

// Process streaming responses
await foreach (var response in streamingCall.ResponseStream.ReadAllAsync())
{
    foreach (var marketData in response.MarketData)
    {
        Console.WriteLine($"Symbol: {marketData.Symbol}, Bid: {marketData.Bid}, Ask: {marketData.Ask}");
    }
}
```

## Validation Scripts

### ChangeSubscriptionValidator.cs
**Comprehensive validation for CHANGE_SUBSCRIPTION functionality:**

- ? Validates all market data level transitions (LEVEL1↔LEVEL2, LEVEL1↔TICK, LEVEL2↔TICK)
- ? Tests error conditions (empty symbols, invalid levels, nonexistent symbols)
- ? Thread-safe response tracking with ConcurrentDictionary
- ? Detailed success/failure metrics and timing analysis
- ? Async/await patterns for non-blocking validation

**Key Features:**
```csharp
// Validate level transitions
await validator.ValidateLevelTransition("AAPL", "LEVEL1", "LEVEL2");
await validator.ValidateLevelTransition("MSFT", "LEVEL2", "TICK");

// Test error conditions
await validator.ValidateErrorCondition("INVALID", "LEVEL1", "Symbol not found");
await validator.ValidateErrorCondition("", "LEVEL2", "Empty symbol list");

// Advanced validation example
var validator = new ChangeSubscriptionValidator(client);
var results = await validator.ValidateAllTransitionsAsync(new[] { "AAPL", "MSFT", "GOOGL" });

Console.WriteLine($"Validation Results:");
Console.WriteLine($"Total Tests: {results.TotalTests}");
Console.WriteLine($"Passed: {results.PassedTests}");
Console.WriteLine($"Failed: {results.FailedTests}");
Console.WriteLine($"Average Response Time: {results.AverageResponseTime}ms");
```

### ValidateChangeSubscription.cs
**Main runner program for CHANGE_SUBSCRIPTION validation:**

- ? Simple entry point for executing comprehensive validation tests
- ? Asynchronous execution with proper error handling
- ? Console output with detailed test results and metrics
- ? Easy integration into automated testing pipelines

**Usage:**
```csharp
// Run comprehensive validation
var program = new ValidateChangeSubscription();
await program.RunValidationAsync();

// Example with custom configuration
var config = new ValidationConfig
{
    Symbols = new[] { "AAPL", "MSFT", "GOOGL", "TSLA" },
    Levels = new[] { "LEVEL1", "LEVEL2", "TICK" },
    MaxResponseTime = TimeSpan.FromSeconds(5),
    RetryAttempts = 3
};

var results = await program.RunValidationAsync(config);
program.PrintResults(results);
```

**Validation Coverage:**
- **Level Transitions**: LEVEL1→LEVEL2, LEVEL2→LEVEL1, LEVEL1→TICK, TICK→LEVEL1, LEVEL2→TICK, TICK→LEVEL2
- **Error Conditions**: Empty symbol arrays, invalid market data levels, nonexistent symbols
- **Response Validation**: Success acknowledgements, error messages, data integrity checks
- **Performance Metrics**: Response times, success rates, failure analysis

## Supported Market Data Types

### Level1 Data
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"LEVEL1"`
- **Response Fields**: Bid, Ask, Last Price, High, Low, Volume, etc.

### Level2 Data  
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"LEVEL2"`
- **Response Fields**: Market Maker ID, Bid/Ask with sizes, Exchange, Status

### Tick Data
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"TICK"`
- **Response Fields**: Trade prices, volumes, tick types, exchanges

## Request Types

| RequestType | Description |
|-------------|-------------|
| `ADD_SYMBOL` | Subscribe to new symbols |
| `REMOVE_SYMBOL` | Unsubscribe from symbols |
| `CHANGE_SUBSCRIPTION` | Change market data level for existing symbols |

## Comprehensive Code Example

Here's a complete example showing how to integrate streaming market data into your application:

```csharp
using System;
using System.Threading.Tasks;
using EzeSoft.XAPI;

public class MarketDataIntegrationExample
{
    private readonly EMSXAPILibrary apiClient;
    private readonly Logger logger;

    public MarketDataIntegrationExample()
    {
        // Initialize the XAPI client
        apiClient = new EMSXAPILibrary();
        logger = new Logger();
    }

    public async Task RunMarketDataStreamingAsync()
    {
        try
        {
            // Login to XAPI
            apiClient.Login();
            logger.LogMessage("Successfully logged in to XAPI");

            // Start heartbeat to maintain connection
            apiClient.StartHeartbeat();

            // Create streaming request for multiple symbols
            var request = new StreamMarketDataRequest
            {
                RequestType = "ADD_SYMBOL",
                Symbols = { "AAPL", "MSFT", "GOOGL" },
                Level = "LEVEL1"
            };

            // Subscribe to market data stream
            using var subscription = apiClient.StreamMarketData(request);

            // Process streaming data
            await foreach (var marketData in subscription.ResponseStream.ReadAllAsync())
            {
                ProcessMarketData(marketData);
            }
        }
        catch (Exception ex)
        {
            logger.LogMessage($"Market data streaming error: {ex.Message}");
        }
        finally
        {
            // Cleanup
            apiClient.StopHeartbeat();
            apiClient.Logout();
        }
    }

    private void ProcessMarketData(MarketDataResponse response)
    {
        foreach (var symbolData in response.SymbolData)
        {
            logger.LogMessage($"Symbol: {symbolData.Symbol}, Bid: {symbolData.Bid}, Ask: {symbolData.Ask}");
        }
    }

    // Example of changing subscription level
    public async Task ChangeSubscriptionLevelAsync(string symbol, string newLevel)
    {
        var changeRequest = new StreamMarketDataRequest
        {
            RequestType = "CHANGE_SUBSCRIPTION",
            Symbols = { symbol },
            Level = newLevel
        };

        var response = await apiClient.StreamMarketData(changeRequest);
        logger.LogMessage($"Changed {symbol} to {newLevel} level");
    }
}
```

This example demonstrates:
- Proper initialization and cleanup
- Error handling for streaming operations
- Dynamic subscription changes
- Processing of real-time market data

## Integration with Main Application

The examples are integrated into `App.cs`:

```csharp
//Example Bidirectional Streaming Market Data API call
Task bidirectionalStreamingTask = Task.Run(async () =>
{
    ExampleBidirectionalStreamMarketData streamingExample = new ExampleBidirectionalStreamMarketData();
    await streamingExample.Run();
});
```

## Error Handling

The examples include comprehensive error handling:

- gRPC connection failures
- Server-side protobuf compatibility issues
- Authentication token expiration
- Network timeouts
- Graceful cleanup and resource disposal

## Best Practices

1. **Always complete request streams**: Call `CompleteAsync()` when done sending requests
2. **Handle response streams properly**: Use `await foreach` with `ReadAllAsync()`
3. **Implement proper cleanup**: Unsubscribe when done to free server resources
4. **Use cancellation tokens**: For graceful shutdown in production applications
5. **Monitor connection health**: Check acknowledgements and status updates

## Dependencies

- EMSXAPILibrary (initialized and logged in)
- Valid user token
- Network connectivity to market data server
- gRPC.Net.Client
- Google.Protobuf

## Running the Examples

1. Ensure EMSXAPILibrary is properly configured
2. Authenticate and obtain a valid user token
3. Run one of the example classes:

```csharp
// Comprehensive example
var example = new ExampleBidirectionalStreamMarketData();
await example.Run();

// Simple examples
await StreamMarketDataQuickDemo.RunAsync();
```

## Troubleshooting

**Common Issues:**
- **Authentication failures**: Ensure valid user token
- **Connection timeouts**: Check network connectivity
- **Symbol not found**: Verify symbol format (e.g., "AAPL" not "AAPL.US")
- **Protobuf Duration warnings**: These are server-side issues and can be safely ignored

**Debug Tips:**
- Enable logging in EMSXAPILibrary
- Monitor console output for real-time updates
- Check server acknowledgement responses
- Verify symbol subscription status before changing levels