using ezesoft.xapi.generated;
using EzeSoft.XAPI;
using Google.Protobuf.WellKnownTypes;

namespace CSharp_XAPI_Client
{
    class ExampleGetOrderDetailByDateRange
    {
        private int timeout = 100;
        // Optional BBCD account filter - requires all 4 components: "BANK;BRANCH;CUSTOMER;DEPOSIT"
        // Leave empty for no account filtering
        private string account = "";

        public ExampleGetOrderDetailByDateRange()
        {
        }

        public void Run()
        {
            EMSXAPILibrary lib = EMSXAPILibrary.Get();

            // Set your date range here
            var startDate = new DateTime(2025, 2, 10, 0, 0, 0, DateTimeKind.Utc);
            var endDate = new DateTime(2026, 2, 10, 23, 59, 59, DateTimeKind.Utc);

            var request = new OrderDetailByDateRangeRequest
            {
                UserToken = lib.UserToken,
                TimeoutInSeconds = timeout,
                StartDate = Timestamp.FromDateTime(startDate),
                EndDate = Timestamp.FromDateTime(endDate)
            };

            if (!string.IsNullOrEmpty(account))
            {
                request.Account = account;
            }

            // Streaming response
            using (var call = lib.OrderClient.GetOrderDetailByDateRange(request))
            {
                while (call.ResponseStream.MoveNext().Result)
                {
                    var response = call.ResponseStream.Current;
                    Console.WriteLine("Order Details by Date Range");
                    Console.WriteLine(response.Acknowledgement.ServerResponse);
                    if (response.Acknowledgement.ServerResponse == "Failed")
                    {
                        Console.WriteLine("Error Message: " + response.Acknowledgement.Message);
                    }
                    else
                    {
                        Console.WriteLine("Response received successfully");
                    }
                    Console.WriteLine("-----------------------------");
                }
            }
        }
    }
}