using System;
using EzeSoft.XAPI;

namespace CSharp_XAPI_Client
{
    public class App
    {
        private static readonly Logger logger = new Logger();
        public string GetGreeting()
        {
            return "Sample xAPI C# Client Application :\n\n";
        }

        public static void Main(string[] args)
        {
            EMSXAPILibrary lib = null;
            try
            {
                logger.LogMessage(new App().GetGreeting());

                // Initialize EMSX API Library with error handling
                try
                {
                    EMSXAPILibrary.Create("config.cfg");
                    EMSXAPILibrary tempLib = EMSXAPILibrary.Get();
                    lib = tempLib;
                }
                catch (FileNotFoundException ex)
                {
                    logger.LogMessage($"Configuration file not found: {ex.Message}");
                    logger.LogMessage("Please ensure config.cfg exists in the application directory.");
                    return;
                }
                catch (UnauthorizedAccessException ex)
                {
                    logger.LogMessage($"Access denied to configuration file: {ex.Message}");
                    logger.LogMessage("Please check file permissions for config.cfg.");
                    return;
                }
                catch (IOException ex)
                {
                    logger.LogMessage($"Error reading configuration file: {ex.Message}");
                    logger.LogMessage("Please verify config.cfg is not corrupted and is accessible.");
                    return;
                }
                catch (InvalidOperationException ex)
                {
                    logger.LogMessage($"Configuration error: {ex.Message}");
                    logger.LogMessage("Please check your config.cfg file for missing or invalid values.");
                    return;
                }
                catch (FormatException ex)
                {
                    logger.LogMessage($"Configuration format error: {ex.Message}");
                    logger.LogMessage("Please check the format of values in config.cfg.");
                    return;
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Unexpected error initializing EMSX API Library: {ex.Message}");
                    logger.LogMessage("Please check your environment and configuration.");
                    return;
                }

                // Attempt login with detailed error reporting
                try
                {
                    lib.Login();
                    if (string.IsNullOrEmpty(lib.UserToken))
                    {
                        logger.LogMessage("Login Failed: Invalid credentials or server connection issue.");
                        logger.LogMessage("Please verify your username, password, and domain in config.cfg.");
                        lib = null;
                        return;
                    }
                }
                catch (LoginFailedException ex)
                {
                    logger.LogMessage($"Authentication failed: {ex.Message}");
                    logger.LogMessage("Please verify your credentials and server connectivity.");
                    return;
                }
                catch (NetworkFailedException ex)
                {
                    logger.LogMessage($"Network error during login: {ex.Message}");
                    logger.LogMessage("Please check your internet connection.");
                    return;
                }
                catch (ServerNotAvailableException ex)
                {
                    logger.LogMessage($"Server unavailable: {ex.Message}");
                    logger.LogMessage("Please verify the XAPI server is running and accessible.");
                    return;
                }
                catch (ChannelClosedException ex)
                {
                    logger.LogMessage($"Communication channel error: {ex.Message}");
                    logger.LogMessage("Please check server address, port, and SSL settings.");
                    return;
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Unexpected error during login: {ex.Message}");
                    logger.LogMessage("Please check your network connection and XAPI server status.");
                    return;
                }

                logger.LogMessage("User token fetched successfully: " + lib.UserToken);
                lib.HeartbeatManager.StartHeartbeat();

                // Run examples with individual error handling
                var exampleTasks = new List<Task>();

                try
                {
                    // Example GetTodaysActivity API call
                    var getTodaysActivityTask = Task.Run(() =>
                    {
                        try
                        {
                            var todaysActivityExample = new ExampleGetTodaysActivity();
                            todaysActivityExample.Run();
                        }
                        catch (Exception ex)
                        {
                            logger.LogMessage($"GetTodaysActivity example failed: {ex.Message}");
                        }
                    });
                    exampleTasks.Add(getTodaysActivityTask);

                    // Example Subscribe Level 1 Market Data API call
                    var subscribeLevel1TicksTask = Task.Run(() =>
                    {
                        try
                        {
                            var subscribeLevel1TicksExample = new ExampleSubscribeLevel1Ticks();
                            subscribeLevel1TicksExample.Run();
                        }
                        catch (Exception ex)
                        {
                            logger.LogMessage($"SubscribeLevel1Ticks example failed: {ex.Message}");
                        }
                    });
                    exampleTasks.Add(subscribeLevel1TicksTask);

                    // Example Subscribe Order Info API call
                    var subscribeOrdInfoTask = Task.Run(() =>
                    {
                        try
                        {
                            var ordInfo = new ExampleSubscribeOrdInfo();
                            ordInfo.Run();
                        }
                        catch (Exception ex)
                        {
                            logger.LogMessage($"SubscribeOrdInfo example failed: {ex.Message}");
                        }
                    });
                    exampleTasks.Add(subscribeOrdInfoTask);
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Failed to start example tasks: {ex.Message}");
                }

                // Submit orders with error handling
                try
                {
                    for (int i = 1; i <= 20; i++)
                    {
                        try
                        {
                            var submitSingleOrdExample = new ExampleSubmitSingleOrder();
                            submitSingleOrdExample.Run();
                            Console.WriteLine($"Submitted Order {i}/20");
                        }
                        catch (Exception ex)
                        {
                            logger.LogMessage($"Failed to submit order {i}: {ex.Message}");
                        }

                        Thread.Sleep(10 * 1000);
                    }
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Order submission loop failed: {ex.Message}");
                }

                // Wait for all tasks to complete or timeout
                try
                {
                    Task.WaitAll(exampleTasks.ToArray(), TimeSpan.FromMinutes(30));
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Error waiting for example tasks: {ex.Message}");
                }

                System.Threading.Thread.Sleep(20 * 60 * 1000);
            }
            catch (Exception ex)
            {
                logger.LogMessage($"Critical error in Main method: {ex.Message}");
                logger.LogMessage($"Stack trace: {ex.StackTrace}");
            }
            finally
            {
                // Ensure proper cleanup even if errors occur
                try
                {
                    if (lib != null)
                    {
                        lib.HeartbeatManager.StopHeartbeat();
                        logger.LogMessage("Suspending heartbeat thread");
                        lib.Logout();
                        logger.LogMessage("Logged out successfully");
                        lib.ChannelManager.CloseChannel();
                        logger.LogMessage("Channel closed successfully");
                    }
                }
                catch (Exception ex)
                {
                    logger.LogMessage($"Error during cleanup: {ex.Message}");
                }
                finally
                {
                    lib = null;
                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                }
            }
        }
    }
}
