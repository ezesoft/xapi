﻿using ezesoft.xapi.generated;
using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Threading;

namespace CSharp_XAPI_Client
{
    class ExampleSubmitOrderRegression
    {
        private readonly Logger logger;


        public ExampleSubmitOrderRegression()
        {
            logger = new Logger();
        }

        public void Run()
        {
            try
            {
                EMSXAPILibrary lib = EMSXAPILibrary.Get();
                EMSXAPIConfig config = new EMSXAPIConfig("config.cfg"); // Read config file

                List<string> symbolsList = new List<string>
                {
                    "AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "GOOG", "TSLA", "BRK.B", "UNH",
                    "JNJ", "V", "XOM", "WMT", "JPM", "MA", "PG", "HD", "CVX", "MRK"
                };

                for (int j = 0; j < 20000; j++)
                {
                    for (int i = 0; i < 500; i++)
                    {
                        string symbol = symbolsList[i % symbolsList.Count];
                        int quantity = new Random().Next(20, 100); // Random quantity between 20 and 150
                        SendSingleOrder(lib, config, symbol, quantity);
                        Thread.Sleep(TimeSpan.FromMinutes(5)); // Sleep for 5 minutes 
                    }
                    Thread.Sleep(TimeSpan.FromMinutes(5));  // Sleep for 5 Mins
                }
            }
            catch (Exception ex)
            {
                logger.LogMessage("Error - " + ex.Message);
            }
        }

        private void SendSingleOrder(EMSXAPILibrary lib, EMSXAPIConfig config, string symbol, int quantity)
        {
            Random rnd = new Random();

            // Create and send a single order for the given symbol and quantity
            SubmitSingleOrderRequest req = new SubmitSingleOrderRequest
            {
                UserToken = lib.GetUserToken(),
                Symbol = symbol,
                Side = "BUY",
                Quantity = quantity,
                Route = config.Route, // Read route from config
                Staged = false,
                ClaimRequire = false,
                Account = config.Account,
                ReturnResult = false,
                OrderTag = "XAPI-ONT_TESTRUN-" + rnd.Next(10000, 2000653)
            };

            SubmitSingleOrderResponse response = lib.getOrderServiceStub.SubmitSingleOrder(req);
            string logMessage = $"Order for {symbol} with quantity {quantity} submitted.OrderTag {req.OrderTag}. User - {lib.UserTokenHash} Server Response: {response.ServerResponse}";
            logger.LogMessage(logMessage + " - " + lib.UserTokenHash);
        }
    }
}
