﻿using System;

namespace CSharp_XAPI_Client
{
    public class App
    {
        private static readonly Logger logger = new Logger();
        public string GetGreeting()
        {
            return "Sample xAPI C# Client Application :\n\n";
        }

        public static void Main(string[] args)
        {
            EMSXAPILibrary lib = null;
            try
            {
                logger.LogMessage(new App().GetGreeting());
                EMSXAPILibrary.Create("config.cfg");
                EMSXAPILibrary templib = EMSXAPILibrary.Get();

                lib = templib;
                lib.Login();
                if (string.IsNullOrEmpty(lib.GetUserToken()))
                {
                    logger.LogMessage("Login Failed....");
                    lib = null;
                    return;
                }


                logger.LogMessage("User token fetched: " + lib.GetUserToken());
                lib.StartListeningHeartbeat(5);

                //Example GetTodaysActivity API call
                Task getTodaysActivityTask = Task.Run(() =>
                {
                    ExampleGetTodaysActivity todaysActivityExample = new ExampleGetTodaysActivity();
                    todaysActivityExample.Run();

                });

                //Example Subscribe Level 1 Market Data API call
                Task subscribeLevel1TicksAsync = Task.Run(() =>
                {
                    ExampleSubscribeLevel1Ticks subscribeLevel1TicksExample = new ExampleSubscribeLevel1Ticks();
                    subscribeLevel1TicksExample.Run();

                });

                //Example Subscribe Order Info API call
                Task subscribeOrdInfoAsync = Task.Run(() =>
                {
                    ExampleSubscribeOrdInfo ordInfo = new ExampleSubscribeOrdInfo();
                    ordInfo.Run();
                });


                //Submit 20 orders each after interval of 10 seconds
                for (int i = 1; i <= 20; i++)
                {
                    ExampleSubmitSingleOrder submitSingleOrdExample = new ExampleSubmitSingleOrder();
                    submitSingleOrdExample.Run();
                    Console.WriteLine("Submitted Order");
                    Thread.Sleep(10 * 1000);
                }


                System.Threading.Thread.Sleep(20 * 60 * 1000);
            }
            catch (Exception ex)
            {
                logger.LogMessage(ex.ToString());
            }
            finally
            {
                if (lib != null)
                {
                    lib.SuspendHeartbeatThread();
                    logger.LogMessage("going to disconnect");
                    lib.Logout();
                    logger.LogMessage("going to close Channel");
                    lib.CloseChannel();
                }
                lib = null;
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
