using StreamingClientApp.Core;
using StreamingClientApp.Handlers;
using EzeSoft.XAPI;

namespace StreamingClientApp
{
    /// <summary>
    /// Command-line application for bidirectional streaming market data operations.
    /// Supports adding/removing symbols, checking status, and changing subscriptions.
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Bidirectional Streaming Market Data Client ===");
            Console.WriteLine("Command-line interface for market data operations");
            Console.WriteLine();

            StreamingClient? streamingClient = null;

            try
            {
                // Initialize EMSXAPILibrary - CRITICAL: Must call Create() before Get()
                EMSXAPILibrary.Create("config.cfg");
                var lib = EMSXAPILibrary.Get();

                // Perform login
                lib.Login();
                if (string.IsNullOrEmpty(lib.UserToken))
                {
                    Console.WriteLine("Login failed. Please check your configuration.");
                    return;
                }

                Console.WriteLine("Successfully logged in and connected to EMS XAPI server.");

                streamingClient = new StreamingClient();
                var requestHandler = new RequestHandler(streamingClient);
                var symbolManager = new SymbolManager(requestHandler);
                var statusManager = new StatusManager(requestHandler, streamingClient);

                Console.WriteLine($"Streaming data will be logged to: {streamingClient.LogFilePath}");
                Console.WriteLine();

                // Start the streaming connection
                await streamingClient.StartStreamingAsync();

                // Show the command menu
                await ShowCommandMenuAsync(symbolManager, statusManager);

                // Stop streaming and cleanup
                await streamingClient.StopStreamingAsync();

                Console.WriteLine("\n=== Streaming client completed successfully ===");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in streaming client: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
            }
            finally
            {
                // Ensure proper cleanup of resources
                if (streamingClient != null)
                {
                    streamingClient.Dispose();
                }
            }
        }

        private static async Task ShowCommandMenuAsync(SymbolManager symbolManager, StatusManager statusManager)
        {
            while (true)
            {
                Console.WriteLine("\n=== Command Menu ===");
                Console.WriteLine("1. Add symbols to stream");
                Console.WriteLine("2. Remove symbols from stream");
                Console.WriteLine("3. Change subscription level");
                Console.WriteLine("4. Check streaming status");
                Console.WriteLine("5. Show message statistics");
                Console.WriteLine("6. Exit");
                Console.Write("\nSelect option (1-6): ");

                var input = Console.ReadLine()?.Trim();

                try
                {
                    switch (input)
                    {
                        case "1":
                            await symbolManager.HandleAddSymbolsAsync();
                            break;
                        case "2":
                            await symbolManager.HandleRemoveSymbolsAsync();
                            break;
                        case "3":
                            await symbolManager.HandleChangeSubscriptionAsync();
                            break;
                        case "4":
                            await statusManager.HandleCheckStatusAsync();
                            break;
                        case "5":
                            statusManager.ShowMessageStatistics();
                            break;
                        case "6":
                            Console.WriteLine("Exiting...");
                            return;
                        default:
                            Console.WriteLine("Invalid option. Please select 1-6.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing command: {ex.Message}");
                }
            }
        }
    }
}
