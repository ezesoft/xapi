# StreamingClientApp

A command-line application for bidirectional streaming market data operations using the EMS XAPI.

## Features

- **Add Symbols**: Subscribe to market data for specific symbols at different levels (LEVEL1, LEVEL2, TICK)
- **Remove Symbols**: Unsubscribe from market data streams
- **Change Subscriptions**: Dynamically change the market data level for existing subscriptions
- **Check Status**: View current streaming status and message statistics
- **Real-time Data Display**: View formatted market data as it streams

## Prerequisites

- .NET 8.0 SDK
- Access to EMS XAPI server
- Valid configuration in `config.cfg`

## Building

```bash
cd StreamingClientApp
dotnet build
```

## Running

```bash
cd StreamingClientApp
dotnet run
```

## Usage

The application presents a command-line menu with the following options:

### 1. Add symbols to stream
- Enter symbols separated by commas (e.g., "AAPL,MSFT,GOOGL")
- Select market data level: LEVEL1, LEVEL2, or TICK
- Default level is LEVEL1 if not specified

### 2. Remove symbols from stream
- Enter symbols to remove separated by commas
- Removes all subscriptions for the specified symbols

### 3. Change subscription level
- Enter symbols to change
- Select new market data level (LEVEL1, LEVEL2, or TICK)
- Dynamically updates existing subscriptions

### 4. Check streaming status
- Shows if streaming is active
- Displays total messages received
- Shows message counts by type

### 5. Show message statistics
- Detailed breakdown of messages by symbol
- Total message counts

### 6. Exit
- Gracefully closes all streams and exits

## Data Display Format

The application displays real-time market data in formatted tables:

### Level 1 Data
```
?? L1  [HH:mm:ss.fff] SYMBOL   | Bid: 150.25 | Ask: 150.30 | Last: 150.27 | Chg: +0.15 | H: 151.00 | L: 149.50
```

### Level 2 Data
```
?? L2  [HH:mm:ss.fff] SYMBOL   | MM: MARKETMAKER | Bid: 150.25(100) | Ask: 150.30(200) | Exch: NYSE | Status: ACTIVE
```

### Tick Data
```
? TICK [HH:mm:ss.fff] SYMBOL   | Count:  10
     [HH:mm:ss.fff] SYMBOL   | #1 Price: 150.25 | Vol: 100 | Type: UP | Exch: NYSE
```

## Configuration

The application uses the shared EMSXAPILibrary configuration. Ensure `config.cfg` is properly configured with:

- Server endpoints
- Authentication credentials
- Connection settings
     - If SSL is enabled (`ssl=true`), certificate validation uses platform defaults; no certificate file path is required.

## Error Handling

- Invalid symbols are rejected with error messages
- Network issues are handled gracefully
- Streaming automatically reconnects on connection loss
- All operations include proper error reporting

## Examples

### Basic Usage
1. Start the application
2. Choose option 1 to add symbols
3. Enter: "AAPL,MSFT"
4. Press Enter for default LEVEL1
5. View real-time data streaming
6. Choose option 3 to change to LEVEL2
7. Choose option 4 to check status
8. Choose option 6 to exit

### Advanced Usage
- Mix different data levels for different symbols
- Monitor message statistics during streaming
- Handle error conditions and recovery

## Related Documentation

For detailed API examples and validation scripts, see: `../CSharp_XAPI_Client/StreamMarketDataExamples_README.md`