# README_CsharpStreaming

This is the consolidated documentation for bidirectional streaming in the C# solution.

## Scope

This document applies to:

- `Client/CSharp/StreamingClientApp`
- Solution: `Client/CSharp/CSharp_XAPI_Client.sln`

## Entry Point

- `Program.cs` starts login, opens the bidirectional stream, then runs the interactive command loop.

Run from repository root:

```bash
dotnet run --project Client/CSharp/StreamingClientApp/StreamingClientApp.csproj
```

## Command Menu

1. Add symbols to stream  
2. Remove symbols from stream (by level)  
3. Change subscription level  
4. Check streaming status  
5. Show message statistics  
6. Exit

## Request Types and Levels

Requests sent over the stream:

- `ADD_SYMBOL`
- `REMOVE_SYMBOL`
- `CHANGE_SUBSCRIPTION`

Supported levels:

- `LEVEL1`
- `LEVEL2`
- `TICK`

## Client-Side Semantics (Validated)

### Add

- Sends add only for symbols not already subscribed at the same level.
- Duplicate add for the same symbol and level is skipped.

### Remove

- Removes only symbols subscribed at the requested level.
- If a symbol exists at multiple levels, removing one level preserves others.

### Change

- Changes subscription level while stream remains active.
- LEVEL1/LEVEL2 transitions replace the opposite level and preserve TICK subscriptions.

## Subscription Model

Active subscriptions are tracked as:

- `symbol -> HashSet<level>`

This supports multi-level subscriptions per symbol.

## Lifecycle

### Start

- `StartStreamingAsync()` validates service availability.
- Opens duplex stream and starts async response processing.

### Stop

- `StopStreamingAsync()` completes request stream, cancels response reader, disposes the call, clears local tracking, and invokes unsubscribe cleanup.

## Key Files

- `Core/StreamingClient.cs`
- `Handlers/RequestHandler.cs`
- `Handlers/SymbolManager.cs`
- `Handlers/StatusManager.cs`
- `Utils/StreamingLogger.cs`
- `Utils/DataFormatter.cs`

## Logging

- Runtime stream data and status are logged to timestamped files under `StreamingClientApp/logs`.

## Configuration

All projects use shared configuration from:

- `Client/CSharp/EMSXAPILibrary/config.cfg`

Required fields include credentials, server, port, and SSL mode.

## Related Documentation

- `Client/CSharp/CSharp_XAPI_Client/Readme_CsharpClient.md` (solution-level overview)
