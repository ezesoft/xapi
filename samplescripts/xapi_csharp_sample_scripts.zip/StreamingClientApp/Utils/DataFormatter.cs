using ezesoft.xapi.generated;

namespace StreamingClientApp.Utils
{
    /// <summary>
    /// Utility class for formatting market data display.
    /// </summary>
    public static class DataFormatter
    {
        /// <summary>
        /// Formats a Price object for display.
        /// </summary>
        public static string FormatPrice(Price? price)
        {
            if (price != null && !price.Isnull)
            {
                return price.DecimalValue.ToString("F2");
            }
            return "N/A";
        }

        /// <summary>
        /// Formats a timestamp for display.
        /// </summary>
        public static string FormatTimestamp(DateTime timestamp)
        {
            return timestamp.ToString("HH:mm:ss.fff");
        }

        /// <summary>
        /// Creates a formatted log message with timestamp.
        /// </summary>
        public static string FormatLogMessage(string message, DateTime? timestamp = null)
        {
            var time = timestamp ?? DateTime.Now;
            return $"[{FormatTimestamp(time)}] {message}";
        }
    }
}