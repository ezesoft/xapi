using System;
using System.IO;
using System.Threading;

namespace StreamingClientApp.Utils
{
    /// <summary>
    /// Simple file logger for streaming market data responses.
    /// Writes log entries to a timestamped log file.
    /// </summary>
    public class StreamingLogger : IDisposable
    {
        private readonly StreamWriter _writer;
        private readonly string _logFilePath;
        private readonly object _lock = new object();
        private bool _disposed = false;

        public StreamingLogger(string logDirectory = "logs")
        {
            // Create logs directory if it doesn't exist
            Directory.CreateDirectory(logDirectory);

            // Create log file with timestamp
            var timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            _logFilePath = Path.Combine(logDirectory, $"streaming_{timestamp}.log");

            // Open the log file for writing
            _writer = new StreamWriter(_logFilePath, append: true)
            {
                AutoFlush = true // Ensure immediate writing to file
            };

            // Write header
            LogMessage("=== Streaming Market Data Log Started ===");
            LogMessage($"Log file: {_logFilePath}");
            LogMessage($"Started at: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            LogMessage("");
        }

        /// <summary>
        /// Logs a message to the file with timestamp.
        /// </summary>
        public void LogMessage(string message)
        {
            if (_disposed) return;

            lock (_lock)
            {
                try
                {
                    var timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                    _writer.WriteLine($"[{timestamp}] {message}");
                }
                catch (Exception ex)
                {
                    // If logging fails, we don't want to crash the application
                    // Just silently fail for logging errors
                    Console.WriteLine($"Logging error: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Logs market data in a structured format.
        /// </summary>
        public void LogMarketData(string symbol, string dataType, string data)
        {
            LogMessage($"MARKET_DATA | {symbol} | {dataType} | {data}");
        }

        /// <summary>
        /// Logs status updates.
        /// </summary>
        public void LogStatus(string status)
        {
            LogMessage($"STATUS | {status}");
        }

        /// <summary>
        /// Logs errors.
        /// </summary>
        public void LogError(string error)
        {
            LogMessage($"ERROR | {error}");
        }

        /// <summary>
        /// Logs warnings.
        /// </summary>
        public void LogWarning(string warning)
        {
            LogMessage($"WARNING | {warning}");
        }

        /// <summary>
        /// Logs success messages.
        /// </summary>
        public void LogSuccess(string message)
        {
            LogMessage($"SUCCESS | {message}");
        }

        /// <summary>
        /// Logs subscription operations (add, remove, change).
        /// </summary>
        public void LogSubscription(string operation, string[] symbols, string marketDataLevel = "")
        {
            var symbolList = symbols.Length > 0 ? string.Join(", ", symbols) : "NONE";
            var levelInfo = string.IsNullOrEmpty(marketDataLevel) ? "" : $" | Level: {marketDataLevel}";
            LogMessage($"SUBSCRIPTION | {operation} | Symbols: [{symbolList}]{levelInfo}");
        }

        /// <summary>
        /// Logs subscription request details.
        /// </summary>
        public void LogSubscriptionRequest(string requestType, string[] symbols, string marketDataLevel, string userToken)
        {
            var symbolList = symbols.Length > 0 ? string.Join(", ", symbols) : "NONE";
            var levelInfo = string.IsNullOrEmpty(marketDataLevel) ? "" : $" | Level: {marketDataLevel}";
            var tokenInfo = $" | Token: {userToken}";
            LogMessage($"REQUEST | {requestType} | Symbols: [{symbolList}]{levelInfo}{tokenInfo}");
        }

        /// <summary>
        /// Gets the current log file path.
        /// </summary>
        public string LogFilePath => _logFilePath;

        public void Dispose()
        {
            if (!_disposed)
            {
                lock (_lock)
                {
                    try
                    {
                        LogMessage("");
                        LogMessage("=== Streaming Market Data Log Ended ===");
                        LogMessage($"Ended at: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                        _writer.Flush();
                        _writer.Dispose();
                    }
                    catch
                    {
                        // Ignore disposal errors
                    }
                }
                _disposed = true;
            }
        }
    }
}