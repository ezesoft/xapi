using System.Collections.Concurrent;

namespace StreamingClientApp.Handlers
{
    /// <summary>
    /// Handles status checking and statistics display.
    /// </summary>
    public class StatusManager
    {
        private readonly StreamingClientApp.Core.StreamingClient _streamingClient;

        public StatusManager(StreamingClientApp.Core.StreamingClient streamingClient)
        {
            _streamingClient = streamingClient;
        }

        /// <summary>
        /// Handles checking and displaying streaming status.
        /// </summary>
        public Task HandleCheckStatusAsync()
        {
            DisplayStatus();
            return Task.CompletedTask;
        }

        /// <summary>
        /// Displays message statistics.
        /// </summary>
        public void ShowMessageStatistics()
        {
            lock (_streamingClient.ConsoleLock)
            {
                Console.WriteLine("\n=== Message Statistics ===");
                Console.WriteLine("????????????????????????????");

                var counters = _streamingClient.MessageCounters;

                if (!counters.Any())
                {
                    Console.WriteLine("No messages received yet.");
                }
                else
                {
                    foreach (var kvp in counters.OrderBy(x => x.Key))
                    {
                        Console.WriteLine($"  {kvp.Key,-15}: {kvp.Value,5} messages");
                    }

                    var totalMessages = counters.Values.Sum();
                    Console.WriteLine($"  {"TOTAL",-15}: {totalMessages,5} messages");
                }

                Console.WriteLine("????????????????????????????\n");
            }
        }

        private void DisplayStatus()
        {
            Console.WriteLine("\n=== Streaming Status ===");
            Console.WriteLine($"Streaming active: {_streamingClient.IsStreaming}");
            Console.WriteLine($"Total messages received: {_streamingClient.MessageCounters.Values.Sum()}");

            // Use GetSubscriptionsByLevel() for the authoritative multi-level view.
            // A symbol can be subscribed at LEVEL1 AND LEVEL2 simultaneously;
            // grouping by a single stored level string would misreport such symbols.
            var byLevel = _streamingClient.GetSubscriptionsByLevel();
            var uniqueSymbols = _streamingClient.ActiveSubscriptions.Keys.ToHashSet(StringComparer.OrdinalIgnoreCase);

            Console.WriteLine();
            Console.WriteLine("Active Subscriptions (by level):");
            foreach (var lvl in new[] { "LEVEL1", "LEVEL2", "TICK" })
            {
                if (byLevel.TryGetValue(lvl, out var lvlSymbols) && lvlSymbols.Count > 0)
                    Console.WriteLine($"  {lvl}: {string.Join(", ", lvlSymbols)}");
                else
                    Console.WriteLine($"  {lvl}: None");
            }

            Console.WriteLine($"  Total unique symbols: {uniqueSymbols.Count}");

            // Per-symbol level detail — shows multi-level subscriptions clearly.
            // We already have an authoritative view from GetSubscriptionsByLevel(); invert it
            // to a symbol→levels map so we can display each symbol's full set.
            if (uniqueSymbols.Count > 0)
            {
                // Build symbol→levels from the already-snapshotted byLevel dict (no extra locking needed)
                var symbolToLevels = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
                foreach (var (lvl, lvlSymbols) in byLevel)
                {
                    foreach (var sym in lvlSymbols)
                    {
                        if (!symbolToLevels.TryGetValue(sym, out var list))
                        {
                            list = new List<string>();
                            symbolToLevels[sym] = list;
                        }
                        list.Add(lvl);
                    }
                }

                Console.WriteLine();
                Console.WriteLine("Per-symbol level detail:");
                foreach (var symbol in symbolToLevels.Keys.OrderBy(s => s))
                {
                    var levelList = symbolToLevels[symbol].OrderBy(l => l).ToList();
                    Console.WriteLine($"  {symbol}: [{string.Join(" + ", levelList)}]");
                }
            }

            var counters = _streamingClient.MessageCounters;
            if (counters.Any())
            {
                Console.WriteLine();
                Console.WriteLine("Messages by symbol:");
                foreach (var kvp in counters.OrderByDescending(x => x.Value))
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value} messages");
                }
            }
            else
            {
                Console.WriteLine("No messages received yet.");
            }

            Console.WriteLine();
        }
    }
}