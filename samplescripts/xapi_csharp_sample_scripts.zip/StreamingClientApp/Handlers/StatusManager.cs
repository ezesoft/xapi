using System.Collections.Concurrent;

namespace StreamingClientApp.Handlers
{
    /// <summary>
    /// Handles status checking and statistics display.
    /// </summary>
    public class StatusManager
    {
        private readonly RequestHandler _requestHandler;
        private readonly StreamingClientApp.Core.StreamingClient _streamingClient;

        public StatusManager(RequestHandler requestHandler, StreamingClientApp.Core.StreamingClient streamingClient)
        {
            _requestHandler = requestHandler;
            _streamingClient = streamingClient;
        }

        /// <summary>
        /// Handles checking and displaying streaming status.
        /// </summary>
        public Task HandleCheckStatusAsync()
        {
            DisplayStatus();
            return Task.CompletedTask;
        }

        /// <summary>
        /// Displays message statistics.
        /// </summary>
        public void ShowMessageStatistics()
        {
            lock (_streamingClient.ConsoleLock)
            {
                Console.WriteLine("\n=== Message Statistics ===");
                Console.WriteLine("????????????????????????????");

                var counters = _streamingClient.MessageCounters;

                if (!counters.Any())
                {
                    Console.WriteLine("No messages received yet.");
                }
                else
                {
                    foreach (var kvp in counters.OrderBy(x => x.Key))
                    {
                        Console.WriteLine($"  {kvp.Key,-15}: {kvp.Value,5} messages");
                    }

                    var totalMessages = counters.Values.Sum();
                    Console.WriteLine($"  {"TOTAL",-15}: {totalMessages,5} messages");
                }

                Console.WriteLine("????????????????????????????\n");
            }
        }

        private void DisplayStatus()
        {
            Console.WriteLine("\n=== Streaming Status ===");
            Console.WriteLine($"Streaming active: {_streamingClient.IsStreaming}");
            Console.WriteLine($"Total messages received: {_streamingClient.MessageCounters.Values.Sum()}");

            var subscriptions = _streamingClient.ActiveSubscriptions;
            if (subscriptions.Any())
            {
                Console.WriteLine("\nActive Subscriptions:");
                var groupedByLevel = subscriptions.GroupBy(s => s.Value)
                                                 .OrderBy(g => g.Key);

                foreach (var group in groupedByLevel)
                {
                    var symbols = string.Join(", ", group.Select(s => s.Key));
                    Console.WriteLine($"  {group.Key}: {symbols}");
                }
                Console.WriteLine($"  Total symbols: {subscriptions.Count}");
            }
            else
            {
                Console.WriteLine("No active subscriptions.");
            }

            var counters = _streamingClient.MessageCounters;
            if (counters.Any())
            {
                Console.WriteLine("\nMessages by symbol:");
                foreach (var kvp in counters.OrderByDescending(x => x.Value))
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value} messages");
                }
            }
            else
            {
                Console.WriteLine("No messages received yet.");
            }

            Console.WriteLine();
        }
    }
}