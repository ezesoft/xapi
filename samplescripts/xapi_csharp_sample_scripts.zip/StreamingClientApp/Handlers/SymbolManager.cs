namespace StreamingClientApp.Handlers
{
    /// <summary>
    /// Handles user input for symbol management operations.
    /// </summary>
    public class SymbolManager
    {
        private readonly RequestHandler _requestHandler;

        public SymbolManager(RequestHandler requestHandler)
        {
            _requestHandler = requestHandler;
        }

        /// <summary>
        /// Handles adding symbols to the stream.
        /// </summary>
        public async Task HandleAddSymbolsAsync()
        {
            var (symbols, level) = GetSymbolInput("add");
            if (symbols.Length == 0) return;

            await _requestHandler.AddSymbolsAsync(symbols, level);
            Console.WriteLine($"Added {string.Join(", ", symbols)} for {level} data.");
        }

        /// <summary>
        /// Handles removing symbols from the stream.
        /// </summary>
        public async Task HandleRemoveSymbolsAsync()
        {
            var symbols = GetSymbolsInput("remove");
            if (symbols.Length == 0) return;

            await _requestHandler.RemoveSymbolsAsync(symbols);
            Console.WriteLine($"Removed {string.Join(", ", symbols)} from streaming.");
        }

        /// <summary>
        /// Handles changing subscription levels for symbols.
        /// </summary>
        public async Task HandleChangeSubscriptionAsync()
        {
            var symbols = GetSymbolsInput("change");
            if (symbols.Length == 0) return;

            var level = GetLevelInput();
            if (string.IsNullOrEmpty(level)) return;

            await _requestHandler.ChangeSubscriptionAsync(symbols, level);
            Console.WriteLine($"Changed {string.Join(", ", symbols)} to {level} data.");
        }

        private (string[] symbols, string level) GetSymbolInput(string operation)
        {
            Console.Write($"Enter symbols to {operation} (comma-separated): ");
            var symbolsInput = Console.ReadLine()?.Trim() ?? "";

            if (string.IsNullOrEmpty(symbolsInput))
            {
                Console.WriteLine("No symbols entered.");
                return (Array.Empty<string>(), "");
            }

            var symbols = ParseSymbols(symbolsInput);
            if (symbols.Length == 0)
            {
                Console.WriteLine("No valid symbols entered.");
                return (Array.Empty<string>(), "");
            }

            var level = GetLevelInput(operation);
            return (symbols, level);
        }

        private string[] GetSymbolsInput(string operation)
        {
            Console.Write($"Enter symbols to {operation} (comma-separated): ");
            var symbolsInput = Console.ReadLine()?.Trim() ?? "";

            if (string.IsNullOrEmpty(symbolsInput))
            {
                Console.WriteLine("No symbols entered.");
                return Array.Empty<string>();
            }

            var symbols = ParseSymbols(symbolsInput);
            if (symbols.Length == 0)
            {
                Console.WriteLine("No valid symbols entered.");
            }

            return symbols;
        }

        private string GetLevelInput(string operation)
        {
            Console.Write($"Enter market data level (LEVEL1/LEVEL2/TICK) [LEVEL1]: ");
            var levelInput = Console.ReadLine()?.Trim().ToUpper() ?? "";
            var level = string.IsNullOrEmpty(levelInput) ? "LEVEL1" : levelInput;

            if (!IsValidLevel(level))
            {
                Console.WriteLine("Invalid level. Use LEVEL1, LEVEL2, or TICK.");
                return "";
            }

            return level;
        }

        private string GetLevelInput()
        {
            Console.Write("Enter new market data level (LEVEL1/LEVEL2/TICK): ");
            var levelInput = Console.ReadLine()?.Trim().ToUpper() ?? "";

            if (string.IsNullOrEmpty(levelInput) || !IsValidLevel(levelInput))
            {
                Console.WriteLine("Invalid level. Use LEVEL1, LEVEL2, or TICK.");
                return "";
            }

            return levelInput;
        }

        private string[] ParseSymbols(string input)
        {
            return input.Split(',')
                       .Select(s => s.Trim())
                       .Where(s => !string.IsNullOrEmpty(s))
                       .ToArray();
        }

        private bool IsValidLevel(string level)
        {
            return level == "LEVEL1" || level == "LEVEL2" || level == "TICK";
        }
    }
}