using ezesoft.xapi.generated;
using EzeSoft.XAPI;
using StreamingClientApp.Utils;

namespace StreamingClientApp.Handlers
{
    /// <summary>
    /// Handles sending subscription requests to the streaming service.
    /// </summary>
    public class RequestHandler
    {
        private readonly EMSXAPILibrary _lib;
        private readonly StreamingClientApp.Core.StreamingClient _streamingClient;
        private readonly StreamingLogger _logger;

        public RequestHandler(StreamingClientApp.Core.StreamingClient streamingClient)
        {
            _lib = EMSXAPILibrary.Get();
            _streamingClient = streamingClient;
            _logger = streamingClient.Logger; // Get logger from streaming client
        }

        /// <summary>
        /// Sends a subscription request for adding symbols.
        /// </summary>
        public async Task AddSymbolsAsync(string[] symbols, string marketDataLevel)
        {
            _logger.LogSubscription("ADD_SYMBOL", symbols, marketDataLevel);
            await SendSubscriptionRequest("ADD_SYMBOL", symbols, marketDataLevel);
            _streamingClient.AddSubscriptions(symbols, marketDataLevel);
        }

        /// <summary>
        /// Sends a subscription request for removing symbols.
        /// </summary>
        public async Task RemoveSymbolsAsync(string[] symbols)
        {
            _logger.LogSubscription("REMOVE_SYMBOL", symbols);
            await SendSubscriptionRequest("REMOVE_SYMBOL", symbols, "");
            _streamingClient.RemoveSubscriptions(symbols);
        }

        /// <summary>
        /// Sends a subscription request for changing subscription levels.
        /// </summary>
        public async Task ChangeSubscriptionAsync(string[] symbols, string marketDataLevel)
        {
            _logger.LogSubscription("CHANGE_SUBSCRIPTION", symbols, marketDataLevel);
            await SendSubscriptionRequest("CHANGE_SUBSCRIPTION", symbols, marketDataLevel);
            _streamingClient.UpdateSubscriptions(symbols, marketDataLevel);
        }

        private async Task SendSubscriptionRequest(string requestType, string[] symbols, string marketDataLevel)
        {
            var request = new MarketDataStreamRequest
            {
                UserToken = _lib.UserToken,
                RequestType = requestType,
                Request = true,
                Advise = true
            };

            if (symbols.Length > 0)
            {
                request.Symbols.AddRange(symbols);
            }

            if (!string.IsNullOrEmpty(marketDataLevel))
            {
                request.MarketDataLevel = marketDataLevel;
            }

            // Log the detailed request before sending
            _logger.LogSubscriptionRequest(requestType, symbols, marketDataLevel, request.UserToken);

            await _streamingClient.SendRequest(request);

            var timestamp = DateTime.Now;
            var symbolList = symbols.Length > 0 ? string.Join(", ", symbols) : "NONE";

            lock (_streamingClient.ConsoleLock)
            {
                var logMessage = $"Sent {requestType}: Level={marketDataLevel}, Symbols=[{symbolList}]";
                Console.WriteLine(DataFormatter.FormatLogMessage(logMessage, timestamp));
            }
        }
    }
}