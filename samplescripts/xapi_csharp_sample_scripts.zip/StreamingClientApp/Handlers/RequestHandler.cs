using ezesoft.xapi.generated;
using EzeSoft.XAPI;
using StreamingClientApp.Utils;

namespace StreamingClientApp.Handlers
{
    /// <summary>
    /// Handles sending subscription requests to the streaming service.
    /// </summary>
    public class RequestHandler
    {
        private readonly EMSXAPILibrary _lib;
        private readonly StreamingClientApp.Core.StreamingClient _streamingClient;
        private readonly StreamingLogger _logger;

        public RequestHandler(StreamingClientApp.Core.StreamingClient streamingClient)
        {
            _lib = EMSXAPILibrary.Get();
            _streamingClient = streamingClient;
            _logger = streamingClient.Logger; // Get logger from streaming client
        }

        /// <summary>
        /// Sends a subscription request for adding symbols.
        /// Only sends request for symbols not already subscribed at the specified level.
        /// </summary>
        public async Task AddSymbolsAsync(string[] symbols, string marketDataLevel)
        {
            if (!_streamingClient.IsStreaming)
            {
                Console.WriteLine("Cannot add symbols: streaming is not active.");
                return;
            }

            if (symbols == null || symbols.Length == 0)
            {
                Console.WriteLine("Cannot add symbols: no symbols provided.");
                return;
            }

            var normalisedLevel = marketDataLevel.ToUpperInvariant();
            var symbolsToAdd = symbols.Where(s =>
                !_streamingClient.ActiveSubscriptions.TryGetValue(s, out var levels) ||
                !levels.Contains(normalisedLevel)).ToArray();

            if (symbolsToAdd.Length == 0)
            {
                Console.WriteLine($"All specified symbols are already subscribed at {marketDataLevel}.");
                return;
            }

            if (symbolsToAdd.Length < symbols.Length)
            {
                var skipped = symbols.Except(symbolsToAdd);
                Console.WriteLine($"Skipped {string.Join(", ", skipped)} (already subscribed at {marketDataLevel}).");
            }

            _logger.LogSubscription("ADD_SYMBOL", symbolsToAdd, marketDataLevel);
            await SendSubscriptionRequest("ADD_SYMBOL", symbolsToAdd, marketDataLevel);
            _streamingClient.AddSubscriptions(symbolsToAdd, marketDataLevel);
        }

        /// <summary>
        /// Sends a subscription request for removing symbols at a specific level.
        /// Only the specified level is removed; the symbol remains active at any
        /// other levels it is subscribed to.
        /// Only sends request for symbols actually subscribed at the specified level.
        /// </summary>
        public async Task RemoveSymbolsAsync(string[] symbols, string marketDataLevel)
        {
            if (!_streamingClient.IsStreaming)
            {
                Console.WriteLine("Cannot remove symbols: streaming is not active.");
                return;
            }

            var normalisedLevel = marketDataLevel.ToUpperInvariant();
            var symbolsToRemove = symbols.Where(s =>
                _streamingClient.ActiveSubscriptions.TryGetValue(s, out var levels) &&
                levels.Contains(normalisedLevel)).ToArray();

            if (symbolsToRemove.Length == 0)
            {
                Console.WriteLine($"None of the specified symbols are subscribed at {marketDataLevel}.");
                return;
            }

            if (symbolsToRemove.Length < symbols.Length)
            {
                var skipped = symbols.Except(symbolsToRemove);
                Console.WriteLine($"Skipped {string.Join(", ", skipped)} (not subscribed at {marketDataLevel}).");
            }

            _logger.LogSubscription("REMOVE_SYMBOL", symbolsToRemove, marketDataLevel);
            await SendSubscriptionRequest("REMOVE_SYMBOL", symbolsToRemove, marketDataLevel);
            _streamingClient.RemoveSubscriptions(symbolsToRemove, marketDataLevel);
        }

        /// <summary>
        /// Sends a subscription request for changing subscription levels.
        /// </summary>
        public async Task ChangeSubscriptionAsync(string[] symbols, string marketDataLevel)
        {
            if (!_streamingClient.IsStreaming)
            {
                Console.WriteLine("Cannot change subscription: streaming is not active.");
                return;
            }

            _logger.LogSubscription("CHANGE_SUBSCRIPTION", symbols, marketDataLevel);
            await SendSubscriptionRequest("CHANGE_SUBSCRIPTION", symbols, marketDataLevel);
            _streamingClient.UpdateSubscriptions(symbols, marketDataLevel);
        }

        private async Task SendSubscriptionRequest(string requestType, string[] symbols, string marketDataLevel)
        {
            if (string.IsNullOrWhiteSpace(_lib.UserToken))
            {
                throw new InvalidOperationException("User token is missing. Ensure login completed before sending streaming requests.");
            }

            var request = new MarketDataStreamRequest
            {
                UserToken = _lib.UserToken,
                RequestType = requestType,
                Request = true,
                Advise = true
            };

            if (symbols.Length > 0)
            {
                request.Symbols.AddRange(symbols);
            }

            if (!string.IsNullOrEmpty(marketDataLevel))
            {
                request.MarketDataLevel = marketDataLevel;
            }

            // Log the detailed request before sending
            _logger.LogSubscriptionRequest(requestType, symbols, marketDataLevel, _lib.UserToken);

            await _streamingClient.SendRequest(request);

            var timestamp = DateTime.Now;
            var symbolList = symbols.Length > 0 ? string.Join(", ", symbols) : "NONE";

            lock (_streamingClient.ConsoleLock)
            {
                var logMessage = $"Sent {requestType}: Level={marketDataLevel}, Symbols=[{symbolList}]";
                Console.WriteLine(DataFormatter.FormatLogMessage(logMessage, timestamp));
            }
        }
    }
}