using ezesoft.xapi.generated;
using Grpc.Core;
using System.Collections.Concurrent;
using EzeSoft.XAPI;
using StreamingClientApp.Utils;

namespace StreamingClientApp.Core
{
    /// <summary>
    /// Core streaming client that manages the bidirectional connection and coordinates operations.
    /// </summary>
    public class StreamingClient : IDisposable
    {
        private readonly EMSXAPILibrary _lib;
        private readonly ConcurrentDictionary<string, int> _messageCounters;
        private readonly object _consoleLock;
        private readonly StreamingLogger _logger;
        private readonly ConcurrentDictionary<string, string> _activeSubscriptions;
        private bool _isStreaming;
        private IClientStreamWriter<MarketDataStreamRequest>? _requestStream;
        private CancellationTokenSource? _cancellationTokenSource;
        private AsyncDuplexStreamingCall<MarketDataStreamRequest, MarketDataStreamResponse>? _streamingCall;

        /// <summary>
        /// Initializes a new instance of the StreamingClient class.
        /// </summary>
        public StreamingClient()
        {
            _lib = InitializeApiLibrary();
            _messageCounters = InitializeMessageCounters();
            _consoleLock = new object();
            _logger = InitializeLogger();
            _activeSubscriptions = InitializeSubscriptions();
            _isStreaming = false;
        }

        /// <summary>
        /// Initializes the EMSXAPILibrary instance.
        /// </summary>
        private EMSXAPILibrary InitializeApiLibrary()
        {
            return EMSXAPILibrary.Get();
        }

        /// <summary>
        /// Initializes the message counter dictionary for tracking responses per symbol.
        /// </summary>
        private ConcurrentDictionary<string, int> InitializeMessageCounters()
        {
            return new ConcurrentDictionary<string, int>();
        }

        /// <summary>
        /// Initializes the streaming logger with file and console handlers.
        /// </summary>
        private StreamingLogger InitializeLogger()
        {
            return new StreamingLogger();
        }

        /// <summary>
        /// Initializes the active subscriptions tracking dictionary.
        /// </summary>
        private ConcurrentDictionary<string, string> InitializeSubscriptions()
        {
            return new ConcurrentDictionary<string, string>();
        }

        /// <summary>
        /// Gets a value indicating whether the streaming connection is currently active.
        /// </summary>
        public bool IsStreaming => _isStreaming;

        /// <summary>
        /// Gets the dictionary tracking message counts per symbol for monitoring purposes.
        /// </summary>
        public ConcurrentDictionary<string, int> MessageCounters => _messageCounters;

        /// <summary>
        /// Gets the lock object used for thread-safe console operations.
        /// </summary>
        public object ConsoleLock => _consoleLock;

        /// <summary>
        /// Gets the file path where streaming logs are written.
        /// </summary>
        public string LogFilePath => _logger.LogFilePath;

        /// <summary>
        /// Gets the streaming logger instance for application logging.
        /// </summary>
        public StreamingLogger Logger => _logger;

        /// <summary>
        /// Gets the dictionary tracking active subscriptions (symbol -> market data level).
        /// </summary>
        public ConcurrentDictionary<string, string> ActiveSubscriptions => _activeSubscriptions;

        /// <summary>
        /// Starts the bidirectional streaming connection to the market data service.
        /// Validates that the EMSXAPILibrary and market data service stub are initialized before attempting connection.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        /// <exception cref="InvalidOperationException">Thrown when the library or service stub is not initialized.</exception>
        public async Task StartStreamingAsync()
        {
            try
            {
                // Validate market data service stub is available
                if (_lib == null)
                {
                    throw new InvalidOperationException("EMSXAPILibrary instance is null");
                }

                if (EMSXAPILibrary.Get().MarketDataClient == null)
                {
                    throw new InvalidOperationException("Market data service stub is not initialized");
                }

                // Start the bidirectional streaming
                _streamingCall = EMSXAPILibrary.Get().MarketDataClient.StreamMarketData();

                // Start reading responses in a background task
                _cancellationTokenSource = new CancellationTokenSource();
                var responseTask = ReadResponsesAsync(_streamingCall.ResponseStream, _cancellationTokenSource.Token);

                // Store the request stream for sending commands
                _requestStream = _streamingCall.RequestStream;
                _isStreaming = true;

                // Return control to caller - they can now send requests
                await Task.CompletedTask;

                // Note: Cleanup happens in StopStreamingAsync
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start streaming: {ex.Message}");
                _isStreaming = false;
                throw;
            }
        }

        /// <summary>
        /// Stops the bidirectional streaming connection and completes the request stream.
        /// Cancels any ongoing response processing and performs cleanup.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task StopStreamingAsync()
        {
            try
            {
                _isStreaming = false;

                // Complete the request stream
                if (_requestStream != null)
                {
                    await _requestStream.CompleteAsync();
                }

                // Cancel the response reading task
                _cancellationTokenSource?.Cancel();

                // Dispose of the streaming call
                if (_streamingCall != null)
                {
                    _streamingCall.Dispose();
                    _streamingCall = null;
                }

                // Clear all active subscriptions
                ClearAllSubscriptions();

                // Unsubscribe from all streaming data
                await UnsubscribeFromStreamingAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error stopping streaming: {ex.Message}");
            }
        }

        /// <summary>
        /// Sends a market data stream request to the server.
        /// </summary>
        /// <param name="request">The market data stream request to send.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        /// <exception cref="ArgumentNullException">Thrown when request is null.</exception>
        /// <exception cref="ArgumentException">Thrown when request is invalid.</exception>
        /// <exception cref="InvalidOperationException">Thrown when request stream is not available.</exception>
        public async Task SendRequest(MarketDataStreamRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), "Market data stream request cannot be null.");
            }

            if (string.IsNullOrWhiteSpace(request.RequestType))
            {
                throw new ArgumentException("Request type cannot be null or empty.", nameof(request.RequestType));
            }

            if (_requestStream == null)
            {
                throw new InvalidOperationException("Request stream not available. Ensure streaming is started before sending requests.");
            }

            await _requestStream.WriteAsync(request);
        }

        private async Task ReadResponsesAsync(IAsyncStreamReader<MarketDataStreamResponse> responseStream, CancellationToken cancellationToken)
        {
            try
            {
                await foreach (var response in responseStream.ReadAllAsync(cancellationToken))
                {
                    if (cancellationToken.IsCancellationRequested) break;

                    ProcessMarketDataResponse(response);
                }
            }
            catch (OperationCanceledException)
            {
                // Expected when cancellation is requested
            }
            catch (Exception ex)
            {
                if (_isStreaming && !cancellationToken.IsCancellationRequested)
                {
                    Console.WriteLine($"Error reading responses: {ex.Message}");
                }
            }
            finally
            {
                _isStreaming = false;
            }
        }

        private void ProcessMarketDataResponse(MarketDataStreamResponse response)
        {
            if (response == null)
            {
                _logger.LogError("Received null response");
                return;
            }

            var timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
            var responseType = response.ResponseType ?? "UNKNOWN";
            var symbol = string.IsNullOrEmpty(response.DispName) ? "N/A" : response.DispName;

            // Update message counter
            _messageCounters.AddOrUpdate(symbol, 1, (key, value) => value + 1);

            lock (_consoleLock)
            {
                switch (responseType)
                {
                    case "LEVEL1_DATA":
                        DisplayLevel1Data(response, timestamp, symbol);
                        break;

                    case "LEVEL2_DATA":
                        DisplayLevel2Data(response, timestamp, symbol);
                        break;

                    case "TICK_DATA":
                        DisplayTickData(response, timestamp, symbol);
                        break;

                    case "STATUS_UPDATE":
                        DisplayStatusUpdate(response, timestamp);
                        break;

                    case "ERROR":
                        _logger.LogError(response.Acknowledgement?.Message ?? "Unknown error");
                        break;

                    case "SUCCESS":
                        _logger.LogSuccess(response.Acknowledgement?.Message ?? "Success");
                        break;

                    default:
                        _logger.LogMessage($"Unknown response type: {responseType} for {symbol}");
                        break;
                }
            }
        }

        private void DisplayLevel1Data(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            var bid = DataFormatter.FormatPrice(response.Bid);
            var ask = DataFormatter.FormatPrice(response.Ask);
            var last = DataFormatter.FormatPrice(response.Trdprc1);
            var change = DataFormatter.FormatPrice(response.ChangeLast);
            var high = DataFormatter.FormatPrice(response.High1);
            var low = DataFormatter.FormatPrice(response.Low1);

            var level1Data = $"Bid: {bid} | Ask: {ask} | Last: {last} | Chg: {change} | H: {high} | L: {low}";
            _logger.LogMarketData(symbol, "LEVEL1", level1Data);

            // Display extended fields if available
            if (response.ExtendedFields?.Count > 0)
            {
                var extendedInfo = string.Join(", ", response.ExtendedFields.Select(kv => $"{kv.Key}={kv.Value}"));
                _logger.LogMarketData(symbol, "LEVEL1_EXTENDED", extendedInfo);
            }
        }

        private void DisplayLevel2Data(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            var marketMaker = response.MktMkrId ?? "N/A";
            var bid = DataFormatter.FormatPrice(response.MktMkrBid);
            var ask = DataFormatter.FormatPrice(response.MktMkrAsk);
            var bidSize = response.MktMkrBidsize?.ToString() ?? "N/A";
            var askSize = response.MktMkrAsksize?.ToString() ?? "N/A";
            var exchange = response.ExchName ?? "N/A";
            var status = response.MktMkrStatus ?? "N/A";

            var level2Data = $"MM: {marketMaker} | Bid: {bid}({bidSize}) | Ask: {ask}({askSize}) | Exch: {exchange} | Status: {status}";
            _logger.LogMarketData(symbol, "LEVEL2", level2Data);
        }

        private void DisplayTickData(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            // Process tick data lists if available
            if (response.TrdPrc1List?.Count > 0)
            {
                for (int i = 0; i < response.TrdPrc1List.Count; i++)
                {
                    var price = DataFormatter.FormatPrice(response.TrdPrc1List[i]);
                    var volume = (response.TrdVol1List != null && i < response.TrdVol1List.Count) ? response.TrdVol1List[i].ToString() : "N/A";
                    var tickType = (response.TickTypeList != null && i < response.TickTypeList.Count) ? response.TickTypeList[i].ToString() : "N/A";
                    var exchange = (response.TrdXid1List != null && i < response.TrdXid1List.Count) ? response.TrdXid1List[i] : "N/A";

                    var tickData = $"Price: {price} | Vol: {volume} | Type: {tickType} | Exch: {exchange}";
                    _logger.LogMarketData(symbol, "TICK", tickData);
                }
            }
            else
            {
                // Fallback if no detailed tick data
                var count = response.Count;
                _logger.LogMarketData(symbol, "TICK_COUNT", $"Count: {count}");
            }
        }

        private void DisplayStatusUpdate(MarketDataStreamResponse response, string timestamp)
        {
            var status = response.StatusMessage ?? "Unknown status";
            _logger.LogStatus(status);
        }

        private async Task UnsubscribeFromStreamingAsync()
        {
            try
            {
                _logger.LogMessage("Unsubscribing from all streaming data...");

                if (_lib == null)
                {
                    _logger.LogError("EMSXAPILibrary instance is null");
                    return;
                }

                if (EMSXAPILibrary.Get().MarketDataClient == null)
                {
                    _logger.LogError("Market data service stub is null");
                    return;
                }

                var unsubscribeRequest = new UnSubscribeStreamMarketDataRequest
                {
                    UserToken = EMSXAPILibrary.Get().UserToken
                };

                var response = await EMSXAPILibrary.Get().MarketDataClient.UnSubscribeStreamMarketDataAsync(unsubscribeRequest);

                _logger.LogMessage($"Unsubscribe response: {response.ServerResponse}");

                if (response.Acknowledgement != null)
                {
                    _logger.LogMessage($"Response Code: {response.Acknowledgement.ResponseCode}");
                    if (!string.IsNullOrEmpty(response.Acknowledgement.Message))
                    {
                        _logger.LogMessage($"Message: {response.Acknowledgement.Message}");
                    }
                }

                if (response.OptionalFields?.Count > 0)
                {
                    foreach (var field in response.OptionalFields)
                    {
                        _logger.LogMessage($"{field.Key}: {field.Value}");
                    }
                }
            }
            catch (RpcException rpcEx) when (rpcEx.StatusCode == StatusCode.Unavailable || rpcEx.StatusCode == StatusCode.Cancelled)
            {
                // Network or connection issues - log but don't rethrow during cleanup
                _logger.LogError($"Network error during unsubscribe (non-critical): {rpcEx.Status.Detail}");
            }
            catch (RpcException rpcEx)
            {
                // Other gRPC errors are critical and should be rethrown
                _logger.LogError($"Critical gRPC error during unsubscribe: {rpcEx.Status.Detail}");
                throw new InvalidOperationException($"Failed to unsubscribe from streaming: {rpcEx.Status.Detail}", rpcEx);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error during unsubscribe: {ex.Message}");
                // Non-critical errors are logged but not rethrown to allow graceful cleanup
            }
        }

        /// <summary>
        /// Adds symbols to the active subscriptions tracking dictionary.
        /// </summary>
        /// <param name="symbols">Array of symbol identifiers to add.</param>
        /// <param name="level">The market data level (LEVEL1, LEVEL2, or TICK).</param>
        public void AddSubscriptions(string[] symbols, string level)
        {
            foreach (var symbol in symbols)
            {
                _activeSubscriptions[symbol] = level;
            }
        }

        /// <summary>
        /// Removes symbols from the active subscriptions tracking dictionary.
        /// </summary>
        /// <param name="symbols">Array of symbol identifiers to remove.</param>
        public void RemoveSubscriptions(string[] symbols)
        {
            foreach (var symbol in symbols)
            {
                _activeSubscriptions.TryRemove(symbol, out _);
            }
        }

        /// <summary>
        /// Updates the market data level for existing symbol subscriptions.
        /// </summary>
        /// <param name="symbols">Array of symbol identifiers to update.</param>
        /// <param name="level">The new market data level (LEVEL1, LEVEL2, or TICK).</param>
        public void UpdateSubscriptions(string[] symbols, string level)
        {
            foreach (var symbol in symbols)
            {
                _activeSubscriptions[symbol] = level;
            }
        }

        /// <summary>
        /// Clears all active subscriptions from the tracking dictionary.
        /// </summary>
        public void ClearAllSubscriptions()
        {
            _activeSubscriptions.Clear();
        }

        /// <summary>
        /// Releases managed resources used by the StreamingClient.
        /// Disposes the StreamingLogger which holds file handles and logging resources.
        /// </summary>
        public void Dispose()
        {
            // Dispose the logger to release file handles and logging resources
            _logger?.Dispose();

            // Cancel any ongoing streaming operations
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource?.Dispose();

            // Complete the request stream if still active
            if (_requestStream != null && _isStreaming)
            {
                try
                {
                    // Use synchronous wait with timeout for cleanup in Dispose method
                    var completeTask = _requestStream.CompleteAsync();
                    if (!completeTask.Wait(TimeSpan.FromSeconds(2)))
                    {
                        _logger?.LogWarning("Request stream completion timed out during disposal");
                    }
                }
                catch (Exception ex)
                {
                    // Log but don't throw exceptions during disposal
                    _logger?.LogError($"Error completing request stream during disposal: {ex.Message}");
                }
            }
        }
    }
}
