﻿using System;
using Grpc.Core;
using Grpc.Net.Client;
using ezesoft.xapi.generated;
using static ezesoft.xapi.generated.SubscribeHeartBeatResponse.Types;
using System.Net.Sockets;
using System.Net;
using System.Text;

//SRP Stuff
using Org.BouncyCastle.Crypto.Agreement.Srp;//for Srp6Client
using Org.BouncyCastle.Crypto.Digests;//SHA256Digest
using Org.BouncyCastle.Security;//SecureRandom
using System.Security.Cryptography;//Sha256Managed
using Org.BouncyCastle.Math;//BigInteger

namespace CSharp_XAPI_Client
{
    public static class Helper
    {
        private static readonly string[] HexTbl = Enumerable.Range(0, 256).Select(v => v.ToString("X2")).ToArray();

        public static T[] Concat<T>(T[] initial, params T[][] args)
        {
            return _Concat(initial, args).ToArray();
        }

        private static IEnumerable<T> _Concat<T>(T[] initial, T[][] args)
        {
            int i = 0;
            while (i < initial.Length)
            {
                yield return initial[i];
                i++;
            }
            i = 0;
            while (i < args.Length)
            {
                int j = 0;
                while (j < args[i].Length)
                {
                    yield return args[i][j];
                    j++;
                }
                i++;
            }
        }

        public static byte[] GetBytesFromHexEncoded(string strSource)
        {
            if (strSource.Length % 2 != 0)//invalid string
                return new byte[0];
            return _GetBytesFromHexEncoded(strSource).ToArray();
        }
        public static IEnumerable<byte> _GetBytesFromHexEncoded(string strSource)
        {
            int nLen = strSource.Length / 2;
            int i = 0;
            while (i < nLen)
            {
                yield return Byte.Parse(strSource.Substring(i * 2, 2), System.Globalization.NumberStyles.HexNumber);
                i++;
            }
        }

        /// <summary>
        /// transforms a a byte [] into its hex encoded equivalent
        /// </summary>
        /// <param name="array"> the byte array to be transformed</param>
        /// <returns>
        /// the string corresponding to the byte array
        /// </returns>
        /// <remarks>
        ///		The hex encoding that yperms uses consists of 
        ///		replacing each byte in an array of bytes with the HEX representation.
        ///		thus for example 'á!>'(length 3)  might become 'E1213E' (length 6)
        ///		This is another way of passing an array of bytes through HTTP SOAP without
        ///		 confusing the parsers; 
        /// </remarks>
        public static string GetHexEncodedStringFromBytes(byte[] array)
        {
            return string.Concat(array.Select(i => HexTbl[i]));
        }
    }
    public class EMSXAPILibrary
    {
        private static object instanceLock = new object();
        private static EMSXAPILibrary instance;

        public  ErrorHandler errHandler;

        private GrpcChannel _channel;

        private UtilityServices.UtilityServicesClient _utilitySvcStub;
        private MarketDataService.MarketDataServiceClient _mktDataSvcStub;
        private SubmitOrderService.SubmitOrderServiceClient _orderServiceStub;

        private EMSXAPIConfig config;
        private string userToken;
        private Thread heartbeatThread;

        private bool isLoggedIn;
        private bool heartbeatExitSignal;
        private object loggedInLock = new object();
        private readonly Logger logger;
        public string UserTokenHash { get; set; }
        public bool IsLoggedIn
        {
            get
            {
                lock (loggedInLock)
                {
                    return isLoggedIn;
                }
            }
            set
            {
                lock (loggedInLock)
                {
                    isLoggedIn = value;
                }
            }
        }

        public bool GetIsLoggedIn()
        {
            lock (loggedInLock)
            {
                return isLoggedIn;
            }
        }

        public void SetIsLoggedIn(bool value)
        {
            lock (loggedInLock)
            {
                isLoggedIn = value;
            }
        }
        public string GetUserTokenHash()
        {
            return UserTokenHash;
        }
        public string GetUserToken()
        {
            return userToken;
        }

        public void SetUserToken(string val)
        {
            userToken = val;
            UserTokenHash = SensitiveMask.Sha256(userToken);
        }

        public UtilityServices.UtilityServicesClient getUtilityServiceStub
        {
            get { return _utilitySvcStub; }
        }

        public MarketDataService.MarketDataServiceClient getMarketDataServiceStub
        {
            get { return _mktDataSvcStub; }
        }

        public SubmitOrderService.SubmitOrderServiceClient getOrderServiceStub
        {
            get { return _orderServiceStub; }
        }

        private EMSXAPILibrary(string configFileName)
        {
            config = new EMSXAPIConfig(configFileName);
            logger = new Logger();
            OpenChannel();
        }

        public static void Create(string configFileName)
        {
            lock (instanceLock)
            {
                instance = new EMSXAPILibrary(configFileName);
            }
        }

        public static EMSXAPILibrary Get()
        {
            return instance;
        }

        private GrpcChannel CreateChannel(string hostName, int port)
        {
            GrpcChannelOptions channelOptions;
            string address;
            if (config.IsSslEnabled)
            {
                address = "https://";
                
                channelOptions = new GrpcChannelOptions
                {
                    MaxReceiveMessageSize = config.MaxMessageSize,
                    Credentials = Grpc.Core.ChannelCredentials.SecureSsl
                };
            }
            else
            {
                address = "http://";

                channelOptions = new GrpcChannelOptions
                {
                    MaxReceiveMessageSize = config.MaxMessageSize,
                    Credentials = Grpc.Core.ChannelCredentials.Insecure
                };
            }
            logger.LogMessage("Create Channel");
            return GrpcChannel.ForAddress($"{address}{hostName}:{port}", channelOptions);
        }

        public GrpcChannel Channel
        {
            get
            {
                if (_channel == null)
                {
                    OpenChannel();
                }

                return _channel;
            }
        }

        public GrpcChannel GetChannel()
        {
            if (_channel == null )
            {
                try
                {
                    OpenChannel();
                }
                catch (NetworkFailedException ex)
                {
                    logger.LogMessage("GetChannel - NetworkFailedException " + ex.Message);
                    throw new NetworkFailedException(ex.Message);
                }
                catch (ServerNotAvailableException ex)
                {
                    logger.LogMessage("GetChannel - ServerNotAvailableException " + ex.Message);
                    throw new ServerNotAvailableException(ex.Message);
                }
            }

            return _channel;
        }

        private void InitStubs()
        {
            _utilitySvcStub = new UtilityServices.UtilityServicesClient(_channel);
            _mktDataSvcStub = new MarketDataService.MarketDataServiceClient(_channel);
            _orderServiceStub = new SubmitOrderService.SubmitOrderServiceClient(_channel);
        }

        private static void _CalculateCompleteSRPLoginVars(string strUserName, string strDomain, string strIdentity, string strOldPassword, string strSRPTransactId, string strSRP_s, string strSRP_B, string strSRP_N, string strSRP_g
            , out string strEphA, out string strSRPKey, out string strMc)
        {
            if (
            !string.IsNullOrEmpty(strSRPTransactId)// from StartLoginSRP
             && !string.IsNullOrEmpty(strSRP_s)// from StartLoginSRP
              && !string.IsNullOrEmpty(strSRP_B)// EphB, from StartLoginSRP
               && !string.IsNullOrEmpty(strSRP_N)// SRP_N, from StartLoginSRP
                && !string.IsNullOrEmpty(strSRP_g))// SRP_g, from StartLoginSRP
            {
                Srp6Client cli = new Srp6Client();
                SecureRandom aRandom = new SecureRandom();
                using (SHA256 hashstring = SHA256.Create())
                {
                    cli.Init(new BigInteger(strSRP_N), new BigInteger(strSRP_g), new Sha256Digest(), aRandom);
                    //string salt = ;
                    byte[] b_salt = Helper.GetBytesFromHexEncoded(strSRP_s);
                    byte[] b_Identity = Encoding.ASCII.GetBytes(strIdentity);
                    byte[] b_Password = Encoding.ASCII.GetBytes(strOldPassword);
                    BigInteger ephA = cli.GenerateClientCredentials(b_salt, b_Identity, b_Password);
                    strEphA = ephA.ToString();

                    BigInteger clientKey = cli.CalculateSecret(new BigInteger(strSRP_B));
                    string strClientKey = clientKey.ToString();

                    //SRP_6_cli. client sends proof of session key to server"
                    //M_c = H(H(N) ^ H(g), H(I), s, A, B, K_c)
                    byte[] H_N = hashstring.ComputeHash(new BigInteger(strSRP_N).ToByteArrayUnsigned());
                    byte[] H_g = hashstring.ComputeHash(new BigInteger(strSRP_g).ToByteArrayUnsigned());
                    byte[] N_XOR_g = new byte[H_N.Length];
                    for (int i = 0; i < H_N.Length; i++)
                    {
                        N_XOR_g[i] = (byte)(H_N[i] ^ H_g[i]);
                    }
                    byte[] H_I = hashstring.ComputeHash(b_Identity);
                    byte[] s = b_salt;

                    byte[] A = new BigInteger(strEphA).ToByteArrayUnsigned();
                    byte[] B = new BigInteger(strSRP_B).ToByteArrayUnsigned();
                    byte[] toHash_kC = clientKey.ToByteArrayUnsigned();

                    byte[] k_c = hashstring.ComputeHash(toHash_kC);
                    strSRPKey = Helper.GetHexEncodedStringFromBytes(k_c);
                    byte[] toHash = Helper.Concat(N_XOR_g, H_I, s, A, B, k_c);

                    byte[] Mc = hashstring.ComputeHash(toHash);
                    strMc = Helper.GetHexEncodedStringFromBytes(Mc);
                }
            }
            else
            {
                strEphA = "";
                strSRPKey = "";
                strMc = "";
            }
        }
        public void Login()
        {
            try
            {
                IsLoggedIn = false;
                if (config.Srp_login)
                {
                    string srpTransactId;
                    // Step 1: create request object for StartLoginSrp API
                    var srpLogin = new StartLoginSrpRequest
                    {
                        UserName = config.User,
                        Domain = config.Domain
                    };

                    logger.LogMessage("Connecting...");
                    var respStartLoginSrp = _utilitySvcStub.StartLoginSrp(srpLogin); // step1 of SRP Login process

                    if (respStartLoginSrp.Response == "success")
                    {
                        // Step 2:
                        string uName = config.User;
                        string domainConnect = config.Domain;
                        string identity = $"{uName.ToUpper()}@{domainConnect.ToUpper()}";
                        string pswrdConnect = config.Password;
                        string localeConnect = config.Locale;

                        srpTransactId = respStartLoginSrp.SrpTransactId;
                        string srpG = respStartLoginSrp.Srpg;
                        string srpN = respStartLoginSrp.SrpN;
                        string srpB = respStartLoginSrp.Srpb;
                        string srpSalt = respStartLoginSrp.SrpSalt;

                        string strEphA; string strSRPKey; string strMc;

                        _CalculateCompleteSRPLoginVars(uName, domainConnect, identity, pswrdConnect, srpTransactId, srpSalt, srpB, srpN, srpG,
                        out strEphA, out strSRPKey, out strMc);
                        
                        var srpComplogin = new CompleteLoginSrpRequest
                        { 
                            Identity = identity,
                            SrpTransactId = srpTransactId,
                            StrEphA = strEphA,
                            StrMc = strMc,
                            UserName = uName,
                            Domain = domainConnect.ToUpper(),
                            Locale = localeConnect.ToUpper()
                        };

                        var connectResponse = _utilitySvcStub.CompleteLoginSrp(srpComplogin);
                        if (connectResponse.Response != "success")
                        {
                            logger.LogMessage(connectResponse.Response);
                            return;
                        }
                        SetUserToken(connectResponse.UserToken);
                    }
                    else
                    {
                        logger.LogMessage("Failed to fetch UserToken from SRP login - " + respStartLoginSrp.Response);
                        return;
                    }
                }
                else
                {
                    var connectRequest = new ConnectRequest
                    {
                        UserName = config.User,
                        Domain = config.Domain,
                        Password = config.Password,
                        Locale = config.Locale
                    };

                    var connectResponse = _utilitySvcStub.Connect(connectRequest);
                    if (connectResponse.Response != "success")
                    {
                        logger.LogMessage(connectResponse.Response);
                        return;
                    }
                    SetUserToken(connectResponse.UserToken);
                }

                logger.LogMessage("Connected User - " + UserTokenHash);
                IsLoggedIn = true;
            }
            catch (Exception ex)
            {
                throw new LoginFailedException(ex.Message, ex);
            }
        }

        public void Logout()
        {
            try
            {
                var disConnReq = new DisconnectRequest
                {
                    UserToken = GetUserToken()
                };

                var disconnectResponse = _utilitySvcStub.Disconnect(disConnReq);

                if (disconnectResponse.ServerResponse == "success")
                {
                    logger.LogMessage("Logged out - " + UserTokenHash);
                }
                else
                {
                    var errorMessage = disconnectResponse.OptionalFields["ErrorMessage"];
                    logger.LogMessage(errorMessage);

                }
            }
            catch (Exception e)
            {
                logger.LogMessage(e.StackTrace);
            }
        }

        public void CloseChannel()
        {
            if (_channel != null)
            {
                try
                {
                    _channel.ShutdownAsync().Wait(TimeSpan.FromSeconds(5));
                    logger.LogMessage("Close Channel - " + UserTokenHash);
                }
                catch (Exception e)
                {
                    logger.LogMessage(e.StackTrace);
                }
            }

            _channel = null;
        }

        public void OpenChannel()
        {
            if (!CanConnectToInternet())
            {
                logger.LogMessage("Network not available - ");
                throw new NetworkFailedException("Network not available");
            }

            if (CanConnectToServer())
            {
                CloseChannel();
                _channel = CreateChannel(config.Server, config.Port);
                InitStubs();
                return;
            }
            logger.LogMessage("Server " + config.Server + " not responding, might be down.");
            throw new ServerNotAvailableException("Server " + config.Server + " not responding, might be down.");
        }

        private void Sleep(long delayMS)
        {
            try
            {
                Thread.Sleep(TimeSpan.FromMilliseconds(delayMS));
            }
            catch (Exception e)
            {
                // Ignore exceptions
            }
        }

        public void StartListeningHeartbeat(int reqTimeout)
        {
            if (!IsLoggedIn)
            {
                logger.LogMessage("User needs to login first");
                throw new Exception("User needs to login first");
            }

            SuspendHeartbeatThread();

            heartbeatExitSignal = false;
            heartbeatThread = new Thread(async () =>
            {
                try
                {
                    heartbeatExitSignal = false;
                    bool refreshChannel = false;
                    bool refreshLogin = false;

                    int retryCount = 0;

                    while (IsLoggedIn && retryCount < config.MaxRetryCount)
                    {
                        try
                        {
                            if (heartbeatExitSignal)
                                break;

                            retryCount++;

                            if (refreshChannel)
                            {
                                logger.LogMessage("Refreshing channel" + " - " + UserTokenHash);
                                CloseChannel();
                                OpenChannel();
                            }
                            if (refreshLogin)
                            {
                                logger.LogMessage("Refreshing login" + " - " + UserTokenHash);
                                IsLoggedIn = false;
                                Login();
                            }
                            refreshChannel = false;
                            refreshLogin = false;

                            await ExecSubscribeHeartBeat(reqTimeout);
                        }
                        catch (RpcException)
                        {
                            // need to initialize the channel again but same token can be re-used
                            long delayMS = CalculateDelayMillis(retryCount);
                            logger.LogMessage("Runtime IO error: attempting again(" + retryCount + ") in " + delayMS + " ms..." + " - " + UserTokenHash);

                            refreshChannel = true;
                            refreshLogin = false;
                            Sleep(delayMS);
                        }
                        catch (SessionNotFoundException)
                        {
                            // need to login again
                            refreshLogin = true;
                            refreshChannel = false;
                            long delayMS = CalculateDelayMillis(retryCount);
                            logger.LogMessage("Session not found: attempting login again(" + retryCount + ") in " + delayMS + " ms..." + " - " + UserTokenHash);

                            Sleep(delayMS);
                        }
                        catch (StreamingAlreadyExistsException ex)
                        {
                            // need to login again
                            refreshLogin = false;
                            refreshChannel = false;
                            long delayMS = CalculateDelayMillis(retryCount);
                            logger.LogMessage(ex.Message + " StreamingAlreadyExistsException - " + UserTokenHash);

                            Sleep(delayMS);
                        }
                        catch (ServerNotAvailableException ex)
                        {
                            // need to login again
                            refreshChannel = true;
                            refreshLogin = true;
                            long delayMS = CalculateDelayMillis(retryCount);
                            logger.LogMessage(ex.Message + " ServerNotAvailableException - " + UserTokenHash);
                            Sleep(delayMS);
                        }
                        catch (Exception ex)
                        {
                            logger.LogMessage(ex.ToString() + " Exception - " + UserTokenHash);
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    errHandler?.OnError(ex, this);
                }
            });

            heartbeatThread.Start();
        }

        private async Task ExecSubscribeHeartBeat(int reqTimeout)
        {
            var subscribeRequest = new SubscribeHeartBeatRequest
            {
                UserToken = GetUserToken(),
                TimeoutInSeconds = reqTimeout
            };

            var hbResponseIt = _utilitySvcStub.SubscribeHeartBeat(subscribeRequest);

            
            await foreach (var response in hbResponseIt.ResponseStream.ReadAllAsync())
            {
                if (heartbeatExitSignal)
                    break;

                //var response = hbResponseIt.Current;
                var resStatus = response.Status;
                var serverMsg = response.Acknowledgement.ServerResponse;

                // writeToLog("HeartBeat response status: " + resStatus.ToString());
                logger.LogMessage("[" + GetCurrentTime() + "]" + " HeartBeat status: " + resStatus.ToString() + " | " + serverMsg + "for user token " + GetUserTokenHash());

                if (resStatus == HeartBeatStatus.Dead)
                {
                    logger.LogMessage("Session not found for user token " + GetUserTokenHash());
                    throw new SessionNotFoundException("Session not found for user token " + GetUserToken());
                   
                }
                else if (resStatus == HeartBeatStatus.Unknown) // || resStatus == HeartBeatStatus.Unrecognized
                {
                    logger.LogMessage("Status received as " + resStatus + GetUserTokenHash());
                    throw new Exception("Status received as " + resStatus);
                }
                else if (serverMsg.Equals("Error: Active streaming subscription already exists.", StringComparison.OrdinalIgnoreCase))
                {
                    logger.LogMessage("Heartbeat subscription already exists - " + GetUserTokenHash());
                    throw new StreamingAlreadyExistsException("Heartbeat subscription already exists");
                }
            }            
        }

        private string GetStatusEnumAsStringFromResponse(object obj)
        {
            try
            {
                var objClass = obj.GetType();
                var statusField = objClass.GetField("Status");
                var statusValue = statusField?.GetValue(obj);
                return statusValue?.ToString();
            }
            catch (Exception ex)
            {
                // Handle exception
            }

            return "";
        }

        private string GetCurrentTime()
        {
            DateTime now = DateTime.Now;

            // Define the desired date and time format
            string format = "yyyy-MM-dd HH:mm:ss";

            // Format the date and time using the formatter
            return now.ToString(format);
        }

        private long CalculateDelayMillis(int retryCount)
        {
            return (long)Math.Pow(2, retryCount) * config.RetryDelayMS;
        }

        public void SuspendHeartbeatThread()
        {
            if (heartbeatThread != null)
            {
                if (heartbeatThread.IsAlive)
                {
                    heartbeatThread.Interrupt();
                    heartbeatExitSignal = true;
                }

                while (heartbeatThread.IsAlive)
                {
                    WriteToLog("Waiting for heartbreat thread to stop");
                    Sleep(config.RetryDelayMS);
                }
                heartbeatThread = null;
            }
        }

        private void WriteToLog(string msg) 
        {
            logger.LogMessage(msg);
        }

        private bool CanConnectToInternet()
        {
            try
            {
                var address = Dns.GetHostEntry("www.google.com");
                return true;
            }
            catch (SocketException)
            {
                return false; // Unable to resolve host
            }
            catch (Exception)
            {
                return false; // Other exceptions
            }
        }

        private bool CanConnectToServer()
        {
            using (var socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
            {
                int timeoutMs = 3000; // Set timeout to 3 seconds

                try
                {
                    var address = new IPAddress(Dns.GetHostEntry(config.Server).AddressList[0].GetAddressBytes());


                    IAsyncResult result = socket.BeginConnect(address, config.Port, null, null);

                    bool success = result.AsyncWaitHandle.WaitOne(timeoutMs, true);

                    if(socket.Connected)
                    {
                        socket.EndConnect(result);
                    }

                    return true;
                }
                catch (SocketException)
                {
                    return false;
                }
            }
        }
    }
}
