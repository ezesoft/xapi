﻿using ezesoft.xapi.generated;

namespace CSharp_XAPI_Client
{
    class ExampleGetTodaysActivity
    {

        public ExampleGetTodaysActivity()
        {
            
        }

        public void Run()
        {

            EMSXAPILibrary lib = EMSXAPILibrary.Get();

            TodaysActivityRequest request = new TodaysActivityRequest();
            request.UserToken = lib.GetUserToken();

            // To Filter based on Order Type - set to true
            // request.IncludeUserSubmitOrder = false;
            // request.IncludeUserSubmitStagedOrder = false;
            // request.IncludeUserSubmitCompoundOrder = false;
            // request.IncludeForeignExecution = false;
            // request.IncludeUserSubmitChange = false;
            // request.IncludeUserSubmitCancel = false;
            // request.IncludeExchangeAcceptOrder = false;
            // request.IncludeExchangeTradeOrder = false;
            // request.IncludeUserSubmitTradeReport = false;
            // request.IncludeUserSubmitAllocation = false;
            // request.IncludeUserSubmitAllocationEx = false;
            // request.IncludeClerkReject = false;

            // To Filter based on CurrentStatus as Completed - set to true
            // request.IncludeOnlyCompleted = false;

            // To Filter based UserSubmitStagedOrder and its child - set to true
            // request.UserSubmitStagedOrderFullInfo = false;

            TodaysActivityResponse response = lib.getUtilityServiceStub.GetTodaysActivity(request);

            Console.WriteLine(response.Acknowledgement.ServerResponse);

            int i = 0;
            foreach (OrderResponse orderRecord in response.OrderRecordList)
            {
                Console.WriteLine($"--------------- Order Num: {i} START ---------------");
                Console.WriteLine(orderRecord);
                Console.WriteLine($"--------------- Order Num: {i} END ---------------");
                i++;
            }
        }
    }
}
