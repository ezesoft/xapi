using ezesoft.xapi.generated;
using Grpc.Core;
using System.Collections.Concurrent;

namespace CSharp_XAPI_Client
{
    /// <summary>
    /// Example demonstrating bidirectional streaming market data using StreamMarketData and UnSubscribeStreamMarketData APIs.
    /// This example shows how to subscribe to Level1, Level2, and Tick data for multiple symbols using bidirectional streaming.
    /// </summary>
    class ExampleBidirectionalStreamMarketData
    {
        private readonly EMSXAPILibrary _lib;
        private readonly ConcurrentDictionary<string, int> _messageCounters;
        private readonly object _consoleLock = new object();
        private bool _isStreaming = false;

        public ExampleBidirectionalStreamMarketData()
        {
            _lib = EMSXAPILibrary.Get();
            _messageCounters = new ConcurrentDictionary<string, int>();
        }

        public async Task Run()
        {
            try
            {
                Console.WriteLine("=== Bidirectional Stream Market Data Example ===");
                Console.WriteLine("This example demonstrates Level1, Level2, and Tick data streaming");
                Console.WriteLine();

                // Start the bidirectional streaming
                using var call = _lib.getMarketDataServiceStub.StreamMarketData();
                
                // Start reading responses in a background task
                var responseTask = ReadResponsesAsync(call.ResponseStream);
                
                // Send initial subscription requests
                await SendSubscriptionRequestsAsync(call.RequestStream);
                
                // Wait for responses and demonstrate various operations
                await DemonstrateStreamingOperationsAsync(call.RequestStream);
                
                // Complete the request stream
                await call.RequestStream.CompleteAsync();
                
                // Wait for the response task to complete
                await responseTask;
                
                // Unsubscribe from all streaming data
                await UnsubscribeFromStreamingAsync();
                
                Console.WriteLine("\n=== Streaming completed successfully ===");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in bidirectional streaming: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
            }
        }

        private async Task ReadResponsesAsync(IAsyncStreamReader<MarketDataStreamResponse> responseStream)
        {
            try
            {
                _isStreaming = true;
                
                await foreach (var response in responseStream.ReadAllAsync())
                {
                    if (!_isStreaming) break;
                    
                    ProcessMarketDataResponse(response);
                }
            }
            catch (Exception ex)
            {
                if (_isStreaming)
                {
                    Console.WriteLine($"Error reading responses: {ex.Message}");
                }
            }
            finally
            {
                _isStreaming = false;
            }
        }

        private void ProcessMarketDataResponse(MarketDataStreamResponse response)
        {
            var timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
            var responseType = response.ResponseType ?? "UNKNOWN";
            var symbol = response.DispName ?? "N/A";
            
            // Update message counter
            _messageCounters.AddOrUpdate(symbol, 1, (key, value) => value + 1);
            
            lock (_consoleLock)
            {
                switch (responseType)
                {
                    case "LEVEL1_DATA":
                        ProcessLevel1Response(response, timestamp, symbol);
                        break;
                        
                    case "LEVEL2_DATA":
                        ProcessLevel2Response(response, timestamp, symbol);
                        break;
                        
                    case "TICK_DATA":
                        ProcessTickResponse(response, timestamp, symbol);
                        break;
                        
                    case "STATUS_UPDATE":
                        ProcessStatusResponse(response, timestamp);
                        break;
                        
                    default:
                        Console.WriteLine($"[{timestamp}] Unknown response type: {responseType} for {symbol}");
                        break;
                }
            }
        }

        private void ProcessLevel1Response(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            var bid = FormatPrice(response.Bid);
            var ask = FormatPrice(response.Ask);
            var last = FormatPrice(response.Trdprc1);
            var change = FormatPrice(response.ChangeLast);
            var high = FormatPrice(response.High1);
            var low = FormatPrice(response.Low1);
            
            Console.WriteLine($"?? L1  [{timestamp}] {symbol,-8} | Bid: {bid,8} | Ask: {ask,8} | Last: {last,8} | Chg: {change,7} | H: {high,8} | L: {low,8}");
            
            // Display extended fields if available
            if (response.ExtendedFields?.Count > 0)
            {
                var extendedInfo = string.Join(", ", response.ExtendedFields.Select(kv => $"{kv.Key}={kv.Value}"));
                Console.WriteLine($"     [{timestamp}] {symbol,-8} | Extended: {extendedInfo}");
            }
        }

        private void ProcessLevel2Response(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            var marketMaker = response.MktMkrId ?? "N/A";
            var bid = FormatPrice(response.MktMkrBid);
            var ask = FormatPrice(response.MktMkrAsk);
            var bidSize = response.MktMkrBidsize?.ToString() ?? "N/A";
            var askSize = response.MktMkrAsksize?.ToString() ?? "N/A";
            var exchange = response.ExchName ?? "N/A";
            var status = response.MktMkrStatus ?? "N/A";
            
            Console.WriteLine($"?? L2  [{timestamp}] {symbol,-8} | MM: {marketMaker,-8} | Bid: {bid,8}({bidSize,6}) | Ask: {ask,8}({askSize,6}) | Exch: {exchange,-6} | Status: {status}");
        }

        private void ProcessTickResponse(MarketDataStreamResponse response, string timestamp, string symbol)
        {
            var count = response.Count;
            
            Console.WriteLine($"? TICK [{timestamp}] {symbol,-8} | Count: {count,3}");
            
            // Process tick data lists if available
            if (response.TrdPrc1List?.Count > 0)
            {
                for (int i = 0; i < Math.Min(3, response.TrdPrc1List.Count); i++) // Show first 3 ticks
                {
                    var price = FormatPrice(response.TrdPrc1List[i]);
                    var volume = i < (response.TrdVol1List?.Count ?? 0) ? response.TrdVol1List[i].ToString() : "N/A";
                    var tickType = i < (response.TickTypeList?.Count ?? 0) ? response.TickTypeList[i].ToString() : "N/A";
                    var exchange = i < (response.TrdXid1List?.Count ?? 0) ? response.TrdXid1List[i] : "N/A";
                    
                    Console.WriteLine($"     [{timestamp}] {symbol,-8} | #{i + 1} Price: {price,8} | Vol: {volume,8} | Type: {tickType,-2} | Exch: {exchange,-6}");
                }
                
                if (response.TrdPrc1List.Count > 3)
                {
                    Console.WriteLine($"     [{timestamp}] {symbol,-8} | ... and {response.TrdPrc1List.Count - 3} more ticks");
                }
            }
        }

        private void ProcessStatusResponse(MarketDataStreamResponse response, string timestamp)
        {
            var status = response.StatusMessage ?? "Unknown status";
            Console.WriteLine($"??  STATUS [{timestamp}] {status}");
        }

        private async Task SendSubscriptionRequestsAsync(IClientStreamWriter<MarketDataStreamRequest> requestStream)
        {
            Console.WriteLine("?? Starting subscriptions...");
            
            // Subscribe to Level1 data for major stocks
            await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "AAPL", "MSFT", "GOOGL" }, "LEVEL1");
            await Task.Delay(1000);
            
            // Subscribe to Level2 data for financial stocks
            await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "JPM", "BAC" }, "LEVEL2");
            await Task.Delay(1000);
            
            // Subscribe to Tick data for energy stocks
            await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "XOM", "CVX" }, "TICK");
            await Task.Delay(1000);
        }

        private async Task DemonstrateStreamingOperationsAsync(IClientStreamWriter<MarketDataStreamRequest> requestStream)
        {
            Console.WriteLine("\n?? Receiving initial data for 15 seconds...");
            await Task.Delay(15000);
            
            Console.WriteLine("\n? Adding more symbols...");
            await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "TSLA", "NVDA" }, "LEVEL1");
            await Task.Delay(10000);
            
            Console.WriteLine("\n?? Changing subscription levels...");
            await SendSubscriptionRequest(requestStream, "CHANGE_SUBSCRIPTION", new[] { "AAPL" }, "LEVEL2");
            await Task.Delay(10000);
            
            Console.WriteLine("\n? Removing some symbols...");
            await SendSubscriptionRequest(requestStream, "REMOVE_SYMBOL", new[] { "GOOGL", "BAC" }, "");
            await Task.Delay(10000);
            
            Console.WriteLine("\n?? Final streaming phase for 10 seconds...");
            DisplayMessageStatistics();
            await Task.Delay(10000);
            
            _isStreaming = false;
        }

        private async Task SendSubscriptionRequest(IClientStreamWriter<MarketDataStreamRequest> requestStream, 
            string requestType, string[] symbols, string marketDataLevel)
        {
            var request = new MarketDataStreamRequest
            {
                UserToken = _lib.GetUserToken(),
                RequestType = requestType,
                MarketDataLevel = marketDataLevel,
                Request = true,
                Advise = true
            };
            
            request.Symbols.AddRange(symbols);
            
            await requestStream.WriteAsync(request);
            
            var symbolList = string.Join(", ", symbols);
            var action = requestType switch
            {
                "ADD_SYMBOL" => "Added",
                "REMOVE_SYMBOL" => "Removed",
                "CHANGE_SUBSCRIPTION" => "Changed",
                _ => "Updated"
            };
            
            Console.WriteLine($"?? {action} {marketDataLevel} subscription for: {symbolList}");
        }

        private async Task UnsubscribeFromStreamingAsync()
        {
            try
            {
                Console.WriteLine("\n?? Unsubscribing from all streaming data...");
                
                var unsubscribeRequest = new UnSubscribeStreamMarketDataRequest
                {
                    UserToken = _lib.GetUserToken()
                };
                
                var response = await _lib.getMarketDataServiceStub.UnSubscribeStreamMarketDataAsync(unsubscribeRequest);
                
                Console.WriteLine($"? Unsubscribe response: {response.ServerResponse}");
                
                if (response.Acknowledgement != null)
                {
                    Console.WriteLine($"   Response Code: {response.Acknowledgement.ResponseCode}");
                    if (!string.IsNullOrEmpty(response.Acknowledgement.Message))
                    {
                        Console.WriteLine($"   Message: {response.Acknowledgement.Message}");
                    }
                }
                
                if (response.OptionalFields?.Count > 0)
                {
                    foreach (var field in response.OptionalFields)
                    {
                        Console.WriteLine($"   {field.Key}: {field.Value}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"? Error unsubscribing: {ex.Message}");
            }
        }

        private void DisplayMessageStatistics()
        {
            lock (_consoleLock)
            {
                Console.WriteLine("\n?? Message Statistics:");
                Console.WriteLine("????????????????????????????");
                
                if (_messageCounters.IsEmpty)
                {
                    Console.WriteLine("No messages received yet.");
                }
                else
                {
                    foreach (var kvp in _messageCounters.OrderBy(x => x.Key))
                    {
                        Console.WriteLine($"  {kvp.Key,-10}: {kvp.Value,5} messages");
                    }
                    
                    var totalMessages = _messageCounters.Values.Sum();
                    Console.WriteLine($"  {"TOTAL",-10}: {totalMessages,5} messages");
                }
                
                Console.WriteLine("????????????????????????????\n");
            }
        }

        private static string FormatPrice(Price? price)
        {
            if (price != null && !price.Isnull)
            {
                return price.DecimalValue.ToString("F2");
            }
            return "N/A";
        }
    }
}