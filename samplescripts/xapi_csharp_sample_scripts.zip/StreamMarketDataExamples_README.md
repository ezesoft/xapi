# StreamMarketData and UnSubscribeStreamMarketData API Examples

This document provides comprehensive examples for using the bidirectional streaming market data APIs in the C# XAPI Client.

## Overview

The examples demonstrate how to use the following gRPC streaming APIs:
- `StreamMarketData` - Bidirectional streaming for real-time market data
- `UnSubscribeStreamMarketData` - Unary call to stop all streaming subscriptions

## API Methods

### StreamMarketData
- **Type**: Bidirectional Streaming RPC
- **Request**: `stream MarketDataStreamRequest`
- **Response**: `stream MarketDataStreamResponse`
- **Description**: Allows dynamic subscription management for Level1, Level2, and Tick data

### UnSubscribeStreamMarketData  
- **Type**: Unary RPC
- **Request**: `UnSubscribeStreamMarketDataRequest`
- **Response**: `UnSubscribeStreamMarketDataResponse`
- **Description**: Stops all active streaming subscriptions

## Example Files

### 1. ExampleBidirectionalStreamMarketData.cs
**Comprehensive bidirectional streaming example with advanced features:**

- ? Level1, Level2, and Tick data streaming
- ? Dynamic symbol addition and removal
- ? Subscription level changes
- ? Real-time statistics tracking
- ? Professional formatting and error handling
- ? Complete lifecycle management

**Key Features:**
```csharp
// Subscribe to different data levels
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "AAPL", "MSFT" }, "LEVEL1");
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "JPM", "BAC" }, "LEVEL2");
await SendSubscriptionRequest(requestStream, "ADD_SYMBOL", new[] { "XOM", "CVX" }, "TICK");

// Change subscription levels dynamically
await SendSubscriptionRequest(requestStream, "CHANGE_SUBSCRIPTION", new[] { "AAPL" }, "LEVEL2");

// Remove symbols
await SendSubscriptionRequest(requestStream, "REMOVE_SYMBOL", new[] { "MSFT" }, "");
```

### 2. SimpleStreamMarketDataExample.cs
**Simple, focused examples for quick learning:**

- ? Individual demos for Level1, Level2, and Tick data
- ? Clear separation of concerns
- ? Easy to understand code structure
- ? UnSubscribeStreamMarketData demonstration

**Usage:**
```csharp
// Run all demos
await StreamMarketDataQuickDemo.RunAsync();

// Or run individual example
var example = new SimpleStreamMarketDataExample();
await example.Run();
```

## Supported Market Data Types

### Level1 Data
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"LEVEL1"`
- **Response Fields**: Bid, Ask, Last Price, High, Low, Volume, etc.

### Level2 Data  
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"LEVEL2"`
- **Response Fields**: Market Maker ID, Bid/Ask with sizes, Exchange, Status

### Tick Data
- **RequestType**: `"ADD_SYMBOL"`, `"REMOVE_SYMBOL"`, `"CHANGE_SUBSCRIPTION"`
- **MarketDataLevel**: `"TICK"`
- **Response Fields**: Trade prices, volumes, tick types, exchanges

## Request Types

| RequestType | Description |
|-------------|-------------|
| `ADD_SYMBOL` | Subscribe to new symbols |
| `REMOVE_SYMBOL` | Unsubscribe from symbols |
| `CHANGE_SUBSCRIPTION` | Change market data level for existing symbols |

## Sample Output

```
?? L1  [14:23:15.123] AAPL     | Bid:   150.25 | Ask:   150.30 | Last:   150.28 | Chg:  +1.25 | H:   151.00 | L:   149.50
?? L2  [14:23:15.124] JPM      | MM: NSDQ     | Bid:   145.50(  1000) | Ask:   145.55(   500) | Exch: NASDAQ | Status: Active
? TICK [14:23:15.125] XOM      | Count:   3
     [14:23:15.125] XOM      | #1 Price:    89.25 | Vol:      100 | Type: 0  | Exch: NYSE
     [14:23:15.125] XOM      | #2 Price:    89.26 | Vol:      200 | Type: 0  | Exch: NYSE
```

## Integration with Main Application

The examples are integrated into `App.cs`:

```csharp
//Example Bidirectional Streaming Market Data API call
Task bidirectionalStreamingTask = Task.Run(async () =>
{
    ExampleBidirectionalStreamMarketData streamingExample = new ExampleBidirectionalStreamMarketData();
    await streamingExample.Run();
});
```

## Error Handling

The examples include comprehensive error handling:

- gRPC connection failures
- Server-side protobuf compatibility issues
- Authentication token expiration
- Network timeouts
- Graceful cleanup and resource disposal

## Best Practices

1. **Always complete request streams**: Call `CompleteAsync()` when done sending requests
2. **Handle response streams properly**: Use `await foreach` with `ReadAllAsync()`
3. **Implement proper cleanup**: Unsubscribe when done to free server resources
4. **Use cancellation tokens**: For graceful shutdown in production applications
5. **Monitor connection health**: Check acknowledgements and status updates

## Dependencies

- EMSXAPILibrary (initialized and logged in)
- Valid user token
- Network connectivity to market data server
- gRPC.Net.Client
- Google.Protobuf

## Running the Examples

1. Ensure EMSXAPILibrary is properly configured
2. Authenticate and obtain a valid user token
3. Run one of the example classes:

```csharp
// Comprehensive example
var example = new ExampleBidirectionalStreamMarketData();
await example.Run();

// Simple examples
await StreamMarketDataQuickDemo.RunAsync();
```

## Troubleshooting

**Common Issues:**
- **Authentication failures**: Ensure valid user token
- **Connection timeouts**: Check network connectivity
- **Symbol not found**: Verify symbol format (e.g., "AAPL" not "AAPL.US")
- **Protobuf Duration warnings**: These are server-side issues and can be safely ignored

**Debug Tips:**
- Enable logging in EMSXAPILibrary
- Monitor console output for real-time updates
- Check server acknowledgement responses
- Verify symbol subscription status before changing levels