﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_XAPI_Client
{
    class SensitiveMask
    {
        /// <summary>
        /// Return a string suitable for logging (null for an empty or null parameter).
        /// </summary>
        /// <remarks>This is equivalent to the hash algorithm used by logging on the DPerms side.</remarks>
        public static string Sha256(string sensitive, string valueIfEmpty = null)
        {
            if (string.IsNullOrWhiteSpace(sensitive))
            {
                return valueIfEmpty;
            }
            // If changing this code be sure that the output is the same to support cross-correlation with DPerms token logging.
            var utfBytes = Encoding.UTF8.GetBytes(sensitive);
            byte[] hashBytes;
            using (var sha256Managed = new System.Security.Cryptography.SHA256Managed())
            {
                hashBytes = sha256Managed.ComputeHash(utfBytes, 0, Encoding.UTF8.GetByteCount(sensitive));
            }
            return Convert.ToBase64String(hashBytes);
        }
    }
}
