# EMS XAPI Java Client Library

A comprehensive Java client library for the EMS (Execution Management System) XAPI, providing access to market data, order management, and utility services through gRPC-based communication.

## Features

### 🚀 Core Capabilities
- **Market Data**: Real-time and historical market data streaming
- **Order Management**: Complete order lifecycle management (submit, modify, cancel)
- **Authentication**: Secure SRP (Secure Remote Password) authentication
- **Utility Services**: Account management, position tracking, and system utilities

### 🛠️ Technical Features
- **gRPC-based Communication**: High-performance, type-safe API calls
- **Protocol Buffers**: Efficient serialization with .proto definitions
- **Automatic Reconnection**: Built-in connection management and retry logic
- **Async APIs**: CompletableFuture support for non-blocking operations
- **Streaming Support**: Bidirectional streaming for real-time data

## Prerequisites

- **Java**: JDK 17 or higher
- **Build Tool**: Gradle 8.1+ (included via Gradle Wrapper)
- **Network**: Internet connection for server communication

## Installation

### Clone the Repository
```bash
git clone <repository-url>
```

### Build the Project
```bash
# Using Gradle Wrapper (recommended)
./gradlew build

# Or using system Gradle
gradle build
```

### Verify Installation
```bash
./gradlew test
```

### Project Structure

```
Client/Java/com.ezesoft.xapi/
├── app/
│   ├── build.gradle           # Gradle build configuration
│   └── src/
│       ├── main/
│       │   ├── java/          # Java source files
│       │   └── proto/         # Protocol buffer definitions
│       └── test/              # Unit tests
├── gradle/wrapper/            # Gradle wrapper files
├── config.cfg                 # Configuration template
└── README.md                  # This file
```

### Building from Source

```bash
# Clean build
./gradlew clean build

# Generate protobuf classes
./gradlew generateProto

# Run tests
./gradlew test

# Create JAR
./gradlew jar
```

## Configuration

### Configuration File (config.cfg)

Create a `config.cfg` file in the project root with the following parameters:

```properties
# Authentication
user=your_username
password=your_password
domain=your_domain

# Server Connection
server=your_server_address
port=your_port_number
ssl=true

# Authentication Method
# Set to true to use SRP (Secure Remote Password) authentication
# Set to false to use regular password authentication
srpLogin=false

# Localization
locale=en_US

# SSL Configuration (required when ssl=true)
# Path to the certificate file in PEM format
# Can be absolute path or relative to the working directory
certFilePath=certificate_file_path

# Connection Settings
keepAliveTime=3600000
keepAliveTimeout=30000
maxRetryCount=3
retryDelayMS=1000
```

### Certificate File Setup

When SSL is enabled (`ssl=true`), you must provide a valid certificate file:

1. **Certificate File Location**: Place your certificate file (e.g., `roots_qa.pem`) in the project root directory or specify the full path.

2. **Certificate Format**: The certificate file must be in PEM format containing the server's root certificate.

3. **Path Configuration**:
   - **Relative Path**: `certFilePath=roots_qa.pem` (recommended for project root)
   - **Absolute Path**: `certFilePath=/full/path/to/certificate.pem`
   - **Current Directory**: `certFilePath=./certificate.pem`

4. **Default Certificate**: A QA certificate file `roots_qa.pem` is included in the project root for testing purposes.

### Authentication Methods

The client supports two authentication methods:

#### Regular Authentication (`srpLogin=false`)
- Uses standard username/password authentication
- Password is sent directly to the server
- Default method for backward compatibility

#### SRP Authentication (`srpLogin=true`)
- Uses Secure Remote Password (SRP) protocol
- Provides enhanced security by never sending the password in plain text
- Implements SRP-6a cryptographic protocol
- More secure alternative to regular authentication

**Note**: SRP authentication requires server support and appropriate user credentials. The client implementation is complete and functional, but the server must be configured to accept SRP authentication for the specified user/domain combination. If SRP login fails, the server will return an error indicating that SRP is not supported for those credentials.

### Configuration Method

The primary configuration method is through the `config.cfg` file. All settings should be configured in this file as described above.

## Quick Start

### 1. Basic Example

```java
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;

public class MyFirstExample implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = EMSXAPILibrary.Get();

        // Your API calls here
        System.out.println("User Token: " + lib.getUserToken());
    }

    public String getExampleName() {
        return "My First Example";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new MyFirstExample());
    }
}
```

### 2. Run an Example

```bash
# Run an example
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetLevel1MarketData"
```

### 3. Run All Examples

Create custom scripts or run examples individually based on your testing requirements.

## API Reference

### Market Data APIs

| Method | Description |
|--------|-------------|
| `getLevel1MarketData()` | Get real-time level 1 market data |
| `getLevel2MarketData()` | Get real-time level 2 market data |
| `getTickData()` | Get historical tick data |
| `getDailyBars()` | Get daily price bars |
| `subscribeTickData()` | Stream real-time tick data |
| `subscribeLevel1Ticks()` | Stream real-time Level 1 market data |
| `subscribeLevel2Ticks()` | Stream real-time Level 2 market data |
| `streamMarketData()` | Bidirectional streaming with dynamic subscriptions |

### Order Management APIs

| Method | Description |
|--------|-------------|
| `submitOrder()` | Submit new orders |
| `cancelOrder()` | Cancel existing orders |
| `modifyOrder()` | Modify order parameters |
| `getOrderStatus()` | Get order status information |
| `subscribeOrderUpdates()` | Subscribe to order status updates |

### Utility APIs

| Method | Description |
|--------|-------------|
| `getAccountBalances()` | Get account balance information |
| `getPositions()` | Get current positions |
| `getUserInfo()` | Get user account information |

## Examples

The Java client library includes comprehensive examples demonstrating all major API functionalities. Each example implements the `ExampleRunner.RunnableExample` interface and can be executed using the Gradle tasks.

### Running Examples

```bash
# Run an example
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetLevel1MarketData"
```

### Market Data Examples

#### Level 1 Market Data
**Example**: `ExampleGetLevel1MarketData`  
**Purpose**: Retrieve real-time Level 1 market data for specified symbols  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetLevel1MarketData"
```

#### Level 1 Tick Subscription
**Example**: `ExampleSubscribeLevel1Ticks`  
**Purpose**: Subscribe to real-time Level 1 market data updates via streaming  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleSubscribeLevel1Ticks"
```

#### Level 2 Tick Subscription
**Example**: `ExampleSubscribeLevel2Ticks`  
**Purpose**: Subscribe to real-time Level 2 market data (order book) updates  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleSubscribeLevel2Ticks"
```

#### Bidirectional Stream Market Data
**Example**: `ExampleStreamMarketData`  
**Purpose**: Demonstrate bidirectional streaming for dynamic market data subscriptions  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleStreamMarketData"
```

#### Historical Tick Data
**Example**: `ExampleGetTickData`  
**Purpose**: Retrieve historical tick-by-tick market data for analysis  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetTickData"
```

#### Daily/Weekly/Monthly Bars
**Example**: `ExampleGetDailyWeeklyMonthlyBars`  
**Purpose**: Get aggregated price bars (OHLC) for different timeframes  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetDailyWeeklyMonthlyBars"
```

#### Intraday Bars
**Example**: `ExampleGetIntradayBars`  
**Purpose**: Retrieve intraday price bars for short-term analysis  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.marketdata.ExampleGetIntradayBars"
```

### Order Management Examples

#### Submit Single Order
**Example**: `ExampleSubmitSingleOrder`  
**Purpose**: Place individual equity orders in the market  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.order.ExampleSubmitSingleOrder"
```

#### Submit Basket Order
**Example**: `ExampleSubmitBasketOrder`  
**Purpose**: Execute multiple orders as a single basket transaction  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.order.ExampleSubmitBasketOrder"
```

#### Order Details by ID
**Example**: `ExampleGetOrderDetailByOrderId`  
**Purpose**: Retrieve complete order information using order identifier  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.order.ExampleGetOrderDetailByOrderId"
```

#### Order Details by Date Range
**Example**: `ExampleGetOrderDetailByDateRange`  
**Purpose**: Retrieve orders within specified date ranges  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.order.ExampleGetOrderDetailByDateRange"
```

#### Modify Orders
**Example**: `ExampleChangePairOrder`  
**Purpose**: Modify existing pair orders (quantity, price, etc.)  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.order.ExampleChangePairOrder"
```

### Utility Examples

#### Account Balances
**Example**: `ExampleGetTodaysBalances`  
**Purpose**: Retrieve current account balance information  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.utility.ExampleGetTodaysBalances"
```

#### Net Positions
**Example**: `ExampleGetTodaysNetPositions`  
**Purpose**: Get aggregated position summaries across accounts  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.utility.ExampleGetTodaysNetPositions"
```

#### Trading Activity
**Example**: `ExampleGetTodaysActivity`  
**Purpose**: Retrieve today's trading activity and executions  
**Usage**:
```bash
./gradlew runExample --args="com.ezesoft.xapi.utility.ExampleGetTodaysActivity"
```

## Troubleshooting

### Common Issues

#### Authentication Failures
- Check credentials in config.cfg
- Verify server connectivity
- Ensure correct domain configuration

#### Connection Issues
- Verify server address and port
- Check SSL certificate configuration
- Confirm network connectivity

#### SSL Certificate Issues

**Common Problems:**
- Certificate file not found
- Invalid certificate format
- Incorrect file path

**Solutions:**

1. **Verify Certificate File Exists**:
   ```bash
   # Check if certificate file exists
   ls -la roots_qa.pem
   ```

2. **Correct Configuration**:
   ```properties
   # config.cfg
   ssl=true
   certFilePath=roots_qa.pem
   ```

3. **Path Resolution**: The application searches for the certificate file relative to the working directory. Ensure you're running the application from the correct directory or use absolute paths.

4. **Certificate Format**: Ensure your certificate file is in PEM format with proper `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----` markers.

### Debug Mode

Enable detailed logging:

```bash
java -Demsxapi.debug=true -Djava.util.logging.level=FINE -cp "app/build/libs/app.jar" com.ezesoft.xapi.example.ExampleClass
```

### Response Codes

The API uses standardized response codes in the `ServerAcknowledgement` message:

| Response Code | Value | Description | Solution |
|---------------|-------|-------------|----------|
| `SUCCESS` | 0 | Operation completed successfully | No action required |
| `WARNING` | 1 | Operation completed with warnings | Review optional fields for details |
| `FAILED` | 2 | Operation failed | Check the Message field for specific error details |
| `ERROR` | 3 | Server-side error occurred | Contact system administrator |
| `TIMED_OUT` | 4 | Operation timed out | Retry the operation or check network connectivity |
| `SESSION_NOT_FOUND` | 5 | Session not found or expired | Re-authenticate and retry |

## Support

For support and questions:
- **Documentation**: [API Reference](api-reference.md)
- **Examples**: [Example Guide](examples.md)
- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-repo/discussions)

---

**Java Version**: 17+  
**Protocol**: gRPC with Protocol Buffers  
**Authentication**: Dual support for SRP-6a and Connect API