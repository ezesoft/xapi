package com.ezesoft.xapi.marketdata;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubscribeLevel1Ticks extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        List<String> symbolsList = new ArrayList<>();
        symbolsList.add("VOD.LSE");
        symbolsList.add("BARC.LSE");
        symbolsList.add("GSK.LSE");

        Level1MarketDataRequest req = Level1MarketDataRequest.newBuilder()
                                        .setUserToken(lib.getUserToken())
                                        .setAdvise(true)
                                        .setRequest(true)
                                        .addAllSymbols(symbolsList)
                                        .build();

        Iterator<Level1MarketDataResponse> responseIt =  lib.getMarketDataServiceStub().subscribeLevel1Ticks(req);
        while(responseIt.hasNext()){
            Level1MarketDataResponse data = responseIt.next();

            printResponseHeader("Subscribe Level 1 Ticks");
            System.out.println(data.toString());
            printResponseFooter();
         }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Level 1 Ticks";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeLevel1Ticks());
    }
}
