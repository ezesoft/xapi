package com.ezesoft.xapi;

import com.ezesoft.xapi.ExampleRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Base class for EMS XAPI examples to reduce code duplication.
 * Provides common error handling and library initialization.
 */
public abstract class BaseExample implements ExampleRunner.RunnableExample {

    private static final Logger logger = LoggerFactory.getLogger(BaseExample.class);

    @Override
    public final void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();
            doRun(lib);
        } catch (Exception ex) {
            logger.error("Error in {}: {}", getExampleName(), ex.getMessage(), ex);
        }
    }

    /**
     * Utility method to print common response header.
     */
    protected void printResponseHeader(String title) {
        System.out.println("------------------------------");
        System.out.println(title);
    }

    /**
     * Utility method to print server response.
     */
    protected void printServerResponse(com.ezesoft.xapi.generated.Utilities.ServerAcknowledgement response) {
        System.out.println("Server Response: " + response.getServerResponse());
    }

    /**
     * Utility method to print response footer.
     */
    protected void printResponseFooter() {
        System.out.println("------------------------------");
    }

    /**
     * Implement this method with the specific example logic.
     * The EMSXAPILibrary is already initialized and authenticated.
     *
     * @param lib The initialized EMSXAPILibrary instance
     * @throws Exception if the example execution fails
     */
    protected abstract void doRun(EMSXAPILibrary lib) throws Exception;
}