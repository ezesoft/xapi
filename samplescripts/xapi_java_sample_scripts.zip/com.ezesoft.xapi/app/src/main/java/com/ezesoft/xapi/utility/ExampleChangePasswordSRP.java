package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.ChangePasswordSRPRequest;
import com.ezesoft.xapi.generated.Utilities.ChangePasswordSRPResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleChangePasswordSRP implements ExampleRunner.RunnableExample {
    public void run() {
        try {
            // Note: Password changes are typically handled through admin interfaces
            // This example shows how to use the ChangePasswordSRP method directly
            ChangePasswordSRPRequest req = ChangePasswordSRPRequest.newBuilder()
                    .setTransactId("transaction_id")
                    .setUserName("testuser")
                    .setDomain("testdomain")
                    .setOldPassword("old_password")
                    .setNewPassword("new_password")
                    .build();

            // In a real scenario, you'd have a utility service stub
            // ChangePasswordSRPResponse response = utilityServiceStub.changePasswordSRP(req);

            System.out.println("------------------------------");
            System.out.println("Change Password SRP:");
            System.out.println("Note: Password changes are typically handled through admin interfaces");
            System.out.println("This method allows changing user passwords using SRP protocol");
            System.out.println("Requires proper authentication and authorization");
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Change Password SRP";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleChangePasswordSRP());
    }
}