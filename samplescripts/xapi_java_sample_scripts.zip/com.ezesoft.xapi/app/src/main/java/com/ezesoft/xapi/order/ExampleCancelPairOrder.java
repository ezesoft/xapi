package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.CancelPairOrderRequest;
import com.ezesoft.xapi.generated.Order.CancelPairOrderResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleCancelPairOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example order ID to cancel - replace with actual order ID
        String orderId = "12345678";

        CancelPairOrderRequest request = CancelPairOrderRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setOrderId(orderId)
                .build();

        CancelPairOrderResponse response = lib.getOrderServiceStub().cancelPairOrder(request);

        printResponseHeader("Cancel Pair Order Response");
        System.out.println("Server Response: " + response.getServerResponse());
        System.out.println("Order Cancellation Response received");
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Cancel Pair Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleCancelPairOrder());
    }
}