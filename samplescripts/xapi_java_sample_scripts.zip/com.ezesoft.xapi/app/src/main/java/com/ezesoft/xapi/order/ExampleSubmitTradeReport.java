package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubmitTradeReportRequest;
import com.ezesoft.xapi.generated.Order.SubmitTradeReportResponse;
import com.ezesoft.xapi.generated.Order.TradeType;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubmitTradeReport extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example trade report parameters - replace with actual values
        String symbol = "AAPL";
        String side = "BUY";
        int quantity = 100;
        String account = "ACCOUNT123";
        String route = "ROUTE1";

        SubmitTradeReportRequest request = SubmitTradeReportRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol(symbol)
                .setSide(side)
                .setQuantity(quantity)
                .setAccount(account)
                .setRoute(route)
                .setOrderType(TradeType.newBuilder()
                        .setOrderTypes(TradeType.TypeofOrder.UserSubmitTradeReport)
                        .build())
                .build();

        SubmitTradeReportResponse response = lib.getOrderServiceStub().submitTradeReport(request);

        printResponseHeader("Submit Trade Report Response");
        System.out.println("Server Response: " + response.getServerResponse());
        if (response.getOptionalFieldsMap().containsKey("ErrorMessage")) {
            System.out.println("Error Message: " + response.getOptionalFieldsMap().get("ErrorMessage"));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Submit Trade Report";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitTradeReport());
    }
}