# Java Bidirectional Streaming Market Data Client

This Java implementation provides a command-line interface for bidirectional streaming market data operations, mirroring the functionality of the C# StreamingClientApp.

## Features

- **Bidirectional Streaming**: Real-time market data streaming with the ability to add/remove symbols and change subscription levels
- **Level-Aware Remove**: `REMOVE_SYMBOL` requests are sent with an explicit level and only remove that level subscription
- **Multi-Level Tracking**: Local client state tracks a symbol subscribed at multiple levels concurrently
- **Interactive Command Menu**: User-friendly command-line interface for managing streaming operations
- **Comprehensive Logging**: All streaming data is logged to timestamped files
- **Message Statistics**: Track and display message counts per symbol
- **Status Monitoring**: Real-time status checking and subscription management

## Project Structure

```
streaming/
├── StreamingClientApp.java          # Main application entry point
├── core/
│   └── StreamingClient.java         # Core streaming logic and connection management
├── handlers/
│   ├── RequestHandler.java          # Handles sending requests to the streaming service
│   ├── SymbolManager.java           # Manages user input for symbol operations
│   └── StatusManager.java           # Handles status checking and statistics display
└── utils/
    ├── StreamingLogger.java         # File logging utility for streaming data
    └── DataFormatter.java           # Data formatting utilities
```

## Usage

### Prerequisites

1. Ensure the EMS XAPI Java library is properly configured
2. Valid `config.cfg` file with server connection details
3. Successful authentication credentials

### Running the Application

```bash
# Compile and run the streaming client
./gradlew runStreamingClient
```

Or compile and run manually:

```bash
./gradlew build
java -cp build/libs/*:path/to/dependencies com.ezesoft.xapi.streaming.StreamingClientApp
```

### Command Menu Options

1. **Add symbols to stream**: Subscribe to market data for specific symbols
2. **Remove symbols from stream**: Unsubscribe symbols at a specific market-data level
3. **Change subscription level**: Modify the market data level (LEVEL1/LEVEL2/TICK)
4. **Check streaming status**: Display current streaming status and active subscriptions
5. **Show message statistics**: Display message counts per symbol
6. **Exit**: Stop streaming and exit the application

## Configuration

The application uses the same `config.cfg` file as other EMS XAPI Java examples. Ensure the configuration includes:

- Server host and port
- Authentication credentials
- Connection timeouts
- Other EMS XAPI settings

## Logging

All streaming data is automatically logged to timestamped files in the `logs/` directory:

- Log files are named: `streaming_YYYY-MM-DD_HH-mm-ss.log`
- Each log entry includes timestamp, response type, symbol, and data summary
- Logs are written in real-time for immediate analysis

## Comparison with C# Implementation

This Java implementation mirrors the C# StreamingClientApp with equivalent functionality:

| Feature | C# Implementation | Java Implementation |
|---------|------------------|-------------------|
| Core Streaming | StreamingClient.cs | StreamingClient.java |
| Request Handling | RequestHandler.cs | RequestHandler.java |
| User Input | SymbolManager.cs | SymbolManager.java |
| Status Display | StatusManager.cs | StatusManager.java |
| Logging | StreamingLogger.cs | StreamingLogger.java |
| Data Formatting | DataFormatter.cs | DataFormatter.java |
| Main App | Program.cs | StreamingClientApp.java |

## Error Handling

The application includes comprehensive error handling for:

- Connection failures
- Authentication errors
- Invalid user input
- Streaming interruptions
- File I/O errors

All errors are logged and displayed to the user with appropriate error messages.

## Bidirectional Subscription Semantics

- `ADD_SYMBOL`: Adds the requested level for each symbol if not already present at that level.
- `REMOVE_SYMBOL`: Removes only the requested level for each symbol.
- `CHANGE_SUBSCRIPTION`: Switches between `LEVEL1` and `LEVEL2` while preserving `TICK` subscriptions.

## Thread Safety

The implementation uses thread-safe data structures and synchronization:

- `ConcurrentHashMap` for message counters and subscriptions
- Synchronized console output
- Thread-safe logging operations

## Dependencies

- EMS XAPI Java Library
- gRPC Java libraries
- Protocol Buffers Java libraries
- Java 11 or higher