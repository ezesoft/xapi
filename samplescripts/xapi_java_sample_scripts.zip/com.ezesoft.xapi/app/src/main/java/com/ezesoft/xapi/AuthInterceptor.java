package com.ezesoft.xapi;

import io.grpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * gRPC client interceptor for automatic authentication token injection.
 * Adds the user token to all outgoing requests.
 */
public class AuthInterceptor implements ClientInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);
    private final EMSXAPILibrary library;

    public AuthInterceptor(EMSXAPILibrary library) {
        this.library = library;
    }

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(
            MethodDescriptor<ReqT, RespT> method,
            CallOptions callOptions,
            Channel next) {

        return new ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>(
                next.newCall(method, callOptions)) {

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                // Add authentication token to headers if available
                if (library.getUserToken() != null && !library.getUserToken().isEmpty()) {
                    headers.put(Metadata.Key.of("authorization", Metadata.ASCII_STRING_MARSHALLER),
                               "Bearer " + library.getUserToken());
                    logger.debug("Added authentication token to request headers");
                }

                super.start(responseListener, headers);
            }
        };
    }
}