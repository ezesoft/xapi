package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.StartLoginSrpRequest;
import com.ezesoft.xapi.generated.Utilities.StartLoginSrpResponse;
import com.ezesoft.xapi.generated.Utilities.CompleteLoginSrpRequest;
import com.ezesoft.xapi.generated.Utilities.CompleteLoginSrpResponse;
import com.ezesoft.xapi.generated.Utilities.DisconnectRequest;
import com.ezesoft.xapi.generated.Utilities.DisconnectResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSrpAuthentication implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            System.out.println("=== SRP Authentication & Session Management Example ===");
            System.out.println();

            // Note: In typical usage, SRP authentication is handled automatically by EMSXAPILibrary.Get()
            // This example demonstrates the complete SRP authentication flow for educational purposes

            System.out.println("1. Start Login SRP:");
            System.out.println("Note: SRP authentication is typically handled automatically by EMSXAPILibrary initialization");
            System.out.println("The StartLoginSrp API initiates the Secure Remote Password authentication process");

            // Show the StartLoginSrp request structure (normally handled automatically)
            StartLoginSrpRequest startReq = StartLoginSrpRequest.newBuilder()
                    .setUserName("testuser")
                    .setDomain("testdomain")
                    .build();

            System.out.println("StartLoginSrp Request: User=" + startReq.getUserName() +
                             ", Domain=" + startReq.getDomain());
            System.out.println("This would return SRP parameters (salt, B, etc.) for the client to compute proof");
            System.out.println();

            System.out.println("2. Complete Login SRP:");
            System.out.println("Using the parameters from StartLoginSrp, the client computes the SRP proof");

            // Show the CompleteLoginSrp request structure (normally handled automatically)
            CompleteLoginSrpRequest completeReq = CompleteLoginSrpRequest.newBuilder()
                    .setIdentity("testuser@testdomain")
                    .setSrpTransactId("transaction_id_from_start")
                    .setStrEphA("ephemeral_a_value")
                    .setStrMc("proof_value")
                    .setUserName("testuser")
                    .setDomain("testdomain")
                    .setLocale("en_US")
                    .build();

            System.out.println("CompleteLoginSrp Request: Identity=" + completeReq.getIdentity() +
                             ", TransactionId=" + completeReq.getSrpTransactId());
            System.out.println("This completes authentication and returns a user token");
            System.out.println();

            // Get library instance (this handles SRP authentication automatically)
            lib = EMSXAPILibrary.Get();
            System.out.println("3. Library initialized with automatic SRP authentication");
            System.out.println("User Token: " + lib.getUserToken());
            System.out.println();

            // Demonstrate Disconnect
            System.out.println("4. Session Cleanup - Disconnect:");
            DisconnectRequest disconnectReq = DisconnectRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .build();

            DisconnectResponse disconnectResponse = lib.getUtilityServiceStub().disconnect(disconnectReq);

            System.out.println("Disconnect Response:");
            System.out.println("Server Response: " + disconnectResponse.getServerResponse());
            if (disconnectResponse.getOptionalFieldsMap().size() > 0) {
                System.out.println("Optional Fields:");
                disconnectResponse.getOptionalFieldsMap().forEach((key, value) ->
                    System.out.println("  " + key + ": " + value));
            }

            System.out.println();
            System.out.println("=== SRP Authentication & Session Management Complete ===");

        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "SRP Authentication & Session Management";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSrpAuthentication());
    }
}