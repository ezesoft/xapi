package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.OrderDetailByOrderIdRequest;
import com.ezesoft.xapi.generated.Order.OrderDetailByOrderIdResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetOrderDetailByOrderId extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example order ID - replace with actual order ID
        String orderId = "12345678";

        OrderDetailByOrderIdRequest request = OrderDetailByOrderIdRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setOrderId(orderId)
                .build();

        OrderDetailByOrderIdResponse response = lib.getOrderServiceStub().getOrderDetailByOrderId(request);

        printResponseHeader("Order Details by Order ID");
        printServerResponse(response.getAcknowledgement());
        System.out.println("Response received successfully");
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Order Detail By Order Id";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOrderDetailByOrderId());
    }
}