package com.ezesoft.xapi.order;

import java.util.Iterator;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoJsonRequest;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoJsonResponse;
import com.ezesoft.xapi.generated.Order.OrderInfoFilters;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubscribeOrderInfoJson extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        OrderInfoFilters filters = OrderInfoFilters.newBuilder()
                .setIncludeOrders(true)
                .setIncludeExecutions(true)
                .setIncludeClerkReject(false)
                .setIncludeExchangeKillOrder(false)
                .build();

        SubscribeOrderInfoJsonRequest req = SubscribeOrderInfoJsonRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setFilters(filters)
                .build();

        Iterator<SubscribeOrderInfoJsonResponse> responseIt = lib.getOrderServiceStub().subscribeOrderInfoJson(req);

        printResponseHeader("Subscribe Order Info JSON");
        System.out.println("Waiting for order info updates...");

        // Process a few responses (in real usage, this would run continuously)
        int count = 0;
        while (responseIt.hasNext() && count < 3) {
            SubscribeOrderInfoJsonResponse data = responseIt.next();
            System.out.println("Order Info JSON: " + data.getOrderInfoJson());
            count++;
        }

        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Subscribe Order Info JSON";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeOrderInfoJson());
    }
}