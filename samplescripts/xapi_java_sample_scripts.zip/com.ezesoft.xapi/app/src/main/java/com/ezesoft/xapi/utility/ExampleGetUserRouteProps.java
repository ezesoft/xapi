package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.GetUserRoutePropsRequest;
import com.ezesoft.xapi.generated.Utilities.GetUserRoutePropsResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetUserRouteProps implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            GetUserRoutePropsRequest req = GetUserRoutePropsRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setFilterRoutesList("SMART,DMA")
                    .setFilterRoutePropsList("MaxOrderSize,MinOrderSize")
                    .build();

            GetUserRoutePropsResponse response = lib.getUtilityServiceStub().getUserRouteProps(req);

            System.out.println("------------------------------");
            System.out.println("Get User Route Properties:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("User Route Properties:");
            response.getUserRoutePropsMap().forEach((route, props) -> {
                System.out.println("  Route: " + route);
                props.getPropertiesMap().forEach((key, value) ->
                    System.out.println("    " + key + ": " + value));
            });
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get User Route Properties";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetUserRouteProps());
    }
}