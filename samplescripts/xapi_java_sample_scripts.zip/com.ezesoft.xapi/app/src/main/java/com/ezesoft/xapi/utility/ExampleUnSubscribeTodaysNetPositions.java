package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.UnSubscribeNetPositionsRequest;
import com.ezesoft.xapi.generated.Utilities.UnSubscribeNetPositionsResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleUnSubscribeTodaysNetPositions implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            UnSubscribeNetPositionsRequest req = UnSubscribeNetPositionsRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .build();

            UnSubscribeNetPositionsResponse response = lib.getUtilityServiceStub().unSubscribeTodaysNetPositions(req);

            System.out.println("------------------------------");
            System.out.println("UnSubscribe Todays Net Positions:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            if (response.getAcknowledgement().getOptionalFieldsMap().size() > 0) {
                System.out.println("Optional Fields:");
                response.getAcknowledgement().getOptionalFieldsMap().forEach((key, value) ->
                    System.out.println("  " + key + ": " + value));
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "UnSubscribe Todays Net Positions";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleUnSubscribeTodaysNetPositions());
    }
}