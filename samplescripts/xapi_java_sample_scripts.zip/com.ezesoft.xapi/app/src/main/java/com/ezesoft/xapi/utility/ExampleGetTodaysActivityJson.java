package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.TodaysActivityJsonRequest;
import com.ezesoft.xapi.generated.Utilities.TodaysActivityJsonResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetTodaysActivityJson implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            TodaysActivityJsonRequest request = TodaysActivityJsonRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)
                    .setIncludeUserSubmitOrder(true)
                    .setIncludeUserSubmitStagedOrder(true)
                    .setIncludeUserSubmitCompoundOrder(true)
                    .setIncludeForeignExecution(true)
                    .setIncludeUserSubmitChange(true)
                    .setIncludeUserSubmitCancel(true)
                    .setIncludeExchangeAcceptOrder(true)
                    .setIncludeExchangeTradeOrder(true)
                    .setIncludeUserSubmitTradeReport(true)
                    .setIncludeUserSubmitAllocation(true)
                    .setIncludeUserSubmitAllocationEx(true)
                    .setIncludeClerkReject(true)
                    .setIncludeOnlyCompleted(true)
                    .build();

            TodaysActivityJsonResponse response = lib.getUtilityServiceStub().getTodaysActivityJson(request);

            System.out.println("------------------------------");
            System.out.println("Today's Activity JSON:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Activity JSON: " + response.getTodaysActivityJson());
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Todays Activity Json";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetTodaysActivityJson());
    }
}