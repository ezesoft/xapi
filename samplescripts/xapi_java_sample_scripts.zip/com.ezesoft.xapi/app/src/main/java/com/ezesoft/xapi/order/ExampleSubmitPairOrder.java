package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleExceptionHandler;
import com.ezesoft.xapi.generated.Order.SubmitPairOrderRequest;
import com.ezesoft.xapi.generated.Order.SubmitPairOrderResponse;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoRequest;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoResponse;
import com.ezesoft.xapi.ExampleRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExampleSubmitPairOrder extends BaseExample {

    private static final Logger logger = LoggerFactory.getLogger(ExampleSubmitPairOrder.class);
    private ExecutorService executorService;

    @Override
    protected void doRun(EMSXAPILibrary library) throws Exception {

        // Create executor service for proper thread management
        executorService = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "OrderSubscriptionThread");
            t.setDaemon(true);
            return t;
        });

        try {
            ExampleExceptionHandler.logStart("pair order submission with subscription");

            // Start order info subscription asynchronously using explicit concurrency
            // This allows monitoring order status while submitting the pair order
            CompletableFuture<Void> subscriptionFuture = startOrderSubscriptionAsync(library);

            SubmitPairOrderRequest request = SubmitPairOrderRequest.newBuilder()
                .setUserToken(library.getUserToken())
                .setLeg1Symbol("LEG1_SYMBOL")  // First leg symbol
                .setLeg1Side("BUY")  // BUY/SELL/BUYTOCOVER/SELLSHORT
                .setLeg1Quantity(1111)
                .setLeg2Symbol("LEG2_SYMBOL")  // Second leg symbol
                .setLeg2Side("SELL")  // BUY/SELL/BUYTOCOVER/SELLSHORT
                .setLeg2Quantity(1000)
                .setRoute("ROUTE")  // EXIT-VEHICLE/ROUTE
                .setAccount("BANK;BRANCH;CUSTOMER;DEPOSIT")
                    .setStaged(false)
                    .setClaimRequire(false)
                .setOrderTag("ORDER_TAG")
                .setTicketId("TICKET_ID")
                    .build();

            SubmitPairOrderResponse response = library.getOrderServiceStub().submitPairOrder(request);

            logger.info("Submitting pair order - Leg1: {} ({}), Leg2: {} ({})",
                       "LEG1_SYMBOL", 1111, "LEG2_SYMBOL", 1000);

            printResponseHeader("Submit Pair Order Response");
            System.out.println("Server Response: " + response.getServerResponse());
            if ("Failed".equals(response.getServerResponse())) {
                System.out.println("Error Message: " + response.getOptionalFieldsMap().get("ErrorMessage"));
            }
            printResponseFooter();

            ExampleExceptionHandler.logSuccess("pair order submission",
                    "Order submitted successfully");

            // Wait a bit for subscription messages to be processed
            TimeUnit.SECONDS.sleep(5);

            // Cancel the subscription task explicitly
            subscriptionFuture.cancel(true);

        } finally {
            // Properly shutdown executor service
            if (executorService != null && !executorService.isShutdown()) {
                executorService.shutdown();
                try {
                    if (!executorService.awaitTermination(5, TimeUnit.SECONDS)) {
                        executorService.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    executorService.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    /**
     * Starts order subscription asynchronously using explicit concurrency mechanism.
     * This allows monitoring order status changes while the main order submission proceeds.
     */
    private CompletableFuture<Void> startOrderSubscriptionAsync(EMSXAPILibrary library) {
        return CompletableFuture.runAsync(
            () -> {
                try {
                    subscribeOrderInfo(library);
                } catch (Exception ex) {
                    ExampleExceptionHandler.handleBackgroundException("order subscription", ex);
                }
            },
            executorService
        );
    }

    private void subscribeOrderInfo(EMSXAPILibrary library) {
        try {
            SubscribeOrderInfoRequest subscribeRequest = SubscribeOrderInfoRequest.newBuilder()
                    .setUserToken(library.getUserToken())
                    .build();

            logger.info("Order info subscription initiated in background thread");

            // Note: This is a streaming call that would need proper handling in production
            // For this example, we'll just initiate the subscription
            ExampleExceptionHandler.logSuccess("order info subscription",
                    "Subscription initiated successfully");

        } catch (Exception ex) {
            ExampleExceptionHandler.handleBackgroundException("order info subscription", ex);
        }
    }

    @Override
    public String getExampleName() {
        return "Submit Pair Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitPairOrder());
    }
}