package com.ezesoft.xapi;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.LoginFailedException;
import com.ezesoft.xapi.NetworkFailedException;
import com.ezesoft.xapi.ServerNotAvailableException;

/**
 * Test class to verify both SRP and regular connect authentication work with the current configuration
 * Tests authentication based on the srpLogin flag in config.cfg
 */
public class SrpTest {
    public static void main(String[] args) {
        System.out.println("=== Authentication Test ===");
        System.out.println("Testing authentication with current configuration (SRP or Connect based on srpLogin flag)...");

        EMSXAPILibrary lib = null;
        try {
            // This will create the library instance with configuration
            lib = EMSXAPILibrary.create("../config.cfg");
            
            System.out.println("Library created successfully. Now attempting login...");

            // Explicitly perform authentication
            lib.login();

            System.out.println("✅ Authentication successful!");
            System.out.println("User Token: " + lib.getUserToken());
            System.out.println("Is Logged In: " + lib.getIsLoggedIn());

            // Try a simple API call to verify authentication works
            System.out.println("Testing basic connectivity...");
            // Note: Connection status check not available, but successful login indicates connection works

        } catch (NetworkFailedException e) {
            System.out.println("❌ Network connection failed: " + e.getMessage());
            e.printStackTrace();
        } catch (ServerNotAvailableException e) {
            System.out.println("❌ Server not available: " + e.getMessage());
            e.printStackTrace();
        } catch (InterruptedException e) {
            System.out.println("❌ Connection interrupted: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("❌ Unexpected error during authentication: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (lib != null) {
                try {
                    lib.logout();
                    System.out.println("Logged out successfully");
                } catch (Exception e) {
                    System.out.println("Error during logout: " + e.getMessage());
                }
            }
        }

        System.out.println("=== Authentication Test Complete ===");
    }
}