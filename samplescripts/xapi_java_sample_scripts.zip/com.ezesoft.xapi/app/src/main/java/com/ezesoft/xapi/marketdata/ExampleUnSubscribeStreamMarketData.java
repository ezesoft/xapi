package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleUnSubscribeStreamMarketData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        UnSubscribeStreamMarketDataRequest req = UnSubscribeStreamMarketDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .build();

        UnSubscribeStreamMarketDataResponse response = lib.getMarketDataServiceStub().unSubscribeStreamMarketData(req);

        printResponseHeader("Unsubscribed from Stream Market Data");
        System.out.println("Server Response: " + response.getServerResponse());
        if (!response.getOptionalFieldsMap().isEmpty()) {
            System.out.println("Optional Fields: " + response.getOptionalFieldsMap());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "UnSubscribe Stream Market Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleUnSubscribeStreamMarketData());
    }
}