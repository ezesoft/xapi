package com.ezesoft.xapi.streaming.handlers;

import com.ezesoft.xapi.generated.MarketData.MarketDataStreamRequest;
import com.ezesoft.xapi.streaming.core.StreamingClient;
import com.ezesoft.xapi.streaming.utils.MarketDataConstants;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles sending requests to the streaming service.
 * Requires proper authentication through EMSXAPILibrary.
 */
public class RequestHandler {
    private final StreamingClient streamingClient;
    private final String userToken;

    public RequestHandler(StreamingClient streamingClient, String userToken) {
        this.streamingClient = streamingClient;
        this.userToken = userToken;
    }

    /**
     * Adds symbols to the streaming subscription with full parameter support.
     */
    public CompletableFuture<Void> addSymbolsAsync(String[] symbols, String level) {
        if (symbols == null || symbols.length == 0) {
            throw new IllegalArgumentException("Symbols array cannot be null or empty");
        }
        if (level == null || level.trim().isEmpty()) {
            throw new IllegalArgumentException("Market data level cannot be null or empty");
        }
        return addSymbolsAsync(symbols, level, null, null, false, false);
    }

    /**
     * Adds symbols to the streaming subscription with all supported parameters.
     */
    public CompletableFuture<Void> addSymbolsAsync(String[] symbols, String level,
                                                  List<String> regionalExchangeIds,
                                                  List<String> marketSources,
                                                  boolean request, boolean advise) {
        return CompletableFuture.runAsync(() -> {
            try {
                validateRequestParameters(symbols, level);
                validateUserToken();

                String normalizedLevel = level.toUpperCase();

                String[] symbolsToAdd = java.util.Arrays.stream(symbols)
                    .filter(symbol -> {
                        Set<String> levels = streamingClient.getActiveSubscriptions().get(symbol);
                        return levels == null || !levels.contains(normalizedLevel);
                    })
                    .toArray(String[]::new);

                if (symbolsToAdd.length == 0) {
                    System.out.println("All specified symbols are already subscribed at " + normalizedLevel + ".");
                    return;
                }

                System.out.println("Processing add symbols request for: " + String.join(", ", symbolsToAdd) + " at level: " + normalizedLevel);

                for (String symbol : symbolsToAdd) {
                    MarketDataStreamRequest.Builder builder = MarketDataStreamRequest.newBuilder()
                        .setUserToken(userToken)
                        .setRequestType(MarketDataConstants.REQUEST_TYPE_ADD_SYMBOL)
                        .addSymbols(symbol)
                        .setMarketDataLevel(normalizedLevel)
                        .setRequest(request)
                        .setAdvise(advise);

                    // Add optional parameters
                    if (regionalExchangeIds != null && !regionalExchangeIds.isEmpty()) {
                        builder.addAllRegionalExchangeIds(regionalExchangeIds);
                    }
                    if (marketSources != null && !marketSources.isEmpty()) {
                        builder.addAllMarketSource(marketSources);
                    }

                    MarketDataStreamRequest requestMsg = builder.build();
                    streamingClient.sendRequest(requestMsg).join();

                    // Track active subscription
                    streamingClient.getActiveSubscriptions()
                        .computeIfAbsent(symbol, key -> ConcurrentHashMap.newKeySet())
                        .add(normalizedLevel);
                }
            } catch (CompletionException ex) {
                Throwable cause = ex.getCause();
                if (cause instanceof IllegalArgumentException) {
                    System.out.println("Invalid request parameters: " + cause.getMessage());
                } else {
                    System.out.println("Error sending request: " + cause.getMessage());
                }
            } catch (Exception ex) {
                System.out.println("Unexpected error adding symbols: " + ex.getMessage());
            }
        });
    }

    /**
     * Removes symbols from the streaming subscription.
     */
    public CompletableFuture<Void> removeSymbolsAsync(String[] symbols, String level) {
        if (symbols == null || symbols.length == 0) {
            throw new IllegalArgumentException("Symbols array cannot be null or empty");
        }
        if (level == null || level.trim().isEmpty()) {
            throw new IllegalArgumentException("Market data level cannot be null or empty");
        }
        return removeSymbolsAsync(symbols, level, null, null, false, false);
    }

    /**
     * Removes symbols from the streaming subscription with all supported parameters.
     */
    public CompletableFuture<Void> removeSymbolsAsync(String[] symbols, String level,
                                                     List<String> regionalExchangeIds,
                                                     List<String> marketSources,
                                                     boolean request, boolean advise) {
        return CompletableFuture.runAsync(() -> {
            try {
                validateRequestParameters(symbols, level);
                validateUserToken();

                String normalizedLevel = level.toUpperCase();
                String[] symbolsToRemove = java.util.Arrays.stream(symbols)
                    .filter(symbol -> {
                        Set<String> levels = streamingClient.getActiveSubscriptions().get(symbol);
                        return levels != null && levels.contains(normalizedLevel);
                    })
                    .toArray(String[]::new);

                if (symbolsToRemove.length == 0) {
                    System.out.println("None of the specified symbols are subscribed at " + normalizedLevel + ".");
                    return;
                }

                System.out.println("Processing remove symbols request for: " + String.join(", ", symbolsToRemove) + " at level: " + normalizedLevel);

                for (String symbol : symbolsToRemove) {
                    MarketDataStreamRequest.Builder builder = MarketDataStreamRequest.newBuilder()
                        .setUserToken(userToken)
                        .setRequestType(MarketDataConstants.REQUEST_TYPE_REMOVE_SYMBOL)
                        .addSymbols(symbol)
                        .setMarketDataLevel(normalizedLevel)
                        .setRequest(request)
                        .setAdvise(advise);

                    // Add optional parameters
                    if (regionalExchangeIds != null && !regionalExchangeIds.isEmpty()) {
                        builder.addAllRegionalExchangeIds(regionalExchangeIds);
                    }
                    if (marketSources != null && !marketSources.isEmpty()) {
                        builder.addAllMarketSource(marketSources);
                    }

                    MarketDataStreamRequest requestMsg = builder.build();
                    streamingClient.sendRequest(requestMsg).join();

                    // Remove from active subscriptions
                    var subscriptions = streamingClient.getActiveSubscriptions();
                    Set<String> levels = subscriptions.get(symbol);
                    if (levels != null) {
                        levels.remove(normalizedLevel);
                        if (levels.isEmpty()) {
                            subscriptions.remove(symbol);
                        }
                    }
                }
            } catch (CompletionException ex) {
                Throwable cause = ex.getCause();
                if (cause instanceof IllegalArgumentException) {
                    System.out.println("Invalid request parameters: " + cause.getMessage());
                } else {
                    System.out.println("Error sending request: " + cause.getMessage());
                }
            } catch (Exception ex) {
                System.out.println("Unexpected error removing symbols: " + ex.getMessage());
            }
        });
    }

    /**
     * Changes subscription level for symbols.
     */
    public CompletableFuture<Void> changeSubscriptionAsync(String[] symbols, String level) {
        return changeSubscriptionAsync(symbols, level, null, null, false, false);
    }

    /**
     * Changes subscription level for symbols with all supported parameters.
     */
    public CompletableFuture<Void> changeSubscriptionAsync(String[] symbols, String level,
                                                          List<String> regionalExchangeIds,
                                                          List<String> marketSources,
                                                          boolean request, boolean advise) {
        return CompletableFuture.runAsync(() -> {
            try {
                validateRequestParameters(symbols, level);
                validateUserToken();

                String normalizedLevel = level.toUpperCase();

                for (String symbol : symbols) {
                    MarketDataStreamRequest.Builder builder = MarketDataStreamRequest.newBuilder()
                        .setUserToken(userToken)
                        .setRequestType(MarketDataConstants.REQUEST_TYPE_CHANGE_SUBSCRIPTION)
                        .addSymbols(symbol)
                        .setMarketDataLevel(normalizedLevel)
                        .setRequest(request)
                        .setAdvise(advise);

                    // Add optional parameters
                    if (regionalExchangeIds != null && !regionalExchangeIds.isEmpty()) {
                        builder.addAllRegionalExchangeIds(regionalExchangeIds);
                    }
                    if (marketSources != null && !marketSources.isEmpty()) {
                        builder.addAllMarketSource(marketSources);
                    }

                    MarketDataStreamRequest requestMsg = builder.build();
                    streamingClient.sendRequest(requestMsg).join();

                    // Update active subscription: preserve TICK, replace LEVEL1/LEVEL2 with the requested level.
                    Set<String> levels = streamingClient.getActiveSubscriptions()
                        .computeIfAbsent(symbol, key -> ConcurrentHashMap.newKeySet());

                    if (MarketDataConstants.MARKET_DATA_LEVEL1.equals(normalizedLevel)) {
                        levels.remove(MarketDataConstants.MARKET_DATA_LEVEL2);
                        levels.add(MarketDataConstants.MARKET_DATA_LEVEL1);
                    } else if (MarketDataConstants.MARKET_DATA_LEVEL2.equals(normalizedLevel)) {
                        levels.remove(MarketDataConstants.MARKET_DATA_LEVEL1);
                        levels.add(MarketDataConstants.MARKET_DATA_LEVEL2);
                    } else {
                        levels.add(normalizedLevel);
                    }
                }
            } catch (CompletionException ex) {
                Throwable cause = ex.getCause();
                if (cause instanceof IllegalArgumentException) {
                    System.out.println("Invalid request parameters: " + cause.getMessage());
                } else {
                    System.out.println("Error sending request: " + cause.getMessage());
                }
            } catch (Exception ex) {
                System.out.println("Unexpected error changing subscription: " + ex.getMessage());
            }
        });
    }

    /**
     * Validates request parameters.
     */
    private void validateRequestParameters(String[] symbols, String level) {
        validateSymbols(symbols);
        validateMarketDataLevel(level);
    }

    /**
     * Validates symbols array.
     */
    private void validateSymbols(String[] symbols) {
        if (symbols == null || symbols.length == 0) {
            throw new IllegalArgumentException("Symbols array cannot be null or empty");
        }
        for (String symbol : symbols) {
            if (symbol == null || symbol.trim().isEmpty()) {
                throw new IllegalArgumentException("Symbol cannot be null or empty");
            }
        }
    }

    /**
     * Validates market data level.
     */
    private void validateMarketDataLevel(String level) {
        if (level == null || level.trim().isEmpty()) {
            throw new IllegalArgumentException("Market data level cannot be null or empty");
        }
        String normalizedLevel = level.toUpperCase();
        if (!MarketDataConstants.isValidMarketDataLevel(normalizedLevel)) {
            throw new IllegalArgumentException("Invalid market data level: " + level +
                ". Valid levels are: LEVEL1, LEVEL2, TICK");
        }
    }

    private void validateUserToken() {
        if (userToken == null || userToken.trim().isEmpty()) {
            throw new IllegalStateException("User token is missing. Ensure login completed before sending streaming requests.");
        }
    }
}