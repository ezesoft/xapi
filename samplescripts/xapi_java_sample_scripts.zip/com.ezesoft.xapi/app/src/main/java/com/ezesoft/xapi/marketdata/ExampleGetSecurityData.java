package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.SecurityDataRequest;
import com.ezesoft.xapi.generated.MarketData.SecurityDataResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetSecurityData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        SecurityDataRequest request = SecurityDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("VOD.LSE")  // The ticker symbol
                .build();

        SecurityDataResponse response = lib.getMarketDataServiceStub().getSecurityData(request);

        printResponseHeader("Security Data");
        System.out.println("Symbol: " + request.getSymbol());
        System.out.println("Response: " + response.toString());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Security Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetSecurityData());
    }
}