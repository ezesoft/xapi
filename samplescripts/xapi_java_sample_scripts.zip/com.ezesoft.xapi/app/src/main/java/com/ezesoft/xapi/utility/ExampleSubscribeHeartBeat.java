package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.SubscribeHeartBeatRequest;
import com.ezesoft.xapi.generated.Utilities.SubscribeHeartBeatResponse;
import com.ezesoft.xapi.ExampleRunner;
import java.util.Iterator;

public class ExampleSubscribeHeartBeat implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            SubscribeHeartBeatRequest request = SubscribeHeartBeatRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)
                    .build();

            // This returns a streaming response
            Iterator<SubscribeHeartBeatResponse> responses = lib.getUtilityServiceStub().subscribeHeartBeat(request);
            while (responses.hasNext()) {
                SubscribeHeartBeatResponse response = responses.next();
                System.out.println("------------------------------");
                System.out.println("Heart Beat Status:");
                System.out.println("Status: " + response.getStatus());
                System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
                System.out.println("------------------------------");
            }
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Heart Beat";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeHeartBeat());
    }
}