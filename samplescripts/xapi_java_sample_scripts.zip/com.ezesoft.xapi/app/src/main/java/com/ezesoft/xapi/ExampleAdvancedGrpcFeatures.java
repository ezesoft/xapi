package com.ezesoft.xapi;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import java.util.concurrent.CompletableFuture;

/**
 * Example demonstrating advanced gRPC features including:
 * - Circuit breaker integration
 * - Async operations with CompletableFuture
 * - Interceptor benefits (authentication, logging)
 * - Development vs production mode handling
 */
public class ExampleAdvancedGrpcFeatures implements ExampleRunner.RunnableExample {

    @Override
    public void run() {
        EMSXAPILibrary lib = EMSXAPILibrary.get();

        System.out.println("=== Advanced gRPC Features Demo ===\n");

        // 1. Demonstrate circuit breaker status
        System.out.println("1. Circuit Breaker Status:");
        GrpcCircuitBreaker circuitBreaker = lib.getCircuitBreaker();
        CircuitBreaker.State state = circuitBreaker.getState();
        System.out.println("   Current state: " + state);
        System.out.println("   Metrics: " + circuitBreaker.getMetrics());
        System.out.println();

        // 2. Demonstrate async connection
        System.out.println("2. Async Connection Example:");
        CompletableFuture<com.ezesoft.xapi.generated.Utilities.ConnectResponse> connectFuture =
            lib.connectAsync();

        connectFuture.thenAccept(response -> {
            System.out.println("   Async connection successful!");
            System.out.println("   User token received: " + (response.getUserToken() != null ? "Yes" : "No"));
            System.out.println("   Connection established with server");
        }).exceptionally(throwable -> {
            System.out.println("   Async connection failed (expected in testing): " + throwable.getMessage());
            return null;
        });

        // Wait for async operation to complete
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println();

        // 3. Explain interceptor benefits
        System.out.println("3. Interceptor Benefits:");
        System.out.println("   ✓ AuthInterceptor: Automatically injects authentication tokens");
        System.out.println("   ✓ LoggingInterceptor: Logs all requests/responses with timing");
        System.out.println("   ✓ CircuitBreaker: Provides fault tolerance and resilience");
        System.out.println("   ✓ Async Support: Non-blocking operations with CompletableFuture");
        System.out.println();

        // 4. Development mode explanation
        System.out.println("4. Development Mode Features:");
        System.out.println("   ✓ Enables detailed logging and debugging");
        System.out.println("   ✓ Provides comprehensive error reporting");
        System.out.println("   ✓ Supports connection testing and validation");
        System.out.println("   ✓ Set emsxapi.development=true system property");
        System.out.println();

        System.out.println("=== Demo Complete ===");
    }

    @Override
    public String getExampleName() {
        return "Advanced gRPC Features";
    }
}