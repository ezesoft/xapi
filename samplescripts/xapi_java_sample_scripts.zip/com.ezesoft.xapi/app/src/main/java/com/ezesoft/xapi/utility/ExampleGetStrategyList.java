package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.StrategyListRequest;
import com.ezesoft.xapi.generated.Utilities.StrategyListResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetStrategyList implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            // Example firm name - replace with actual firm name
            String firmName = "EXAMPLE_FIRM";

            StrategyListRequest request = StrategyListRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setFirmName(firmName)
                    .build();

            StrategyListResponse response = lib.getUtilityServiceStub().getStrategyList(request);

            System.out.println("------------------------------");
            System.out.println("Strategy List:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Number of Strategies: " + response.getStrategyListCount());
            for (int i = 0; i < response.getStrategyListCount(); i++) {
                System.out.println("Strategy " + (i+1) + ": " + response.getStrategyList(i));
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Strategy List";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetStrategyList());
    }
}