package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.UpdateStrategyRequest;
import com.ezesoft.xapi.generated.Utilities.UpdateStrategyResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleUpdateStrategy implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            UpdateStrategyRequest req = UpdateStrategyRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setFirmName("TestFirm")
                    .setAlgoName("TestAlgo")
                    .setStrategyName("TestStrategy")
                    .setVersion(1)
                    .setStratParams("param1=updated_value1,param2=updated_value2")
                    .build();

            UpdateStrategyResponse response = lib.getUtilityServiceStub().updateStrategy(req);

            System.out.println("------------------------------");
            System.out.println("Update Strategy:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            if (response.getAcknowledgement().getMessage() != null) {
                System.out.println("Message: " + response.getAcknowledgement().getMessage());
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Update Strategy";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleUpdateStrategy());
    }
}