package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.SymbolsFromCompanyNameRequest;
import com.ezesoft.xapi.generated.MarketData.SymbolsFromCompanyNameResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetSymbolsFromCompanyName extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        SymbolsFromCompanyNameRequest request = SymbolsFromCompanyNameRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setCompanyName("Microsoft Corporation")  // Company Name
                .build();

        SymbolsFromCompanyNameResponse response = lib.getMarketDataServiceStub().getSymbolsFromCompanyName(request);

        printResponseHeader("Symbols from Company Name");
        System.out.println("Company: " + request.getCompanyName());
        printServerResponse(response.getAcknowledgement());
        System.out.println("Number of Symbols: " + response.getSymbolDatalistCount());
        for (int i = 0; i < response.getSymbolDatalistCount(); i++) {
            System.out.println("Symbol " + (i+1) + ": " + response.getSymbolDatalist(i));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Symbols From Company Name";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetSymbolsFromCompanyName());
    }
}