package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.IntradayBarsRequest;
import com.ezesoft.xapi.generated.MarketData.IntradayBarsResponse;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.Timestamp;
import com.google.protobuf.Duration;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.concurrent.TimeUnit;

public class ExampleGetIntradayBars extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) {
        // Create timestamp for current date
        Instant now = Instant.now();
        Timestamp currentDate = Timestamp.newBuilder()
                .setSeconds(now.getEpochSecond())
                .setNanos(now.getNano())
                .build();

        // Create start time (12:10:50)
        Duration startTime = Duration.newBuilder()
                .setSeconds(12 * 3600 + 10 * 60 + 50)  // 12 hours + 10 minutes + 50 seconds
                .build();

        // Create stop time (20:30:40)
        Duration stopTime = Duration.newBuilder()
                .setSeconds(20 * 3600 + 30 * 60 + 40)  // 20 hours + 30 minutes + 40 seconds
                .build();

        IntradayBarsRequest request = IntradayBarsRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("VOD.LSE")  // The ticker symbol
                .setBarInterval(1)  // Bar interval in minutes
                .setDaysBack(1)  // The number of days worth of bars to retrieve
                .setStartAtMidnight(false)  // If true, first bar includes all data since midnight
                .setShowPrePostMarket(false)  // If true, includes pre/post market data
                .setDate(currentDate)  // The end date for the query
                .setStartTime(startTime)  // Bars earlier than this time will be excluded
                .setStopTime(stopTime)  // Bars later than this time will be excluded
                .setRequestId(com.google.protobuf.Int32Value.newBuilder().setValue(12345).build())
                .build();

        IntradayBarsResponse response = lib.getMarketDataServiceStub().getIntradayBars(request);

        printResponseHeader("Intraday Bars Data");
        printServerResponse(response.getAcknowledgement());
        System.out.println("  Bars: " + response.getBars().toString());
        System.out.println("  Trade Times: " + response.getTrdTim1List());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Intraday Bars";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetIntradayBars());
    }
}