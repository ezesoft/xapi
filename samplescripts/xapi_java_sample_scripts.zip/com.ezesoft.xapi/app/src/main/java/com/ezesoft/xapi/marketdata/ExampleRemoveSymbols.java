package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleRemoveSymbols extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Symbols to remove from existing subscriptions
        java.util.List<String> symbolsList = java.util.Arrays.asList("MSFT", "GOOGL", "TSLA");

        RemoveSymbolsRequest req = RemoveSymbolsRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addAllSymbols(symbolsList)
                .build();

        RemoveSymbolsResponse response = lib.getMarketDataServiceStub().removeSymbols(req);

        printResponseHeader("Removed Symbols from Subscriptions");
        System.out.println("Symbols: " + String.join(", ", symbolsList));
        System.out.println("Server Response: " + response.getServerResponse());
        if (!response.getOptionalFieldsMap().isEmpty()) {
            System.out.println("Optional Fields: " + response.getOptionalFieldsMap());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Remove Symbols";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleRemoveSymbols());
    }
}