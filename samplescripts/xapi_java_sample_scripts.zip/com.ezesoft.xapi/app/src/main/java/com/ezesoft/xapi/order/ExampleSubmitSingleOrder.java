package com.ezesoft.xapi.order;

import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubmitSingleOrderRequest;
import com.ezesoft.xapi.generated.Order.SubmitSingleOrderResponse;

public class ExampleSubmitSingleOrder extends BaseExample{
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        try{
            lib = EMSXAPILibrary.Get();

            SubmitSingleOrderRequest req = SubmitSingleOrderRequest.newBuilder()
                                            .setUserToken(lib.getUserToken())
                                            .setSymbol("VOD.LSE")
                                            .setSide("BUY")
                                            .setQuantity(100)
                                            .setRoute("ROUTE")
                                            .setStaged(false)
                                            .setClaimRequire(false)
                                            .setAccount("BANK;BRANCH;CUSTOMER;DEPOSIT")
                                            .setReturnResult(true)
                                            .setOrderTag("OrderTag")
                                            .build();
            
            SubmitSingleOrderResponse response =  lib.getOrderServiceStub().submitSingleOrder(req);

            System.out.println("------------------------------");
            System.out.println(response.toString());                
            System.out.println("------------------------------");
        }
        catch(Exception ex){
            System.out.println("Error - "+ ex.getMessage());
        }
    }

     @Override
    public String getExampleName() {
        return "Submit Single Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitSingleOrder());
    }
}
