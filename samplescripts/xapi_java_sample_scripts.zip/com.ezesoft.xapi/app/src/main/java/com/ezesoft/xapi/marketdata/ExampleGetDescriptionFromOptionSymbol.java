package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetDescriptionFromOptionSymbol extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example option symbol
        String optionSymbol = "AAPL240315C00150000"; // AAPL March 15, 2024 Call $150

        DescriptionFromOptionSymbolRequest req = DescriptionFromOptionSymbolRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol(optionSymbol)
                .build();

        DescriptionFromOptionSymbolResponse response = lib.getMarketDataServiceStub().getDescriptionFromOptionSymbol(req);

        printResponseHeader("Option Description from Symbol");
        System.out.println("Symbol: " + optionSymbol);
        System.out.println("Root: " + response.getRoot());
        System.out.println("Expiration: " + response.getExpiration());
        System.out.println("Type: " + (response.getOptionType().getCallOrPut() == OptionTypes.Options.CALL ? "CALL" : "PUT"));
        System.out.println("Strike Price: $" + response.getStrikePrice());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Description From Option Symbol";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetDescriptionFromOptionSymbol());
    }
}