package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleUnSubscribeLevel1Data extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Symbols to unsubscribe from
        java.util.List<String> symbolsList = java.util.Arrays.asList("VOD.LSE", "BARC.LSE", "AAPL");

        UnSubscribeLevel1DataRequest req = UnSubscribeLevel1DataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .build();

        UnSubscribeLevel1DataResponse response = lib.getMarketDataServiceStub().unSubscribeLevel1Data(req);

        printResponseHeader("Unsubscribed from Level 1 Data");
        System.out.println("Symbols: " + String.join(", ", symbolsList));
        System.out.println("Server Response: " + response.getServerResponse());
        if (!response.getOptionalFieldsMap().isEmpty()) {
            System.out.println("Optional Fields: " + response.getOptionalFieldsMap());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "UnSubscribe Level 1 Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleUnSubscribeLevel1Data());
    }
}