package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.BasketOrderRequest;
import com.ezesoft.xapi.generated.Order.BasketOrderResponse;
import com.ezesoft.xapi.generated.Order.OrderRow;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.Int32Value;
import java.util.UUID;

public class ExampleSubmitBasketOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        String account = "BANK;BRANCH;CUSTOMER;DEPOSIT";
        String[] accountParts = account.split(";");
        String orderTag1 = "XAP-" + UUID.randomUUID().toString();
        String orderTag2 = "XAP-" + UUID.randomUUID().toString();

        // Create first order row
        OrderRow order1 = OrderRow.newBuilder()
                .setDispName("SYMBOL1")
                .setBuyorsell("BUY")
                .setPriceType("LIMIT")
                .setPrice("100.50")
                .setVolumeType("AsEntered")
                .setVolume(Int32Value.newBuilder().setValue(100).build())
                .setExchange("EXCHANGE1")
                .setStyp(Int32Value.newBuilder().setValue(1).build())
                .setBank(accountParts[0])
                .setBranch(accountParts[1])
                .setCustomer(accountParts[2])
                .setDeposit(accountParts[3])
                .setGoodUntil("DAY")
                .setType("UserSubmitOrder")
                .setRoute("ROUTE1")
                .putExtendedFields("EZE_OMS_TRADER", "OMS Trader Id 1")
                .putExtendedFields("ORDER_TAG", orderTag1)
                .build();

        // Create second order row
        OrderRow order2 = OrderRow.newBuilder()
                .setDispName("SYMBOL2")
                .setBuyorsell("SELL")
                .setPriceType("LIMIT")
                .setPrice("50.25")
                .setVolumeType("AsEntered")
                .setVolume(Int32Value.newBuilder().setValue(200).build())
                .setExchange("EXCHANGE2")
                .setStyp(Int32Value.newBuilder().setValue(1).build())
                .setBank(accountParts[0])
                .setBranch(accountParts[1])
                .setCustomer(accountParts[2])
                .setDeposit(accountParts[3])
                .setGoodUntil("DAY")
                .setType("UserSubmitOrder")
                .setRoute("ROUTE2")
                .putExtendedFields("EZE_OMS_TRADER", "OMS Trader Id 2")
                .putExtendedFields("ORDER_TAG", orderTag2)
                .build();

        // Create basket order request
        BasketOrderRequest request = BasketOrderRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addOrders(order1)
                .addOrders(order2)
                .build();

        BasketOrderResponse response = lib.getOrderServiceStub().submitBasketOrder(request);

        printResponseHeader("Basket Order Submitted");
        System.out.println("Number of Orders: " + request.getOrdersCount());
        printServerResponse(response.getAcknowledgement());
        System.out.println("Order Tag 1: " + orderTag1);
        System.out.println("Order Tag 2: " + orderTag2);
        System.out.println("Note: Use SubscribeOrderInfo to monitor order status updates");
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Submit Basket Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitBasketOrder());
    }
}