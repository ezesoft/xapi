package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.generated.Utilities.ServerAcknowledgement;
import com.ezesoft.xapi.streaming.utils.MarketDataConstants;
import com.ezesoft.xapi.ExampleRunner;
import io.grpc.stub.StreamObserver;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class ExampleStreamMarketData extends BaseExample {
    private final AtomicBoolean stopSignal = new AtomicBoolean(false);
    private final CountDownLatch latch = new CountDownLatch(1);

    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        printResponseHeader("Bidirectional Stream Market Data Example");

        // Start bidirectional streaming in background
        EMSXAPILibrary finalLib = lib;
        CompletableFuture<Void> streamingTask = CompletableFuture.runAsync(() -> {
            try {
                streamMarketData(finalLib);
            } catch (Exception e) {
                System.out.println("Streaming error: " + e.getMessage());
                latch.countDown();
            }
        });

        // Wait for user input or timeout
        System.out.println("Streaming market data... Press Ctrl+C to stop");

        try {
            // Wait for 30 seconds to receive data
            if (!latch.await(30, TimeUnit.SECONDS)) {
                System.out.println("Streaming timeout reached");
            }
        } catch (InterruptedException e) {
            System.out.println("Streaming interrupted");
        }

        // Stop the streaming
        stopSignal.set(true);

        printResponseFooter();
    }

    private void streamMarketData(EMSXAPILibrary lib) {
        try {
            // Create response observer to handle incoming messages
            StreamObserver<MarketDataStreamResponse> responseObserver = new StreamObserver<MarketDataStreamResponse>() {
                @Override
                public void onNext(MarketDataStreamResponse response) {
                    processStreamResponse(response);
                }

                @Override
                public void onError(Throwable t) {
                    System.out.println("Stream error: " + t.getMessage());
                    latch.countDown();
                }

                @Override
                public void onCompleted() {
                    System.out.println("Stream completed");
                    latch.countDown();
                }
            };

            // Get the bidirectional streaming stub
            StreamObserver<MarketDataStreamRequest> requestObserver =
                lib.getMarketDataServiceAsyncStub().streamMarketData(responseObserver);

            // Send initial subscription request for Level 1 data
            MarketDataStreamRequest subscribeRequest = MarketDataStreamRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setRequestType(MarketDataConstants.REQUEST_TYPE_ADD_SYMBOL)
                    .addAllSymbols(Arrays.asList("MSFT", "AAPL", "GOOGL"))
                    .setMarketDataLevel(MarketDataConstants.MARKET_DATA_LEVEL1)
                    .setRequest(true)
                    .setAdvise(true)
                    .build();

            System.out.println("Sending subscription request for Level 1 symbols: " + subscribeRequest.getSymbolsList());
            requestObserver.onNext(subscribeRequest);

            // Wait a bit for data
            Thread.sleep(5000);

            // Send request to add tick data for additional symbols
            if (!stopSignal.get()) {
                MarketDataStreamRequest tickRequest = MarketDataStreamRequest.newBuilder()
                        .setUserToken(lib.getUserToken())
                        .setRequestType(MarketDataConstants.REQUEST_TYPE_ADD_SYMBOL)
                        .addAllSymbols(Arrays.asList("VOD.LSE", "TSLA"))
                        .setMarketDataLevel(MarketDataConstants.MARKET_DATA_TICK)
                        .setRequest(true)
                        .setAdvise(true)
                        .build();

                System.out.println("Sending tick data request for symbols: " + tickRequest.getSymbolsList());
                requestObserver.onNext(tickRequest);

                // Wait a bit more
                Thread.sleep(5000);
            }

            // Send unsubscribe request for some symbols
            if (!stopSignal.get()) {
                MarketDataStreamRequest unsubscribeRequest = MarketDataStreamRequest.newBuilder()
                        .setUserToken(lib.getUserToken())
                        .setRequestType(MarketDataConstants.REQUEST_TYPE_REMOVE_SYMBOL)
                        .addAllSymbols(Arrays.asList("GOOGL"))
                        .build();

                System.out.println("Sending unsubscribe request for symbols: " + unsubscribeRequest.getSymbolsList());
                requestObserver.onNext(unsubscribeRequest);

                // Wait a bit more
                Thread.sleep(2000);
            }

            // Complete the request stream
            requestObserver.onCompleted();

        } catch (Exception e) {
            System.out.println("Streaming setup error: " + e.getMessage());
            latch.countDown();
        }
    }

    private void processStreamResponse(MarketDataStreamResponse response) {
        System.out.println("=== Stream Response ===");
        System.out.println("Response Type: " + response.getResponseType());

        if (response.hasAcknowledgement()) {
            ServerAcknowledgement ack = response.getAcknowledgement();
            System.out.println("Server Response: " + ack.getServerResponse());
            if (!ack.getMessage().isEmpty()) {
                System.out.println("Message: " + ack.getMessage());
            }
        }

        if (!response.getDispName().isEmpty()) {
            System.out.println("Symbol: " + response.getDispName());
        }

        // Handle different response types
        switch (response.getResponseType()) {
            case MarketDataConstants.RESPONSE_TYPE_LEVEL1_DATA:
                // Level 1 data is in flat fields
                System.out.println("Level 1 Data:");
                if (response.hasTrdprc1()) {
                    System.out.println("  Last Price: " + response.getTrdprc1().getDecimalValue());
                }
                if (response.hasBid()) {
                    System.out.println("  Bid: " + response.getBid().getDecimalValue());
                }
                if (response.hasAsk()) {
                    System.out.println("  Ask: " + response.getAsk().getDecimalValue());
                }
                if (response.hasChangeLast()) {
                    System.out.println("  Change: " + response.getChangeLast().getDecimalValue());
                }
                if (response.hasHigh1()) {
                    System.out.println("  High: " + response.getHigh1().getDecimalValue());
                }
                if (response.hasLow1()) {
                    System.out.println("  Low: " + response.getLow1().getDecimalValue());
                }
                break;

            case MarketDataConstants.RESPONSE_TYPE_TICK_DATA:
                // Tick data is in lists
                System.out.println("Tick Data:");
                if (response.getTrdPrc1ListCount() > 0) {
                    for (int i = 0; i < response.getTrdPrc1ListCount(); i++) {
                        System.out.println("  Price: " + response.getTrdPrc1List(i).getDecimalValue());
                        System.out.println("  Size: " + response.getTrdVol1List(i));
                        System.out.println("  Tick Type: " + response.getTickTypeList(i));
                        System.out.println("  Time: " + response.getTrdTim1List(i));
                        System.out.println("  XID: " + response.getTrdXid1List(i));
                    }
                }
                break;

            case MarketDataConstants.RESPONSE_TYPE_STATUS_UPDATE:
                System.out.println("Status Update Received");
                break;

            default:
                System.out.println("Unknown response type: " + response.getResponseType());
        }

        System.out.println("=== End Response ===\n");
    }

    @Override
    public String getExampleName() {
        return "Bidirectional Stream Market Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleStreamMarketData());
    }
}