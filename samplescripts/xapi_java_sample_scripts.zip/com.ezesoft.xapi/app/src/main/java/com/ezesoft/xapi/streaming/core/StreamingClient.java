package com.ezesoft.xapi.streaming.core;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.NetworkFailedException;
import com.ezesoft.xapi.ServerNotAvailableException;
import com.ezesoft.xapi.generated.MarketData.MarketDataStreamRequest;
import com.ezesoft.xapi.generated.MarketData.MarketDataStreamResponse;
import com.ezesoft.xapi.generated.Utilities.ServerAcknowledgement;
import com.ezesoft.xapi.generated.MarketDataServiceGrpc;
import com.ezesoft.xapi.generated.MarketDataServiceGrpc.MarketDataServiceStub;
import com.ezesoft.xapi.generated.MarketDataServiceGrpc.MarketDataServiceBlockingStub;
import com.ezesoft.xapi.streaming.utils.MarketDataConstants;
import com.ezesoft.xapi.streaming.handlers.RequestHandler;
import com.ezesoft.xapi.streaming.utils.StreamingLogger;
import com.ezesoft.xapi.streaming.utils.DataFormatter;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Core streaming client that manages the bidirectional connection and coordinates operations.
 */
public class StreamingClient implements AutoCloseable {
    private final EMSXAPILibrary library;
    private final ManagedChannel channel;
    private final ConcurrentHashMap<String, Integer> messageCounters;
    private final Object consoleLock;
    private final StreamingLogger logger;
    private final ConcurrentHashMap<String, Set<String>> activeSubscriptions;
    private final AtomicBoolean isStreaming;
    private final String userToken;
    private StreamObserver<MarketDataStreamRequest> requestStream;
    private MarketDataServiceStub asyncStub;
    private final boolean suppressConsoleOutput;
    private boolean disposed;

    /**
     * Initializes a new instance of the StreamingClient class.
     */
    public StreamingClient(EMSXAPILibrary library) throws NetworkFailedException, ServerNotAvailableException {
        this(library, false);
    }

    /**
     * Initializes a new instance of the StreamingClient class with console output control.
     * @param suppressConsoleOutput If true, streaming data will not be printed to console (only logged to file)
     */
    public StreamingClient(EMSXAPILibrary library, boolean suppressConsoleOutput) throws NetworkFailedException, ServerNotAvailableException {
        // Validate input parameters to prevent NullPointerExceptions
        if (library == null) {
            throw new IllegalArgumentException("EMSXAPILibrary cannot be null");
        }
        if (library.getChannel() == null) {
            throw new IllegalArgumentException("EMSXAPILibrary channel cannot be null");
        }
        if (library.getUserToken() == null || library.getUserToken().isEmpty()) {
            throw new IllegalArgumentException("EMSXAPILibrary user token cannot be null or empty");
        }

        this.library = library;
        this.userToken = library.getUserToken();
        this.suppressConsoleOutput = suppressConsoleOutput;

        // Use the authenticated channel from the library
        this.channel = library.getChannel();
        this.messageCounters = new ConcurrentHashMap<>();
        this.consoleLock = new Object();
        this.logger = new StreamingLogger();
        this.activeSubscriptions = new ConcurrentHashMap<>();
        this.isStreaming = new AtomicBoolean(false);
        this.disposed = false;
    }

    /**
     * Gets a value indicating whether the streaming connection is currently active.
     */
    public boolean isStreaming() {
        return isStreaming.get();
    }

    /**
     * Gets the dictionary tracking message counts per symbol for monitoring purposes.
     */
    public ConcurrentHashMap<String, Integer> getMessageCounters() {
        return messageCounters;
    }

    /**
     * Gets the lock object used for thread-safe console operations.
     */
    public Object getConsoleLock() {
        return consoleLock;
    }

    /**
     * Gets the file path where streaming logs are written.
     */
    public String getLogFilePath() {
        return logger.getLogFilePath();
    }

    /**
     * Gets the streaming logger instance for application logging.
     */
    public StreamingLogger getLogger() {
        return logger;
    }

    /**
     * Gets the dictionary tracking active subscriptions (symbol -> set of market data levels).
     */
    public ConcurrentHashMap<String, Set<String>> getActiveSubscriptions() {
        return activeSubscriptions;
    }

    /**
     * Starts the bidirectional streaming connection to the market data service.
     */
    public CompletableFuture<Void> startStreamingAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                logger.logSuccess("Starting streaming connection...");

                // Validate that we can get the channel
                if (channel == null) {
                    throw new IllegalStateException("gRPC channel is not available");
                }

                logger.logSuccess("gRPC channel available, getting authenticated async stub...");

                // Get the authenticated async stub from the library
                asyncStub = library.getMarketDataServiceAsyncStub();

                logger.logSuccess("Authenticated async stub obtained, setting up response observer...");

                // Create response observer
                StreamObserver<MarketDataStreamResponse> responseObserver = new StreamObserver<MarketDataStreamResponse>() {
                    @Override
                    public void onNext(MarketDataStreamResponse response) {
                        processMarketDataResponse(response);
                    }

                    @Override
                    public void onError(Throwable t) {
                        if (isStreaming.get()) {
                            logger.logError("Error reading streaming responses: " + t.getMessage());
                        }
                        isStreaming.set(false);
                    }

                    @Override
                    public void onCompleted() {
                        isStreaming.set(false);
                    }
                };

                logger.logSuccess("Response observer created, starting bidirectional streaming...");

                // Start the bidirectional streaming
                requestStream = asyncStub.streamMarketData(responseObserver);
                isStreaming.set(true);

                logger.logSuccess("Streaming connection established successfully");

                // Return control to caller - they can now send requests
            } catch (Exception ex) {
                logger.logError("Failed to start streaming: " + ex.getMessage());
                isStreaming.set(false);
                throw new RuntimeException(ex);
            }
        });
    }

    /**
     * Stops the bidirectional streaming connection and completes the request stream.
     */
    public CompletableFuture<Void> stopStreamingAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                isStreaming.set(false);

                // Complete the request stream
                if (requestStream != null) {
                    requestStream.onCompleted();
                }

                // Clear all active subscriptions
                clearAllSubscriptions();

                // Unsubscribe from all streaming data
                unsubscribeFromStreamingAsync().join();
            } catch (Exception ex) {
                if (!suppressConsoleOutput) {
                    System.out.println("Error stopping streaming: " + ex.getMessage());
                }
            }
        });
    }

    /**
     * Sends a market data stream request to the server.
     */
    public CompletableFuture<Void> sendRequest(MarketDataStreamRequest request) {
        return CompletableFuture.runAsync(() -> {
            if (request == null) {
                throw new IllegalArgumentException("Market data stream request cannot be null.");
            }

            if (request.getRequestType().isEmpty()) {
                throw new IllegalArgumentException("Request type cannot be null or empty.");
            }

            if (requestStream == null) {
                throw new IllegalStateException("Request stream not available. Ensure streaming is started before sending requests.");
            }

            logger.logSuccess("Sending request: " + request.getRequestType() + " for symbol: " + request.getSymbols(0));
            requestStream.onNext(request);
            logger.logSuccess("Request sent successfully");
        });
    }

    private void processMarketDataResponse(MarketDataStreamResponse response) {
        if (response == null) {
            logger.logError("Received null response");
            return;
        }

        // Handle server acknowledgments and errors
        if (response.hasAcknowledgement()) {
            processAcknowledgment(response.getAcknowledgement());
        }

        String timestamp = DataFormatter.formatTimestamp(java.time.LocalDateTime.now());
        String responseType = response.getResponseType().isEmpty() ? "UNKNOWN" : response.getResponseType();
        String symbol = response.getDispName().isEmpty() ? "N/A" : response.getDispName();

        // Update message counter
        messageCounters.merge(symbol, 1, Integer::sum);

        // Create a summary of the response data
        String summary = createResponseSummary(response);

        // Log the response using structured logging
        String logMessage = String.format("[%s] %s - %s: %s",
            timestamp, responseType, symbol, summary);

        // Use structured logging based on response type
        switch (responseType) {
            case "LEVEL1_DATA":
            case "LEVEL2_DATA":
            case "TICK_DATA":
                logger.logMarketData(symbol, responseType, summary);
                break;
            case "STATUS_UPDATE":
                logger.logStatus(summary);
                break;
            default:
                logger.logMessage(logMessage);
                break;
        }

        // Display to console (thread-safe) - only if console output is not suppressed
        if (!suppressConsoleOutput) {
            synchronized (consoleLock) {
                System.out.println(logMessage);
            }
        }
    }

    private void processAcknowledgment(com.ezesoft.xapi.generated.Utilities.ServerAcknowledgement ack) {
        String ackMessage = String.format("Server Acknowledgment - Response: %s", ack.getServerResponse());

        if (!ack.getMessage().isEmpty()) {
            ackMessage += ", Message: " + ack.getMessage();
        }

        // Check if response code indicates an error
        if (ack.getResponseCode() != com.ezesoft.xapi.generated.Utilities.ServerAcknowledgement.ResponseCodesEnum.SUCCESS) {
            logger.logError("Server Error: " + ackMessage);
            if (!suppressConsoleOutput) {
                System.err.println("SERVER ERROR: " + ackMessage);
            }
        } else {
            logger.logSuccess("Server Ack: " + ackMessage);
        }
    }

    private String createResponseSummary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder();

        // Process based on response type
        String responseType = response.getResponseType();
        switch (responseType) {
            case "LEVEL1_DATA":
                summary.append(createLevel1Summary(response));
                break;
            case "LEVEL2_DATA":
                summary.append(createLevel2Summary(response));
                break;
            case "TICK_DATA":
                summary.append(createTickDataSummary(response));
                break;
            case "STATUS_UPDATE":
                summary.append(createStatusSummary(response));
                break;
            default:
                summary.append(createGenericSummary(response));
                break;
        }

        return summary.length() > 0 ? summary.toString() : "Response received";
    }

    private String createLevel1Summary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder();

        // Basic symbol info
        if (!response.getDispName().isEmpty()) {
            summary.append("Symbol: ").append(response.getDispName());
        }
        if (!response.getSymbolDesc().isEmpty()) {
            summary.append(", Desc: ").append(response.getSymbolDesc());
        }
        if (!response.getCompanyName().isEmpty()) {
            summary.append(", Company: ").append(response.getCompanyName());
        }

        // Price data
        if (response.hasTrdprc1()) {
            summary.append(", Last: ").append(DataFormatter.formatPrice(response.getTrdprc1()));
        }
        if (response.hasBid()) {
            summary.append(", Bid: ").append(DataFormatter.formatPrice(response.getBid()));
        }
        if (response.hasAsk()) {
            summary.append(", Ask: ").append(DataFormatter.formatPrice(response.getAsk()));
        }
        if (response.hasChangeLast()) {
            summary.append(", Change: ").append(DataFormatter.formatPrice(response.getChangeLast()));
        }
        if (response.hasHigh1()) {
            summary.append(", High: ").append(DataFormatter.formatPrice(response.getHigh1()));
        }
        if (response.hasLow1()) {
            summary.append(", Low: ").append(DataFormatter.formatPrice(response.getLow1()));
        }

        // Timing
        if (response.hasTrdtim1()) {
            summary.append(", Time: ").append(DataFormatter.formatDuration(response.getTrdtim1()));
        }

        // Extended fields
        if (!response.getExtendedFieldsMap().isEmpty()) {
            summary.append(", Extended: ").append(response.getExtendedFieldsMap().size()).append(" fields");
        }

        return summary.toString();
    }

    private String createLevel2Summary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder();

        // Market maker info
        if (!response.getMktSource().isEmpty()) {
            summary.append("Source: ").append(response.getMktSource());
        }
        if (!response.getMktMkrId().isEmpty()) {
            summary.append(", MMID: ").append(response.getMktMkrId());
        }
        if (!response.getMktMkrStatus().isEmpty()) {
            summary.append(", Status: ").append(response.getMktMkrStatus());
        }
        if (!response.getExchName().isEmpty()) {
            summary.append(", Exchange: ").append(response.getExchName());
        }
        if (!response.getMktMkrDisplay().isEmpty()) {
            summary.append(", Display: ").append(response.getMktMkrDisplay());
        }

        // Quote data
        if (response.hasMktMkrBid()) {
            summary.append(", Bid: ").append(DataFormatter.formatPrice(response.getMktMkrBid()));
        }
        if (response.hasMktMkrAsk()) {
            summary.append(", Ask: ").append(DataFormatter.formatPrice(response.getMktMkrAsk()));
        }
        if (response.hasMktMkrBidsize()) {
            summary.append(", BidSize: ").append(DataFormatter.formatInt32Value(response.getMktMkrBidsize()));
        }
        if (response.hasMktMkrAsksize()) {
            summary.append(", AskSize: ").append(DataFormatter.formatInt32Value(response.getMktMkrAsksize()));
        }

        return summary.toString();
    }

    private String createTickDataSummary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder();

        // Tick data arrays
        if (!response.getTrdPrc1ListList().isEmpty()) {
            summary.append("Prices: ").append(DataFormatter.formatPriceList(response.getTrdPrc1ListList()));
        }
        if (!response.getTrdVol1ListList().isEmpty()) {
            summary.append(", Volumes: ").append(DataFormatter.formatIntList(response.getTrdVol1ListList()));
        }
        if (!response.getTickTypeListList().isEmpty()) {
            summary.append(", Types: [");
            for (int i = 0; i < response.getTickTypeListList().size(); i++) {
                if (i > 0) summary.append(", ");
                summary.append(MarketDataConstants.getTickTypeName(response.getTickTypeList(i)));
            }
            summary.append("]");
        }
        if (!response.getTrdDateListList().isEmpty()) {
            summary.append(", Dates: ").append(DataFormatter.formatTimestampList(response.getTrdDateListList()));
        }
        if (!response.getTrdTim1ListList().isEmpty()) {
            summary.append(", Times: ").append(response.getTrdTim1ListList().size()).append(" entries");
        }
        if (!response.getTrdXid1ListList().isEmpty()) {
            summary.append(", XIDs: ").append(DataFormatter.formatStringList(response.getTrdXid1ListList()));
        }

        if (response.getCount() > 0) {
            summary.append(", Count: ").append(response.getCount());
        }

        return summary.toString();
    }

    private String createStatusSummary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder("Status Update");

        if (!response.getStatusMessage().isEmpty()) {
            summary.append(": ").append(response.getStatusMessage());
        }

        // Check for acknowledgment
        if (response.hasAcknowledgement()) {
            summary.append(", Ack: ").append(response.getAcknowledgement().getServerResponse());
        }

        return summary.toString();
    }

    private String createGenericSummary(MarketDataStreamResponse response) {
        StringBuilder summary = new StringBuilder();

        // Add basic response info
        if (!response.getDispName().isEmpty()) {
            summary.append("Symbol: ").append(response.getDispName());
        }

        if (!response.getResponseType().isEmpty()) {
            if (summary.length() > 0) summary.append(", ");
            summary.append("Type: ").append(response.getResponseType());
        }

        // Add field count for unknown types
        if (response.getAllFields().size() > 2) {
            if (summary.length() > 0) summary.append(", ");
            summary.append("Data fields: ").append(response.getAllFields().size());
        }

        return summary.length() > 0 ? summary.toString() : "Response received";
    }

    private void clearAllSubscriptions() {
        activeSubscriptions.clear();
    }

    private CompletableFuture<Void> unsubscribeFromStreamingAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                if (channel != null) {
                    // Create blocking stub for unary call
                    MarketDataServiceBlockingStub blockingStub = MarketDataServiceGrpc.newBlockingStub(channel);

                    // Create unsubscribe request
                    com.ezesoft.xapi.generated.MarketData.UnSubscribeStreamMarketDataRequest unsubscribeRequest =
                        com.ezesoft.xapi.generated.MarketData.UnSubscribeStreamMarketDataRequest.newBuilder()
                            .setUserToken(userToken)
                            .build();

                    // Make the unary call to unsubscribe
                    com.ezesoft.xapi.generated.MarketData.UnSubscribeStreamMarketDataResponse response =
                        blockingStub.unSubscribeStreamMarketData(unsubscribeRequest);

                    logger.logSuccess("Unsubscribed from streaming: " + response.getServerResponse());

                    // Clear all subscriptions
                    clearAllSubscriptions();
                }
            } catch (Exception ex) {
                logger.logError("Error unsubscribing from streaming: " + ex.getMessage());
            }
        });
    }

    @Override
    public void close() {
        dispose();
    }

    public void dispose() {
        if (disposed) return;

        try {
            if (isStreaming.get()) {
                stopStreamingAsync().join();
            }

            if (logger != null) {
                logger.close();
            }

            if (channel != null && !channel.isShutdown()) {
                channel.shutdown();
            }
        } catch (Exception ex) {
            if (!suppressConsoleOutput) {
                System.out.println("Error during disposal: " + ex.getMessage());
            }
        } finally {
            disposed = true;
        }
    }
}