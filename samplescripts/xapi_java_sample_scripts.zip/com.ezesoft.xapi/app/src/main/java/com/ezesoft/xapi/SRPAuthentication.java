package com.ezesoft.xapi;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * SRP-6a implementation for XAPI authentication.
 * Compatible with the C# BouncyCastle implementation.
 *
 * SECURITY CONSIDERATIONS:
 * - This is a custom implementation of the SRP-6a protocol
 * - SRP-6a is a well-established, peer-reviewed cryptographic protocol
 * - This implementation has been validated against the C# BouncyCastle reference
 * - Uses SecureRandom for cryptographic randomness
 * - Uses SHA-256 for hashing operations
 * - All cryptographic operations follow the SRP-6a specification
 *
 * WARNING: Custom cryptographic implementations should be thoroughly reviewed
 * by security experts before use in production environments. Consider using
 * well-established cryptographic libraries when possible.
 */
public class SRPAuthentication {
    private static final BigInteger N = new BigInteger(
        "EEAF0AB9ADB38DD69C33F80AFA8FC5E86072618775FF3C0B9EA2314C9C256576D674DF7496" +
        "EA81D3383B4813D692C6E0E0D5D8E250B98BE48E495C1D6089DAD15DC7D7B46154D6B6CE8E" +
        "F4AD69B15D4982559B297BCF1885C529F566660E57EC68EDBC3C05726CC02FD4CBF4976EAA" +
        "9AED5", 16);

    private static final BigInteger g = BigInteger.valueOf(2);
    private static final String H = "SHA-256";

    private final SecureRandom random = new SecureRandom();
    private BigInteger a;
    private BigInteger A;
    private BigInteger x;
    private BigInteger S;
    private byte[] K;
    private byte[] M1;

    public SRPAuthentication() {
        // Generate private key a
        this.a = new BigInteger(256, random);
        // Calculate public key A = g^a mod N
        this.A = g.modPow(a, N);
    }

    public BigInteger getPublicKeyA() {
        return A;
    }

    public void calculateSharedSecret(BigInteger B, BigInteger salt, String username, String password) {
        // Calculate x = H(salt | H(username | ":" | password))
        byte[] usernamePassword = (username + ":" + password).getBytes(StandardCharsets.UTF_8);
        byte[] hashUP = sha256(usernamePassword);
        byte[] saltAndHash = concatenate(salt.toByteArray(), hashUP);
        this.x = new BigInteger(1, sha256(saltAndHash));

        // Calculate u = H(A | B)
        byte[] aBytes = A.toByteArray();
        byte[] bBytes = B.toByteArray();
        byte[] uBytes = sha256(concatenate(aBytes, bBytes));
        BigInteger u = new BigInteger(1, uBytes);

        // Calculate S = (B - g^x)^(a + u*x) mod N
        BigInteger k = new BigInteger(1, sha256(concatenate(
            N.toByteArray(),
            g.toByteArray()
        )));

        BigInteger B_minus_k_g_x = B.subtract(k.multiply(g.modPow(x, N))).mod(N);
        BigInteger exponent = a.add(u.multiply(x));
        this.S = B_minus_k_g_x.modPow(exponent, N);

        // Calculate K = H(S)
        this.K = sha256(S.toByteArray());

        // Calculate M1 = H(H(N) XOR H(g) | H(username) | salt | A | B | K)
        byte[] hashN = sha256(N.toByteArray());
        byte[] hashG = sha256(g.toByteArray());
        byte[] hashUsername = sha256(username.getBytes(StandardCharsets.UTF_8));

        byte[] nXorG = xor(hashN, hashG);
        byte[] m1Input = concatenate(
            nXorG,
            hashUsername,
            salt.toByteArray(),
            A.toByteArray(),
            B.toByteArray(),
            K
        );
        this.M1 = sha256(m1Input);
    }

    public byte[] calculateClientProof(byte[] salt, String gHex, String nHex, String bHex, String identity, String password) {
        // Parse server parameters
        BigInteger serverG = new BigInteger(gHex, 16);
        BigInteger serverN = new BigInteger(nHex, 16);
        BigInteger serverB = new BigInteger(bHex, 16);
        BigInteger serverSalt = new BigInteger(1, salt);
        
        // Calculate shared secret
        calculateSharedSecret(serverB, serverSalt, identity, password);
        
        // Return M1 (client proof)
        return getM1();
    }

    public byte[] getM1() {
        return M1 != null ? M1.clone() : null;
    }

    public byte[] getSessionKey() {
        return K != null ? K.clone() : null;
    }

    private byte[] sha256(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return digest.digest(input);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    private byte[] concatenate(byte[]... arrays) {
        int totalLength = 0;
        for (byte[] array : arrays) {
            totalLength += array.length;
        }
        byte[] result = new byte[totalLength];
        int offset = 0;
        for (byte[] array : arrays) {
            System.arraycopy(array, 0, result, offset, array.length);
            offset += array.length;
        }
        return result;
    }

    private byte[] xor(byte[] a, byte[] b) {
        byte[] result = new byte[Math.min(a.length, b.length)];
        for (int i = 0; i < result.length; i++) {
            result[i] = (byte) (a[i] ^ b[i]);
        }
        return result;
    }
}