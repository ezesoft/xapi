package com.ezesoft.xapi.marketdata;

import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.generated.MarketData.Level2MarketDataRequest;
import com.ezesoft.xapi.generated.MarketData.Level2MarketDataResponse;

public class ExampleSubscribeLevel2Ticks extends BaseExample {
    private final AtomicBoolean stopSignal = new AtomicBoolean(false);

    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Start subscription in background
        EMSXAPILibrary finalLib = lib;
        CompletableFuture<Void> subscriptionTask = CompletableFuture.runAsync(() -> {
            try {
                subscribeLevel2Ticks(finalLib);
            } catch (Exception e) {
                System.out.println("Subscription error: " + e.getMessage());
            }
        });

        // Wait for some time to receive data
        TimeUnit.SECONDS.sleep(10);

        // Stop the subscription
        stopSignal.set(true);

        printResponseHeader("Level 2 ticks subscription completed");
        printResponseFooter();
    }

    private void subscribeLevel2Ticks(EMSXAPILibrary lib) {
        try {
            Level2MarketDataRequest request = Level2MarketDataRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .addAllSymbols(Arrays.asList("VOD.LSE", "MSFT", "GOOGL"))  // List of ticker symbols
                    .setRequest(true)  // Request initial snapshot
                    .setAdvise(true)   // Enable real-time streaming
                    .setRequestId(com.google.protobuf.Int32Value.newBuilder().setValue(12345).build())
                    .build();

            System.out.println("Subscribing to Level 2 ticks for symbols: " + request.getSymbolsList());

            // Note: In a real implementation, this would be a streaming call
            // For this example, we'll simulate the subscription setup
            System.out.println("Level 2 ticks subscription initiated...");

            // In production, you would iterate over the streaming response:
            Iterator<Level2MarketDataResponse> response = lib.getMarketDataServiceStub().subscribeLevel2Ticks(request);
            while(response.hasNext()){
            Level2MarketDataResponse data = response.next();

            printResponseHeader("Subscribe Level 1 Ticks");
            System.out.println(data.toString());
            printResponseFooter();
         }

        } catch (Exception e) {
            System.out.println("Subscription setup error: " + e.getMessage());
        }
    }

    private void processLevel2Data(Level2MarketDataResponse data) {
        if ("success".equals(data.getAcknowledgement().getServerResponse())) {
            System.out.println("Level 2 Data - " +
                    "DispName: " + data.getDispName() + ", " +
                    "MktMkrId: " + data.getMktMkrId() + ", " +
                    "MktMkrDisplay: " + data.getMktMkrDisplay() + ", " +
                    "Bid: " + (data.getMktMkrBid().getDecimalValue()) + ", " +
                    "BidSize: " + data.getMktMkrBidsize() + ", " +
                    "Ask: " + (data.getMktMkrAsk().getDecimalValue()) + ", " +
                    "AskSize: " + data.getMktMkrAsksize() + ", " +
                    "Status: " + data.getMktMkrStatus() + ", " +
                    "Source: " + data.getMktSource());
        } else {
            System.out.println("Server Response: " + data.getAcknowledgement().getServerResponse() +
                    ", Error: " + data.getAcknowledgement().getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Level 2 Ticks";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeLevel2Ticks());
    }
}