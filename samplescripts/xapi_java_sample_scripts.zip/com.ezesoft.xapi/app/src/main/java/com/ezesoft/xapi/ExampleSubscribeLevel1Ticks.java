package com.ezesoft.xapi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ezesoft.xapi.generated.MarketData.*;

public class ExampleSubscribeLevel1Ticks {
    public void run() {
        EMSXAPILibrary lib = null;
        try{
            lib = EMSXAPILibrary.Get();
            List<String> symbolsList = new ArrayList<>();
            symbolsList.add("VOD.LSE`");            
            symbolsList.add("BARC.LSE`");
            symbolsList.add("AAPL");

            Level1MarketDataRequest req = Level1MarketDataRequest.newBuilder()
                                            .setUserToken(lib.getUserToken())
                                            .setAdvise(true)
                                            .setRequest(true)
                                            .addAllSymbols(symbolsList)
                                            .build();
           
            Iterator<Level1MarketDataResponse> responseIt =  lib.getMarketDataServiceStub().subscribeLevel1Ticks(req);
            while(responseIt.hasNext()){
                Level1MarketDataResponse data = responseIt.next();

                System.out.println("------------------------------");
                System.out.println(data.toString());                
                System.out.println("------------------------------");
             }
        }
        catch(Exception ex){
            System.out.println("Error - "+ ex.getMessage());
        }
    }
}
