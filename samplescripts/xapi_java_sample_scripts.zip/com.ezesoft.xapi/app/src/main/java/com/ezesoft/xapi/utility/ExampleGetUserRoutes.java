package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.GetUserRoutesRequest;
import com.ezesoft.xapi.generated.Utilities.GetUserRoutesResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetUserRoutes implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            GetUserRoutesRequest req = GetUserRoutesRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setAccountList("BANK;BRANCH;CUSTOMER;DEPOSIT")
                    .build();

            GetUserRoutesResponse response = lib.getUtilityServiceStub().getUserRoutes(req);

            System.out.println("------------------------------");
            System.out.println("Get User Routes:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("User Routes:");
            response.getUserRoutesMap().forEach((key, value) ->
                System.out.println("  " + key + ": " + value));
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get User Routes";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetUserRoutes());
    }
}