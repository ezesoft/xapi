package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.generated.Utilities.ConnectResponse;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * Advanced example demonstrating gRPC best practices:
 * - Async operations with CompletableFuture
 * - Circuit breaker resilience
 * - Interceptor-based authentication and logging
 */
public class ExampleAdvancedGrpcFeatures implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            // Initialize library first
            EMSXAPILibrary.create("../config.cfg");
            lib = EMSXAPILibrary.get();

            System.out.println("=== Advanced gRPC Features Example ===");
            System.out.println();

            // Demonstrate circuit breaker status
            System.out.println("1. Circuit Breaker Status:");
            System.out.println("State: " + lib.getCircuitBreaker().getState());
            System.out.println("Metrics: " + lib.getCircuitBreaker().getMetrics());
            System.out.println();

            // Demonstrate async connection (in testing this will work)
            System.out.println("2. Async Connection:");
            boolean developmentMode = "true".equals(System.getProperty("emsxapi.development", "true"));

            if (developmentMode) {
                System.out.println("TESTING MODE: Demonstrating async connection pattern");
                System.out.println("In production, this would establish a real async connection");

                // Show the async pattern (would work with real server)
                CompletableFuture<ConnectResponse> connectFuture = lib.connectAsync();
                System.out.println("Async connect initiated - Future created: " + !connectFuture.isDone());

                // For demo purposes, we'll simulate completion
                System.out.println("Async pattern demonstrated successfully");
            } else {
                // Real async connection
                CompletableFuture<ConnectResponse> connectFuture = lib.connectAsync();
                System.out.println("Async connect initiated...");

                try {
                    ConnectResponse response = connectFuture.get(); // Wait for completion
                    System.out.println("Async connect completed successfully");
                    System.out.println("User Token: " + response.getUserToken());
                } catch (ExecutionException e) {
                    System.out.println("Async connect failed: " + e.getCause().getMessage());
                }
            }
            System.out.println();

            // Demonstrate circuit breaker protection
            System.out.println("3. Circuit Breaker Protection:");
            try {
                String result = lib.executeWithCircuitBreaker(() -> {
                    System.out.println("Executing operation with circuit breaker protection");
                    return "Operation completed successfully";
                });
                System.out.println("Result: " + result);
            } catch (Exception e) {
                System.out.println("Circuit breaker operation failed: " + e.getMessage());
            }
            System.out.println();

            // Show interceptor benefits
            System.out.println("4. Interceptor Benefits:");
            System.out.println("✓ Authentication tokens automatically added to requests");
            System.out.println("✓ Request/response logging with timing information");
            System.out.println("✓ Error handling and monitoring built into all calls");
            System.out.println("✓ Cross-cutting concerns handled transparently");
            System.out.println();

            System.out.println("=== Advanced gRPC Features Complete ===");

        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Advanced gRPC Features (Async, Circuit Breaker, Interceptors)";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleAdvancedGrpcFeatures());
    }
}