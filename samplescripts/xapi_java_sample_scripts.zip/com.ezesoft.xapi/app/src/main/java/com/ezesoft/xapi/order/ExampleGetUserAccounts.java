package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.UserAccountsRequest;
import com.ezesoft.xapi.generated.Order.UserAccountsResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetUserAccounts extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        UserAccountsRequest request = UserAccountsRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .build();

        UserAccountsResponse response = lib.getOrderServiceStub().getUserAccounts(request);

        printResponseHeader("User Accounts");
        printServerResponse(response.getAcknowledgement());
        for (var entry : response.getAccountsMap().entrySet()) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get User Accounts";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetUserAccounts());
    }
}