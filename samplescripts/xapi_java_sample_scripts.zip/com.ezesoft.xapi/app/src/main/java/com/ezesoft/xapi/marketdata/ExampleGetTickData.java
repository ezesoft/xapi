package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.TickDataRequest;
import com.ezesoft.xapi.generated.MarketData.TickDataResponse;
import com.ezesoft.xapi.generated.MarketData.TickTypes;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.Timestamp;
import com.google.protobuf.Duration;

import java.time.Instant;
import java.util.Arrays;
import java.util.UUID;

public class ExampleGetTickData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) {

            // Create timestamp for current date
            Instant now = Instant.now();
            Timestamp currentDate = Timestamp.newBuilder()
                    .setSeconds(now.getEpochSecond())
                    .setNanos(now.getNano())
                    .build();

            // Create start time (12:10:50)
            Duration startTime = Duration.newBuilder()
                    .setSeconds(12 * 3600 + 10 * 60 + 50)
                    .build();

            // Create stop time (20:30:40)
            Duration stopTime = Duration.newBuilder()
                    .setSeconds(20 * 3600 + 30 * 60 + 40)
                    .build();

            // Create tick types
            TickTypes tickType1 = TickTypes.newBuilder()
                    .setTickOption(TickTypes.Ticks.TRADE)
                    .build();
            TickTypes tickType2 = TickTypes.newBuilder()
                    .setTickOption(TickTypes.Ticks.BID)
                    .build();
            TickTypes tickType3 = TickTypes.newBuilder()
                    .setTickOption(TickTypes.Ticks.ASK)
                    .build();

            // Generate a unique request ID using UUID hash code for better uniqueness
            int requestId = UUID.randomUUID().hashCode();

            TickDataRequest request = TickDataRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setSymbol("VOD.LSE")  // The ticker symbol
                    .setDate(currentDate)  // The end date for the query
                    .setStartTime(startTime)  // Records earlier than this time will be excluded
                    .setStopTime(stopTime)  // Records later than this time will be excluded
                    .setRequestId(com.google.protobuf.Int32Value.newBuilder().setValue(requestId).build())
                    .addAllTickTypes(Arrays.asList(tickType1, tickType2, tickType3))
                    .build();

            TickDataResponse response = lib.getMarketDataServiceStub().getTickData(request);

            System.out.println("------------------------------");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Tick Data:");
            System.out.println("Number of Records: " + response.getTickInfoCount());
            for (int i = 0; i < response.getTickInfoCount(); i++) {
                var tickRecord = response.getTickInfo(i);
                System.out.println("Record " + (i+1) + ":");
                System.out.println("  Symbol: " + String.join(", ", tickRecord.getDispNameList()));
                System.out.println("  Count: " + tickRecord.getCount());
                System.out.println("  Trade Prices: " + tickRecord.getTrdPrc1List());
                System.out.println("  Trade Dates: " + tickRecord.getTrdDateList());
                System.out.println("  Tick Types: " + tickRecord.getTickTypeList());
                System.out.println("  Trade Volumes: " + tickRecord.getTrdVol1List());
            }
            System.out.println("------------------------------");
    }

    @Override
    public String getExampleName() {
        return "Get Tick Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetTickData());
    }
}