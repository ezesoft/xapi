package com.ezesoft.xapi;

import com.ezesoft.xapi.generated.Order.SubmitSingleOrderRequest;
import com.ezesoft.xapi.generated.Order.SubmitSingleOrderResponse;

public class ExampleSubmitSingleOrder {
    public void run() {
        EMSXAPILibrary lib = null;
        try{
            lib = EMSXAPILibrary.Get();

            SubmitSingleOrderRequest req = SubmitSingleOrderRequest.newBuilder()
                                            .setUserToken(lib.getUserToken())
                                            .setSymbol("SYMBOL")
                                            .setSide("BUY/SELL")
                                            .setQuantity(100)
                                            .setRoute("ROUTE")
                                            .setStaged(false)
                                            .setClaimRequire(false)
                                            .setAccount("BANK;BRANCH;CUSTOMER;DEPOSIT")
                                            .build();
            
            SubmitSingleOrderResponse response =  lib.getOrderServiceStub().submitSingleOrder(req);

            System.out.println("------------------------------");
            System.out.println(response.toString());                
            System.out.println("------------------------------");
        }
        catch(Exception ex){
            System.out.println("Error - "+ ex.getMessage());
        }
    }
}
