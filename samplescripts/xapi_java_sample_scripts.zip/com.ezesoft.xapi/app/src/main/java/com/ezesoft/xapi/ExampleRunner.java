package com.ezesoft.xapi;

/**
 * Utility class for running EMS XAPI examples with common authentication and cleanup logic.
 * This eliminates code duplication across all example main methods.
 */
public class ExampleRunner {

    /**
     * Interface for example classes that can be run.
     */
    public interface RunnableExample {
        void run();
        String getExampleName();
    }

    /**
     * Interface for asynchronous examples that return CompletableFuture.
     */
    public interface AsyncRunnableExample {
        java.util.concurrent.CompletableFuture<Void> runAsync();
        String getExampleName();
    }

    /**
     * Interface for multi-step examples with setup, execution, and cleanup phases.
     */
    public interface MultiStepExample {
        void setup() throws Exception;
        void execute() throws Exception;
        void cleanup() throws Exception;
        String getExampleName();
    }

    /**
     * Runs an example with automatic authentication and cleanup.
     *
     * @param example The example to run
     */
    public static void runExample(RunnableExample example) {
        EMSXAPILibrary lib = null;

        try {
            System.out.println("=== EMS XAPI " + example.getExampleName() + " ===");

            // Initialize and authenticate
            EMSXAPILibrary.create("../config.cfg");
            lib = EMSXAPILibrary.get();
            lib.login();

            if (lib.getIsLoggedIn()) {
                String token = lib.getUserToken();
                if (token == null || token.trim().isEmpty()) {
                    System.out.println("Warning: User token is null or empty after login!");
                    System.out.println("Authentication failed - no valid token!");
                    return;
                }
                System.out.println("Authentication successful. Running example...");
                System.out.println("Token status: " + (token.length() > 20 ? token.substring(0, 20) + "..." : token));

                // Run the example
                example.run();

                System.out.println("Example completed successfully!");
            } else {
                System.out.println("Authentication failed!");
            }

        } catch (Exception ex) {
            System.out.println("Error in example: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            // Cleanup
            if (lib != null) {
                if (lib.getIsLoggedIn()) {
                    lib.logout();
                }
                lib.closeChannel();
            }
        }
    }

    /**
     * Runs a streaming example with automatic authentication and cleanup.
     * Note: Streaming examples may run continuously until interrupted.
     *
     * @param example The streaming example to run
     */
    public static void runStreamingExample(RunnableExample example) {
        EMSXAPILibrary lib = null;

        try {
            System.out.println("=== EMS XAPI " + example.getExampleName() + " ===");
            System.out.println("Note: This is a streaming example that may run continuously.");
            System.out.println("Press Ctrl+C to stop the streaming.");

            // Initialize and authenticate
            EMSXAPILibrary.create("../config.cfg");
            lib = EMSXAPILibrary.get();
            lib.login();

            if (lib.getIsLoggedIn()) {
                System.out.println("Authentication successful. Running streaming example...");

                // Run the example
                example.run();

                System.out.println("Streaming example completed!");
            } else {
                System.out.println("Authentication failed!");
            }

        } catch (Exception ex) {
            System.out.println("Error in streaming example: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            // Cleanup
            if (lib != null) {
                if (lib.getIsLoggedIn()) {
                    lib.logout();
                }
                lib.closeChannel();
            }
        }
    }

    /**
     * Runs an asynchronous example with automatic authentication and cleanup.
     *
     * @param example The asynchronous example to run
     */
    public static void runAsyncExample(AsyncRunnableExample example) {
        EMSXAPILibrary lib = null;

        try {
            System.out.println("=== EMS XAPI " + example.getExampleName() + " (Async) ===");

            // Initialize and authenticate
            EMSXAPILibrary.create("../config.cfg");
            lib = EMSXAPILibrary.get();
            lib.login();

            if (lib.getIsLoggedIn()) {
                System.out.println("Authentication successful. Running async example...");

                // Run the example asynchronously
                java.util.concurrent.CompletableFuture<Void> future = example.runAsync();
                future.get(); // Wait for completion

                System.out.println("Async example completed successfully!");
            } else {
                System.out.println("Authentication failed!");
            }

        } catch (Exception ex) {
            System.out.println("Error in async example: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            // Cleanup
            if (lib != null) {
                if (lib.getIsLoggedIn()) {
                    lib.logout();
                }
                lib.closeChannel();
            }
        }
    }

    /**
     * Runs a multi-step example with automatic authentication and cleanup.
     *
     * @param example The multi-step example to run
     */
    public static void runMultiStepExample(MultiStepExample example) {
        EMSXAPILibrary lib = null;

        try {
            System.out.println("=== EMS XAPI " + example.getExampleName() + " (Multi-Step) ===");

            // Initialize and authenticate
            EMSXAPILibrary.create("../config.cfg");
            lib = EMSXAPILibrary.get();
            lib.login();

            if (lib.getIsLoggedIn()) {
                System.out.println("Authentication successful. Running multi-step example...");

                // Run the multi-step example
                example.setup();
                System.out.println("Setup completed. Executing main logic...");
                example.execute();
                System.out.println("Execution completed. Cleaning up...");
                example.cleanup();

                System.out.println("Multi-step example completed successfully!");
            } else {
                System.out.println("Authentication failed!");
            }

        } catch (Exception ex) {
            System.out.println("Error in multi-step example: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            // Cleanup
            if (lib != null) {
                if (lib.getIsLoggedIn()) {
                    lib.logout();
                }
                lib.closeChannel();
            }
        }
    }

    /**
     * Main method to run examples from command line.
     * Usage: java ExampleRunner com.ezesoft.xapi.marketdata.ExampleGetLevel1MarketData
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java ExampleRunner <fully-qualified-class-name>");
            System.out.println("Example: java ExampleRunner com.ezesoft.xapi.marketdata.ExampleGetLevel1MarketData");
            System.exit(1);
        }

        String className = args[0];
        try {
            Class<?> clazz = Class.forName(className);
            Object instance = clazz.getDeclaredConstructor().newInstance();

            if (instance instanceof RunnableExample) {
                runExample((RunnableExample) instance);
            } else {
                System.out.println("Error: Class " + className + " does not implement RunnableExample interface");
                System.exit(1);
            }
        } catch (Exception ex) {
            System.out.println("Error running example: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
        }
    }
}