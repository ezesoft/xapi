package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.ChangeSingleOrderRequest;
import com.ezesoft.xapi.generated.Order.ChangeSingleOrderResponse;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.DoubleValue;

public class ExampleChangeSingleOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Note: In a real scenario, you would first submit an order and get its OrderId
        // For this example, we'll use a placeholder OrderId
        String orderId = "ORDER_ID_PLACEHOLDER";  // Replace with actual order ID

        ChangeSingleOrderRequest request = ChangeSingleOrderRequest.newBuilder()
                .setOrderId(orderId)  // The order ID to change
                .setUserToken(lib.getUserToken())
                .setQuantity(5000)  // New quantity
                .setPrice(DoubleValue.newBuilder().setValue(121.5).build())  // New limit price
                .setOrderTag("CHANGE_ORDER_TAG")  // Unique tag for this change request
                .putExtendedFields("DEST_ROUTE", "DEMOEUR")  // Extended fields
                .build();

        ChangeSingleOrderResponse response = lib.getOrderServiceStub().changeSingleOrder(request);

        printResponseHeader("Change Single Order Response");
        printServerResponse(response.getAcknowledgement());
        if ("Failed".equals(response.getServerResponse())) {
            System.out.println("Error Message: " + response.getOptionalFieldsMap().get("ErrorMessage"));
        } else {
            System.out.println("Order changed successfully");
            System.out.println("New Quantity: " + request.getQuantity());
            System.out.println("New Price: " + request.getPrice().getValue());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Change Single Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleChangeSingleOrder());
    }
}