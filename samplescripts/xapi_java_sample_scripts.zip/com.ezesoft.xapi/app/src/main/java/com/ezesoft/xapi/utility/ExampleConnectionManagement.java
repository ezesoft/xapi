package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.ConnectRequest;
import com.ezesoft.xapi.generated.Utilities.ConnectResponse;
import com.ezesoft.xapi.generated.Utilities.DisconnectRequest;
import com.ezesoft.xapi.generated.Utilities.DisconnectResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleConnectionManagement implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            System.out.println("=== Connection Management Example ===");
            System.out.println();

            // Note: In typical usage, connection is handled automatically by EMSXAPILibrary.Get()
            // This example demonstrates both Connect and Disconnect APIs for completeness

            System.out.println("1. Connect Operation:");
            System.out.println("Note: Connect is typically handled automatically by EMSXAPILibrary initialization");
            System.out.println("The Connect API establishes a connection and returns a user token");

            // Show the Connect request structure (normally handled automatically)
            ConnectRequest connectReq = ConnectRequest.newBuilder()
                    .setUserName("testuser")
                    .setDomain("testdomain")
                    .setPassword("testpassword")
                    .setLocale("en_US")
                    .build();

            System.out.println("Connect Request: User=" + connectReq.getUserName() +
                             ", Domain=" + connectReq.getDomain());
            System.out.println("Connection typically established automatically by library");
            System.out.println();

            // Get library instance (this handles connection automatically)
            lib = EMSXAPILibrary.Get();
            System.out.println("2. Library initialized with automatic connection");
            System.out.println("User Token: " + lib.getUserToken());
            System.out.println();

            // Demonstrate Disconnect
            System.out.println("3. Disconnect Operation:");
            DisconnectRequest disconnectReq = DisconnectRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .build();

            DisconnectResponse disconnectResponse = lib.getUtilityServiceStub().disconnect(disconnectReq);

            System.out.println("Disconnect Response:");
            System.out.println("Server Response: " + disconnectResponse.getServerResponse());
            if (disconnectResponse.getOptionalFieldsMap().size() > 0) {
                System.out.println("Optional Fields:");
                disconnectResponse.getOptionalFieldsMap().forEach((key, value) ->
                    System.out.println("  " + key + ": " + value));
            }

            System.out.println();
            System.out.println("=== Connection Management Complete ===");

        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Connection Management (Connect & Disconnect)";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleConnectionManagement());
    }
}