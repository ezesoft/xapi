package com.ezesoft.xapi.marketdata;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubscribeTickData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        String symbol = "AAPL";

        SubscribeTickDataRequest req = SubscribeTickDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol(symbol)
                .setRequest(true)
                .build();

        Iterator<SubscribeTickDataResponse> responseIt = lib.getMarketDataServiceStub().subscribeTickData(req);
        while (responseIt.hasNext()) {
            SubscribeTickDataResponse data = responseIt.next();

            printResponseHeader("Tick Data Subscription");
            System.out.println(data.toString());
            printResponseFooter();
        }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Tick Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeTickData());
    }
}