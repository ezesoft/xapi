package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.OptionsAndGreekDataRequest;
import com.ezesoft.xapi.generated.MarketData.OptionsAndGreekDataResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetOptionsAndGreekData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        OptionsAndGreekDataRequest request = OptionsAndGreekDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addSymbols("M")  // list of ticker symbols
                .addSymbols("+AAPL\\15B9\\223")
                .addSymbols("+IBM\\09D9\\150")
                .build();

        OptionsAndGreekDataResponse response = lib.getMarketDataServiceStub().getOptionsAndGreekData(request);

        printResponseHeader("Options and Greek Data");
        printServerResponse(response.getAcknowledgement());
        System.out.println("Number of Options: " + response.getOptionsListCount());
        for (int i = 0; i < response.getOptionsListCount(); i++) {
            System.out.println("Option " + (i+1) + ": " + response.getOptionsList(i));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Options And Greek Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOptionsAndGreekData());
    }
}