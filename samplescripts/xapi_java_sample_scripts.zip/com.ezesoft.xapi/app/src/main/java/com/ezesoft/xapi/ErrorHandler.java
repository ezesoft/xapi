package com.ezesoft.xapi;

public interface ErrorHandler {
    void onError(Throwable error);
}