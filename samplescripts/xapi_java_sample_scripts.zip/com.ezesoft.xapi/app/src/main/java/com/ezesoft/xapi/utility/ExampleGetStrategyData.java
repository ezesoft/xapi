package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.GetStrategyDataRequest;
import com.ezesoft.xapi.generated.Utilities.GetStrategyDataResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetStrategyData implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            // Example strategy parameters - replace with actual values
            String firmName = "EXAMPLE_FIRM";
            String algoName = "EXAMPLE_ALGO";
            String strategyName = "EXAMPLE_STRATEGY";

            GetStrategyDataRequest request = GetStrategyDataRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setFirmName(firmName)
                    .setAlgoName(algoName)
                    .setStrategyName(strategyName)
                    .build();

            GetStrategyDataResponse response = lib.getUtilityServiceStub().getStrategyData(request);

            System.out.println("------------------------------");
            System.out.println("Strategy Data:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Strategy Data: " + response.getStrategyData());
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Strategy Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetStrategyData());
    }
}