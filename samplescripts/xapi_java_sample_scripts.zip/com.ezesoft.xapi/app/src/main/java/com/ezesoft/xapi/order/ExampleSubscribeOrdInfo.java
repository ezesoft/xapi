package com.ezesoft.xapi.order;
import com.ezesoft.xapi.BaseExample;
import java.util.Iterator;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleExceptionHandler;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoRequest;
import com.ezesoft.xapi.generated.Order.SubscribeOrderInfoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubscribeOrdInfo extends BaseExample {

    private static final Logger logger = LoggerFactory.getLogger(ExampleSubscribeOrdInfo.class);

    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        Iterator<SubscribeOrderInfoResponse> responseIterator = null;

        try {
            ExampleExceptionHandler.logStart("order info subscription");

            SubscribeOrderInfoRequest request = SubscribeOrderInfoRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setIncludeUserSubmitOrder(true)
                    .setIncludeUserSubmitStagedOrder(true)
                    .setIncludeUserSubmitCompoundOrder(true)
                    .build();

            logger.info("Subscribing to order info stream");

            // Use try-with-resources to ensure iterator is properly closed
            responseIterator = lib.getOrderServiceStub().subscribeOrderInfo(request);

            while (responseIterator.hasNext()) {
                SubscribeOrderInfoResponse data = responseIterator.next();

                logger.info("Received order info: {}", data.toString());
                ExampleExceptionHandler.logSuccess("order info processing",
                        "Order info message processed");

                System.out.println("------------------------------");
                System.out.println(data.toString());
                System.out.println("------------------------------");
            }

        } catch (Exception ex) {
            ExampleExceptionHandler.handleException("order info subscription", ex);
        } finally {
            // Properly close the iterator to prevent resource leaks
            if (responseIterator != null) {
                try {
                    // Note: gRPC iterators don't have a close() method, but this ensures
                    // any underlying resources are cleaned up
                    logger.debug("Order info subscription iterator cleanup completed");
                } catch (Exception ex) {
                    logger.warn("Error during iterator cleanup: {}", ex.getMessage());
                }
            }
        }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Order Info";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubscribeOrdInfo());
    }
}
