package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.OrderDetailByOrderTagRequest;
import com.ezesoft.xapi.generated.Order.OrderDetailByOrderTagResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetOrderDetailByOrderTag extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        OrderDetailByOrderTagRequest req = OrderDetailByOrderTagRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addOrderTags("ORDER_TAG_1")
                .addOrderTags("ORDER_TAG_2")
                .setOrderEventType("ALL")
                .build();

        OrderDetailByOrderTagResponse response = lib.getOrderServiceStub().getOrderDetailByOrderTag(req);

        printResponseHeader("Get Order Detail By Order Tag");
        System.out.println("Number of Order Details: " + response.getOrderDetailsCount());

        for (int i = 0; i < response.getOrderDetailsCount(); i++) {
            System.out.println("Order Detail " + (i+1) + ":");
            System.out.println("  Order ID: " + response.getOrderDetails(i).getOrderId());
            System.out.println("  Refers To ID: " + response.getOrderDetails(i).getRefersToId());
        }

        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Order Detail By Order Tag";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOrderDetailByOrderTag());
    }
}