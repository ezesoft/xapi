package com.ezesoft.xapi;

import com.ezesoft.xapi.streaming.core.StreamingClient;
import com.ezesoft.xapi.streaming.handlers.RequestHandler;

/**
 * Example demonstrating market data streaming subscription and unsubscription.
 * This example subscribes to market data, waits for 50 seconds to receive data,
 * then unsubscribes from the stream.
 */
public class ExampleStreamingMarketData extends BaseExample {

    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        System.out.println("=== Market Data Streaming Example ===");
        System.out.println("This example will:");
        System.out.println("1. Start a streaming connection");
        System.out.println("2. Subscribe to market data for MSFT.OQ");
        System.out.println("3. Wait 50 seconds to receive streaming data");
        System.out.println("4. Unsubscribe from the stream");
        System.out.println("5. Stop the streaming connection");
        System.out.println();

        StreamingClient streamingClient = null;
        RequestHandler requestHandler = null;

        try {
            // Initialize streaming client with proper authentication
            streamingClient = new StreamingClient(lib);
            requestHandler = new RequestHandler(streamingClient, lib.getUserToken());

            System.out.println("Starting streaming connection...");
            streamingClient.startStreamingAsync().join();
            System.out.println("✓ Streaming connection established");

            // Subscribe to market data
            System.out.println("\nSubscribing to MSFT.OQ market data...");
            String[] symbols = {"MSFT.OQ"};
            requestHandler.addSymbolsAsync(symbols, "LEVEL1").join();
            System.out.println("✓ Successfully subscribed to MSFT.OQ");

            // Wait 50 seconds to receive streaming data
            System.out.println("\nWaiting 50 seconds to receive streaming market data...");
            System.out.println("Streaming data will be logged to: " + streamingClient.getLogFilePath());
            Thread.sleep(50000); // 50 seconds
            System.out.println("✓ Completed 50-second streaming period");

            // Unsubscribe from the stream
            System.out.println("\nUnsubscribing from MSFT.OQ...");
            requestHandler.removeSymbolsAsync(symbols, "LEVEL1").join();
            System.out.println("✓ Successfully unsubscribed from MSFT.OQ");

            // Stop streaming connection
            System.out.println("\nStopping streaming connection...");
            streamingClient.stopStreamingAsync().join();
            System.out.println("✓ Streaming connection stopped");

            System.out.println("\n=== Streaming Example Completed Successfully ===");

        } catch (Exception ex) {
            System.out.println("Error in streaming example: " + ex.getMessage());
            ex.printStackTrace();
            throw ex;
        } finally {
            // Cleanup
            if (streamingClient != null) {
                try {
                    streamingClient.dispose();
                    System.out.println("✓ Streaming client disposed");
                } catch (Exception ex) {
                    System.out.println("Warning: Error disposing streaming client: " + ex.getMessage());
                }
            }
        }
    }

    @Override
    public String getExampleName() {
        return "Streaming Market Data Subscription/Unsubscription";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleStreamingMarketData());
    }
}