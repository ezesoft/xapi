package com.ezesoft.xapi;

/**
 * Example demonstrating how to use EMSXAPIConfig to load and access configuration settings.
 * This shows how configuration is loaded from a properties file and accessed.
 */
public class ConfigExample {

    public static void main(String[] args) {
        try {
            System.out.println("=== EMS XAPI Configuration Example ===");

            // Load configuration from default config file
            EMSXAPIConfig config = new EMSXAPIConfig("../config.cfg");

            System.out.println("Configuration loaded successfully!");
            System.out.println("=================================");

            // Display all configuration values
            System.out.println("User: " + config.getUser());
            System.out.println("Server: " + config.getServer());
            System.out.println("Domain: " + config.getDomain());
            System.out.println("Port: " + config.getPort());
            System.out.println("Locale: " + config.getLocale());
            System.out.println("SSL Enabled: " + config.getIsSslEnabled());
            System.out.println("SRP Login Enabled: " + config.getSrpLoginEnabled());
            System.out.println("Certificate File Path: " + config.getCertFilePath());
            System.out.println("Keep Alive Time: " + config.getKeepAliveTime());
            System.out.println("Keep Alive Timeout: " + config.getKeepAliveTimeout());
            System.out.println("Max Retry Count: " + config.getMaxRetryCount());
            System.out.println("Retry Delay (ms): " + config.getRetryDelayMS());
            System.out.println("Max Message Size: " + config.getMaxMessageSize());

            System.out.println("=================================");
            System.out.println("Configuration example completed!");

        } catch (Exception ex) {
            System.out.println("Error loading configuration: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}