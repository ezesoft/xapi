package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetOptionSymbolFromDescription extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example option description - parse into components
        String root = "AAPL";
        String expiration = "20240315"; // YYYYMMDD format
        OptionTypes optionType = OptionTypes.newBuilder().setCallOrPut(OptionTypes.Options.CALL).build();
        double strikePrice = 150.0;

        OptionSymbolFromDescriptionRequest req = OptionSymbolFromDescriptionRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setRoot(root)
                .setExpiration(expiration)
                .setOptionType(optionType)
                .setStrikePrice(strikePrice)
                .build();

        OptionSymbolFromDescriptionResponse response = lib.getMarketDataServiceStub().getOptionSymbolFromDescription(req);

        printResponseHeader("Option Symbol from Description");
        System.out.println("Root: " + root);
        System.out.println("Expiration: " + expiration);
        System.out.println("Type: " + (optionType.getCallOrPut() == OptionTypes.Options.CALL ? "CALL" : "PUT"));
        System.out.println("Strike: $" + strikePrice);
        System.out.println("Symbol: " + response.getSymbol());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Option Symbol From Description";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOptionSymbolFromDescription());
    }
}