package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.ConnectRequest;
import com.ezesoft.xapi.generated.Utilities.ConnectResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleConnect implements ExampleRunner.RunnableExample {
    public void run() {
        try {
            // Note: Connect is typically handled by EMSXAPILibrary initialization
            // This example shows how to use the Connect method directly
            ConnectRequest req = ConnectRequest.newBuilder()
                    .setUserName("testuser")
                    .setDomain("testdomain")
                    .setPassword("testpassword")
                    .setLocale("en_US")
                    .build();

            // In a real scenario, you'd have a utility service stub
            // ConnectResponse response = utilityServiceStub.connect(req);

            System.out.println("------------------------------");
            System.out.println("Connect:");
            System.out.println("Note: Connect is typically handled by EMSXAPILibrary initialization");
            System.out.println("This method establishes a connection and returns a user token");
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Connect";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleConnect());
    }
}