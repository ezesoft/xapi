package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubmitSeedDataRequest;
import com.ezesoft.xapi.generated.Order.SubmitSeedDataResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubmitSeedData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        SubmitSeedDataRequest request = SubmitSeedDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("Symbol")
                .setAccount("BANK;BRANCH;CUSTOMER;DEPOSIT")
                .build();

        SubmitSeedDataResponse response = lib.getOrderServiceStub().submitSeedData(request);

        printResponseHeader("Submit Seed Data");
        System.out.println("Account: BANK;BRANCH;CUSTOMER;DEPOSIT");
        printServerResponse(response.getAcknowledgement());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Submit Seed Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitSeedData());
    }
}
