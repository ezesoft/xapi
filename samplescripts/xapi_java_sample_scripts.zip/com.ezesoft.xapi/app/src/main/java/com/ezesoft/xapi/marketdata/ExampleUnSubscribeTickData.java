package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleUnSubscribeTickData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Symbols to unsubscribe from
        java.util.List<String> symbolsList = java.util.Arrays.asList("VOD.LSE", "BARC.LSE", "AAPL");

        UnSubscribeTickDataRequest req = UnSubscribeTickDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .build();

        UnSubscribeTickDataResponse response = lib.getMarketDataServiceStub().unSubscribeTickData(req);

        printResponseHeader("Unsubscribed from Tick Data");
        System.out.println("Symbols: " + String.join(", ", symbolsList));
        System.out.println("Acknowledgement: " + response.getAcknowledgement());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "UnSubscribe Tick Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleUnSubscribeTickData());
    }
}