package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.GetFirmNameRequest;
import com.ezesoft.xapi.generated.Utilities.GetFirmNameResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetFirmName implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            GetFirmNameRequest request = GetFirmNameRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .build();

            GetFirmNameResponse response = lib.getUtilityServiceStub().getFirmName(request);

            System.out.println("------------------------------");
            System.out.println("Firm Name:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Firm Name: " + response.getFirmName());
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Firm Name";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetFirmName());
    }
}