package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.SymbolReferenceDataRequest;
import com.ezesoft.xapi.generated.MarketData.SymbolReferenceDataResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetSymbolReferenceData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        SymbolReferenceDataRequest request = SymbolReferenceDataRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("VOD.LSE")  // The ticker symbol
                .build();

        SymbolReferenceDataResponse response = lib.getMarketDataServiceStub().getSymbolReferenceData(request);

        printResponseHeader("Symbol Reference Data");
        System.out.println("Symbol: " + request.getSymbol());
        System.out.println("Response: " + response.toString());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Symbol Reference Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetSymbolReferenceData());
    }
}