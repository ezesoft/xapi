package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.OptionChainRequest;
import com.ezesoft.xapi.generated.MarketData.OptionChainResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetOptionChainForUnderlier extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        OptionChainRequest request = OptionChainRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbolRoot("M")  // The underlier symbol, e.g. a stock symbol or future root
                .build();

        OptionChainResponse response = lib.getMarketDataServiceStub().getOptionChainForUnderlier(request);

        printResponseHeader("Option Chain for Underlier");
        System.out.println("Symbol Root: " + request.getSymbolRoot());
        printServerResponse(response.getAcknowledgement());
        System.out.println("Number of Derivatives: " + response.getDerivativeCount());
        for (int i = 0; i < response.getDerivativeCount(); i++) {
            System.out.println("Derivative " + (i+1) + ": " + response.getDerivative(i));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Option Chain For Underlier";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOptionChainForUnderlier());
    }
}