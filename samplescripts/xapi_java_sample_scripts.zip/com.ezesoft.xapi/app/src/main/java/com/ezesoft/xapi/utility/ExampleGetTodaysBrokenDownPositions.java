package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.ExampleRunner.RunnableExample;
import com.ezesoft.xapi.generated.Utilities.TodaysBrokenDownPositionsRequest;
import com.ezesoft.xapi.generated.Utilities.TodaysBrokenDownPositionsResponse;

public class ExampleGetTodaysBrokenDownPositions implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            TodaysBrokenDownPositionsRequest request = TodaysBrokenDownPositionsRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)  // Optional timeout
                    .build();

            TodaysBrokenDownPositionsResponse response = lib.getUtilityServiceStub().getTodaysBrokenDownPositions(request);

            System.out.println("------------------------------");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Today's Broken Down Positions:");

            int numOfRecords = 0;
            for (var positionRecord : response.getPositionRecordsList()) {
                numOfRecords++;
                System.out.println("-------------------------------------------------------");
                System.out.println(" POSITION RECORD - " + numOfRecords);
                System.out.println(positionRecord.toString());
            }
            System.out.println("Total Records: " + numOfRecords);
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Todays Broken Down Positions";
    }

    /**
     * Main method to run this example standalone.
     * Handles authentication and cleanup automatically.
     */
    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetTodaysBrokenDownPositions());
    }
}