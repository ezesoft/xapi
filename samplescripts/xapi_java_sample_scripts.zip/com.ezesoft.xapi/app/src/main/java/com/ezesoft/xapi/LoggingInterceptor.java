package com.ezesoft.xapi;

import io.grpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * gRPC client interceptor for request/response logging and monitoring.
 * Logs all gRPC calls with timing information and errors.
 *
 * Security Note: This interceptor only logs method names, timing, and status codes.
 * Request/response payloads are NOT logged to prevent sensitive data exposure.
 * Configure logging levels appropriately for production environments.
 */
public class LoggingInterceptor implements ClientInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(LoggingInterceptor.class);

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(
            MethodDescriptor<ReqT, RespT> method,
            CallOptions callOptions,
            Channel next) {

        return new ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>(
                next.newCall(method, callOptions)) {

            private long startTime;

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                startTime = System.nanoTime();
                logger.debug("Starting gRPC call: {}", method.getFullMethodName());

                super.start(new ForwardingClientCallListener.SimpleForwardingClientCallListener<RespT>(
                        responseListener) {

                    @Override
                    public void onMessage(RespT message) {
                        long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                        logger.debug("gRPC call completed: {} in {}ms",
                                   method.getFullMethodName(), durationMs);
                        super.onMessage(message);
                    }

                    @Override
                    public void onClose(Status status, Metadata trailers) {
                        long durationMs = (System.nanoTime() - startTime) / 1_000_000;

                        if (status.isOk()) {
                            logger.debug("gRPC call succeeded: {} in {}ms",
                                       method.getFullMethodName(), durationMs);
                        } else {
                            logger.error("gRPC call failed: {} - {} ({}ms)",
                                       method.getFullMethodName(), status, durationMs);
                        }

                        super.onClose(status, trailers);
                    }
                }, headers);
            }
        };
    }
}