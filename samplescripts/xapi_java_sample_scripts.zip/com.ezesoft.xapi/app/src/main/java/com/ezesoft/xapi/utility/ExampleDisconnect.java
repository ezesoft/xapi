package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.DisconnectRequest;
import com.ezesoft.xapi.generated.Utilities.DisconnectResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleDisconnect implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            DisconnectRequest req = DisconnectRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .build();

            DisconnectResponse response = lib.getUtilityServiceStub().disconnect(req);

            System.out.println("------------------------------");
            System.out.println("Disconnect:");
            System.out.println("Server Response: " + response.getServerResponse());
            if (response.getOptionalFieldsMap().size() > 0) {
                System.out.println("Optional Fields:");
                response.getOptionalFieldsMap().forEach((key, value) ->
                    System.out.println("  " + key + ": " + value));
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Disconnect";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleDisconnect());
    }
}