package com.ezesoft.xapi;

import java.math.BigInteger;

/**
 * Educational example demonstrating SRP (Secure Remote Password) authentication protocol.
 * This example shows the mathematical calculations involved in SRP authentication.
 * NOTE: This is for educational purposes only and does not perform real authentication.
 * In production, SRP authentication is handled automatically by EMSXAPILibrary.
 */
public class SRPExample {

    public static void main(String[] args) {
        try {
            System.out.println("=== EMS XAPI SRP Authentication Educational Example ===");
            System.out.println("NOTE: This demonstrates SRP mathematics, not real authentication.");
            System.out.println("Real authentication is handled by EMSXAPILibrary.login()");
            System.out.println();

            // Create SRP authentication instance
            SRPAuthentication srp = new SRPAuthentication();

            // Get public key A (this would be sent to server)
            BigInteger publicKeyA = srp.getPublicKeyA();
            System.out.println("SRP Public Key A: " + publicKeyA.toString(16));

            // In a real scenario, you would:
            // 1. Send publicKeyA to server
            // 2. Receive server's public key B and salt from server
            // 3. Calculate shared secret using username/password

            System.out.println("In production, EMSXAPILibrary handles all SRP calculations automatically.");
            System.out.println("This example shows the protocol mathematics for educational purposes.");
            System.out.println();

            // For educational demonstration, we'll use example values
            // (These are NOT used in real authentication)
            BigInteger exampleSalt = new BigInteger("1234567890ABCDEF", 16);
            BigInteger exampleServerPublicKey = new BigInteger("FEDCBA0987654321", 16);
            String exampleUsername = "demo_user";
            String examplePassword = "demo_password";

            System.out.println("Educational Example Values:");
            System.out.println("Example Salt: " + exampleSalt.toString(16));
            System.out.println("Example Server Public Key B: " + exampleServerPublicKey.toString(16));
            System.out.println("Example Username: " + exampleUsername);
            System.out.println("Example Password: " + examplePassword);
            System.out.println();

            // Calculate shared secret (educational demonstration only)
            srp.calculateSharedSecret(exampleServerPublicKey, exampleSalt, exampleUsername, examplePassword);

            // Get the proof M1 (this would be sent to server to prove we know the password)
            byte[] m1 = srp.getM1();
            System.out.println("SRP Proof M1: " + bytesToHex(m1));

            // Get session key K (used for encrypting subsequent communications)
            byte[] sessionKey = srp.getSessionKey();
            System.out.println("SRP Session Key K: " + bytesToHex(sessionKey));

            System.out.println();
            System.out.println("SRP protocol demonstration completed!");
            System.out.println("Remember: Use EMSXAPILibrary for actual authentication, not this educational example.");

        } catch (Exception ex) {
            System.out.println("Error during SRP demonstration: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }
}