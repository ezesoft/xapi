package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.SymbolFromAlternateSymbologyRequest;
import com.ezesoft.xapi.generated.MarketData.SymbolFromAlternateSymbologyResponse;
import com.ezesoft.xapi.generated.MarketData.AlternateSymbology;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetSymbolFromAlternateSymbology extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        AlternateSymbology symbolInfo = AlternateSymbology.newBuilder()
                .setSymbolOption(AlternateSymbology.Symbology.CUSIP)
                .build();

        SymbolFromAlternateSymbologyRequest request = SymbolFromAlternateSymbologyRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("037833100")  // any valid symbol such as Isin, Sedol, RIC, Cusip or BBG id
                .setSymbolInfo(symbolInfo)
                .build();

        SymbolFromAlternateSymbologyResponse response = lib.getMarketDataServiceStub().getSymbolFromAlternateSymbology(request);

        printResponseHeader("Symbol from Alternate Symbology");
        System.out.println("Input Symbol: " + request.getSymbol());
        System.out.println("Symbol Type: " + request.getSymbolInfo().getSymbolOption());
        printServerResponse(response.getAcknowledgement());
        System.out.println("Result: " + response.toString());
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Symbol From Alternate Symbology";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetSymbolFromAlternateSymbology());
    }
}