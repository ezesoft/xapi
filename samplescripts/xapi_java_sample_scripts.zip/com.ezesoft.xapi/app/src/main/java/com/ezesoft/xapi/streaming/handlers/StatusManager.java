package com.ezesoft.xapi.streaming.handlers;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.concurrent.CompletableFuture;

import com.ezesoft.xapi.streaming.core.StreamingClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handles status checking and statistics display.
 */
public class StatusManager {
    private static final Logger logger = LoggerFactory.getLogger(StatusManager.class);
    private final RequestHandler requestHandler;
    private final StreamingClient streamingClient;

    public StatusManager(RequestHandler requestHandler, StreamingClient streamingClient) {
        this.requestHandler = requestHandler;
        this.streamingClient = streamingClient;
    }

    /**
     * Handles checking and displaying streaming status asynchronously.
     */
    public CompletableFuture<Void> handleCheckStatusAsync() {
        return CompletableFuture.runAsync(this::displayStatus);
    }

    /**
     * Displays message statistics.
     */
    public void showMessageStatistics() {
        synchronized (streamingClient.getConsoleLock()) {
            logger.info("=== Message Statistics ===");

            var counters = streamingClient.getMessageCounters();

            if (counters.isEmpty()) {
                logger.info("No messages received yet.");
            } else {
                counters.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> {
                        logger.info("  {}: {} messages", entry.getKey(), entry.getValue());
                    });

                int totalMessages = counters.values().stream().mapToInt(Integer::intValue).sum();
                logger.info("  TOTAL: {} messages", totalMessages);
            }
        }
    }

    private void displayStatus() {
        logger.info("=== Streaming Status ===");
        logger.info("Streaming active: {}", streamingClient.isStreaming());

        int totalMessages = streamingClient.getMessageCounters().values().stream().mapToInt(Integer::intValue).sum();
        logger.info("Total messages received: {}", totalMessages);

        var subscriptions = streamingClient.getActiveSubscriptions();
        if (!subscriptions.isEmpty()) {
            logger.info("Active Subscriptions:");

            // Group by level from symbol -> levels mapping
            var groupedByLevel = subscriptions.entrySet().stream()
                .flatMap(entry -> entry.getValue().stream().map(level -> Map.entry(level, entry.getKey())))
                .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.mapping(Map.Entry::getValue, Collectors.toList())))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toList());

            for (var group : groupedByLevel) {
                logger.info("  {}: {}", group.getKey(), String.join(", ", group.getValue()));
            }
            logger.info("  Total symbols: {}", subscriptions.size());
        } else {
            logger.info("No active subscriptions.");
        }

        var counters = streamingClient.getMessageCounters();
        if (!counters.isEmpty()) {
            logger.info("Messages by symbol:");
            counters.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEach(entry -> {
                    logger.info("  {}: {} messages", entry.getKey(), entry.getValue());
                });
        } else {
            logger.info("No messages received yet.");
        }
    }
}