package com.ezesoft.xapi.streaming;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.streaming.core.StreamingClient;
import com.ezesoft.xapi.streaming.handlers.RequestHandler;
import com.ezesoft.xapi.streaming.handlers.StatusManager;
import com.ezesoft.xapi.streaming.handlers.SymbolManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Command-line application for bidirectional streaming market data operations.
 * Supports adding/removing symbols, checking status, and changing subscriptions.
 */
public class StreamingClientApp implements ExampleRunner.RunnableExample {
    private static final Logger logger = LoggerFactory.getLogger(StreamingClientApp.class);
    private static final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
        ExampleRunner.runExample(new StreamingClientApp());
    }

    @Override
    public void run() {
        logger.info("=== Bidirectional Streaming Market Data Client ===");
        logger.info("Command-line interface for market data operations");

        StreamingClient streamingClient = null;

        try {
            // Initialize EMSXAPILibrary - CRITICAL: Must call create() before get()
            try {
                EMSXAPILibrary.create("../config.cfg");
            } catch (Exception ex) {
                logger.error("Failed to initialize EMSXAPILibrary: {}", ex.getMessage());
                logger.debug("Stack trace: ", ex);
                return;
            }
            EMSXAPILibrary lib = EMSXAPILibrary.get();

            // Perform login
            lib.login();
            if (!lib.getIsLoggedIn()) {
                logger.error("Login failed. Please check your configuration.");
                return;
            }

            logger.info("Successfully logged in and connected to EMS XAPI server.");

            streamingClient = new StreamingClient(lib, true); // Suppress console output for interactive mode
            runStreamingSession(streamingClient, lib);

            logger.info("=== Streaming client completed successfully ===");
        }
        catch (Exception ex) {
            logger.error("Error in streaming client: {}", ex.getMessage());
            logger.debug("Stack trace: ", ex);
        }
        finally {
            cleanup(streamingClient);
        }
    }

    @Override
    public String getExampleName() {
        return "StreamingClientApp";
    }

    private static void runStreamingSession(StreamingClient streamingClient, EMSXAPILibrary lib) throws Exception {
        RequestHandler requestHandler = new RequestHandler(streamingClient, lib.getUserToken());
        SymbolManager symbolManager = new SymbolManager(requestHandler);
        StatusManager statusManager = new StatusManager(requestHandler, streamingClient);

        logger.info("Streaming data will be logged to: {}", streamingClient.getLogFilePath());

        // Start the streaming connection
        streamingClient.startStreamingAsync().join();

        // Show the command menu
        showCommandMenu(symbolManager, statusManager);

        // Stop streaming and cleanup
        streamingClient.stopStreamingAsync().join();

        // Logout when done
        lib.logout();
    }

    private static void cleanup(StreamingClient streamingClient) {
        if (streamingClient != null) {
            streamingClient.dispose();
        }
        try {
            reader.close();
        } catch (Exception e) {
            // Ignore
        }
    }

    private static void showCommandMenu(SymbolManager symbolManager, StatusManager statusManager) {
        while (true) {
            System.out.println("\n=== Streaming Market Data Client ===");
            System.out.println("Available commands:");
            System.out.println("1. Add symbols to stream");
            System.out.println("2. Remove symbols from stream (by level)");
            System.out.println("3. Change subscription level");
            System.out.println("4. Check streaming status");
            System.out.println("5. Show message statistics");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            try {
                System.out.print("Enter your choice (1-6): ");
                String input = reader.readLine();
                if (input == null) {
                    System.out.println("No interactive input available. Exiting...");
                    return;
                }
                input = input.trim();
                logger.debug("User selected option: {}", input);

                if (input.isEmpty()) {
                    System.out.println("No option selected. Please enter a number 1-6.");
                    continue;
                }

                switch (input) {
                    case "1":
                        symbolManager.handleAddSymbolsAsync().join();
                        break;
                    case "2":
                        symbolManager.handleRemoveSymbolsAsync().join();
                        break;
                    case "3":
                        symbolManager.handleChangeSubscriptionAsync().join();
                        break;
                    case "4":
                        statusManager.handleCheckStatusAsync().join();
                        break;
                    case "5":
                        statusManager.showMessageStatistics();
                        break;
                    case "6":
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please select 1-6.");
                        break;
                }
            }
            catch (Exception ex) {
                logger.error("Error processing command: {}", ex.getMessage());
            }
        }
    }
}