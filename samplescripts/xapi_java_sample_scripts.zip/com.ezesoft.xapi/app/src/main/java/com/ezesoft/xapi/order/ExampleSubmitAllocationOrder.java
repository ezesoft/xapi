package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubmitAllocationOrderRequest;
import com.ezesoft.xapi.generated.Order.SubmitAllocationOrderResponse;
import com.ezesoft.xapi.generated.Order.AllocationType;
import com.ezesoft.xapi.generated.Order.OrderType;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.DoubleValue;

public class ExampleSubmitAllocationOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example allocation parameters - replace with actual values
        String orderId = "12345678";
        String symbol = "AAPL";
        String exchange = "NASDAQ";
        String sourceAccount = "BANK;BRANCH;CUSTOMER;DEPOSIT";
        String targetAccount = "TARGET_ACCOUNT";
        int targetQuantity = 100;
        double targetPrice = 150.50;

        SubmitAllocationOrderRequest request = SubmitAllocationOrderRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setOrderId(orderId)
                .setSymbol(symbol)
                .setExchange(exchange)
                .setSourceAccount(sourceAccount)
                .setTargetAccount(targetAccount)
                .setTargetQuantity(targetQuantity)
                .setTargetPrice(DoubleValue.newBuilder().setValue(targetPrice).build())
                .setTypeOfAllocation(AllocationType.newBuilder()
                        .setAllocationOrAllocationEx(AllocationType.Allocation.UserSubmitAllocation)
                        .build())
                .setOrderTypes(OrderType.newBuilder()
                        .setTypeOfOrder(OrderType.Type.UserSubmitOrder)
                        .build())
                .build();

        SubmitAllocationOrderResponse response = lib.getOrderServiceStub().submitAllocationOrder(request);

        printResponseHeader("Submit Allocation Order Response");
        System.out.println("Server Response: " + response.getServerResponse());
        if (response.getOptionalFieldsMap().containsKey("ErrorMessage")) {
            System.out.println("Error Message: " + response.getOptionalFieldsMap().get("ErrorMessage"));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Submit Allocation Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitAllocationOrder());
    }
}