package com.ezesoft.xapi.streaming.utils;

import com.ezesoft.xapi.generated.Utilities.Price;
import com.google.protobuf.Duration;
import com.google.protobuf.Timestamp;
import com.google.protobuf.Int32Value;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for formatting market data display.
 */
public class DataFormatter {

    private static final ThreadLocal<DateTimeFormatter> TIMESTAMP_FORMATTER =
        ThreadLocal.withInitial(() -> DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));

    /**
     * Formats a timestamp for display.
     */
    public static String formatTimestamp(LocalDateTime timestamp) {
        return timestamp.format(DateTimeFormatter.ofPattern("HH:mm:ss.SSS"));
    }

    /**
     * Creates a formatted log message with timestamp.
     */
    public static String formatLogMessage(String message, LocalDateTime timestamp) {
        String time = formatTimestamp(timestamp);
        return "[" + time + "] " + message;
    }

    /**
     * Creates a formatted log message with current timestamp.
     */
    public static String formatLogMessage(String message) {
        return formatLogMessage(message, LocalDateTime.now());
    }

    /**
     * Formats a Price message to a readable string.
     */
    public static String formatPrice(Price price) {
        if (price == null) {
            return "N/A";
        }

        // Use decimal value if available, otherwise calculate from numerator/denominator
        if (price.getDecimalValue() != 0.0) {
            return String.format("%.4f", price.getDecimalValue());
        }

        int numerator = price.getNumerator();
        int denominator = price.getDenominator();

        if (denominator == 0) {
            return String.valueOf(numerator);
        }

        double decimal = (double) numerator / denominator;
        return String.format("%.4f", decimal);
    }

    /**
     * Formats a Timestamp to a readable string.
     */
    public static String formatTimestamp(Timestamp timestamp) {
        if (timestamp == null) {
            return "N/A";
        }

        try {
            Instant instant = Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos());
            LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
            return dateTime.format(TIMESTAMP_FORMATTER.get());
        } catch (Exception e) {
            return timestamp.toString();
        }
    }

    /**
     * Formats a Duration to a readable string.
     */
    public static String formatDuration(Duration duration) {
        if (duration == null) {
            return "N/A";
        }

        try {
            long totalSeconds = duration.getSeconds();
            int nanos = duration.getNanos();

            long hours = totalSeconds / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            long seconds = totalSeconds % 60;

            return String.format("%02d:%02d:%02d.%03d",
                hours, minutes, seconds, nanos / 1000000);
        } catch (Exception e) {
            return duration.toString();
        }
    }

    /**
     * Formats an Int32Value (nullable integer) to a readable string.
     */
    public static String formatInt32Value(Int32Value value) {
        if (value == null) {
            return "N/A";
        }
        return String.valueOf(value.getValue());
    }

    /**
     * Formats a list of prices for display.
     */
    public static String formatPriceList(java.util.List<Price> prices) {
        if (prices == null || prices.isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < prices.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(formatPrice(prices.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Formats a list of integers for display.
     */
    public static String formatIntList(java.util.List<Integer> values) {
        if (values == null || values.isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(values.get(i));
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Formats a list of timestamps for display.
     */
    public static String formatTimestampList(java.util.List<Timestamp> timestamps) {
        if (timestamps == null || timestamps.isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < timestamps.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(formatTimestamp(timestamps.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Formats a list of strings for display.
     */
    public static String formatStringList(java.util.List<String> values) {
        if (values == null || values.isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append("\"").append(values.get(i)).append("\"");
        }
        sb.append("]");
        return sb.toString();
    }
}