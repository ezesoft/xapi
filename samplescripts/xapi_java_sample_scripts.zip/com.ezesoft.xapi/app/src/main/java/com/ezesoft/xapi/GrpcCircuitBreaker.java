package com.ezesoft.xapi;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.function.Supplier;

/**
 * Circuit breaker implementation for gRPC client resilience.
 * Prevents cascading failures by temporarily stopping calls to failing services.
 */
public class GrpcCircuitBreaker {
    private static final Logger logger = LoggerFactory.getLogger(GrpcCircuitBreaker.class);

    private final CircuitBreaker circuitBreaker;

    public GrpcCircuitBreaker(String serviceName) {
        this(serviceName, 50.0f);
    }

    public GrpcCircuitBreaker(String serviceName, float failureRateThreshold) {
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .failureRateThreshold(failureRateThreshold) // Configurable failure rate threshold
                .waitDurationInOpenState(Duration.ofSeconds(30)) // Wait 30s before trying again
                .permittedNumberOfCallsInHalfOpenState(3) // Allow 3 test calls in half-open
                .slidingWindowSize(10) // Consider last 10 calls for failure rate
                .minimumNumberOfCalls(5) // Need at least 5 calls before calculating failure rate
                .build();

        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(config);
        this.circuitBreaker = registry.circuitBreaker(serviceName);

        // Add event listeners for monitoring
        circuitBreaker.getEventPublisher()
                .onSuccess(event -> logger.debug("Circuit breaker success: {}", event))
                .onError(event -> logger.warn("Circuit breaker error: {}", event))
                .onStateTransition(event -> logger.info("Circuit breaker state changed: {}", event));
    }

    /**
     * Executes a supplier function with circuit breaker protection.
     *
     * @param supplier The function to execute
     * @param <T> The return type
     * @return The result of the supplier
     * @throws Exception if the circuit is open or the supplier fails
     */
    public <T> T execute(Supplier<T> supplier) throws Exception {
        try {
            return circuitBreaker.executeSupplier(supplier);
        } catch (io.github.resilience4j.circuitbreaker.CallNotPermittedException e) {
            logger.error("Circuit breaker is OPEN - call not permitted");
            throw new ServerNotAvailableException("Service temporarily unavailable due to circuit breaker");
        }
    }

    /**
     * Gets the current state of the circuit breaker.
     */
    public CircuitBreaker.State getState() {
        return circuitBreaker.getState();
    }

    /**
     * Gets circuit breaker metrics.
     */
    public String getMetrics() {
        return String.format("State: %s, Failure Rate: %.2f%%, Calls: %d",
                circuitBreaker.getState(),
                circuitBreaker.getMetrics().getFailureRate(),
                circuitBreaker.getMetrics().getNumberOfBufferedCalls());
    }
}