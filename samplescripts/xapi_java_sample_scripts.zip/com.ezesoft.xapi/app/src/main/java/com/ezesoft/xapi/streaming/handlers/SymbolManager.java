package com.ezesoft.xapi.streaming.handlers;

import java.util.Scanner;
import java.util.concurrent.CompletableFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handles user input for symbol management operations.
 */
public class SymbolManager {
    private static final Logger logger = LoggerFactory.getLogger(SymbolManager.class);
    private final RequestHandler requestHandler;
    private final Scanner scanner;

    public SymbolManager(RequestHandler requestHandler) {
        this.requestHandler = requestHandler;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Handles adding symbols to the stream.
     */
    public CompletableFuture<Void> handleAddSymbolsAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                SymbolInput input = getSymbolInput("add");
                if (input.symbols.length == 0) return;

                requestHandler.addSymbolsAsync(input.symbols, input.level).join();
                logger.info("Added {} for {} data.", String.join(", ", input.symbols), input.level);
            } catch (Exception ex) {
                logger.error("Error adding symbols: {}", ex.getMessage(), ex);
            }
        });
    }

    /**
     * Handles removing symbols from the stream.
     */
    public CompletableFuture<Void> handleRemoveSymbolsAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                SymbolInput input = getSymbolInput("remove");
                if (input.symbols.length == 0) return;

                requestHandler.removeSymbolsAsync(input.symbols, input.level).join();
                logger.info("Removed {} from {} data stream.", String.join(", ", input.symbols), input.level);
            } catch (Exception ex) {
                logger.error("Error removing symbols: {}", ex.getMessage(), ex);
            }
        });
    }

    /**
     * Handles changing subscription levels for symbols.
     */
    public CompletableFuture<Void> handleChangeSubscriptionAsync() {
        return CompletableFuture.runAsync(() -> {
            try {
                String[] symbols = getSymbolsInput("change");
                if (symbols.length == 0) return;

                String level = getLevelInput();
                if (level == null || level.isEmpty()) return;

                requestHandler.changeSubscriptionAsync(symbols, level).join();
                logger.info("Changed {} to {} data.", String.join(", ", symbols), level);
            } catch (Exception ex) {
                logger.error("Error changing subscription: {}", ex.getMessage(), ex);
            }
        });
    }

    private SymbolInput getSymbolInput(String operation) {
        logger.debug("Prompting user to enter symbols to {}", operation);
        String symbolsInput = scanner.nextLine().trim();

        if (symbolsInput.isEmpty()) {
            logger.warn("No symbols entered for {} operation.", operation);
            return new SymbolInput(new String[0], "");
        }

        // Validate input for security - only allow alphanumeric, comma, space, and common symbols
        if (!symbolsInput.matches("[a-zA-Z0-9,\\s]+")) {
            logger.warn("Invalid characters in input for {} operation. Only alphanumeric characters, commas, and spaces are allowed.", operation);
            return new SymbolInput(new String[0], "");
        }

        String[] symbols = parseSymbols(symbolsInput);
        if (symbols.length == 0) {
            logger.warn("No valid symbols entered for {} operation.", operation);
            return new SymbolInput(new String[0], "");
        }

        String level = getLevelInput(operation);
        return new SymbolInput(symbols, level);
    }

    private String[] getSymbolsInput(String operation) {
        logger.debug("Prompting user to enter symbols to {}", operation);
        String symbolsInput = scanner.nextLine().trim();

        if (symbolsInput.isEmpty()) {
            logger.warn("No symbols entered for {} operation.", operation);
            return new String[0];
        }

        // Validate input for security - only allow alphanumeric, comma, space, and common symbols
        if (!symbolsInput.matches("[a-zA-Z0-9,\\s]+")) {
            logger.warn("Invalid characters in input for {} operation. Only alphanumeric characters, commas, and spaces are allowed.", operation);
            return new String[0];
        }

        String[] symbols = parseSymbols(symbolsInput);
        if (symbols.length == 0) {
            logger.warn("No valid symbols entered for {} operation.", operation);
        }

        return symbols;
    }

    private String getLevelInput(String operation) {
        logger.debug("Prompting user to enter market data level");
        String levelInput = scanner.nextLine().trim().toUpperCase();
        String level = levelInput.isEmpty() ? "LEVEL1" : levelInput;

        // Validate level
        if (!level.equals("LEVEL1") && !level.equals("LEVEL2") && !level.equals("TICK")) {
            logger.warn("Invalid level '{}' provided. Using LEVEL1.", levelInput);
            level = "LEVEL1";
        }

        return level;
    }

    private String getLevelInput() {
        return getLevelInput("");
    }

    private String[] parseSymbols(String input) {
        return input.split("\\s*,\\s*");
    }

    private static class SymbolInput {
        public final String[] symbols;
        public final String level;

        public SymbolInput(String[] symbols, String level) {
            this.symbols = symbols;
            this.level = level;
        }
    }
}