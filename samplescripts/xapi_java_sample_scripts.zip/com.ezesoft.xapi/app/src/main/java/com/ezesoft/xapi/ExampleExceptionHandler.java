package com.ezesoft.xapi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for consistent exception handling across examples.
 */
public class ExampleExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ExampleExceptionHandler.class);

    /**
     * Handle exceptions consistently across all examples.
     * Logs the error and returns a user-friendly message.
     */
    public static void handleException(String operation, Exception ex) {
        logger.error("Error during {}: {}", operation, ex.getMessage(), ex);
        System.err.println("Error during " + operation + ": " + ex.getMessage());
    }

    /**
     * Handle exceptions in background threads consistently.
     */
    public static void handleBackgroundException(String operation, Exception ex) {
        logger.error("Background task error during {}: {}", operation, ex.getMessage(), ex);
        System.err.println("Background task error during " + operation + ": " + ex.getMessage());
    }

    /**
     * Log successful operations.
     */
    public static void logSuccess(String operation, String details) {
        logger.info("Successfully completed {}: {}", operation, details);
    }

    /**
     * Log operation start.
     */
    public static void logStart(String operation) {
        logger.info("Starting {}", operation);
    }
}