package com.ezesoft.xapi.streaming.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Simple file logger for streaming market data responses.
 * Writes log entries to a timestamped log file.
 */
public class StreamingLogger implements AutoCloseable {
    private final PrintWriter writer;
    private final String logFilePath;
    private final Object lock = new Object();
    private boolean disposed = false;

    public StreamingLogger(String logDirectory) {
        // Create logs directory if it doesn't exist
        try {
            Path logDir = Paths.get(logDirectory);
            Files.createDirectories(logDir);

            // Create log file with timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            this.logFilePath = Paths.get(logDirectory, "streaming_" + timestamp + ".log").toString();

            // Open the log file for writing
            this.writer = new PrintWriter(new FileWriter(logFilePath, true));

            // Write header
            logMessage("=== Streaming Market Data Log Started ===");
            logMessage("Log file: " + logFilePath);
            logMessage("Started at: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            logMessage("");

        } catch (IOException ex) {
            throw new RuntimeException("Failed to initialize logger: " + ex.getMessage(), ex);
        }
    }

    public StreamingLogger() {
        this("logs");
    }

    /**
     * Gets the path to the log file.
     */
    public String getLogFilePath() {
        return logFilePath;
    }

    /**
     * Logs a message to the file with timestamp.
     */
    public void logMessage(String message) {
        if (disposed) return;

        synchronized (lock) {
            try {
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
                writer.println("[" + timestamp + "] " + message);
                writer.flush(); // Ensure immediate writing to file
            } catch (Exception ex) {
                throw new RuntimeException("Failed to write to log file: " + ex.getMessage(), ex);
            }
        }
    }

    /**
     * Logs an error message.
     */
    public void logError(String message) {
        logMessage("ERROR | " + message);
    }

    /**
     * Logs an info message.
     */
    public void logInfo(String message) {
        logMessage("INFO | " + message);
    }

    /**
     * Logs market data in a structured format.
     */
    public void logMarketData(String symbol, String dataType, String data) {
        logMessage("MARKET_DATA | " + symbol + " | " + dataType + " | " + data);
    }

    /**
     * Logs status updates.
     */
    public void logStatus(String status) {
        logMessage("STATUS | " + status);
    }

    /**
     * Logs warnings.
     */
    public void logWarning(String warning) {
        logMessage("WARNING | " + warning);
    }

    /**
     * Logs success messages.
     */
    public void logSuccess(String message) {
        logMessage("SUCCESS | " + message);
    }

    @Override
    public void close() {
        if (disposed) return;

        synchronized (lock) {
            try {
                logMessage("=== Streaming Market Data Log Ended ===");
                logMessage("Ended at: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                writer.close();
            } catch (Exception ex) {
                System.err.println("Error closing log file: " + ex.getMessage());
            } finally {
                disposed = true;
            }
        }
    }
}