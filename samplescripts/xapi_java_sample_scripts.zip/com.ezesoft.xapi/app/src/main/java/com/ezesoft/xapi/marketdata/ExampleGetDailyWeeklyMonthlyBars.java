package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.DailyWeeklyMonthlyBarsRequest;
import com.ezesoft.xapi.generated.MarketData.DailyWeeklyMonthlyBarsResponse;
import com.ezesoft.xapi.generated.MarketData.Interval;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetDailyWeeklyMonthlyBars extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) {
        DailyWeeklyMonthlyBarsRequest request = DailyWeeklyMonthlyBarsRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setSymbol("VOD.LSE")  // The ticker symbol
                .setInterim(Interval.newBuilder()
                        .setBarIntervalOption(Interval.Options.DAILY)  // 0: Daily, 1: Weekly, 2: Monthly
                        .build())
                .build();

        DailyWeeklyMonthlyBarsResponse response = lib.getMarketDataServiceStub().getDailyWeeklyMonthlyBars(request);

        printResponseHeader("Daily Weekly Monthly Bars");
        printServerResponse(response.getAcknowledgement());
        System.out.println("Display Name: " + response.getDispName());
        System.out.println("Bar Data:");
        System.out.println("  Accumulated Volume 1: " + response.getBarFields().getAcVol1(0));
        System.out.println("  High 1: " + response.getBarFields().getHigh1(0));
        System.out.println("  Low 1: " + response.getBarFields().getLow1(0));
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Daily Weekly Monthly Bars";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetDailyWeeklyMonthlyBars());
    }
}