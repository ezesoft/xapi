package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.OrderDetailByDateRangeRequest;
import com.ezesoft.xapi.generated.Order.OrderDetailByDateRangeResponse;
import com.ezesoft.xapi.ExampleRunner;
import com.google.protobuf.Timestamp;
import java.time.Instant;
import java.util.Iterator;

public class ExampleGetOrderDetailByDateRange extends BaseExample {
    // Optional BBCD account filter - requires all 4
    // components:"BANK;BRANCH;CUSTOMER;DEPOSIT"
    // Or Leave empty for no account filtering
    private String account = "";

    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Create timestamps for date range (last 24 hours)
        Instant now = Instant.now();
        Instant yesterday = now.minusSeconds(24 * 60 * 60);

        Timestamp startDate = Timestamp.newBuilder()
                .setSeconds(yesterday.getEpochSecond())
                .setNanos(yesterday.getNano())
                .build();

        Timestamp endDate = Timestamp.newBuilder()
                .setSeconds(now.getEpochSecond())
                .setNanos(now.getNano())
                .build();

        OrderDetailByDateRangeRequest request = OrderDetailByDateRangeRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setStartDate(startDate)
                .setEndDate(endDate)
                .build();

        // Optional BBCD account filter
        if (account != null && !account.isEmpty())
            requestBuilder.setAccount(account);

        // This returns a streaming response
        Iterator<OrderDetailByDateRangeResponse> responses = lib.getOrderServiceStub().getOrderDetailByDateRange(request);
        while (responses.hasNext()) {
            OrderDetailByDateRangeResponse response = responses.next();
            printResponseHeader("Order Details by Date Range");
            printServerResponse(response.getAcknowledgement());
            if ("Failed".equals(response.getAcknowledgement().getServerResponse())) {
                System.out.println("Error Message: " + response.getAcknowledgement().getMessage());
            } else {
                System.out.println("Response received successfully");
            }
            printResponseFooter();
        }
    }

    @Override
    public String getExampleName() {
        return "Get Order Detail By Date Range";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetOrderDetailByDateRange());
    }
}