package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.TodaysBalancesRequest;
import com.ezesoft.xapi.generated.Utilities.TodaysBalancesResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetTodaysBalances implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            TodaysBalancesRequest request = TodaysBalancesRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)  // Optional timeout
                    .build();

            TodaysBalancesResponse response = lib.getUtilityServiceStub().getTodaysBalances(request);

            System.out.println("------------------------------");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Today's Balances:");

            int i = 0;
            for (var depositRecord : response.getDepositListList()) {
                System.out.println("--------------- Deposit Num: " + i + " START ---------------");
                System.out.println(depositRecord.toString());
                System.out.println("--------------- Deposit Num: " + i + " END ---------------");
                i++;
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Todays Balances";
    }

    /**
     * Main method to run this example standalone.
     * Handles authentication and cleanup automatically.
     */
    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetTodaysBalances());
    }
}