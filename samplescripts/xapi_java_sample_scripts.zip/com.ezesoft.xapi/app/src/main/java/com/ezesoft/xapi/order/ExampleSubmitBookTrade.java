package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.SubmitBookTradeRequest;
import com.ezesoft.xapi.generated.Order.SubmitBookTradeResponse;
import com.ezesoft.xapi.generated.Order.AllocationDetails;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleSubmitBookTrade extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Create allocation details
        AllocationDetails allocDetail = AllocationDetails.newBuilder()
                .setTargetAccount("BANK;BRANCH;CUSTOMER;DEPOSIT")
                .setTargetQuantity(50)
                .setTargetPrice(com.google.protobuf.DoubleValue.newBuilder().setValue(100.0).build())
                .setNetPrice(com.google.protobuf.DoubleValue.newBuilder().setValue(99.5).build())
                .build();

        SubmitBookTradeRequest req = SubmitBookTradeRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setOrderId("ORDER123")
                .setSourceAccount("SOURCE_ACCOUNT")
                .setOrderTag("BOOK_TRADE_TAG")
                .addAllocDetails(allocDetail)
                .build();

        SubmitBookTradeResponse response = lib.getOrderServiceStub().submitBookTrade(req);

        printResponseHeader("Submit Book Trade Response");
        System.out.println("Server Response: " + response.getServerResponse());
        if (response.getOptionalFieldsMap().size() > 0) {
            System.out.println("Optional Fields:");
            response.getOptionalFieldsMap().forEach((key, value) ->
                System.out.println("  " + key + ": " + value));
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Submit Book Trade";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleSubmitBookTrade());
    }
}