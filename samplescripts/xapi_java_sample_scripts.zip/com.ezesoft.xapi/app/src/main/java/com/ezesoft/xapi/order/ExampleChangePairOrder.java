package com.ezesoft.xapi.order;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.ChangePairOrderRequest;
import com.ezesoft.xapi.generated.Order.ChangePairOrderResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleChangePairOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Example order ID to change - replace with actual order ID
        String orderId = "12345678";

        ChangePairOrderRequest request = ChangePairOrderRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .setPairOrderId(orderId)
                .build();

        ChangePairOrderResponse response = lib.getOrderServiceStub().changePairOrder(request);

        printResponseHeader("Change Pair Order Response");
        printServerResponse(response.getAcknowledgement());
        System.out.println("Response received successfully");
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Change Pair Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleChangePairOrder());
    }
}