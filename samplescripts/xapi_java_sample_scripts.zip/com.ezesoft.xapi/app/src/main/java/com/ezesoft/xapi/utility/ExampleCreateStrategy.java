package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.CreateStrategyRequest;
import com.ezesoft.xapi.generated.Utilities.CreateStrategyResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleCreateStrategy implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            CreateStrategyRequest req = CreateStrategyRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setFirmName("TestFirm")
                    .setAlgoName("TestAlgo")
                    .setStrategyName("TestStrategy")
                    .setStratParams("param1=value1,param2=value2")
                    .build();

            CreateStrategyResponse response = lib.getUtilityServiceStub().createStrategy(req);

            System.out.println("------------------------------");
            System.out.println("Create Strategy:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            if (response.getAcknowledgement().getMessage() != null) {
                System.out.println("Message: " + response.getAcknowledgement().getMessage());
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Create Strategy";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleCreateStrategy());
    }
}