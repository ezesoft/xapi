package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.*;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleAddSymbols extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        // Symbols to add to existing subscriptions
        java.util.List<String> symbolsList = java.util.Arrays.asList("MSFT", "GOOGL", "TSLA");

        AddSymbolsRequest req = AddSymbolsRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addAllSymbols(symbolsList)
                .build();

        AddSymbolsResponse response = lib.getMarketDataServiceStub().addSymbols(req);

        printResponseHeader("Added Symbols to Subscriptions");
        System.out.println("Symbols: " + String.join(", ", symbolsList));
        System.out.println("Server Response: " + response.getServerResponse());
        if (!response.getOptionalFieldsMap().isEmpty()) {
            System.out.println("Optional Fields: " + response.getOptionalFieldsMap());
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Add Symbols";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleAddSymbols());
    }
}