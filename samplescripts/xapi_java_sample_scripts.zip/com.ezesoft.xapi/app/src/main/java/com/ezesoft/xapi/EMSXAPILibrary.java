package com.ezesoft.xapi;

import io.grpc.ClientInterceptor;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslContext;
import io.grpc.stub.StreamObserver;

import com.ezesoft.xapi.generated.MarketDataServiceGrpc;
import com.ezesoft.xapi.generated.SubmitOrderServiceGrpc;
import com.ezesoft.xapi.generated.UtilityServicesGrpc;
import com.ezesoft.xapi.generated.MarketDataServiceGrpc.MarketDataServiceBlockingStub;
import com.ezesoft.xapi.generated.MarketDataServiceGrpc.MarketDataServiceStub;
import com.ezesoft.xapi.generated.SubmitOrderServiceGrpc.SubmitOrderServiceBlockingStub;
import com.ezesoft.xapi.generated.SubmitOrderServiceGrpc.SubmitOrderServiceStub;
import com.ezesoft.xapi.generated.Utilities.*;
import com.ezesoft.xapi.generated.Utilities.SubscribeHeartBeatResponse.HeartBeatStatus;
import com.ezesoft.xapi.generated.UtilityServicesGrpc.UtilityServicesBlockingStub;
import com.ezesoft.xapi.generated.UtilityServicesGrpc.UtilityServicesStub;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLException;

public class EMSXAPILibrary {
    private EMSXAPILibrary(String configFileName) throws InterruptedException, NetworkFailedException, ServerNotAvailableException {
        this.config = new EMSXAPIConfig(configFileName);

        // Initialize interceptors and circuit breaker
        this.authInterceptor = new AuthInterceptor(this);
        this.loggingInterceptor = new LoggingInterceptor();
        this.circuitBreaker = new GrpcCircuitBreaker("ems-xapi-client");

        // Initialize channel
        this.openChannel();
    }

    private static final Object INSTANCE_LOCK = new Object();
    private static volatile EMSXAPILibrary instance;

    /**
     * Creates and returns a singleton instance of EMSXAPILibrary.
     * Thread-safe implementation using double-checked locking.
     *
     * @param configFileName The configuration file name (optional, defaults to "config.cfg")
     * @return The singleton EMSXAPILibrary instance
     * @throws InterruptedException if initialization is interrupted
     * @throws NetworkFailedException if network connection fails
     * @throws ServerNotAvailableException if server is not available
     */
    public static EMSXAPILibrary create(String configFileName)
            throws InterruptedException, NetworkFailedException, ServerNotAvailableException {
        if (configFileName == null || configFileName.trim().isEmpty()) {
            configFileName = "../config.cfg";
        }

        if (instance == null) {
            synchronized (INSTANCE_LOCK) {
                if (instance == null) {
                    instance = new EMSXAPILibrary(configFileName);
                }
            }
        }
        return instance;
    }

    /**
     * Gets the singleton instance of EMSXAPILibrary.
     * Must be called after create() has been called.
     *
     * @return The singleton EMSXAPILibrary instance
     * @throws IllegalStateException if create() has not been called first
     */
    public static EMSXAPILibrary get() {
        if (instance == null) {
            throw new IllegalStateException("EMSXAPILibrary must be created first by calling create(configFileName)");
        }
        return instance;
    }

    /**
     * Legacy method for backward compatibility.
     * @deprecated Use create() instead
     */
    @Deprecated
    public static void Create(String configFileName)
            throws InterruptedException, NetworkFailedException, ServerNotAvailableException {
        create(configFileName);
    }

    /**
     * Legacy method for backward compatibility.
     * @deprecated Use get() instead
     */
    @Deprecated
    public static EMSXAPILibrary Get() {
        return get();
    }


    public ErrorHandler errorHandler;
    private ManagedChannel _channel;

    // Blocking stubs (synchronous)
    private UtilityServicesBlockingStub _utilitySvcStub;
    private MarketDataServiceBlockingStub _mktDataSvcStub;
    private SubmitOrderServiceBlockingStub _orderServiceStub;

    // Async stubs (non-blocking)
    private UtilityServicesStub _utilitySvcAsyncStub;
    private MarketDataServiceStub _mktDataSvcAsyncStub;
    private SubmitOrderServiceStub _orderServiceAsyncStub;

    // Interceptors and resilience
    private final AuthInterceptor authInterceptor;
    private final LoggingInterceptor loggingInterceptor;
    private final GrpcCircuitBreaker circuitBreaker;

    private EMSXAPIConfig config;
    private volatile String userToken;
    private Thread heartBeatThread;   


    private boolean isLoggedIn;
    private boolean heartbeatExitSignal;

    private Object loggedInLock = new Object();
    private Object tokenLock = new Object();

    public boolean getIsLoggedIn() {
        synchronized (this.loggedInLock) {
            return this.isLoggedIn;
        }
    }

    public void setIsLoggedIn(boolean value) {
        synchronized (this.loggedInLock) {
            this.isLoggedIn = value;
        }
    }

    public String getUserToken() {
        synchronized (this.tokenLock) {
            return this.userToken;
        }
    }

    public void setUserToken(String val) {
        synchronized (this.tokenLock) {
            this.userToken = val;
        }
    }

    public UtilityServicesBlockingStub getUtilityServiceStub() {
        return this._utilitySvcStub;
    }

    public MarketDataServiceBlockingStub getMarketDataServiceStub() {
        return this._mktDataSvcStub;
    }

    public SubmitOrderServiceBlockingStub getOrderServiceStub() {
        return this._orderServiceStub;
    }

    public UtilityServicesStub getUtilityServiceAsyncStub() {
        return this._utilitySvcAsyncStub;
    }

    public MarketDataServiceStub getMarketDataServiceAsyncStub() {
        return this._mktDataSvcAsyncStub;
    }

    public GrpcCircuitBreaker getCircuitBreaker() {
        return this.circuitBreaker;
    }

    /**
     * Asynchronous version of connect operation.
     * Returns a CompletableFuture that completes when connection is established.
     */
    public CompletableFuture<ConnectResponse> connectAsync() {
        CompletableFuture<ConnectResponse> future = new CompletableFuture<>();

        try {
            ConnectRequest connectRequest = ConnectRequest.newBuilder()
                    .setUserName(config.getUser())
                    .setDomain(config.getDomain())
                    .setPassword(config.getPassword())
                    .setLocale(config.getLocale())
                    .build();

            getUtilityServiceAsyncStub().connect(connectRequest, new StreamObserver<ConnectResponse>() {
                @Override
                public void onNext(ConnectResponse response) {
                    userToken = response.getUserToken();
                    setIsLoggedIn(true);
                    future.complete(response);
                }

                @Override
                public void onError(Throwable throwable) {
                    future.completeExceptionally(throwable);
                }

                @Override
                public void onCompleted() {
                    // Single response, nothing additional to do
                }
            });
        } catch (Exception ex) {
            future.completeExceptionally(ex);
        }

        return future;
    }

    /**
     * Executes an operation with circuit breaker protection.
     *
     * @param operation The operation to execute
     * @param <T> The return type
     * @return The result of the operation
     * @throws Exception if the operation fails or circuit breaker is open
     */
    public <T> T executeWithCircuitBreaker(java.util.function.Supplier<T> operation) throws Exception {
        return circuitBreaker.execute(operation);
    }

    private ManagedChannel createChannel(String hostName, int port) {

        NettyChannelBuilder builder = NettyChannelBuilder.forAddress(hostName, port);

        if (config.getKeepAliveTime() > 0) {
            builder.keepAliveTime(config.getKeepAliveTime(), TimeUnit.MILLISECONDS)
                    .keepAliveTimeout(config.getKeepAliveTimeout(), TimeUnit.MILLISECONDS)
                    .keepAliveWithoutCalls(true);
        }
        if (config.getMaxMessageSize() > 0) {
            builder.maxInboundMessageSize(config.getMaxMessageSize());
        }
        if (config.getIsSslEnabled()) {
            try {
                File certFile = config.getResolvedCertFile();
                if (certFile != null) {
                    if (!certFile.exists()) {
                        throw new RuntimeException("Certificate file " + certFile.getAbsolutePath() + " does not exist");
                    }
                    SslContext sslContext = GrpcSslContexts.forClient()
                            .trustManager(certFile)
                            .build();
                    builder.sslContext(sslContext);
                }
            } catch (SSLException e) {
                throw new RuntimeException("Couldn't set up SSL context", e);
            }
        } else {
            builder.usePlaintext();
        }
        return builder.build();
    }

    public ManagedChannel getChannel() throws NetworkFailedException, ServerNotAvailableException {
        if (_channel == null || _channel.isShutdown()) {
            this.openChannel();
        }

        return this._channel;
    }

    private void initStubs() {
        // Create blocking stubs with interceptors
        _utilitySvcStub = UtilityServicesGrpc.newBlockingStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);
        _mktDataSvcStub = MarketDataServiceGrpc.newBlockingStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);
        _orderServiceStub = SubmitOrderServiceGrpc.newBlockingStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);

        // Create async stubs with interceptors
        _utilitySvcAsyncStub = UtilityServicesGrpc.newStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);
        _mktDataSvcAsyncStub = MarketDataServiceGrpc.newStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);
        _orderServiceAsyncStub = SubmitOrderServiceGrpc.newStub(this._channel)
                .withInterceptors(authInterceptor, loggingInterceptor);
    }



    public void login() throws LoginFailedException {
        try {
            setIsLoggedIn(false);
            
            if (config.getSrpLoginEnabled()) {
                // Use SRP authentication
                performSrpLogin();
            } else {
                // Use regular connect authentication
                performConnectLogin();
            }
            
            this.setIsLoggedIn(true);
            System.out.println("Login successful. Token received.");
        } catch (Exception ex) {
            throw new LoginFailedException(ex.getMessage(), ex);
        }
    }

    /**
     * Login method with uppercase L to match C# API and streaming client expectations.
     */
    public void Login() throws LoginFailedException {
        login();
    }

    /**
     * Perform regular connect-based authentication
     */
    private void performConnectLogin() throws LoginFailedException {
        ConnectRequest connectRequest = ConnectRequest.newBuilder()
                .setUserName(config.getUser())
                .setDomain(config.getDomain())
                .setPassword(config.getPassword())
                .setLocale(config.getLocale())
                .build();

        ConnectResponse connectResponse = this.getUtilityServiceStub().connect(connectRequest);

        String serverResponse = connectResponse.getResponse();
        String newToken = connectResponse.getUserToken();

        // Check if server returned an error
        if (connectResponse.hasAcknowledgement() &&
            connectResponse.getAcknowledgement().getServerResponse().equals("Failed")) {
            String errorMsg = "Server login failed: " + serverResponse;
            System.out.println(errorMsg);
            System.out.println("Server acknowledgement: " + connectResponse.getAcknowledgement().getMessage());
            throw new LoginFailedException(errorMsg);
        }

        if (newToken == null || newToken.trim().isEmpty()) {
            throw new LoginFailedException("Server returned empty or null token. Response: " + serverResponse);
        }

        this.setUserToken(newToken);
    }

    /**
     * Perform SRP-based authentication
     */
    private void performSrpLogin() throws LoginFailedException {
        try {
            // Step 1: Start SRP login
            StartLoginSrpRequest startRequest = StartLoginSrpRequest.newBuilder()
                    .setUserName(config.getUser())
                    .setDomain(config.getDomain())
                    .build();

            StartLoginSrpResponse startResponse = this.getUtilityServiceStub().startLoginSrp(startRequest);

            if (!"success".equals(startResponse.getResponse())) {
                throw new LoginFailedException("SRP start login failed: " + startResponse.getResponse());
            }

            // Step 2: Perform SRP calculations
            SRPAuthentication srp = new SRPAuthentication();
            String identity = config.getUser().toUpperCase() + "@" + config.getDomain().toUpperCase();
            
            byte[] clientProof = srp.calculateClientProof(
                startResponse.getSrpSalt().getBytes(),
                startResponse.getSrpg(),
                startResponse.getSrpN(),
                startResponse.getSrpb(),
                identity,
                config.getPassword()
            );

            // Step 3: Complete SRP login
            CompleteLoginSrpRequest completeRequest = CompleteLoginSrpRequest.newBuilder()
                    .setSrpTransactId(startResponse.getSrpTransactId())
                    .setStrMc(bytesToHex(clientProof))
                    .setLocale(config.getLocale())
                    .build();

            CompleteLoginSrpResponse completeResponse = this.getUtilityServiceStub().completeLoginSrp(completeRequest);

            if (!"success".equals(completeResponse.getResponse())) {
                throw new LoginFailedException("SRP complete login failed: " + completeResponse.getResponse());
            }

            String newToken = completeResponse.getUserToken();
            if (newToken == null || newToken.trim().isEmpty()) {
                throw new LoginFailedException("Server returned empty or null token during SRP login");
            }

            this.setUserToken(newToken);
            this.setIsLoggedIn(true);
            this.setIsLoggedIn(true);
            
        } catch (Exception ex) {
            throw new LoginFailedException("SRP authentication failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Utility method to convert byte array to hex string
     */
    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    public void logout() {
        try {
            if (userToken == null) {
                System.out.println("Already logged out");
                return;
            }
            DisconnectRequest disConnReq = DisconnectRequest.newBuilder()
                    .setUserToken(userToken)
                    .build();

            DisconnectResponse disconnectResponse = getUtilityServiceStub().disconnect(disConnReq);

            if (disconnectResponse.getServerResponse().equals("success")) {
                System.out.println("Logged out");
                this.userToken = null;
                this.setIsLoggedIn(false);
            } else {
                String errorMessage = disconnectResponse.getOptionalFieldsMap().get("ErrorMessage");
                System.out.println(errorMessage);
            }
        } catch (Exception e) {
          e.printStackTrace();
        }
    }

    public void closeChannel() {

        if (this._channel != null && !this._channel.isShutdown())
            try {
                this._channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        this._channel = null;
        // Clear stubs when channel is closed
        this._utilitySvcStub = null;
        this._mktDataSvcStub = null;
        this._orderServiceStub = null;
        this._utilitySvcAsyncStub = null;
        this._mktDataSvcAsyncStub = null;
        this._orderServiceAsyncStub = null;
    }

    public void openChannel() throws NetworkFailedException, ServerNotAvailableException {
        if(!this.canConnectToInternet()){
            throw new NetworkFailedException(
                "Network not available");
        }
        if (this.canConnectToServer()) {
            this.closeChannel();
            this._channel = createChannel(config.getServer(), config.getPort());
            this.initStubs();
            return;
        }
        throw new ServerNotAvailableException(
                "Server "+config.getServer()+" not responding, might be down.");
    }

    private void sleep(long delayMS) {
        try {
            Thread.sleep(delayMS);
        } catch (Exception e) {

        }
    }

    public void startListeningHeartbeat(int reqTimeout) throws Exception {
        if (!this.getIsLoggedIn()) {
            throw new Exception("User needs to login first");
        }

        suspendHeartbeatThread();

        heartbeatExitSignal = false;
        heartBeatThread = new Thread(() -> {
            try {
                heartbeatExitSignal = false;
                boolean refreshChannel = false;
                boolean refreshLogin = false;

                int retryCount = 0;

                while (this.getIsLoggedIn() && retryCount < config.getMaxRetryCount()) {
                    try {
                        if(heartbeatExitSignal)
                            break;

                        retryCount++;

                        if (refreshChannel) {
                            this.closeChannel();
                            this.openChannel();
                        }
                        if (refreshLogin) {
                            this.setIsLoggedIn(false);
                            this.login();
                        }
                        refreshChannel = false;
                        refreshLogin = false;

                        this.execSubscribeHeartBeat(reqTimeout);
                    } catch (RuntimeException runEx) {
                        // need to initialize the channel again but same token can be re-used
                        long delayMS = calculateDelayMillis(retryCount);
                        if (runEx instanceof RuntimeException)
                            writeToLog(
                                    "Runtime IO error: attempting again(" + retryCount + ") in " + delayMS + " ms...");
                        refreshChannel = true;
                        refreshLogin = false;
                        sleep(delayMS);

                    } catch (SessionNotFoundException ssnEx) {
                        // need to login again
                        refreshLogin = true;
                        refreshChannel = false;
                        long delayMS = calculateDelayMillis(retryCount);
                        writeToLog("Session not found: attempting login again(" + retryCount + ") in " + delayMS
                                + " ms...");
                        sleep(delayMS);

                    } catch (StreamingAlreadyExistsException strEx) {
                        // need to login again
                        refreshLogin = false;
                        refreshChannel = false;
                        long delayMS = calculateDelayMillis(retryCount);
                        writeToLog(strEx.getMessage());
                        sleep(delayMS);

                    } catch (ServerNotAvailableException srvrEx) {
                        // need to login again
                        refreshChannel = true;
                        refreshLogin = true;
                        long delayMS = calculateDelayMillis(retryCount);
                        writeToLog(srvrEx.getMessage());
                        sleep(delayMS);
                    }
                    catch (Exception ex) {
                        writeToLog(ex.toString());
                        break;
                    }
                }
            } catch (Exception ex) {
                if (this.errorHandler != null)
                    this.errorHandler.onError(ex);
            }
        });

        heartBeatThread.start();
    }

    private void writeToLog(String msg) {
        System.out.println(msg);
    }

    public void execSubscribeHeartBeat(int reqTimeout)
            throws SessionNotFoundException, RuntimeException, StreamingAlreadyExistsException {

        SubscribeHeartBeatRequest subscribeRequest = SubscribeHeartBeatRequest.newBuilder()
                .setUserToken(getUserToken())
                .setTimeoutInSeconds(reqTimeout)
                .build();

        Iterator<SubscribeHeartBeatResponse> hbResponseIt = this.getUtilityServiceStub().subscribeHeartBeat(subscribeRequest);

        while (hbResponseIt != null && hbResponseIt.hasNext()) {

            if(heartbeatExitSignal)
                break;

            SubscribeHeartBeatResponse response = hbResponseIt.next();
            HeartBeatStatus resStatus = response.getStatus();
            String serverMsg = response.getAcknowledgement().getServerResponse();

            // writeToLog("HeartBeat response status: " + resStatus.toString());
            writeToLog("[" + getCurrentTime() + "]" + " HeartBeat status: " + resStatus.toString() + " | " + serverMsg);

            if (resStatus == HeartBeatStatus.DEAD) {
                hbResponseIt = null;
                throw new SessionNotFoundException("Session not found for user token " + this.getUserToken());
            } else if (resStatus == HeartBeatStatus.UNKNOWN || resStatus == HeartBeatStatus.UNRECOGNIZED) {
                hbResponseIt = null;
                throw new RuntimeException("Status received as " + resStatus + "");
            } else if (serverMsg.equalsIgnoreCase("Error: Active streaming subscription already exists.")) {
                hbResponseIt = null;
                throw new StreamingAlreadyExistsException("Heartbeat subscription already exists");
            }
        }
    }

    private String getCurrentTime() {
        LocalDateTime now = LocalDateTime.now();

        // Define the desired date and time format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // Format the date and time using the formatter
        return now.format(formatter);
    }

    private long calculateDelayMillis(int retryCount) {
        return (long) Math.pow(2, retryCount) * config.getRetryDelayMS();
    }

    public void suspendHeartbeatThread() {
        if (heartBeatThread != null) {
            if (heartBeatThread.isAlive()){
                heartBeatThread.interrupt();
                heartbeatExitSignal = true;
            }

            while (heartBeatThread.isAlive()) {
                writeToLog("Waiting for heartbreat thread to stop");
                sleep(config.getRetryDelayMS());
            }
            heartBeatThread = null;
        }
    }

    private boolean canConnectToInternet() {
        try {
            InetAddress address = InetAddress.getByName("www.google.com");
            return address.isReachable(3000); // Timeout of 5 seconds
        } catch (UnknownHostException e) {
            return false; // Unable to resolve host
        } catch (Exception e) {
            return false; // Other exceptions
        }
    }

    private boolean canConnectToServer() {
        Socket socket = new Socket();
        int timeoutMs = 3000; // Set timeout to 3 seconds

        try {
            InetSocketAddress address = new InetSocketAddress(config.getServer(), config.getPort());
            socket.connect(address, timeoutMs);
            socket.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
