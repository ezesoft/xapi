package com.ezesoft.xapi;

public class ChannelClosedException extends Exception {
     public ChannelClosedException() {
        super("Channel might be closed or unresponsive");
    }

    public ChannelClosedException(String message) {
        super(message);
    }
}
