package com.ezesoft.xapi;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class EMSXAPIConfig {

   
    private int keepAliveTime;
    private int keepAliveTimeout;
    private String user;
    private String password;
    private String server;
    private String domain;
    private int port;
    private String locale;
    private String certFilePath;
    private Boolean ssl;
    private int maxRetryCount;
    private int retryDelayMS;
    private Boolean srpLogin;
    private File configDir;

    public EMSXAPIConfig(String cfgFileName) {
        if (cfgFileName == null || cfgFileName.isEmpty()) {
            cfgFileName = "../config.cfg";
        }

        // Search for config file in multiple locations
        File configFile = findConfigFile(cfgFileName);
        if (configFile == null) {
            throw new RuntimeException("Configuration file not found: " + cfgFileName);
        }

        // Store the config file directory for resolving relative paths
        configDir = configFile.getParentFile();

        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load configuration file: " + configFile.getAbsolutePath(), e);
        }

        // read config items
        user = properties.getProperty("user");
        password = properties.getProperty("password");
        server = properties.getProperty("server");
        domain = properties.getProperty("domain");
        port = Integer.parseInt(properties.getProperty("port").trim());
        locale = properties.getProperty("locale");
        certFilePath = properties.getProperty("certFilePath");
        keepAliveTime = Integer.parseInt(properties.getProperty("keepAliveTime").trim());
        keepAliveTimeout = Integer.parseInt(properties.getProperty("keepAliveTimeout").trim());
        ssl = Boolean.parseBoolean(properties.getProperty("ssl"));
        maxRetryCount = Integer.parseInt(properties.getProperty("maxRetryCount").trim());
        retryDelayMS = Integer.parseInt(properties.getProperty("retryDelayMS").trim());
        srpLogin = Boolean.parseBoolean(properties.getProperty("srpLogin", "false"));
    }
 
    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getServer() {
        return server;
    }

    public String getDomain() {
        return domain;
    }

    public int getPort() {
        return port;
    }

    public String getLocale() {
        return locale;
    }

    public String getCertFilePath() {
        return certFilePath;
    }

    /**
     * Get the resolved certificate file path relative to the config file directory
     */
    public File getResolvedCertFile() {
        if (certFilePath == null || certFilePath.trim().isEmpty()) {
            return null;
        }

        // If it's an absolute path, use it as-is
        File certFile = new File(certFilePath);
        if (certFile.isAbsolute()) {
            return certFile;
        }

        // Otherwise, resolve relative to config directory
        if (configDir != null) {
            return new File(configDir, certFilePath);
        }

        // Fallback to current directory
        return certFile;
    }
    
    /**
     * Find configuration file by searching in multiple locations:
     * 1. Current working directory
     * 2. Parent directory
     * 3. Project root (../../ from app/src/main/java)
     */
    private File findConfigFile(String fileName) {
        // Try current directory
        File configFile = new File(fileName);
        if (configFile.exists()) {
            System.out.println("Found config file: " + configFile.getAbsolutePath());
            return configFile;
        }
        
        // Try parent directory
        configFile = new File("../" + fileName);
        if (configFile.exists()) {
            System.out.println("Found config file: " + configFile.getAbsolutePath());
            return configFile;
        }
        
        // Try project root (for gradle builds from app directory)
        configFile = new File("../../" + fileName);
        if (configFile.exists()) {
            System.out.println("Found config file: " + configFile.getAbsolutePath());
            return configFile;
        }
        
        System.err.println("Config file not found in:");
        System.err.println("  - " + new File(fileName).getAbsolutePath());
        System.err.println("  - " + new File("../" + fileName).getAbsolutePath());
        System.err.println("  - " + new File("../../" + fileName).getAbsolutePath());
        return null;
    }
    
    public int getMaxMessageSize(){
        return  1024 * 1024 * 1024;
    }

    public int getKeepAliveTimeout(){
        return keepAliveTimeout;
    }
    
    public int getKeepAliveTime(){
        return keepAliveTime;
    }

    public boolean getIsSslEnabled(){
        return ssl;
    }

    public int getMaxRetryCount(){
        return maxRetryCount;
    }

    public int getRetryDelayMS(){
        return retryDelayMS;
    }

    public boolean getSrpLoginEnabled(){
        return srpLogin != null ? srpLogin : false;
    }

}