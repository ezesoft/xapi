package com.ezesoft.xapi.order;
import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Order.CancelSingleOrderRequest;
import com.ezesoft.xapi.generated.Order.CancelSingleOrderResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleCancelSingleOrder extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        try {

            // Note: In a real scenario, you would get the OrderId from a submitted order
            // For this example, we'll use a placeholder OrderId
            String orderId = "ORDER_ID_PLACEHOLDER";  // Replace with actual order ID

            CancelSingleOrderRequest request = CancelSingleOrderRequest.newBuilder()
                    .setOrderId(orderId)  // The order ID to cancel
                    .setUserToken(lib.getUserToken())
                    .build();

            CancelSingleOrderResponse response = lib.getOrderServiceStub().cancelSingleOrder(request);

            System.out.println("------------------------------");
            System.out.println("Server Response: " + response.getServerResponse());
            if ("Failed".equals(response.getServerResponse())) {
                System.out.println("Error Message: " + response.getOptionalFieldsMap().get("ErrorMessage"));
            } else {
                System.out.println("Order cancelled successfully");
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Cancel Single Order";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleCancelSingleOrder());
    }
}