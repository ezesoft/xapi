package com.ezesoft.xapi.streaming.utils;

/**
 * Constants for market data streaming operations.
 */
public class MarketDataConstants {

    // Request Types
    public static final String REQUEST_TYPE_ADD_SYMBOL = "ADD_SYMBOL";
    public static final String REQUEST_TYPE_REMOVE_SYMBOL = "REMOVE_SYMBOL";
    public static final String REQUEST_TYPE_CHANGE_SUBSCRIPTION = "CHANGE_SUBSCRIPTION";

    // Market Data Levels
    public static final String MARKET_DATA_LEVEL1 = "LEVEL1";
    public static final String MARKET_DATA_LEVEL2 = "LEVEL2";
    public static final String MARKET_DATA_TICK = "TICK";

    // Response Types
    public static final String RESPONSE_TYPE_LEVEL1_DATA = "LEVEL1_DATA";
    public static final String RESPONSE_TYPE_LEVEL2_DATA = "LEVEL2_DATA";
    public static final String RESPONSE_TYPE_TICK_DATA = "TICK_DATA";
    public static final String RESPONSE_TYPE_STATUS_UPDATE = "STATUS_UPDATE";

    // Tick Types (matching protobuf enum)
    public static final int TICK_TYPE_TRADE = 0;
    public static final int TICK_TYPE_BID = 1;
    public static final int TICK_TYPE_ASK = 2;
    public static final int TICK_TYPE_REGIONAL_BID = 3;
    public static final int TICK_TYPE_REGIONAL_ASK = 4;
    public static final int TICK_TYPE_DELETED = 11;
    public static final int TICK_TYPE_INSERTED = 12;
    public static final int TICK_TYPE_IRREGULAR_DELETE = 44;
    public static final int TICK_TYPE_FORM_T_TRADE = 32;

    /**
     * Gets the string representation of a tick type.
     */
    public static String getTickTypeName(int tickType) {
        switch (tickType) {
            case TICK_TYPE_TRADE: return "TRADE";
            case TICK_TYPE_BID: return "BID";
            case TICK_TYPE_ASK: return "ASK";
            case TICK_TYPE_REGIONAL_BID: return "REGIONAL_BID";
            case TICK_TYPE_REGIONAL_ASK: return "REGIONAL_ASK";
            case TICK_TYPE_DELETED: return "DELETED";
            case TICK_TYPE_INSERTED: return "INSERTED";
            case TICK_TYPE_IRREGULAR_DELETE: return "IRREGULAR_DELETE";
            case TICK_TYPE_FORM_T_TRADE: return "FORM_T_TRADE";
            default: return "UNKNOWN(" + tickType + ")";
        }
    }

    /**
     * Validates if a market data level is supported.
     */
    public static boolean isValidMarketDataLevel(String level) {
        return MARKET_DATA_LEVEL1.equals(level) ||
               MARKET_DATA_LEVEL2.equals(level) ||
               MARKET_DATA_TICK.equals(level);
    }

    /**
     * Validates if a request type is supported.
     */
    public static boolean isValidRequestType(String requestType) {
        return REQUEST_TYPE_ADD_SYMBOL.equals(requestType) ||
               REQUEST_TYPE_REMOVE_SYMBOL.equals(requestType) ||
               REQUEST_TYPE_CHANGE_SUBSCRIPTION.equals(requestType);
    }
}