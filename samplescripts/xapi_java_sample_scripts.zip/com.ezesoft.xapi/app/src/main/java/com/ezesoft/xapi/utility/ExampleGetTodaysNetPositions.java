package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.ExampleRunner;
import com.ezesoft.xapi.ExampleRunner.RunnableExample;
import com.ezesoft.xapi.generated.Utilities.TodaysNetPositionsRequest;
import com.ezesoft.xapi.generated.Utilities.TodaysNetPositionsResponse;

public class ExampleGetTodaysNetPositions implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            TodaysNetPositionsRequest request = TodaysNetPositionsRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)
                    .build();

            TodaysNetPositionsResponse response = lib.getUtilityServiceStub().getTodaysNetPositions(request);

            System.out.println("------------------------------");
            System.out.println("Today's Net Positions:");
            System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
            System.out.println("Number of Aggregate Positions: " + response.getAggregatePositionsListCount());
            for (int i = 0; i < response.getAggregatePositionsListCount(); i++) {
                System.out.println("Position " + (i+1) + ": " + response.getAggregatePositionsList(i));
            }
            System.out.println("------------------------------");
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Get Todays Net Positions";
    }

    /**
     * Main method to run this example standalone.
     * Handles authentication and cleanup automatically.
     */
    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetTodaysNetPositions());
    }
}