package com.ezesoft.xapi;

import com.ezesoft.xapi.generated.Utilities.*;

public class ExampleGetTodaysActivity {
    public void run() {
        EMSXAPILibrary lib = null;
        try{
            EMSXAPILibrary.Create("config.cfg");
            lib = EMSXAPILibrary.Get();
            lib.login();

            TodaysActivityRequest req = TodaysActivityRequest.newBuilder().setUserToken(lib.getUserToken()).build();
            TodaysActivityResponse response =  lib.getUtilityServiceStub().getTodaysActivity(req);

             System.out.println("Server Response: "+ response.getAcknowledgement().getServerResponse());             
             System.out.println("Count of Order Response: "+ response.getOrderRecordListList().size());
             int index = 0;
             for (OrderResponse orderRecord : response.getOrderRecordListList()) {
                System.out.println("--------------- Order Num:" +index+" START ---------------");
                System.out.println(orderRecord.toString());
                System.out.println("--------------- Order Num:" +index+" END ---------------");
             }
            
        }
        catch(Exception ex){
            System.out.println("Error - "+ ex.getMessage());
        }
    }
}
