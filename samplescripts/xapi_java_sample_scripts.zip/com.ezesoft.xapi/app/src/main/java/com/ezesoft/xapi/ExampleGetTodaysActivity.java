package com.ezesoft.xapi;

import com.ezesoft.xapi.generated.Utilities.*;

public class ExampleGetTodaysActivity extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) throws Exception {
        TodaysActivityRequest req = TodaysActivityRequest.newBuilder()
            .setUserToken(lib.getUserToken())
            .build();

        TodaysActivityResponse response = lib.getUtilityServiceStub().getTodaysActivity(req);

        printResponseHeader("Today's Activity");
        System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
        System.out.println("Count of Order Response: " + response.getOrderRecordListList().size());

        int index = 0;
        for (OrderResponse orderRecord : response.getOrderRecordListList()) {
            System.out.println("--------------- Order Num:" + index + " START ---------------");
            System.out.println(orderRecord.toString());
            System.out.println("--------------- Order Num:" + index + " END ---------------");
            index++;
        }
        printResponseFooter();
    }

    @Override
    public String getExampleName() {
        return "Get Today's Activity";
    }
}
