package com.ezesoft.xapi.marketdata;

import com.ezesoft.xapi.BaseExample;
import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.MarketData.Level1MarketDataRecordRequest;
import com.ezesoft.xapi.generated.MarketData.Level1MarketDataRecordResponse;
import com.ezesoft.xapi.ExampleRunner;

public class ExampleGetLevel1MarketData extends BaseExample {
    @Override
    protected void doRun(EMSXAPILibrary lib) {
        Level1MarketDataRecordRequest request = Level1MarketDataRecordRequest.newBuilder()
                .setUserToken(lib.getUserToken())
                .addSymbols("VOD.LSE")  // List of ticker symbols
                .addSymbols("BARC.LSE")
                .addSymbols("GSK.LSE")
                .build();

        Level1MarketDataRecordResponse response = lib.getMarketDataServiceStub().getLevel1MarketData(request);

        System.out.println("------------------------------");
        System.out.println("Level1 Market Data:");
        System.out.println("Server Response: " + response.getAcknowledgement().getServerResponse());
        System.out.println("Number of Records: " + response.getDataRecordCount());
        for (int i = 0; i < response.getDataRecordCount(); i++) {
            System.out.println("Symbol " + (i+1) + ": " + response.getDataRecord(i).getDispName());
            System.out.println("  Last Price: " + response.getDataRecord(i).getTrdprc1());
            System.out.println("  Bid: " + response.getDataRecord(i).getBid());
            System.out.println("  Ask: " + response.getDataRecord(i).getAsk());
        }
        System.out.println("------------------------------");
    }

    @Override
    public String getExampleName() {
        return "Get Level 1 Market Data";
    }

    public static void main(String[] args) {
        ExampleRunner.runExample(new ExampleGetLevel1MarketData());
    }
}