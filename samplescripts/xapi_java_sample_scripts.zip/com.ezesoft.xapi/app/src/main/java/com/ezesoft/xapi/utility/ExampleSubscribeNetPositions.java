package com.ezesoft.xapi.utility;

import com.ezesoft.xapi.EMSXAPILibrary;
import com.ezesoft.xapi.generated.Utilities.SubscribeNetPositionsRequest;
import com.ezesoft.xapi.generated.Utilities.SubscribeNetPositionsResponse;
import com.ezesoft.xapi.ExampleRunner;
import java.util.Iterator;

public class ExampleSubscribeNetPositions implements ExampleRunner.RunnableExample {
    public void run() {
        EMSXAPILibrary lib = null;
        try {
            lib = EMSXAPILibrary.Get();

            SubscribeNetPositionsRequest request = SubscribeNetPositionsRequest.newBuilder()
                    .setUserToken(lib.getUserToken())
                    .setTimeoutInSeconds(30)
                    .build();

            // This returns a streaming response
            // Note: The subscribeNetPositions method may not be available in all service versions
            System.out.println("------------------------------");
            System.out.println("Subscribe Net Positions - Note: Method availability depends on service version");
            System.out.println("------------------------------");
            // Uncomment below if subscribeNetPositions is available
            // Iterator<SubscribeNetPositionsResponse> responses = lib.getUtilityServiceStub().subscribeNetPositions(request);
            // while (responses.hasNext()) { ... }
        }
        catch(Exception ex) {
            System.out.println("Error - " + ex.getMessage());
        }
    }

    @Override
    public String getExampleName() {
        return "Subscribe Net Positions";
    }

    public static void main(String[] args) {
        ExampleRunner.runStreamingExample(new ExampleSubscribeNetPositions());
    }
}